# SAYROX 19.11.13

## هدف این نسخه

انتقال میزبان اصلی برنامه از الگوی Cloudflare Pages به یک **Cloudflare Worker مستقل با نام `sayrox`**. رابط وب به‌صورت Static Assets از همان Worker ارائه می‌شود و مسیرهای `/api/*` در Worker اجرا می‌شوند. نام و مقصد Worker در `wrangler.jsonc` تعریف شده است. `keep_vars` نیز متغیرهای غیرحساس انتخاب‌شده در Dashboard (مثل شناسهٔ مدل) را هنگام Deployهای بعدی حفظ می‌کند؛ مقادیر حساس فقط Secret هستند.

Origin Worker پس از ساخت در اکانت جدید (نمونهٔ placeholder؛ مقدار واقعی را از Overview بردار):

```text
https://REPLACE-WITH-NEW-SAYROX-ORIGIN.workers.dev
```

## ساختار پروژه

```text
app/               سورس منطق مرورگر؛ خروجی آن site/src/app.js است
worker/            سورس API و Main Agent؛ خروجی آن site/_worker.js است
site/              فایل‌های عمومی Static Assets؛ فقط این پوشه به‌عنوان asset منتشر می‌شود
auth-worker/       Worker مستقل حساب‌ها، نشست‌ها، حافظه و محدودیت ورود
billing-worker/    Worker مستقل دفتر پرداخت و اشتراک
usage-worker/      Worker مستقل سهمیه و تاریخچه Agent
tasks-worker/      Worker مستقل زمان‌بندی SAYROX
sandbox-worker/    Worker ایزوله اجرای Python با Cloudflare Containers
voice-sdk/         ورودی ساخت SDK مکالمه زنده
scripts/           Build و بررسی پیکربندی/انتشار
tests/             تست‌های منطق، امنیت و زیرساخت
docs/              قرارداد معماری، استقرار، امنیت و قابلیت‌ها
wrangler.jsonc     تنظیمات Worker اصلی با نام sayrox
```

قواعد سورس: `site/src/app.js` و `site/_worker.js` خروجی Build هستند و دستی ویرایش نمی‌شوند. سورس‌های مرجع در `app/` و `worker/` هستند. فایل `site/.assetsignore` مانع انتشار `_worker.js` و `_headers` به‌عنوان فایل عمومی می‌شود؛ Worker هدرهای امنیتی را خودش اعمال می‌کند.

## آماده‌سازی و بررسی محلی

نیازمندی‌ها: Node.js نسخه 22 یا بالاتر و npm.

```bash
npm install
npm test
npm run build
npm run verify
```

`npm run build` رابط، Worker و SDK صوت را می‌سازد. قبل از Deploy، تست‌ها و بررسی همگام‌بودن خروجی‌ها باید موفق باشند.

## ترتیب استقرار در اکانت تازه

برای استقرار از گوشی، از بستهٔ پنج‌فایلی `SAYROX-GITHUB-DEPLOY-KIT` استفاده کن. راهنمای همان بسته (`README-ANDROID-SETUP.md`) تنظیمات دقیق Cloudflare Workers Builds را توضیح می‌دهد.

در Build settings متغیر `SAYROX_APP_ORIGIN` را با Origin دقیق Worker جدید `sayrox` تنظیم کن؛ نمونهٔ شکل آن `https://sayrox.SUBDOMAIN.workers.dev` است. مقدار واقعی را از Overview کپی کن؛ مقدار نمونه را عیناً وارد نکن.

Deploy Kit پس از نصب وابستگی‌ها، اجرای تست‌ها و Build، به‌ترتیب Workerهای `sayrox-auth-storage`، `sayrox-billing-storage`، `sayrox-usage-storage` و `sayrox-tasks-storage` را می‌سازد و در پایان Worker اصلی `sayrox` را منتشر می‌کند. اگر هر تست یا اعتبارسنجی Origin شکست بخورد، Deploy متوقف می‌شود.

## Secretها و متغیرهای اصلی

Secret واقعی را هیچ‌وقت در ZIP، Git، فایل‌های مرورگر یا پیام چت قرار نده. آن‌ها را در تنظیمات همان Worker در Cloudflare ثبت کن.

| Worker | نام | نوع / کاربرد |
|---|---|---|
| `sayrox` | `GAPGPT_API_KEY` | Secret ضروری برای گفتگو با Provider اصلی |
| `sayrox` | `GAPGPT_DEFAULT_MODEL` | Variable؛ شناسه دقیق مدل فعال در GapGPT |
| `sayrox` | `AUTH_SESSION_SECRET` | Secret تصادفی حداقل ۳۲ نویسه برای امضای نشست |
| `sayrox` | `TAVILY_API_KEY` | Secret اختیاری برای جست‌وجوی وب |
| `sayrox` | `ELEVENLABS_API_KEY` | Secret اختیاری برای صوت و مکالمه زنده |
| `sayrox` | `ELEVENLABS_SPEECH_ENGINE_ID` | Variable با شناسهٔ `seng_...`؛ پس از ساخت Speech Engine |
| `sayrox` | `OPENROUTER_API_KEY` | Secret اختیاری فقط برای قابلیت تولید تصویر فعلی |
| `sayrox` | `OPENROUTER_IMAGE_MODEL` | Variable شناسه مدل تصویر؛ تا انتخاب مدل معتبر، تصویر خاموش است |
| `sayrox` | `TASKS_INTERNAL_SECRET` | Secret تصادفی حداقل ۳۲ نویسه؛ با Tasks Worker یکسان |
| `sayrox` | `CODE_SANDBOX_INTERNAL_SECRET` | Secret اختیاری مرحله Sandbox؛ با `SAYROX_INTERNAL_SECRET` یکسان |
| `sayrox-tasks-storage` | `TASKS_INTERNAL_SECRET` | Secret مشترک و یکسان با Worker اصلی |
| `sayrox-code-sandbox-preview` | `SAYROX_INTERNAL_SECRET` | Secret مشترک مرحله Sandbox؛ با `CODE_SANDBOX_INTERNAL_SECRET` یکسان |

`AI_PROVIDER=gapgpt` و `GAPGPT_BASE_URL` در تنظیمات Worker مشخص شده‌اند. شناسه مدل GapGPT باید با مقدار واقعی موجود در حساب خودت تعیین شود؛ تا آن زمان `GAPGPT_DEFAULT_MODEL` خالی است و چت ابری آماده نیست. پرداخت واقعی عمداً خاموش است؛ `PAYMENTS_ENABLED` و `SUBSCRIPTION_ACTIVATION_READY` تا تکمیل آزمون زرین‌پال `false` باقی می‌مانند.

تولید تصویر در کد نسخه 19.11.13 همچنان به تنظیمات تصویری OpenRouter وابسته است و به‌طور خودکار از GapGPT استفاده نمی‌کند. تا وقتی Provider تصویری تأییدشده و Secret/مدل لازم تنظیم نشده، این قابلیت خاموش می‌ماند.

## معماری ذخیره‌سازی و قانون D1

- Worker اصلی `sayrox` به Namespaceهای جدید `AUTH_ACCOUNTS`، `AUTH_RATE_LIMITER`، `BILLING_ACCOUNT` و `USAGE_ACCOUNT` متصل می‌شود. مالک این Namespaceها Workerهای مستقل `sayrox-auth-storage`، `sayrox-billing-storage` و `sayrox-usage-storage` هستند.
- زمان‌بندی در Namespace مستقل `TASKS_ACCOUNT` متعلق به `sayrox-tasks-storage` نگهداری می‌شود.
- این Namespaceها از SQLite داخلی Durable Objects استفاده می‌کنند؛ این فناوری **Cloudflare D1 نیست**.
- در هیچ‌یک از Wrangler configها `d1_databases`، Binding دیتابیس D1 یا migration مربوط به D1 وجود ندارد.
- Worker Sandbox نیز بعد از آماده‌شدن، از Durable Object اختصاصی همان سرویس و Container محدود استفاده می‌کند؛ هیچ فایل، Secret یا Binding برنامه به کد اجراشده داده نمی‌شود.

## وضعیت محدودیت‌های تحویل

- ZIP حاوی سورس کامل و خروجی Build است؛ SDK صوت (`site/vendor/elevenlabs-client.mjs`) خروجی Build محسوب می‌شود و با `npm run build:voice-sdk` ساخته می‌شود؛ SDK صوت در مرحلهٔ Build توسط `esbuild` تولید می‌شود و باید در خروجی Build بررسی شود.
- در محیط ساخت این ZIP، اتصال زنده به GapGPT، Tavily، ElevenLabs، زرین‌پال و اجرای Cloudflare Container تأیید نشده است. تست‌های محلی از Mock استفاده می‌کنند.
- `sayrox` در اکانت جدید با Hello World ساخته شده است؛ Deploy Kit آن را با نسخهٔ پروژه جایگزین می‌کند و سپس باید با Secretهای واقعی در آزمون کنترل‌شده تأیید شود.
- دامنه سفارشی هنوز به Worker وصل نشده است؛ فعلاً Origin آزمایشی `workers.dev` استفاده می‌شود.
