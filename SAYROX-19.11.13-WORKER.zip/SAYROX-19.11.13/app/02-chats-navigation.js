// Chat model, views/tabs, safe message-content renderer
// Part of the SAYROX app closure: parts are concatenated in file order by scripts/build-app.mjs.
// Do not edit site/src/app.js directly.
function newChat(){
  toggleHeaderMenu?.(false);
  toggleToolMenu?.(false);
  const chat={id:crypto.randomUUID?.()||String(Date.now()),title:'گفتگوی جدید',messages:[],updated:Date.now()};
  state.chats.unshift(chat);
  state.active=chat.id;
  state.work=false;
  updateTabs();
  renderMessages();
  renderRecent();
  hideDrawer();
  $('#promptInput').focus();
  persist()
}
function activeChat(){return state.chats.find(c=>c.id===state.active)}
function saveChat(chatId=state.active){
  const c=state.chats.find(x=>x.id===chatId);
  if(c){
    c.updated=Date.now();
    state.chats.sort((a,b)=>b.updated-a.updated);
    persist();
    renderRecent()
  }
}
function setView(view){
  state.view=view;
  $('#settingsView').classList.toggle('active',view==='settings');
  $('#moduleView').classList.toggle('active',view==='module');
  $('#settingsDetail').classList.remove('active');
  $('#chatScroll').classList.toggle('hidden',view!=='chat');
  $('#composerWrap').classList.toggle('hidden',view!=='chat');
  $('#topbar').classList.toggle('hidden',view!=='chat');
  if(view==='settings'){renderSettings();hideDrawer()}
  if(view==='module')hideDrawer()
}
function updateTabs(){
  $('#chatTab').classList.toggle('active',!state.work);
  $('#workTab').classList.toggle('active',state.work);
  $('#chatTab').setAttribute('aria-selected',String(!state.work));
  $('#workTab').setAttribute('aria-selected',String(state.work));
  $('#homeActions').classList.toggle('hidden',!!activeChat()?.messages.length);
  $('#homeSpace').classList.toggle('hidden',!!activeChat()?.messages.length);
  if(state.work){
    $('#composerHint').textContent='فضای کار — برای شروع، وظیفه‌ای تعریف کنید.';
    $('#promptInput').placeholder='چه کاری را انجام بدهم؟'
  }else{
    $('#composerHint').textContent='پردازش پیش‌فرض گفتگو با GapGPT انجام می‌شود؛ اطلاعات حساس را ارسال نکنید.';
    $('#promptInput').placeholder='از SAYROX بپرسید'
  }
}
function replaceAssistantCodeBlock(source,blockIndex,nextCode){
  if(String(nextCode).includes('```'))return null;
  const fence=/```([\w.+#-]*)\n?([\s\S]*?)```/g;
  let current=0,replaced=false;
  const result=String(source??'').replace(fence,(whole,language)=>{
    if(current++!==blockIndex)return whole;
    replaced=true;
    return `\`\`\`${language}\n${nextCode}\n\`\`\``;
  });
  return replaced?result:null;
}
function appendSafeMessageContent(container,raw){
  const renderer=window.SayroxResponseRenderer;
  if(!renderer?.render){container.textContent=String(raw??'');return}
  renderer.render(container,raw,{onCodeSave:(blockIndex,nextCode)=>{
    const article=container.closest('article.message');
    const messageIndex=Number(article?.dataset.messageIndex);
    const chat=activeChat();
    const message=Number.isInteger(messageIndex)?chat?.messages?.[messageIndex]:null;
    if(!message||message.role!=='assistant'){toast('پیام برای ذخیرهٔ ویرایش پیدا نشد.');return false}
    const revised=replaceAssistantCodeBlock(message.content,blockIndex,nextCode);
    if(revised===null){toast('ساختار بلوک کد تغییر کرده است؛ پیام را دوباره باز کن.');return false}
    const previousContent=message.content,previousUpdated=chat.updated;
    message.content=revised;chat.updated=Date.now();
    if(!persist()){
      message.content=previousContent;chat.updated=previousUpdated;
      toast('فضای ذخیره‌سازی مرورگر اجازهٔ ذخیره نداد.');return false;
    }
    renderRecent();toast('ویرایش کد در گفتگو ذخیره شد.');return true;
  }});
}
