// Long-press / context menu on user messages
// Part of the SAYROX app closure: parts are concatenated in file order by scripts/build-app.mjs.
// Do not edit site/src/app.js directly.
let userContextTarget=null;
let userPressTimer=null,userPressOrigin=null,suppressLongPressClick=false;
function closeUserMessageMenu(){
  const menu=$('#userMessageMenu');
  if(!menu)return;
  menu.classList.add('hidden');
  menu.style.left='';
  menu.style.top='';
  if(userContextTarget?.article)userContextTarget.article.setAttribute('aria-expanded','false');
  userContextTarget=null;
}
function openUserMessageMenu(article,x,y){
  if(!article||!article.isConnected||state.busy)return;
  const index=Number(article.dataset.messageIndex),chat=activeChat(),message=chat?.messages[index];
  if(!chat||!message||message.role!=='user'||message.internal)return;
  const menu=$('#userMessageMenu');
  userContextTarget={chatId:chat.id,index,article};
  menu.classList.remove('hidden');
  article.setAttribute('aria-expanded','true');
  const rect=menu.getBoundingClientRect(),width=rect.width||224,height=rect.height||190,gap=10;
  const left=Math.max(gap,Math.min(window.innerWidth-width-gap,x-width/2));
  let top=y-height-12;
  if(top<gap)top=y+12;
  if(top+height>window.innerHeight-gap)top=Math.max(gap,window.innerHeight-height-gap);
  menu.style.left=`${Math.round(left)}px`;
  menu.style.top=`${Math.round(top)}px`;
}
async function copyUserPrompt(text){
  try{
    if(navigator.clipboard?.writeText){await navigator.clipboard.writeText(text);return true}
  }catch{}
  try{
    const temporary=document.createElement('textarea');
    temporary.value=text;
    temporary.setAttribute('readonly','');
    temporary.style.cssText='position:fixed;inset:auto auto 0 -9999px;opacity:0';
    document.body.appendChild(temporary);
    temporary.select();
    const ok=document.execCommand('copy');
    temporary.remove();
    return ok
  }catch{return false}
}
function selectUserPrompt(article){
  const text=article?.querySelector('.message-text');
  if(!text)return false;
  if(text.classList.contains('is-collapsed')){
    text.classList.remove('is-collapsed');
    const expand=article.querySelector('.message-expand');
    if(expand){
      expand.textContent='نمایش کمتر ↑';
      expand.setAttribute('aria-expanded','true')
    }
  }
  try{
    const selection=window.getSelection(),range=document.createRange();
    range.selectNodeContents(text);
    selection.removeAllRanges();
    selection.addRange(range);
    return true
  }catch{return false}
}
function clearUserPress(){
  if(userPressTimer){clearTimeout(userPressTimer);userPressTimer=null}
  userPressOrigin=null
}
function cancelUserPress(){
  clearUserPress();
  if(suppressLongPressClick)setTimeout(()=>{suppressLongPressClick=false},700)
}
const userMessageHost=$('#messages');
userMessageHost.addEventListener('pointerdown',event=>{
  const article=event.target.closest('.message.user');
  if(!article||event.target.closest('button,.user-message-editor'))return;
  if(event.pointerType==='mouse'||event.button!==0)return;
  clearUserPress();
  userPressOrigin={article,x:event.clientX,y:event.clientY};
  userPressTimer=setTimeout(()=>{
    const origin=userPressOrigin;
    if(!origin)return;
    suppressLongPressClick=true;
    openUserMessageMenu(origin.article,origin.x,origin.y)
  },520);
});
userMessageHost.addEventListener('pointermove',event=>{
  if(!userPressOrigin)return;
  if(Math.hypot(event.clientX-userPressOrigin.x,event.clientY-userPressOrigin.y)>11)clearUserPress()
},{passive:true});
userMessageHost.addEventListener('pointerup',()=>{
  clearUserPress();
  if(suppressLongPressClick)setTimeout(()=>{suppressLongPressClick=false},700)
},{passive:true});
userMessageHost.addEventListener('pointercancel',cancelUserPress,{passive:true});
userMessageHost.addEventListener('click',event=>{
  if(suppressLongPressClick&&event.target.closest('.message.user')){
    event.preventDefault();
    event.stopPropagation();
    suppressLongPressClick=false
  }
},true);
userMessageHost.addEventListener('contextmenu',event=>{
  const article=event.target.closest('.message.user');
  if(!article)return;
  event.preventDefault();
  openUserMessageMenu(article,event.clientX,event.clientY)
});
document.addEventListener('keydown',event=>{
  if(event.key==='Escape'){closeUserMessageMenu();return}
  if((event.key==='ContextMenu'||(event.shiftKey&&event.key==='F10'))&&document.activeElement?.matches('.message.user')){
    event.preventDefault();
    const article=document.activeElement,rect=article.getBoundingClientRect();
    openUserMessageMenu(article,rect.left+rect.width/2,rect.top+rect.height/2);
    $('#userMessageMenu').querySelector('button')?.focus({preventScroll:true})
  }
});
$('#userMessageMenu').addEventListener('click',async event=>{
  const button=event.target.closest('button[data-user-context-action]');
  if(!button||!userContextTarget)return;
  const target=userContextTarget,chat=state.chats.find(item=>item.id===target.chatId),message=chat?.messages[target.index];
  if(!message||message.role!=='user'||message.internal){closeUserMessageMenu();return}
  const action=button.dataset.userContextAction;
  if(action==='edit'){
    closeUserMessageMenu();
    beginEditUserMessage(target.chatId,target.index,target.article);
    return
  }
  if(action==='select'){
    const selected=selectUserPrompt(target.article);
    closeUserMessageMenu();
    toast(selected?'متن پیام انتخاب شد':'انتخاب متن در دسترس نیست');
    return
  }
  if(action==='copy'){
    const copied=await copyUserPrompt(message.content);
    closeUserMessageMenu();
    toast(copied?'پرامپت کپی شد':'کپی در این مرورگر در دسترس نیست');
    return
  }
  if(action==='share'){
    closeUserMessageMenu();
    if(navigator.share){
      try{await navigator.share({title:'پرامپت از SAYROX',text:message.content})}catch(error){
        if(error.name!=='AbortError'){
          const copied=await copyUserPrompt(message.content);
          toast(copied?'اشتراک‌گذاری مستقیم در دسترس نبود؛ پرامپت کپی شد.':'اشتراک‌گذاری انجام نشد')
        }
      }
    }else{
      const copied=await copyUserPrompt(message.content);
      toast(copied?'پرامپت برای اشتراک‌گذاری کپی شد':'اشتراک‌گذاری در این مرورگر در دسترس نیست')
    }
  }
});
document.addEventListener('click',event=>{if(!event.target.closest('#userMessageMenu'))closeUserMessageMenu()});
window.addEventListener('resize',closeUserMessageMenu,{passive:true});
$('#chatScroll').addEventListener('scroll',closeUserMessageMenu,{passive:true});
