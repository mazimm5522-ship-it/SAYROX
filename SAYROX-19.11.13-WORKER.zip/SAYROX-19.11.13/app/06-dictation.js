// Speech-to-text dictation (Scribe + browser fallback)
// Part of the SAYROX app closure: parts are concatenated in file order by scripts/build-app.mjs.
// Do not edit site/src/app.js directly.
let dictationRecognition=null,dictationSession=null,dictationStarting=false;
function setDictationText(base,committed,partial=''){
  const input=$('#promptInput');
  input.value=[base,...committed,partial].map(value=>String(value||'').trim()).filter(Boolean).join(base?' ':' ');
  resizeInput();
  updateComposerButton()
}
function startBrowserSTTFallback(base){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
  if(!SR)return false;
  const rec=new SR();
  dictationRecognition=rec;
  rec.lang='fa-IR';
  rec.interimResults=true;
  rec.continuous=false;
  let finalText='';
  rec.onresult=e=>{
    let interim='';
    for(let i=e.resultIndex;i<e.results.length;i++){
      if(e.results[i].isFinal)finalText+=e.results[i][0].transcript;else interim+=e.results[i][0].transcript
    }
    setDictationText(base,finalText?[finalText]:[],interim)
  };
  rec.onerror=e=>{
    if(e.error!=='no-speech'&&e.error!=='aborted')toast(`تشخیص گفتار مرورگر ناموفق بود: ${e.error}`)
  };
  rec.onend=()=>{
    dictationRecognition=null;
    $('#micBtn').classList.remove('active');
    $('#micBtn').setAttribute('aria-label','گفتار به متن');
    resizeInput();
    updateComposerButton()
  };
  try{
    rec.start();
    $('#micBtn').classList.add('active');
    $('#micBtn').setAttribute('aria-label','توقف تشخیص گفتار');
    toast('حالت سازگار مرورگر فعال شد؛ دقت و پشتیبانی آن به مرورگر بستگی دارد.');
    return true
  }catch{dictationRecognition=null;return false}
}
async function startSTT(){
  const mic=$('#micBtn');
  if(dictationSession){
    dictationSession.stop();
    dictationSession=null;
    mic.classList.remove('active');
    mic.setAttribute('aria-label','گفتار به متن');
    toast('شنیدن صدا متوقف شد.');
    return
  }
  if(dictationRecognition){
    try{dictationRecognition.stop()}catch{}
    dictationRecognition=null;
    mic.classList.remove('active');
    mic.setAttribute('aria-label','گفتار به متن');
    return
  }
  if(dictationStarting)return;
  if(!requireAccountForProtectedApis())return;
  const input=$('#promptInput'),base=input.value.trimEnd();
  let permittedStream=null,streamTransferred=false;
  dictationStarting=true;
  mic.disabled=true;
  mic.classList.add('is-loading');
  try{
    if(!navigator.mediaDevices?.getUserMedia)throw new Error('این مرورگر به میکروفون دسترسی نمی‌دهد.');
    permittedStream=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
    const response=await fetch('/api/voice/transcription-token',{method:'GET',credentials:'same-origin',cache:'no-store',headers:{accept:'application/json'}});
    const data=await response.json().catch(()=>({}));
    const authError=protectedApiAuthError(response,data);
    if(authError)throw authError;
    if(!response.ok||!data.token){
      if(data.code==='VOICE_INPUT_NOT_CONFIGURED'){
        permittedStream.getTracks().forEach(track=>track.stop());
        permittedStream=null;
        if(startBrowserSTTFallback(base))return;
      }
      throw new Error(data.message||'آماده‌سازی ورودی گفتار ناموفق بود.');
    }
    if(!window.SayroxSpeechInput?.start)throw new Error('ماژول ورودی گفتار SAYROX بارگذاری نشده است.');
    const committed=[];
    dictationSession=await window.SayroxSpeechInput.start({token:data.token,stream:permittedStream,languageCode:'fa',maxDurationMs:180000,
   onPartial:text=>setDictationText(base,committed,text),
   onCommitted:text=>{
      if(text.trim())committed.push(text.trim());
      setDictationText(base,committed,'')
    },
   onState:()=>{
      mic.classList.add('active');
      mic.setAttribute('aria-label','توقف تشخیص گفتار');
      toast('تشخیص زندهٔ فارسی فعال است؛ برای پایان دوباره میکروفون را بزن.')
    },
   onLimit:()=>{
      dictationSession=null;
      mic.classList.remove('active');
      mic.setAttribute('aria-label','گفتار به متن');
      toast('برای کنترل هزینه، نشست ورودی گفتار پس از ۳ دقیقه متوقف شد.')
    },
   onError:error=>{
      dictationSession=null;
      mic.classList.remove('active');
      mic.setAttribute('aria-label','گفتار به متن');
      toast(error.message||'خطای تشخیص گفتار')
    }
  });
    streamTransferred=true;
  }catch(error){
    if(error?.authGate)return;
    toast(error.message||'ورودی گفتار در دسترس نیست.');
  }
 finally{
    if(permittedStream&&!streamTransferred)permittedStream.getTracks().forEach(track=>track.stop());
    dictationStarting=false;
    mic.disabled=false;
    mic.classList.remove('is-loading');
    resizeInput();
    updateComposerButton()
  }
}
