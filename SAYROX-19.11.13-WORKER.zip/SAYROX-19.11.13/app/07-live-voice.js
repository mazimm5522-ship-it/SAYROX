// Live voice overlay: SDK preflight, session, reconnect, mute, volume
// Part of the SAYROX app closure: parts are concatenated in file order by scripts/build-app.mjs.
// Do not edit site/src/app.js directly.
function setVoiceStatus(text,status){
  $('#voiceStatus').textContent=text;
  $('#voiceOverlay').dataset.state=status;
  voiceOrb?.setState(status==='connecting'?'loading':status)
}
let voiceOrb=null,voiceSdkPromise=null;
function ensureVoiceOrb(){
  const persona=window.SayroxVoicePersonas.get(state.settings.voicePersona||'ara');
  voiceOrb=window.SayroxOrb.mount($('#orbScene'),{accent:persona.accent,glow:persona.glow,seed:persona.key,state:'idle'});
  voiceOrb.setColors(persona.accent,persona.glow);
  voiceOrb.setSeed(persona.key);
  const name=$('#voicePersonaName');
  if(name)name.textContent='SAYROX Live';
  return voiceOrb
}
function setOrbEnergy(value){voiceOrb?.setEnergy(value)}
function setMuteUI(muted){
  const b=$('#voiceMute');
  b.classList.toggle('is-muted',muted);
  b.setAttribute('aria-pressed',String(muted));
  b.querySelector('.voice-ctl-label').textContent=muted?'روشن‌کردن میکروفون':'بی‌صدا';
  const icon=b.querySelector('.voice-ctl-icon');
  icon.innerHTML=window.SayroxIcons.svg(muted?'micOff':'mic')
}
function updateLiveVoiceTranscript(message){
  if(!message||typeof message!=='object')return;
  const payload=message.data&&typeof message.data==='object'?message.data:message;
  const history=Array.isArray(payload.user_transcript)?payload.user_transcript:null;
  const lastTurn=history?.slice().reverse().find(item=>item&&typeof item.content==='string'&&item.content.trim());
  const candidates=[
   payload.message,payload.text,payload.content,payload.transcript,
   payload.agent_response?.text,payload.agent_response?.content,
   payload.agent_response_event?.agent_response,payload.agent_response_event?.text,
   payload.user_transcription_event?.user_transcript,payload.user_transcript?.content,
   lastTurn?.content
 ];
  const textValue=candidates.find(value=>typeof value==='string'&&value.trim());
  if(!textValue)return;
  const type=String(payload.type||payload.source||payload.role||lastTurn?.role||'').toLowerCase();
  const isUser=/user|human/.test(type)||payload.role==='user'||!!payload.user_transcription_event||lastTurn?.role==='user';
  const line=`${isUser?'شما':'SAYROX'}: ${String(textValue).trim().slice(0,900)}`;
  if(line===state.lastVoiceMessage)return;
  state.lastVoiceMessage=line;
  $('#voiceTranscript').textContent=line;
}
async function loadLiveVoiceSDK(){
  if(!voiceSdkPromise)voiceSdkPromise=(async()=>{
    let localError=null;
    try{
      const local=await import('/vendor/elevenlabs-client.mjs');
      if(local?.Conversation?.startSession)return local.Conversation;
      throw new Error('Local SDK bundle export missing');
    }catch(error){localError=error}
   // Remote CDNs are an explicit emergency opt-in only; normal builds stay same-origin.
    const allowRemoteFallback=window.SAYROX_ALLOW_REMOTE_VOICE_SDK_FALLBACK===true;
    const sources=allowRemoteFallback?[()=>import('https://esm.sh/@elevenlabs/client@1.32.1?bundle'),()=>import('https://cdn.jsdelivr.net/npm/@elevenlabs/client@1.32.1/+esm')]:[];
    let lastError=localError;
    for(const load of sources){
      try{
        const module=await load();
        if(module?.Conversation?.startSession)return module.Conversation;
        lastError=new Error('SDK export missing')
      }catch(error){lastError=error}
    }
    voiceSdkPromise=null;
    console.warn('SAYROX Live Voice SDK loading failed',String(lastError?.name||'Error'));
    throw new Error('مکالمهٔ زنده هنوز آماده نیست؛ لطفاً کمی بعد دوباره امتحان کن.');
  })();
  return voiceSdkPromise;
}
const voiceAttempt=window.SayroxVoiceLifecycle.createAttemptGate();
function stopLiveVoiceMeter(){
  clearTimeout(state.voiceMeterTimer);
  state.voiceMeterTimer=0;
  setOrbEnergy(0)
}
function showVoiceReconnect(message='اتصال قطع شد؛ اینترنت را بررسی کن و دوباره وصل شو.'){
  if(!state.voiceActive||state.voiceStopping)return;
  stopLiveVoiceMeter();
  setVoiceStatus(message,'idle');
  $('#voiceReconnect').classList.remove('hidden');
}
function startLiveVoiceMeter(attempt){
  stopLiveVoiceMeter();
  const tick=async()=>{
    if(!state.voiceActive||!voiceAttempt.isCurrent(attempt)||!state.liveConversation)return;
    const conversation=state.liveConversation;
    try{
      const [input,output]=await Promise.all([conversation.getInputVolume?.(),conversation.getOutputVolume?.()]);
      if(!state.voiceActive||!voiceAttempt.isCurrent(attempt)||conversation!==state.liveConversation)return;
      const level=Math.max(Number(input)||0,Number(output)||0);
      setOrbEnergy(Math.min(.98,Math.max(0,(level-.075)*1.55)));
    }catch{if(state.voiceActive&&voiceAttempt.isCurrent(attempt))setOrbEnergy(0)}
    if(state.voiceActive&&voiceAttempt.isCurrent(attempt)&&conversation===state.liveConversation)state.voiceMeterTimer=setTimeout(tick,90);
  };
  void tick();
}
async function showVoice(){
  if(state.voiceActive)return;
  if(!navigator.mediaDevices?.getUserMedia){
    toast('برای مکالمه زنده به مرورگر سازگار و دسترسی میکروفون نیاز است.');
    return
  }
  const attempt=voiceAttempt.begin();
  const controller=new AbortController();
  state.voiceStartController=controller;
  const isCurrent=()=>state.voiceActive&&voiceAttempt.isCurrent(attempt)&&!controller.signal.aborted;
  state.voiceActive=true;
  state.voiceStopping=false;
  state.voiceReconnectPending=false;
  state.voiceMuted=false;
  state.lastVoiceMessage='';
  $('#voiceReconnect').classList.add('hidden');
  if(state.voiceAudio){
    try{state.voiceAudio.pause()}catch{}
    if(state.voiceAudioUrl)URL.revokeObjectURL(state.voiceAudioUrl);
    state.voiceAudio=null;
    state.voiceAudioUrl=null
  }
  if('speechSynthesis'in window)speechSynthesis.cancel();
  $('#voiceOverlay').classList.add('active');
  ensureVoiceOrb();
  $('#voiceTranscript').textContent='';
  $('#voiceVolumeControl').value=String(Math.min(1,Math.max(0,Number(state.settings.voiceVolume??.9))));
  setMuteUI(false);
  setVoiceStatus('در حال آماده‌سازی اتصال زنده…','connecting');
  try{
   // Load the local SDK first: if it is missing, fail before the mic prompt and before any live_voice quota is spent.
    const Conversation=await loadLiveVoiceSDK();
    if(!isCurrent())return;
  // Request microphone permission before creating a paid, remote speech session.
    const permissionStream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}});
    permissionStream.getTracks().forEach(track=>track.stop());
    if(!isCurrent())return;
    const tokenResponse=await fetch('/api/voice/token',{
      method:'GET',
      credentials:'same-origin',
      cache:'no-store',
      headers:{accept:'application/json'},
      signal:controller.signal
    });
    const tokenData=await tokenResponse.json().catch(()=>({}));
    if(!tokenResponse.ok||!tokenData.token)throw new Error(tokenData.message||'ساخت نشست صوتی ناموفق بود.');
    const conversation=await Conversation.startSession({
     conversationToken:tokenData.token,
     connectionType:'webrtc',
     connectionDelay:{android:3000,ios:0,default:0},
     preferHeadphonesForIosDevices:true,
     useWakeLock:true,
     onConnect:()=>{
      if(isCurrent()){
        setVoiceStatus('وصل شدم رفیق؛ بگو، گوش می‌دهم.','listening');
        $('#voiceReconnect').classList.add('hidden');
      }
    },
     onDisconnect:()=>{
      if(isCurrent())showVoiceReconnect('اتصال قطع شد؛ می‌توانی دوباره وصل شوی.')
    },
     // ElevenLabs SDK onMessage emits finalized user transcripts and agent replies.
     onMessage:message=>{if(isCurrent())updateLiveVoiceTranscript(message)},
     onError:error=>{
      if(isCurrent()){
        console.warn('SAYROX live voice SDK error',String(error?.name||'Error'));
        showVoiceReconnect('در مکالمه مشکلی پیش آمد؛ اتصال را بررسی کن و دوباره تلاش کن.')
      }
    },
     onStatusChange:status=>{
      if(!isCurrent())return;
      const value=typeof status==='string'?status:String(status?.status||status?.state||'');
      if(value==='connecting')setVoiceStatus('در حال اتصال به مکالمه زنده…','connecting');
       else if(value==='connected'){
        setVoiceStatus('وصل شدم رفیق؛ بگو، گوش می‌دهم.','listening');
        $('#voiceReconnect').classList.add('hidden')
      }
       else if(value==='disconnected')showVoiceReconnect('اتصال قطع شد؛ می‌توانی دوباره وصل شوی.');
    },
     onModeChange:mode=>{
      if(!isCurrent())return;
      const value=typeof mode==='string'?mode:String(mode?.mode||mode?.status||'');
      if(value==='speaking')setVoiceStatus('دارم باهات صحبت می‌کنم…','speaking');
       else if(value==='listening')setVoiceStatus('گوش می‌دهم… هر وقت خواستی وسط حرفم بیا.','listening');
       else if(value==='thinking'||value==='processing')setVoiceStatus('دارم پاسخ را آماده می‌کنم…','thinking');
    }
   });
    if(!isCurrent()){await conversation.endSession?.();return}
    state.liveConversation=conversation;
    state.voiceStartController=null;
    if(state.voiceSessionTimer)clearTimeout(state.voiceSessionTimer);
    state.voiceSessionTimer=window.setTimeout(()=>{
      if(!state.voiceActive)return;
      setVoiceStatus('مدت مکالمه به سقف سه‌دقیقه‌ای رسید.','idle');
      void stopVoiceSession();
    },180000);
    await conversation.setVolume?.({volume:Math.min(1,Math.max(0,Number($('#voiceVolumeControl').value)||0))});
    if(isCurrent())startLiveVoiceMeter(attempt);
  }catch(error){
    if(error?.name==='AbortError'||!voiceAttempt.isCurrent(attempt)||!state.voiceActive)return;
    state.voiceStartController=null;
    state.liveConversation=null;
    stopLiveVoiceMeter();
    const denied=/NotAllowedError|PermissionDeniedError/i.test(String(error?.name||''));
    showVoiceReconnect(denied?'اجازه‌ی میکروفون داده نشد؛ دسترسی میکروفون مرورگر را فعال کن.':'شروع مکالمه کامل نشد؛ اتصال را بررسی کن و دوباره تلاش کن.');
    toast(denied?'برای شروع مکالمه، اجازه‌ی دسترسی به میکروفون لازم است.':(error.message||'شروع مکالمه زنده ناموفق بود'));
  }
}
async function stopVoiceSession(){
  voiceAttempt.invalidate();
  state.voiceReconnectPending=false;
  state.voiceStopping=true;
  state.voiceActive=false;
  state.voiceProcessing=false;
  if(state.voiceSessionTimer){clearTimeout(state.voiceSessionTimer);state.voiceSessionTimer=0;}
  state.voiceStartController?.abort();
  state.voiceStartController=null;
  stopLiveVoiceMeter();
  const conversation=state.liveConversation;
  state.liveConversation=null;
  if(conversation){try{await conversation.endSession()}catch{}}
  $('#voiceOverlay').classList.remove('active');
  $('#voiceReconnect').classList.add('hidden');
  setOrbEnergy(0);
  voiceOrb?.setState('idle');
  setMuteUI(false);
  state.voiceMuted=false;
  state.voiceStopping=false;
}
async function reconnectLiveVoice(){
  if(!state.voiceActive||state.voiceStopping||state.voiceReconnectPending)return;
  state.voiceReconnectPending=true;
  const attempt=voiceAttempt.begin();
  state.voiceStartController?.abort();
  state.voiceStartController=null;
  const old=state.liveConversation;
  state.liveConversation=null;
  stopLiveVoiceMeter();
  if(state.voiceSessionTimer){clearTimeout(state.voiceSessionTimer);state.voiceSessionTimer=0;}
  if(old){try{await old.endSession()}catch{}}
 // Ending a WebRTC session is asynchronous. A user may close the overlay while it
 // resolves; only the still-current reconnect is allowed to start another session.
  if(!voiceAttempt.isCurrent(attempt)||!state.voiceActive||state.voiceStopping)return;
  state.voiceReconnectPending=false;
  state.voiceActive=false;
  state.voiceStopping=false;
  $('#voiceReconnect').classList.add('hidden');
  await showVoice();
}
async function toggleLiveVoiceMute(){
  const conversation=state.liveConversation;
  if(!conversation)return;
  const next=!state.voiceMuted;
  try{
    await conversation.setMicMuted(next);
    state.voiceMuted=next;
    setMuteUI(next);
    setVoiceStatus(next?'میکروفون موقتاً بی‌صداست.':'میکروفون روشن است؛ گوش می‌دهم.',next?'idle':'listening')
  }
 catch{toast('تغییر وضعیت میکروفون انجام نشد؛ دوباره تلاش کن')}
}
async function setLiveVoiceVolume(value,save=false){
  const volume=Math.min(1,Math.max(0,Number(value)||0));
  state.settings.voiceVolume=volume;
  if(save)persist();
  try{await state.liveConversation?.setVolume({volume})}catch{if(state.voiceActive)toast('تغییر بلندی صدا انجام نشد')}
}
