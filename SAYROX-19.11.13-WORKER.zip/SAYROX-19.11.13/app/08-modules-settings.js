// Settings feature, modules pages, voice persona preview, data export/clear
// Part of the SAYROX app closure: parts are concatenated in file order by scripts/build-app.mjs.
// Do not edit site/src/app.js directly.
let settingsFeature=null;
function renderSettings(filter=''){if(settingsFeature)settingsFeature.renderList(filter)}
function openSettings(){
  setView('settings');
  $('#settingsSearch').value='';
  settingsFeature?.openHome()
}
function openSettingDetail(key,title){settingsFeature?.openPage(key,title)}
function renderModule(key){
  if(key!=='library')window.SayroxFileLibraryUI?.destroy?.();
  const root=$('#moduleContent');
  if(key==='library'){
    if(window.SayroxFileLibraryUI?.render){
      window.SayroxFileLibraryUI.render(root,{
        onOpenFile:id=>{window.SayroxFileStudioBridge?.openFile?.(id);openModule('file-studio','استودیو فایل')},
        onSendToChat:id=>window.SayroxChatFileBridge?.attachFromLibrary?.(id)
      });
    }else root.textContent='کتابخانه فایل بارگیری نشد؛ صفحه را تازه‌سازی کن.';
    return
  }
  if(key==='file-studio'){
    root.innerHTML='<div class="module-note">در حال آماده‌سازی استودیو فایل…</div>';
    if(window.SayroxFileStudioBridge?.render)window.SayroxFileStudioBridge.render(root);else root.textContent='بارگذاری استودیو فایل ناموفق بود؛ صفحه را دوباره باز کن.';
    return
  }
  const content={
gallery:`<h2>گالری رابط هوشمند</h2><p>نمای کلی بخش‌های ساخته‌شده و وضعیت اتصال ابزارها.</p><div class="module-note">این صفحه فقط وضعیت و مستندات را نمایش می‌دهد؛ قابلیت‌های متصل‌نشده به‌عنوان فعال معرفی نمی‌شوند.</div><div class="module-list"><div class="module-item"><span>چت و تاریخچه<small>گفتگوهای محلی و عملیات پیام</small></span><span>در دسترس</span></div><div class="module-item"><span>ورود حساب<small>نیازمند اتصال زیرساخت امن حساب</small></span><span>نیازمند پیکربندی</span></div></div>`,
projects:`<h2>پروژه‌ها</h2><p>پروژه‌های محلی SAYROX برای نگهداری موضوع و دستورالعمل‌ها.</p><form class="module-card module-form" id="projectForm"><input id="projectName" maxlength="80" required placeholder="نام پروژه‌ی جدید"><button class="primary-btn">ایجاد</button></form><div class="module-list">${state.projects.length?state.projects.map((p,i)=>`<div class="module-item"><span>${escapeHtml(p.name)}<small>${new Date(p.created).toLocaleDateString('fa-IR')}</small></span><button class="secondary-btn" data-remove-project="${i}">حذف</button></div>`).join(''):'<div class="module-note">هنوز پروژه‌ای نساخته‌ای.</div>'}</div>`,
remote:`<h2>کنترل از راه دور</h2><p>این قابلیت به عامل دسکتاپ امن و احراز هویت متصل نیاز دارد.</p><div class="module-note">وضعیت: تنظیم نشده؛ هیچ دستگاهی به این حساب متصل نیست.</div>`,
apps:`<h2>افزونه‌ها و اپ‌ها</h2><p>اتصال سرویس‌ها از طریق Cloudflare Worker انجام می‌شود؛ کلیدها نباید در مرورگر ذخیره شوند.</p><div class="module-list"><div class="module-item"><span>GapGPT اصلی / OpenRouter جایگزین<small>مدل‌های گفتگو — نیازمند Secret</small></span><span data-provider="chat">در حال بررسی</span></div><p class="module-note">در حالت خودکار، گفتگوها ابتدا با GapGPT پردازش می‌شوند. <a href="https://aigap.app/rules" target="_blank" rel="noopener noreferrer">شرایط استفاده‌ی GapGPT</a></p><div class="module-item"><span>Tavily<small>جست‌وجوی وب — نیازمند Secret</small></span><span data-provider="search">در حال بررسی</span></div><div class="module-item"><span>ElevenLabs<small>تبدیل متن به صدا — نیازمند Secret و Voice ID</small></span><span data-provider="tts">در حال بررسی</span></div><div class="module-item"><span>ورودی گفتار زنده — ElevenLabs Scribe<small>تشخیص فارسی بلادرنگ — API Key و سهمیهٔ مستقل</small></span><span data-provider="voiceInput">در حال بررسی</span></div><div class="module-item"><span>ElevenLabs Live Voice<small>مکالمه‌ی زنده — Speech Engine و Voice ID</small></span><span data-provider="voiceLive">در حال بررسی</span></div><div class="module-item"><span>تولید تصویر — OpenRouter<small>نیازمند OPENROUTER_IMAGE_MODEL</small></span><span data-provider="images">در حال بررسی</span></div><div class="module-item"><span>کارهای زمان‌بندی‌شده<small>Scheduler Durable Object و راز امضای داخلی</small></span><span data-provider="tasks">در حال بررسی</span></div><div class="module-item"><span>Zarinpal<small>پرداخت — نیازمند Merchant ID و ذخیره‌سازی امن</small></span><span data-provider="payments">در حال بررسی</span></div></div>`
};
  if(key==='images'){renderImagesStudio(root);return}
  if(key==='tasks'){renderTasksPage(root);return}
  if(key==='agent-history'){renderAgentHistoryPage(root);return}
  root.innerHTML=content[key]||'<h2>بخش</h2><div class="module-note">این بخش هنوز پیاده‌سازی نشده است.</div>';
  if(key==='apps'&&['http:','https:'].includes(location.protocol)){
    fetch('/api/health').then(r=>r.json()).then(h=>{
      root.querySelectorAll('[data-provider]').forEach(el=>{
        const ok=Boolean(h.providers?.[el.dataset.provider]);
        el.textContent=ok?'متصل':'تنظیم نشده';
        el.classList.toggle('provider-ready',ok)
      })
    }).catch(()=>{})
  }
  $('#projectForm')?.addEventListener('submit',e=>{
    e.preventDefault();
    const name=$('#projectName').value.trim();
    if(!name)return;
    state.projects.unshift({name,created:Date.now()});
    persist();
    renderModule('projects');
    toast('پروژه ذخیره شد')
  });
  root.querySelectorAll('[data-remove-project]').forEach(b=>b.onclick=()=>{
    state.projects.splice(Number(b.dataset.removeProject),1);
    persist();
    renderModule('projects')
  });
}
function escapeHtml(value){
  return String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))
}
function openModule(key,title){
  $('#moduleTitle').textContent=title||({
    images:'تصاویر',
    library:'کتابخانه',
    projects:'پروژه‌ها',
    remote:'کنترل از راه دور',
    tasks:'کارهای زمان‌بندی‌شده',
    'agent-history':'تاریخچهٔ Agent',
    apps:'افزونه‌ها و اپ‌ها',
    'file-studio':'استودیو فایل'
  }[key]||'فضای کاری');
  renderModule(key);
  setView('module')
}
function exportData(){
  const chats=window.SayroxChatActions.exportableChats(state.chats);
  const blob=new Blob([JSON.stringify({chats,projects:state.projects,tasks:state.tasks,files:state.files,exportedAt:new Date().toISOString()},null,2)],{type:'application/json'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download='sayrox-data.json';
  a.click();
  URL.revokeObjectURL(a.href)
}
async function previewVoicePersona(persona,studioRoot){
  const orb=studioRoot?.querySelector('#voiceStudioOrb'),status=studioRoot?.querySelector('#voicePreviewStatus');
  const setStatus=(message)=>{if(status)status.textContent=message};
  const setOrb=(mode)=>{
    if(orb){
      orb.dataset.state=mode;
      window.SayroxOrb.get(orb)?.setState(mode==='loading'?'loading':mode==='speaking'?'speaking':'idle')
    }
  };
  setOrb('loading');
  setStatus('در حال بررسی موتور صوتی…');
  const sample=`سلام، من ${persona.name} هستم. این نمونه‌ی صدای من در SAYROX است.`;
  let providerReady=false;
  if(['http:','https:'].includes(location.protocol)){
    try{
      const health=await fetch('/api/health',{credentials:'same-origin'}).then(r=>r.json());
      providerReady=Boolean(health.providers?.tts);
      if(providerReady){
        if(!requireAccountForProtectedApis()){
          setOrb('idle');
          setStatus('برای پیش‌نمایش صدای اختصاصی ابتدا وارد حساب SAYROX شو.');
          return
        }
        const response=await fetch('/api/tts',{
          method:'POST',
          credentials:'same-origin',
          headers:{'content-type':'application/json'},
          body:JSON.stringify({text:sample,voice:persona.provider,rate:Number(state.settings.voiceRate)||1})
        });
        if(response.ok){
          const blob=await response.blob(),url=URL.createObjectURL(blob),audio=new Audio(url);
          audio.volume=Number(state.settings.voiceVolume)||1;
          let audioContext=null,raf=0,analyser=null,source=null;
          try{
            if(window.AudioContext){
              audioContext=new AudioContext();
              await audioContext.resume();
              source=audioContext.createMediaElementSource(audio);
              analyser=audioContext.createAnalyser();
              analyser.fftSize=256;
              source.connect(analyser);
              analyser.connect(audioContext.destination)
            }
          }catch{analyser=null}
          const animate=()=>{
            if(!analyser||!orb)return;
            const data=new Uint8Array(analyser.fftSize);
            analyser.getByteTimeDomainData(data);
            let sum=0;
            for(const value of data){const v=(value-128)/128;sum+=v*v}
            const rms=Math.sqrt(sum/data.length);
            window.SayroxOrb.get(orb)?.setEnergy(Math.min(.95,Math.max(0,rms*5.5)));
            raf=requestAnimationFrame(animate)
          };
          setOrb('speaking');
          setStatus('نمونه‌ی واقعی ElevenLabs در حال پخش است.');
          if(analyser)animate();
          try{await audio.play()}catch(error){
            cancelAnimationFrame(raf);
            URL.revokeObjectURL(url);
            await audioContext?.close().catch(()=>{});
            throw error
          }
          await new Promise(resolve=>{audio.onended=resolve;audio.onerror=resolve});
          cancelAnimationFrame(raf);
          audio.pause();
          URL.revokeObjectURL(url);
          await audioContext?.close().catch(()=>{});
          if(orb){window.SayroxOrb.get(orb)?.setEnergy(0);setOrb('idle')}
          setStatus('پخش نمونه پایان یافت.');
          return;
        }
        const details=await response.json().catch(()=>({}));
        const authError=protectedApiAuthError(response,details);
        if(authError){setStatus(authError.message);setOrb('idle');return}
        setStatus(details.message||'Voice ID انتخاب‌شده در ElevenLabs تنظیم نشده است؛ صدای مرورگر امتحان می‌شود.');
      }
    }catch(error){
      setStatus(`موتور اختصاصی در دسترس نیست: ${error.message||'خطای اتصال'}`)
    }
  }
  if('speechSynthesis'in window){
    speechSynthesis.cancel();
    const utterance=new SpeechSynthesisUtterance(sample);
    utterance.lang='fa-IR';
    utterance.rate=Math.min(1.25,Math.max(.75,Number(state.settings.voiceRate)||1));
    utterance.volume=Math.min(1,Math.max(.1,Number(state.settings.voiceVolume)||1));
    setOrb('speaking');
    setStatus('پیش‌نمایش با صدای بومی مرورگر؛ این صدا الزاماً شخصیت اختصاصی انتخاب‌شده نیست.');
    await new Promise(resolve=>{
      utterance.onend=resolve;
      utterance.onerror=resolve;
      try{speechSynthesis.speak(utterance)}catch{resolve()}
    });
    setOrb('idle');
    setStatus(providerReady?'نمونه‌ی مرورگر پخش شد؛ برای صدای اختصاصی، Voice ID این شخصیت را در Worker تنظیم کن.':'نمونه‌ی صدای مرورگر پخش شد؛ ElevenLabs هنوز متصل یا پیکربندی نشده است.');
    return;
  }
  setOrb('idle');
  setStatus('نه ElevenLabs برای این صدا تنظیم شده و نه مرورگر از پخش گفتار پشتیبانی می‌کند.');
  toast('پیش‌نمایش صدا در این محیط در دسترس نیست.');
}
function requestNotificationPermission(){
  if(!('Notification'in window)){toast('اعلان سیستم در این مرورگر پشتیبانی نمی‌شود.');return}
  Notification.requestPermission().then(permission=>{
    state.settings.notificationsSystem=permission==='granted';
    persist();
    toast(permission==='granted'?'اجازه‌ی اعلان داده شد':permission==='denied'?'اجازه‌ی اعلان رد شد':'اجازه‌ی اعلان داده نشد')
  }).catch(()=>toast('دریافت اجازه‌ی اعلان ناموفق بود.'))
}
function clearLocalChats(){
  const reset=()=>$('#modalOk').classList.remove('danger-btn');
  showModal('پاک‌سازی گفتگوهای محلی','<p>تمام گفتگوهای ذخیره‌شده در همین مرورگر حذف شوند؟ این عملیات قابل بازگشت نیست.</p>','حذف گفتگوها',()=>{
    state.chats.forEach(clearVolatilePayloadsForChat);
    state.chats=[];
    state.active=null;
    persist();
    renderRecent();
    renderMessages();
    toast('گفتگوهای محلی حذف شدند');
    reset()
  });
  $('#modalOk').classList.add('danger-btn');
  $('#modalCancel').onclick=()=>{$('#modalBackdrop').classList.remove('open');reset()}
}
function deleteAllChats(){clearLocalChats()}
settingsFeature=window.SayroxSettingsFeature.create({
  state,
  elements:{
    list:$('#settingsGroups'),
    view:$('#settingsView'),
    detail:$('#settingsDetail'),
    title:$('#detailTitle'),
    content:$('#detailContent'),
    back:$('#detailBack'),
    homeBack:$('#settingsBack'),
    search:$('#settingsSearch')
  },
  adapter:{
    icon:svg,
    toast,
    persist,
    setTheme,
    updateToolMenu:()=>typeof updateToolMenu==='function'?updateToolMenu():undefined,
    accountAction:()=>{
      if(state.user)logoutAccount();else{setView('chat');$('#authScreen').classList.remove('hidden')}
    },
    previewVoice:previewVoicePersona,
    exportData,
    clearLocalChats,
    deleteAllChats,
    requestNotificationPermission,
    closeSettings:()=>setView('chat'),
    onModelChange:value=>{
      $('#modelName').textContent=value==='auto'?'مدل خودکار':value.split('/').pop();
    },
    onOrbPreference:value=>{state.settings.orbReactive=value;},
    setVoiceAccent:persona=>{
      document.documentElement.style.setProperty('--active-voice-accent',persona.accent);
      document.documentElement.style.setProperty('--active-voice-glow',persona.glow);
      voiceOrb?.setColors(persona.accent,persona.glow);
      voiceOrb?.setSeed(persona.key);
      const n=$('#voicePersonaName');
      if(n)n.textContent=persona.name;
    },
    userName:()=>userLabel(),
    userInitials:()=>userInitials(),
    onPageBack:()=>{},
    onPageOpen:key=>{if(key==='general'){}},
  }
});
const initialVoicePersona=window.SayroxVoicePersonas.get(state.settings.voicePersona||'ara');
document.documentElement.style.setProperty('--active-voice-accent',initialVoicePersona.accent);
document.documentElement.style.setProperty('--active-voice-glow',initialVoicePersona.glow);
