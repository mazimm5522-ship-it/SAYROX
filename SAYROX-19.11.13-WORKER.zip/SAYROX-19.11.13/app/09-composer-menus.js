// Top-level event bindings: drawer, composer, header menu, tool menu
// Part of the SAYROX app closure: parts are concatenated in file order by scripts/build-app.mjs.
// Do not edit site/src/app.js directly.
$('#menuBtn').onclick=openDrawer;
// Conversation response modes are local preferences; Worker instructions are a fixed allowlist.
const CONVERSATION_MODES={
  auto:{label:'خودکار',description:'تعادل میان سرعت، دقت و جزئیات',glyph:'✦'},
  fast:{label:'سریع',description:'پاسخ مستقیم و کوتاه، بدون حاشیه',glyph:'ϟ'},
  precise:{label:'دقیق',description:'توجه به جزئیات، صحت و عدم قطعیت',glyph:'◎'},
  creative:{label:'خلاقانه',description:'ایده‌پردازی و پیشنهادهای تازه',glyph:'✧'},
  deep:{label:'تحلیل عمیق',description:'بررسی همه‌جانبه؛ در صورت پشتیبانی مدل',glyph:'◈'},
  coding:{label:'برنامه‌نویسی',description:'راه‌حل فنی، کد قابل اجرا و تست',glyph:'</>'}
};
function updateConversationModeUI(){
  const mode=CONVERSATION_MODES[state.conversationMode]?state.conversationMode:'auto';
  state.conversationMode=mode;
  const config=CONVERSATION_MODES[mode];
  const trigger=$('#conversationModeBtn'),name=$('#conversationModeName'),announce=$('#conversationModeAnnounce');
  if(name)name.textContent=config.label;
  if(trigger){trigger.setAttribute('aria-label',`حالت گفتگو: ${config.label}`);trigger.title=`حالت گفتگو: ${config.label}`;trigger.dataset.mode=mode}
  if(announce)announce.textContent=`حالت گفتگو روی ${config.label} تنظیم شد`;
  document.querySelectorAll('[data-conversation-mode]').forEach(button=>{
    const selected=button.dataset.conversationMode===mode;
    button.setAttribute('aria-checked',String(selected));
    button.classList.toggle('is-selected',selected);
  });
  $('#deepModeLabel')?.classList.toggle('hidden',!state.deepMode);
}
function toggleConversationModeMenu(force){
  const menu=$('#conversationModeMenu');
  if(!menu)return;
  const open=force??!menu.classList.contains('open');
  if(open)toggleToolMenu(false);
  menu.classList.toggle('open',open);
  menu.setAttribute('aria-hidden',String(!open));
  $('#conversationModeBtn')?.setAttribute('aria-expanded',String(open));
  if(open)menu.querySelector('[aria-checked="true"]')?.focus({preventScroll:true});
}
function setConversationMode(mode){
  if(!Object.prototype.hasOwnProperty.call(CONVERSATION_MODES,mode))return;
  state.conversationMode=mode;
  state.deepMode=mode==='deep';
  persist();
  updateConversationModeUI();
  updateToolMenu();
  toggleConversationModeMenu(false);
  $('#conversationModeBtn')?.focus({preventScroll:true});
  toast(`حالت گفتگو: ${CONVERSATION_MODES[mode].label}`);
}
$('#closeDrawer').onclick=hideDrawer;
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('#drawer').classList.contains('open'))hideDrawer()});
$('#drawerBackdrop').onclick=hideDrawer;
$('#newChatTop').onclick=newChat;
$('#drawerNew').onclick=newChat;
$('#openSettings').onclick=openSettings;
$('#settingsInfo').onclick=()=>toast('تنظیمات SAYROX');
$('#detailInfo').onclick=()=>toast('اطلاعات این بخش');
$('#chatSearch').oninput=e=>renderRecent(e.target.value);
$('#drawerSearchBtn').onclick=()=>{
  const box=$('#drawerSearchBox');
  box.classList.toggle('active');
  if(box.classList.contains('active'))$('#chatSearch').focus()
};
$('#galleryIntro').onclick=()=>openModule('gallery','معرفی گالری رابط هوشمند');
$('#chatTab').onclick=()=>{state.work=false;updateTabs()};
$('#workTab').onclick=()=>{state.work=true;updateTabs();toast('حالت Work انتخاب شد')};
$('#promptInput').addEventListener('input',()=>{resizeInput();updateComposerButton()});
function handleComposerKeydown(event){
  if(event.key!=='Enter'||event.shiftKey||event.isComposing||event.keyCode===229)return;
  event.preventDefault();
  sendMessage()
}
$('#promptInput').addEventListener('keydown',handleComposerKeydown);
$('#conversationModeBtn').onclick=()=>toggleConversationModeMenu();
document.querySelectorAll('[data-conversation-mode]').forEach(button=>{
  button.addEventListener('click',()=>setConversationMode(button.dataset.conversationMode));
});
updateConversationModeUI();
$('#composer').addEventListener('submit',e=>e.preventDefault());
function rememberLegacyFileName(name){
  if(!state.files.includes(name)){state.files.push(String(name).slice(0,180));if(state.files.length>100)state.files.splice(0,state.files.length-100);persist()}
}
async function rememberFileInLibrary(file){
  try{await window.SayroxFileLibrary?.add(file,{source:'chat'})}
  catch(error){toast(`${file.name}: در گفتگوی فعلی استفاده می‌شود، اما در کتابخانه ذخیره نشد: ${error.message}`)}
}
$('#fileInput').onchange=async e=>{
  const files=[...e.target.files];if(!files.length)return;
  const result=await window.SayroxFileLibrary.addMany(files,{source:'library-picker'});
  result.results.forEach(item=>rememberLegacyFileName(item.name));
  renderModule('library');
  toast(`${result.results.length} فایل به کتابخانه افزوده شد${result.errors.length?`؛ ${result.errors.length} فایل ذخیره نشد`:''}`);
  e.target.value=''
};
async function processChatFileSelection(files){
  if(!files.length)return;
  let ingested=0,addedImages=0,addedPdfs=0,addedSpreadsheets=0,addedArchives=0;
  for(const file of files){
    const isImage=String(file.type||'').toLowerCase().startsWith('image/')||/\.(jpe?g|png|webp|gif)$/i.test(file.name);
    if(isImage){
      try{
        const prepared=await window.SayroxChatImageInput.prepareImage(file);
        window.SayroxChatImageInput.validateBatch([...pendingImageAttachments,prepared]);
        pendingImageAttachments.push(prepared);addedImages++;
        await rememberFileInLibrary(file);rememberLegacyFileName(file.name);
      }catch(error){toast(`${file.name}: ${error.message||'آماده‌سازی تصویر ناموفق بود'}`)}
      continue;
    }
    if(/\.zip$/i.test(file.name)){
      try{
        if(pendingPdfAttachments.length+pendingSpreadsheetAttachments.length+pendingZipAttachments.length>=2)throw new Error('در هر پیام حداکثر دو سند PDF، Excel یا ZIP می‌توانی پیوست کنی.');
        const prepared=await window.SayroxChatZipInput.prepareZipFile(file);
        pendingZipAttachments.push(prepared);addedArchives++;await rememberFileInLibrary(file);rememberLegacyFileName(file.name);
        if(prepared.truncated)toast(`${file.name}: فقط ${prepared.includedChars.toLocaleString('fa-IR')} نویسه از محتوای آرشیو برای تحلیل آماده شد.`);
      }catch(error){toast(`${file.name}: ${error.message||'خواندن ZIP ناموفق بود'}`)}
      continue;
    }
    if(/\.pdf$/i.test(file.name)){
      try{
        if(pendingPdfAttachments.length)throw new Error('در هر پیام فقط یک PDF می‌توانی پیوست کنی. ابتدا PDF قبلی را ارسال یا حذف کن.');
        if(pendingPdfAttachments.length+pendingSpreadsheetAttachments.length+pendingZipAttachments.length>=2)throw new Error('در هر پیام حداکثر دو سند PDF، Excel یا ZIP می‌توانی پیوست کنی.');
        const prepared=await window.SayroxChatPdfInput.preparePdfFile(file);
        pendingPdfAttachments.push(prepared);addedPdfs++;await rememberFileInLibrary(file);rememberLegacyFileName(file.name);
        if(prepared.truncated)toast(`${file.name}: متن برای تحلیل به ${prepared.includedChars.toLocaleString('fa-IR')} نویسه محدود شد.`);
      }catch(error){toast(`${file.name}: ${error.message||'خواندن PDF ناموفق بود'}`)}
      continue;
    }
    if(/\.(xlsx|xlsm|csv)$/i.test(file.name)){
      try{
        if(pendingPdfAttachments.length+pendingSpreadsheetAttachments.length+pendingZipAttachments.length>=2)throw new Error('در هر پیام حداکثر دو سند PDF، Excel یا ZIP می‌توانی پیوست کنی.');
        const prepared=await window.SayroxChatSpreadsheetInput.prepareSpreadsheetFile(file);
        pendingSpreadsheetAttachments.push(prepared);addedSpreadsheets++;await rememberFileInLibrary(file);rememberLegacyFileName(file.name);
        if(prepared.truncated)toast(`${file.name}: متن برای تحلیل به ${prepared.includedChars.toLocaleString('fa-IR')} نویسه محدود شد.`);
        if(prepared.macrosIgnored)toast(`${file.name}: محتوای سلول‌ها خوانده می‌شود؛ ماکروها و کدهای VBA اجرا نمی‌شوند.`);
      }catch(error){toast(`${file.name}: ${error.message||'خواندن فایل Excel ناموفق بود'}`)}
      continue;
    }
    if(file.size>20*1024*1024){toast(`${file.name}: حجم فایل بیش از ۲۰ مگابایت است`);continue}
    if(/\.(txt|md|csv|json|xml|html?|css|js|mjs|ts|tsx|jsx|py|java|c|cpp|h|cs|php|rb|go|rs|sql|ya?ml)$/i.test(file.name)){
      try{
        const content=await file.text();
        $('#promptInput').value+=`\n\n[فایل ${file.name}]\n${content.slice(0,12000)}`;
        ingested++;await rememberFileInLibrary(file);rememberLegacyFileName(file.name);
      }catch{toast(`خواندن ${file.name} ناموفق بود`)}
    }else{
      try{await rememberFileInLibrary(file);rememberLegacyFileName(file.name);toast(`${file.name}: در کتابخانه ذخیره شد؛ تحلیل مستقیم این نوع فایل در چت هنوز فعال نیست.`)}
      catch(error){toast(`${file.name}: ${error.message}`)}
    }
  }
  if(addedImages||addedPdfs||addedSpreadsheets||addedArchives)renderPendingImages();
  if(addedImages)toast(`${addedImages} تصویر برای ارسال آماده شد؛ متن دلخواهت را هم می‌توانی بنویسی.`);
  if(addedPdfs||addedSpreadsheets||addedArchives)toast('متن PDF، Excel یا ZIP روی دستگاه استخراج شد؛ با ارسال پیام فقط متن استخراج‌شده برای تحلیل فرستاده می‌شود، نه فایل اصلی.');
  if(ingested)toast(`${ingested} فایل متنی به پیام اضافه شد`);
  resizeInput();updateComposerButton();
}
window.SayroxChatFileBridge=Object.freeze({
  attachFromLibrary:async id=>{
    try{const entry=await window.SayroxFileLibrary.get(id);if(!entry?.file)throw new Error('فایل در کتابخانه پیدا نشد.');setView('chat');await processChatFileSelection([entry.file]);toast('فایل از کتابخانه برای گفتگو آماده شد.')}
    catch(error){toast(error.message||'افزودن فایل از کتابخانه ناموفق بود.')}
  }
});
$('#chatFileInput').onchange=async e=>{
  try{await processChatFileSelection([...e.target.files])}
  finally{e.target.value=''}
};
$('#micBtn').onclick=startSTT;
$('#voiceBtn').onclick=()=>{
  $('#promptInput').value.trim()||pendingImageAttachments.length||pendingPdfAttachments.length||pendingSpreadsheetAttachments.length||pendingZipAttachments.length?sendMessage():showVoice()
};
$('#modelBtn').onclick=showModelPicker;
$('#drawer').querySelectorAll('[data-nav]').forEach(b=>b.addEventListener('click',()=>{
  const key=b.dataset.nav;
  hideDrawer();
  if(key==='upgrade'){openSettings();openSettingDetail('plans','ارتقا به Plus / Pro')}else openModule(key,b.textContent.trim())
}));
$('#moduleBack').onclick=()=>setView('chat');
$('#moduleInfo').onclick=()=>toast('اطلاعات این بخش در راهنمای پروژه آمده است');
$('#modelName').textContent=state.model==='auto'?'مدل خودکار':state.model.split('/').pop();
updateComposerButton();
if(state.deepMode){state.conversationMode='deep';persist()}
updateConversationModeUI();
updateToolMenu();
$('#tempChatBtn').onclick=()=>{
  let c=activeChat();
  if(!c){newChat();c=activeChat()}
  if(!c||c.messages.length)return;
  c.temp=!c.temp;
  $('#tempChatBtn').classList.toggle('is-on',c.temp);
  toast(c.temp?'گفتگوی موقت روشن شد؛ این گفتگو ذخیره نمی‌شود.':'گفتگوی موقت خاموش شد.');
  persist()
};// Header overflow menu
function toggleHeaderMenu(force){
  const el=$('#headerMenu');
  el.classList.toggle('open',force??!el.classList.contains('open'))
}
$('#topMoreBtn').onclick=()=>toggleHeaderMenu();
$('#headerMenuNew').onclick=()=>{toggleHeaderMenu(false);newChat()};
$('#headerMenuSettings').onclick=()=>{toggleHeaderMenu(false);openSettings()};
$('#headerMenuExport').onclick=()=>{toggleHeaderMenu(false);exportData()};// Plus menu with real toggles
function updateToolMenu(){
  const auto=state.searchMode==='auto',always=state.searchMode==='always',off=state.searchMode==='off';
  $('#toolAutoSearch').setAttribute('aria-pressed',String(auto));
  $('#autoSearchToolState').textContent=auto?'فعال':'خاموش';
  $('#toolSearch').setAttribute('aria-pressed',String(always&&state.webSearchTopic==='general'));
  $('#searchToolState').textContent=always&&state.webSearchTopic==='general'?'فعال':'خاموش';
  $('#toolNews').setAttribute('aria-pressed',String(always&&state.webSearchTopic==='news'));
  $('#newsSearchToolState').textContent=always&&state.webSearchTopic==='news'?'فعال':'خاموش';
  $('#toolNoSearch').setAttribute('aria-pressed',String(off));
  $('#noSearchToolState').textContent=off?'فعال':'خاموش';
  $('#toolDeep').setAttribute('aria-pressed',String(state.deepMode));
  $('#deepToolState').textContent=state.deepMode?'روشن':'خاموش';
  $('#deepModeLabel').classList.toggle('hidden',!state.deepMode);
  $('#toolMenuFoot').textContent=auto?'حالت پیش‌فرض: جست‌وجو فقط وقتی انجام می‌شود که سؤال به اطلاعات تازه، قیمت، خبر، هوا یا اطلاعات متغیر نیاز داشته باشد.':always?(state.webSearchTopic==='news'?'برای تمام پیام‌ها جست‌وجوی خبری با بازه‌ی یک‌هفته‌ای انجام می‌شود.':'برای تمام پیام‌ها جست‌وجوی عمومی اینترنت انجام می‌شود.'):'جست‌وجوی وب غیرفعال است؛ حتی برای پرسش‌های زمان‌مند هم وب بررسی نمی‌شود.'
}
function resolveSearchPlan(query){
  return window.SayroxSearchIntent.resolve(query,state.searchMode,state.webSearchTopic)
}
function toggleToolMenu(force){
  const menu=$('#toolMenu'),open=force??!menu.classList.contains('open');
  if(open){const modeMenu=$('#conversationModeMenu');modeMenu?.classList.remove('open');modeMenu?.setAttribute('aria-hidden','true');$('#conversationModeBtn')?.setAttribute('aria-expanded','false')}
  menu.classList.toggle('open',open);
  $('#attachBtn').setAttribute('aria-expanded',String(open));
  menu.setAttribute('aria-hidden',String(!open))
}
$('#attachBtn').onclick=()=>toggleToolMenu();
$('#toolFile').onclick=()=>{toggleToolMenu(false);$('#chatFileInput').click()};
$('#toolFileStudio').onclick=()=>{toggleToolMenu(false);openModule('file-studio','استودیو فایل')};
$('#toolAutoSearch').onclick=()=>{
  state.searchMode='auto';
  persist();
  updateToolMenu();
  toast('تشخیص هوشمند جست‌وجو فعال شد')
};
$('#toolSearch').onclick=()=>{
  const selected=state.searchMode==='always'&&state.webSearchTopic==='general';
  state.searchMode=selected?'auto':'always';
  state.webSearchTopic='general';
  persist();
  updateToolMenu();
  toast(selected?'به تشخیص هوشمند برگشتی':'جست‌وجوی عمومی برای همه‌ی پیام‌ها فعال شد')
};
$('#toolNews').onclick=()=>{
  const selected=state.searchMode==='always'&&state.webSearchTopic==='news';
  state.searchMode=selected?'auto':'always';
  state.webSearchTopic='news';
  persist();
  updateToolMenu();
  toast(selected?'به تشخیص هوشمند برگشتی':'جست‌وجوی خبری برای همه‌ی پیام‌ها فعال شد')
};
$('#toolNoSearch').onclick=()=>{
  state.searchMode=state.searchMode==='off'?'auto':'off';
  persist();
  updateToolMenu();
  toast(state.searchMode==='off'?'جست‌وجوی اینترنت غیرفعال شد':'تشخیص هوشمند جست‌وجو فعال شد')
};
$('#toolDeep').onclick=()=>{
  state.deepMode=!state.deepMode;
  state.conversationMode=state.deepMode?'deep':'auto';
  persist();
  updateToolMenu();
  updateConversationModeUI();
  toast(state.deepMode?'حالت تحلیل عمیق فعال شد':'تحلیل عمیق خاموش شد')
};
document.addEventListener('click',e=>{
  if(!e.target.closest('#toolMenu')&&!e.target.closest('#attachBtn'))toggleToolMenu(false);
  if(!e.target.closest('#conversationModeMenu')&&!e.target.closest('#conversationModeBtn'))toggleConversationModeMenu(false);
  if(!e.target.closest('#headerMenu')&&!e.target.closest('#topMoreBtn'))toggleHeaderMenu(false)
});

$('#conversationModeMenu').addEventListener('keydown',event=>{
  const items=[...$('#conversationModeMenu').querySelectorAll('[data-conversation-mode]')];
  const index=items.indexOf(document.activeElement);
  if(index<0)return;
  let next=index;
  if(event.key==='ArrowDown')next=(index+1)%items.length;
  else if(event.key==='ArrowUp')next=(index-1+items.length)%items.length;
  else if(event.key==='Home')next=0;
  else if(event.key==='End')next=items.length-1;
  else return;
  event.preventDefault();items[next].focus();
});

document.addEventListener('keydown',event=>{
  if(event.key!=='Escape')return;
  if($('#conversationModeMenu')?.classList.contains('open')){toggleConversationModeMenu(false);$('#conversationModeBtn').focus({preventScroll:true});return}
  if($('#toolMenu').classList.contains('open')){toggleToolMenu(false);$('#attachBtn').focus({preventScroll:true})}
});
