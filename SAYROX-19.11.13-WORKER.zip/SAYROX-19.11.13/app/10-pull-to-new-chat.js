// Pull-down gesture to start a new chat
// Part of the SAYROX app closure: parts are concatenated in file order by scripts/build-app.mjs.
// Do not edit site/src/app.js directly.
// Pull-down gesture: only while the chat scroll is already at its top edge.
let pullStartY=null,pullDistance=0,pullArmed=false;
$('#chatScroll').addEventListener('touchstart',e=>{
  if(e.touches.length!==1||$('#chatScroll').scrollTop>0||e.target.closest('button,input,textarea,select,a')){pullStartY=null;return}
  pullStartY=e.touches[0].clientY;
  pullDistance=0;
  pullArmed=false
},{passive:true});
$('#chatScroll').addEventListener('touchmove',e=>{
  if(pullStartY===null||e.touches.length!==1||$('#chatScroll').scrollTop>0)return;
  const delta=e.touches[0].clientY-pullStartY;
  if(delta<=0){pullDistance=0;return}
  if(delta>12)e.preventDefault();
  pullDistance=Math.min(120,delta*.62);
  const indicator=$('#pullIndicator');
  indicator.classList.add('active');
  indicator.classList.toggle('ready',pullDistance>78);
  indicator.style.height=`${Math.min(48,pullDistance*.42)}px`;
  indicator.querySelector('span:last-child').textContent=pullDistance>78?'رها کن تا گفتگوی جدید باز شود':'برای گفتگوی جدید بیشتر بکش';
  pullArmed=pullDistance>78
},{passive:false});
function finishPull(complete=true){
  if(complete&&pullArmed){newChat();toast('گفتگوی جدید باز شد')}
  $('#pullIndicator').classList.remove('active','ready');
  $('#pullIndicator').style.height='0';
  pullStartY=null;
  pullDistance=0;
  pullArmed=false
}
$('#chatScroll').addEventListener('touchend',()=>finishPull(true),{passive:true});
$('#chatScroll').addEventListener('touchcancel',()=>finishPull(false),{passive:true});
