// Sign-in / sign-up UI, protected-API gate, logout
// Part of the SAYROX app closure: parts are concatenated in file order by scripts/build-app.mjs.
// Do not edit site/src/app.js directly.
// Local-only mode remains available; provider APIs require a validated account session.
let authMode='login',authProviders=false;
function setAuthMode(mode){
  authMode=mode;
  const signup=mode==='signup';
  $('#authSignInTab').classList.toggle('active',!signup);
  $('#authSignUpTab').classList.toggle('active',signup);
  $('#authSignInTab').setAttribute('aria-selected',String(!signup));
  $('#authSignUpTab').setAttribute('aria-selected',String(signup));
  $('#authNameWrap').classList.toggle('hidden',!signup);
  $('#authName').required=signup;
  $('#authPassword').autocomplete=signup?'new-password':'current-password';
  $('#authTitle').textContent=signup?'حساب SAYROX بساز':'به SAYROX خوش آمدی';
  $('#authSubtitle').textContent=signup?'برای ساخت فضای شخصی خودت ثبت‌نام کن.':'برای ادامه وارد حساب خودت شو.';
  $('#authSubmit').textContent=signup?'ساخت حساب':'ورود به حساب';
  $('#authStatus').textContent='';
  $('#authStatus').className='auth-status'
}
$('#authSignInTab').onclick=()=>setAuthMode('login');
$('#authSignUpTab').onclick=()=>setAuthMode('signup');
function setAuthStatus(text,kind=''){
  const el=$('#authStatus');
  el.textContent=text;
  el.className='auth-status '+kind
}
function userLabel(){
  return state.user?(state.user.displayName||state.user.email||'حساب کاربری'):(state.guest?'مهمان':'مهمان')
}
function userInitials(){
  const name=(state.user?.displayName||state.user?.email||'').trim();
  if(!name)return 'X';
  const parts=name.replace(/@.*$/,'').split(/[\s._-]+/).filter(Boolean);
  return ((parts[0]?.[0]||'')+(parts[1]?.[0]||parts[0]?.[1]||'')).toUpperCase()||'X'
}
function refreshAccountUI(){
  const av=$('#drawerAvatar');
  if(av)av.textContent=userInitials();
  $('#openSettings').title=userLabel();
  settingsFeature?.refreshMemoryForAccount?.();
  if(state.view==='settings')settingsFeature?.renderList($('#settingsSearch').value||'')
}
function enterGuest(){
  state.guest=true;
  state.user=null;
  $('#authScreen').classList.add('hidden');
  refreshAccountUI();
  toast('حالت محلی فعال شد؛ برای چت، جست‌وجوی وب و صدای اختصاصی باید وارد حساب شوی')
}
function enterAccount(user){
  state.user=user;
  state.guest=false;
  $('#authScreen').classList.add('hidden');
  refreshAccountUI();
  toast('ورود موفق بود');
  checkTaskInbox(true)
}
function requireAccountForProtectedApis(){
  if(state.user)return true;
  $('#authScreen').classList.remove('hidden');
  setAuthMode('login');
  setAuthStatus(authProviders?'برای استفاده از چت هوشمند، جست‌وجوی وب و صدای اختصاصی ابتدا وارد حساب SAYROX شو.':'سرویس حساب روی Worker هنوز پیکربندی نشده است؛ تا فعال‌شدن آن، APIهای ابری در دسترس نیستند.','error');
  return false
}
function protectedApiAuthError(response,data){
  if(response.status===401&&data.code==='AUTH_REQUIRED'){
    state.user=null;
    state.guest=true;
    refreshAccountUI();
    $('#authScreen').classList.remove('hidden');
    setAuthMode('login');
    setAuthStatus(data.message||'نشست حساب معتبر نیست؛ دوباره وارد شو.','error');
    return Object.assign(new Error(data.message||'ورود به حساب لازم است.'),{authGate:true})
  }
  if(response.status===503&&data.code==='AUTH_UNAVAILABLE'){
    if(!state.user)state.guest=true;
    $('#authScreen').classList.remove('hidden');
    setAuthMode('login');
    setAuthStatus(data.message||'سرویس ورود در دسترس نیست.','error');
    $('#authFootnote').textContent='زیرساخت احراز هویت در Worker آماده نیست؛ درخواست‌های هزینه‌دار تا زمان رفع مشکل مسدود می‌مانند.';
    return Object.assign(new Error(data.message||'سرویس ورود در دسترس نیست.'),{authGate:true})
  }
  return null
}
async function initAuth(){
  if(!['https:','http:'].includes(location.protocol)){
    authProviders=false;
    $('#authFootnote').textContent='این فایل به‌صورت محلی باز شده است. برای ورود واقعی، آن را روی Cloudflare Worker اصلی `sayrox` همراه با زیرساخت حساب مستقر کن. حالت محلی فقط قابلیت‌های مرورگر را دارد.';
    return
  }
  try{
    const health=await fetch('/api/health').then(r=>r.json());
    authProviders=Boolean(health.providers?.auth);
    if(authProviders)$('#authFootnote').textContent='چت هوشمند، جست‌وجوی وب و صدای اختصاصی فقط پس از ورود فعال‌اند؛ نشست با کوکی HttpOnly و Durable Objects اعتبارسنجی می‌شود.';
    if(!authProviders)$('#authFootnote').textContent='زیرساخت حساب Cloudflare هنوز کامل نیست. حالت محلی فقط قابلیت‌های مرورگر را دارد و APIهای هزینه‌دار تا فعال‌شدن ورود مسدود هستند.';
    const me=await fetch('/api/auth/me',{credentials:'same-origin'}).then(r=>r.json()).catch(()=>null);
    if(me?.authenticated&&me.user){enterAccount(me.user);return}
  }catch{
    $('#authFootnote').textContent='سرویس حساب در دسترس نیست؛ قابلیت‌های ابری تا برقراری احراز هویت مسدود هستند.'
  }
  state.authReady=true
}
$('#authForm').addEventListener('submit',async e=>{
  e.preventDefault();
  if(!authProviders){
    setAuthStatus('ورود واقعی هنوز فعال نیست؛ ابتدا زیرساخت حساب را طبق راهنمای استقرار متصل کن.','error');
    return
  }
  const button=$('#authSubmit');
  button.disabled=true;
  button.textContent='در حال بررسی…';
  try{
    const payload={email:$('#authEmail').value.trim(),password:$('#authPassword').value};
    if(authMode==='signup')payload.displayName=$('#authName').value.trim();
    const response=await fetch(`/api/auth/${authMode}`,{
      method:'POST',
      credentials:'same-origin',
      headers:{'content-type':'application/json'},
      body:JSON.stringify(payload)
    });
    const data=await response.json().catch(()=>({}));
    if(!response.ok||!data.ok)throw new Error(data.message||'ورود انجام نشد.');
    enterAccount(data.user)
  }catch(err){setAuthStatus(err.message||'خطای ورود.','error')}finally{
    button.disabled=false;
    button.textContent=authMode==='signup'?'ساخت حساب':'ورود به حساب'
  }
});
$('#authForgot').onclick=()=>setAuthStatus('بازیابی رمز از طریق ایمیل هنوز به سرویس ارسال ایمیل متصل نشده است. برای امنیت، رمز را از این فرم دریافت یا بازیابی نمی‌کنیم.','error');
$('#authGuest').onclick=enterGuest;
async function logoutAccount(){
  showModal('خروج از حساب','<p>از حساب SAYROX خارج شوی؟ گفتگوهای محلی این دستگاه حذف نمی‌شوند.</p>','خروج',async()=>{
    try{
      if(state.user&&['http:','https:'].includes(location.protocol))await fetch('/api/auth/logout',{method:'POST',credentials:'same-origin'}).catch(()=>{})
    }finally{
      state.user=null;
      state.guest=false;
      refreshAccountUI();
      $('#authScreen').classList.remove('hidden');
      setAuthMode('login');
      toast('از حساب خارج شدی')
    }
  })
}
