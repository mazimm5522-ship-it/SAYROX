// Image studio: prompt → POST /api/images/generate. The gallery lives only in this browser (IndexedDB), never on the server.
// Part of the SAYROX app closure: parts are concatenated in file order by scripts/build-app.mjs.
// Do not edit site/src/app.js directly.
const IMAGE_DB_NAME='xynora-images',IMAGE_STORE='gallery',IMAGE_GALLERY_LIMIT=40;
const IMAGE_RATIOS=[['1:1','مربع'],['3:4','عمودی'],['4:3','افقی'],['9:16','استوری'],['16:9','پهن']];
const imageStudio={ratio:'1:1',prompt:'',busy:false,urls:[]};
const idbRequest=request=>new Promise((resolve,reject)=>{
  request.onsuccess=()=>resolve(request.result);
  request.onerror=()=>reject(request.error||new Error('عملیات ذخیره‌سازی ناموفق بود.'))
});
function openImageDb(){
  return new Promise((resolve,reject)=>{
    if(!('indexedDB'in window)){reject(new Error('این مرورگر ذخیره‌سازی تصویر را پشتیبانی نمی‌کند.'));return}
    const request=indexedDB.open(IMAGE_DB_NAME,1);
    request.onupgradeneeded=()=>request.result.createObjectStore(IMAGE_STORE,{keyPath:'id'});
    request.onsuccess=()=>resolve(request.result);
    request.onerror=()=>reject(request.error||new Error('باز کردن ذخیره‌سازی تصویر ناموفق بود.'))
  })
}
async function imageGalleryRun(mode,work){
  const db=await openImageDb();
  try{return await work(db.transaction(IMAGE_STORE,mode).objectStore(IMAGE_STORE))}
  finally{db.close()}
}
async function imageGalleryList(){
  const items=await imageGalleryRun('readonly',store=>idbRequest(store.getAll()));
  return items.sort((a,b)=>b.createdAt-a.createdAt)
}
async function imageGallerySave(item){
  await imageGalleryRun('readwrite',store=>idbRequest(store.put(item)));
  const extra=(await imageGalleryList()).slice(IMAGE_GALLERY_LIMIT);
  for(const old of extra)await imageGalleryRun('readwrite',store=>idbRequest(store.delete(old.id)))
}
function imageStatusSay(message){
  const el=$('#imageStatus');
  if(el)el.textContent=message
}
async function paintImageGallery(){
  const grid=$('#imageGrid');
  if(!grid)return;
  imageStudio.urls.forEach(url=>URL.revokeObjectURL(url));
  imageStudio.urls=[];
  let items=[];
  try{items=await imageGalleryList()}catch(error){grid.innerHTML=`<div class="module-note">${escapeHtml(error.message)}</div>`;return}
  if(!$('#imageGrid'))return;
  if(!items.length){grid.innerHTML='<div class="module-note">هنوز تصویری نساخته‌ای. تصویرها فقط در همین مرورگر نگهداری می‌شوند.</div>';return}
  grid.innerHTML=items.map(item=>{
    const url=URL.createObjectURL(item.blob);
    imageStudio.urls.push(url);
    const extension=item.mimeType==='image/jpeg'?'jpg':item.mimeType==='image/webp'?'webp':'png';
    return `<figure class="image-card"><img src="${url}" alt="${escapeHtml(item.prompt)}" loading="lazy"><figcaption>${escapeHtml(item.prompt)}<small>${escapeHtml(item.ratio)} · ${new Date(item.createdAt).toLocaleDateString('fa-IR')}</small></figcaption><div class="image-actions"><a class="secondary-btn" href="${url}" download="sayrox-${escapeHtml(item.id.slice(0,8))}.${extension}">ذخیره</a><button class="secondary-btn" type="button" data-image-reuse="${escapeHtml(item.id)}">استفادهٔ دوباره</button><button class="secondary-btn" type="button" data-image-delete="${escapeHtml(item.id)}">حذف</button></div></figure>`
  }).join('');
  grid.querySelectorAll('[data-image-delete]').forEach(button=>button.onclick=async()=>{
    try{await imageGalleryRun('readwrite',store=>idbRequest(store.delete(button.dataset.imageDelete)))}catch(error){toast(error.message);return}
    paintImageGallery()
  });
  grid.querySelectorAll('[data-image-reuse]').forEach(button=>button.onclick=()=>{
    const item=items.find(entry=>entry.id===button.dataset.imageReuse);
    if(!item)return;
    imageStudio.prompt=item.prompt;
    imageStudio.ratio=item.ratio;
    renderImagesStudio($('#moduleContent'))
  })
}
async function generateImage(){
  if(imageStudio.busy)return;
  const prompt=($('#imagePrompt')?.value||'').trim();
  imageStudio.prompt=prompt;
  if(prompt.length<3){imageStatusSay('توضیح تصویر را کمی کامل‌تر بنویس.');return}
  if(!['http:','https:'].includes(location.protocol)){imageStatusSay('ساخت تصویر فقط روی نسخهٔ منتشرشده کار می‌کند.');return}
  if(!requireAccountForProtectedApis())return;
  imageStudio.busy=true;
  const button=$('#imageGenerate');
  if(button)button.disabled=true;
  imageStatusSay('در حال ساخت تصویر… این کار تا یک دقیقه طول می‌کشد.');
  try{
    const response=await fetch('/api/images/generate',{method:'POST',credentials:'same-origin',headers:{'content-type':'application/json'},body:JSON.stringify({prompt,ratio:imageStudio.ratio})});
    const data=await response.json().catch(()=>({}));
    if(!response.ok||!data.ok){
      const authError=protectedApiAuthError(response,data);
      if(authError)throw authError;
      throw new Error(data.message||'ساخت تصویر ناموفق بود.')
    }
    const blob=await (await fetch(data.image.dataUrl)).blob();
    await imageGallerySave({id:crypto.randomUUID(),prompt:data.prompt,ratio:data.ratio,createdAt:Date.now(),mimeType:data.image.mimeType,blob});
    imageStatusSay('تصویر ساخته و در گالری همین مرورگر ذخیره شد.');
    toast('تصویر ساخته شد');
    await paintImageGallery()
  }catch(error){
    if(!error.authGate)imageStatusSay(error.message||'ساخت تصویر ناموفق بود.')
  }finally{
    imageStudio.busy=false;
    const again=$('#imageGenerate');
    if(again)again.disabled=false
  }
}
function renderImagesStudio(root){
  root.innerHTML=`<h2>تصاویر</h2><p>تصویر بساز؛ هر ساخت یک واحد از سهمیهٔ «تولید تصویر» پلن را مصرف می‌کند و فقط خروجی موفق شمرده می‌شود.</p>
    <div class="studio-card">
      <textarea class="field" id="imagePrompt" rows="3" maxlength="1200" aria-label="توضیح تصویر" placeholder="تصویر را توصیف کن؛ مثلاً: غروب خورشید روی کویر با کاروان شتر، سبک نقاشی رنگ‌روغن">${escapeHtml(imageStudio.prompt)}</textarea>
      <div class="studio-chips" role="radiogroup" aria-label="نسبت تصویر">${IMAGE_RATIOS.map(([value,label])=>`<button type="button" class="studio-chip${value===imageStudio.ratio?' active':''}" role="radio" aria-checked="${value===imageStudio.ratio}" data-ratio="${value}">${label}<small>${value}</small></button>`).join('')}</div>
      <div class="studio-row"><button class="primary-btn" id="imageGenerate" type="button">ساخت تصویر</button><span class="studio-status" id="imageStatus" role="status" aria-live="polite"></span></div>
    </div>
    <div class="image-grid" id="imageGrid"></div>`;
  root.querySelectorAll('[data-ratio]').forEach(chip=>chip.onclick=()=>{
    imageStudio.ratio=chip.dataset.ratio;
    root.querySelectorAll('[data-ratio]').forEach(other=>{
      const active=other===chip;
      other.classList.toggle('active',active);
      other.setAttribute('aria-checked',String(active))
    })
  });
  $('#imagePrompt').addEventListener('input',e=>{imageStudio.prompt=e.target.value});
  $('#imageGenerate').onclick=generateImage;
  if(['http:','https:'].includes(location.protocol)){
    fetch('/api/health').then(r=>r.json()).then(health=>{
      if(health.providers?.images)return;
      const button=$('#imageGenerate');
      if(button)button.disabled=true;
      imageStatusSay('ساخت تصویر هنوز روی این سرور پیکربندی نشده است (OPENROUTER_IMAGE_MODEL).')
    }).catch(()=>{})
  }
  paintImageGallery()
}
