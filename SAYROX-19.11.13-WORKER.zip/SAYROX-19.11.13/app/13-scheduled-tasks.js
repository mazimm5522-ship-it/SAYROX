// Scheduled tasks: stored and executed server-side by the Scheduler Durable Object; results land in the inbox below.
// Part of the SAYROX app closure: parts are concatenated in file order by scripts/build-app.mjs.
// Do not edit site/src/app.js directly.
const TASK_WEEKDAYS=[[6,'شنبه'],[0,'یکشنبه'],[1,'دوشنبه'],[2,'سه‌شنبه'],[3,'چهارشنبه'],[4,'پنجشنبه'],[5,'جمعه']];
const TASK_STATUS={ok:['انجام شد','ok'],failed:['ناموفق','bad'],quota:['سهمیه تمام شد','warn'],missed:['از دست رفت','warn'],running:['در حال اجرا','info'],dispatched:['در صف اجرا','info']};
const taskInbox={checkedAt:0,announced:0};
function taskZone(){
  try{return Intl.DateTimeFormat().resolvedOptions().timeZone||'Asia/Tehran'}catch{return 'Asia/Tehran'}
}
function describeSchedule(schedule){
  if(schedule.type==='daily')return `هر روز ساعت ${schedule.time}`;
  if(schedule.type==='weekly')return `هر ${TASK_WEEKDAYS.find(([value])=>value===schedule.weekday)?.[1]||''} ساعت ${schedule.time}`;
  return `یک‌بار در ${schedule.date} ساعت ${schedule.time}`
}
async function taskFetch(path,body){
  const init=body===undefined?{credentials:'same-origin',headers:{accept:'application/json'}}:{method:'POST',credentials:'same-origin',headers:{'content-type':'application/json'},body:JSON.stringify(body)};
  const response=await fetch(path,init);
  const data=await response.json().catch(()=>({}));
  if(!response.ok||!data.ok){
    const authError=protectedApiAuthError(response,data);
    if(authError)throw authError;
    throw Object.assign(new Error(data.message||'درخواست انجام نشد.'),{code:data.code})
  }
  return data
}
function taskStatusBadge(status){
  const [label,tone]=TASK_STATUS[status]||[status,'info'];
  return `<span class="task-badge ${tone}">${label}</span>`
}
function taskSay(message){
  const el=$('#taskStatus');
  if(el)el.textContent=message
}
function taskFormHtml(){
  const tomorrow=new Date(Date.now()+86400000).toISOString().slice(0,10);
  return `<form class="studio-card task-form" id="taskCreateForm">
    <input class="field" id="taskTitle" maxlength="80" required placeholder="عنوان کار؛ مثلاً: خلاصهٔ خبرهای فناوری">
    <textarea class="field" id="taskPrompt" rows="3" maxlength="2000" required placeholder="دستور کار؛ مثلاً: مهم‌ترین خبرهای فناوری امروز را در پنج مورد خلاصه کن"></textarea>
    <div class="task-grid">
      <label>تکرار<select class="field" id="taskType"><option value="daily">هر روز</option><option value="weekly">هر هفته</option><option value="once">یک‌بار</option></select></label>
      <label>ساعت<input class="field" id="taskTime" type="time" value="09:00" required></label>
      <label id="taskWeekdayWrap" hidden>روز هفته<select class="field" id="taskWeekday">${TASK_WEEKDAYS.map(([value,label])=>`<option value="${value}">${label}</option>`).join('')}</select></label>
      <label id="taskDateWrap" hidden>تاریخ<input class="field" id="taskDate" type="date" value="${tomorrow}"></label>
    </div>
    <label class="task-check"><input type="checkbox" id="taskSearch"> با جست‌وجوی وب (یک واحد از سهمیهٔ جست‌وجو در هر اجرا)</label>
    <div class="studio-row"><button class="primary-btn" type="submit">ثبت کار</button><span class="studio-status" id="taskStatus" role="status" aria-live="polite"></span></div>
  </form>`
}
function taskListHtml(data){
  const tasks=data.tasks.length?data.tasks.map(task=>`<div class="module-item task-item"><span>${escapeHtml(task.title)}<small>${escapeHtml(describeSchedule(task.schedule))}${task.useSearch?' · با جست‌وجو':''}</small><small>${task.enabled&&task.nextRun?`اجرای بعدی: ${new Date(task.nextRun).toLocaleString('fa-IR')}`:'متوقف'}</small></span><span class="task-actions"><button class="secondary-btn" type="button" data-task-action="run" data-id="${task.id}">اجرای فوری</button><button class="secondary-btn" type="button" data-task-action="toggle" data-enabled="${task.enabled?'0':'1'}" data-id="${task.id}">${task.enabled?'توقف':'ادامه'}</button><button class="secondary-btn" type="button" data-task-action="delete" data-id="${task.id}">حذف</button></span></div>`).join(''):'<div class="module-note">هنوز کاری زمان‌بندی نکرده‌ای.</div>';
  const runs=data.runs.length?data.runs.map(run=>`<details class="module-item task-run"><summary>${taskStatusBadge(run.status)} ${escapeHtml(run.title)}<small>${new Date(run.startedAt).toLocaleString('fa-IR')}${run.searchUsed?' · با جست‌وجو':''}</small></summary>${run.output?`<div class="task-output">${escapeHtml(run.output)}</div><button class="secondary-btn" type="button" data-task-copy="${run.runId}">کپی نتیجه</button>`:`<div class="module-note">${escapeHtml(run.error||'نتیجه‌ای ثبت نشد.')}</div>`}</details>`).join(''):'<div class="module-note">هنوز اجرایی انجام نشده است.</div>';
  const legacy=state.tasks.length?`<h3>کارهای قدیمیِ محلی</h3><p class="module-note">این فهرست فقط در همین مرورگر بود و اجرای خودکار نداشت. برای زمان‌بندی واقعی، کار جدید بساز.</p><div class="module-list">${state.tasks.map((task,index)=>`<div class="module-item"><span>${escapeHtml(task.name)}<small>${task.date?new Date(task.date).toLocaleString('fa-IR'):'بدون زمان'}</small></span><span class="task-actions"><button class="secondary-btn" type="button" data-legacy-use="${index}">استفاده در فرم</button><button class="secondary-btn" type="button" data-legacy-remove="${index}">حذف</button></span></div>`).join('')}</div>`:'';
  return `<h3>کارهای من <small>${data.tasks.length} از ${data.limit}</small></h3><div class="module-list">${tasks}</div><h3>نتیجهٔ اجراها</h3><div class="module-list">${runs}</div>${legacy}`
}
async function renderTasksPage(root){
  const head='<h2>کارهای زمان‌بندی‌شده</h2><p>کار را یک‌بار تعریف کن؛ سرور در زمان تعیین‌شده آن را اجرا و نتیجه را همین‌جا نگه می‌دارد، حتی وقتی برنامه بسته است. هر اجرا یک واحد از سهمیهٔ گفتگوی پلن را مصرف می‌کند.</p>';
  if(!['http:','https:'].includes(location.protocol)){root.innerHTML=`${head}<div class="module-note">کارهای زمان‌بندی‌شده فقط روی نسخهٔ منتشرشده کار می‌کنند.</div>`;return}
  if(!state.user){
    root.innerHTML=`${head}<div class="module-note">برای ساخت کار زمان‌بندی‌شده باید وارد حساب شوی.</div><button class="primary-btn" id="taskSignIn" type="button">ورود به حساب</button>`;
    $('#taskSignIn').onclick=()=>requireAccountForProtectedApis();
    return
  }
  root.innerHTML=`${head}<div class="module-note">در حال دریافت کارها…</div>`;
  let data;
  try{data=await taskFetch('/api/tasks')}catch(error){
    if(error.authGate){root.innerHTML=`${head}<div class="module-note">برای مدیریت کارها دوباره وارد شو.</div>`;return}
    root.innerHTML=`${head}<div class="module-note">${escapeHtml(error.code==='TASKS_UNAVAILABLE'?'سرویس کارهای زمان‌بندی‌شده هنوز روی این سرور پیکربندی نشده است.':error.message)}</div>`;
    return
  }
  root.innerHTML=`${head}${taskFormHtml()}<div id="taskLists">${taskListHtml(data)}</div>`;
  const syncFields=()=>{
    const type=$('#taskType').value;
    $('#taskWeekdayWrap').hidden=type!=='weekly';
    $('#taskDateWrap').hidden=type!=='once'
  };
  $('#taskType').onchange=syncFields;
  syncFields();
  $('#taskCreateForm').addEventListener('submit',async e=>{
    e.preventDefault();
    const type=$('#taskType').value;
    const schedule={type,time:$('#taskTime').value,timezone:taskZone(),...(type==='weekly'?{weekday:Number($('#taskWeekday').value)}:{}),...(type==='once'?{date:$('#taskDate').value}:{})};
    try{
      await taskFetch('/api/tasks',{title:$('#taskTitle').value.trim(),prompt:$('#taskPrompt').value.trim(),useSearch:$('#taskSearch').checked,schedule});
      toast('کار زمان‌بندی شد');
      renderTasksPage(root)
    }catch(error){
      if(!error.authGate)taskSay(error.message)
    }
  });
  root.onclick=async e=>{
    const button=e.target.closest('button');
    if(!button)return;
    try{
      if(button.dataset.taskAction==='run'){await taskFetch('/api/tasks/run-now',{id:button.dataset.id});toast('اجرا در صف قرار گرفت؛ نتیجه تا چند لحظه‌ی دیگر می‌رسد')}
      else if(button.dataset.taskAction==='toggle'){await taskFetch('/api/tasks/toggle',{id:button.dataset.id,enabled:button.dataset.enabled==='1'});renderTasksPage(root)}
      else if(button.dataset.taskAction==='delete'){await taskFetch('/api/tasks/delete',{id:button.dataset.id});renderTasksPage(root)}
      else if(button.dataset.taskCopy){
        const run=data.runs.find(entry=>entry.runId===button.dataset.taskCopy);
        await navigator.clipboard.writeText(run?.output||'');
        toast('نتیجه کپی شد')
      }
      else if(button.dataset.legacyUse!==undefined){
        const legacy=state.tasks[Number(button.dataset.legacyUse)];
        if(legacy){$('#taskTitle').value=legacy.name;$('#taskTitle').focus()}
      }
      else if(button.dataset.legacyRemove!==undefined){
        state.tasks.splice(Number(button.dataset.legacyRemove),1);
        persist();
        renderTasksPage(root)
      }
    }catch(error){
      if(!error.authGate)toast(error.message)
    }
  };
  if(data.unseen>0){
    taskFetch('/api/tasks/seen',{}).then(()=>{
      taskInbox.announced=0;
      document.querySelector('#drawer [data-nav="tasks"]')?.classList.remove('has-dot')
    }).catch(()=>{})
  }
}
/** Quiet background check: marks the drawer entry and announces new results once; never opens the sign-in screen. */
async function checkTaskInbox(force=false){
  if(!state.user||!['http:','https:'].includes(location.protocol))return;
  if(!force&&Date.now()-taskInbox.checkedAt<60000)return;
  taskInbox.checkedAt=Date.now();
  try{
    const response=await fetch('/api/tasks',{credentials:'same-origin',headers:{accept:'application/json'}});
    if(!response.ok)return;
    const data=await response.json();
    if(!data.ok)return;
    document.querySelector('#drawer [data-nav="tasks"]')?.classList.toggle('has-dot',data.unseen>0);
    if(data.unseen>taskInbox.announced&&state.view!=='module')toast(`${data.unseen} نتیجهٔ جدید از کارهای زمان‌بندی‌شده`);
    taskInbox.announced=data.unseen
  }catch{}
}
