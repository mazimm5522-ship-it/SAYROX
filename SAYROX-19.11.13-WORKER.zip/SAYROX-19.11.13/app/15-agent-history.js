// Persistent, privacy-minimal Agent execution history backed by the authenticated account Worker.
// Part of the SAYROX app closure; do not edit generated site/src/app.js directly.
const AGENT_HISTORY_LABELS={
  main:'دستیار اصلی',research:'پژوهشگر',coding:'برنامه‌نویس',documents:'متخصص اسناد',data:'تحلیلگر داده',creative:'متخصص خلاق',verification:'بازبین کیفیت'
};
const AGENT_HISTORY_STATES={
  running:['در حال اجرا','info'],streaming:['در حال ارسال پاسخ','info'],awaiting_approval:['در انتظار تأیید','warn'],completed:['تکمیل‌شده','ok'],failed:['ناموفق','bad'],cancelled:['لغوشده','warn']
};
const AGENT_HISTORY_TOOLS={
  web_research:'جست‌وجوی وب',read_url:'خواندن پیوند',calculate:'ماشین‌حساب',current_time:'زمان و تاریخ',inspect_attached_files:'بررسی فایل پیوست',create_file:'ساخت فایل',search_memory:'جست‌وجوی حافظه',generate_image:'تولید تصویر',create_scheduled_task:'زمان‌بندی کار'
};
const AGENT_HISTORY_RESEARCH={not_used:'بدون جست‌وجو',completed:'تحقیق انجام شد',unavailable:'جست‌وجو در دسترس نبود'};
function agentHistoryBadge(state){
  const [label,tone]=AGENT_HISTORY_STATES[state]||['نامشخص','warn'];
  return `<span class="task-badge ${tone}">${label}</span>`
}
function agentHistoryDuration(value){
  const ms=Math.max(0,Number(value)||0);
  return ms<1000?`${ms} میلی‌ثانیه`:ms<60000?`${(ms/1000).toFixed(1)} ثانیه`:`${Math.floor(ms/60000)} دقیقه و ${Math.round(ms%60000/1000)} ثانیه`
}
async function agentHistoryRequest(method='GET',body,query=''){
  const response=await fetch(`/api/agent/runs${query}`,{method,credentials:'same-origin',headers:body?{'content-type':'application/json'}:{accept:'application/json'},...(body?{body:JSON.stringify(body)}:{})});
  const data=await response.json().catch(()=>({}));
  if(!response.ok||!data.ok){
    const authError=protectedApiAuthError(response,data);
    if(authError)throw authError;
    throw Object.assign(new Error(data.message||'دریافت تاریخچهٔ Agent ناموفق بود.'),{code:data.code})
  }
  return data
}
function agentHistoryRunHtml(run){
  const specialist=AGENT_HISTORY_LABELS[run.specialist]||'دستیار';
  const when=Number(run.createdAt)>0?new Date(run.createdAt).toLocaleString('fa-IR'):'زمان نامشخص';
  const tools=Array.isArray(run.toolEvents)?run.toolEvents:[];
  const toolRows=tools.length?`<div class="module-list">${tools.map(event=>`<div class="module-item"><span>${escapeHtml(AGENT_HISTORY_TOOLS[event.tool]||event.tool||'ابزار نامشخص')}<small>${event.status==='success'?'اجرا موفق':event.status==='pending'?'در انتظار تأیید':event.status==='cancelled'?'لغو شد':'اجرا ناموفق'}${event.code?` · ${escapeHtml(event.code)}`:''}</small></span>${event.status==='success'?'<span class="task-badge ok">موفق</span>':event.status==='pending'?'<span class="task-badge warn">در انتظار تأیید</span>':event.status==='cancelled'?'<span class="task-badge warn">لغو شد</span>':'<span class="task-badge bad">ناموفق</span>'}</div>`).join('')}</div>`:'<div class="module-note">در این اجرا ابزار خارجی فراخوانی نشد.</div>';
  const research=AGENT_HISTORY_RESEARCH[run.researchStatus]||AGENT_HISTORY_RESEARCH.not_used;
  const id=escapeHtml(run.runId||'');
  return `<details class="module-item agent-history-item"><summary>${agentHistoryBadge(run.state)} <strong>${escapeHtml(specialist)}</strong><small>${escapeHtml(when)} · ${escapeHtml(agentHistoryDuration(run.durationMs))}</small></summary><div class="agent-history-details"><div class="agent-history-stats"><span>مراحل ابزار: <strong>${Number(run.stepCount)||0}</strong></span><span>منابع بررسی‌شده: <strong>${Number(run.sourceCount)||0}</strong></span><span>تحقیق: <strong>${escapeHtml(research)}</strong></span><span>مدل: <strong>${escapeHtml(run.model||'خودکار/پیکربندی‌شده')}</strong></span></div>${run.failureCode?`<p class="module-note">کد خطا: ${escapeHtml(run.failureCode)}</p>`:''}<h4>رویدادهای ابزار</h4>${toolRows}<div class="agent-history-actions"><code>${id}</code><button class="secondary-btn" type="button" data-agent-run-delete="${id}">حذف این اجرا</button></div></div></details>`
}
async function renderAgentHistoryPage(root,{offset=0,existingRuns=[]}={}){
  const head='<h2>تاریخچهٔ اجرای Agent</h2><p>گزارش قابل‌پیگیری از کارهایی که Main Agent واقعاً اجرا کرده است.</p>';
  if(!['http:','https:'].includes(location.protocol)){root.innerHTML=`${head}<div class="module-note">تاریخچهٔ پایدار فقط روی نسخهٔ منتشرشده و متصل به حساب کاربری در دسترس است.</div>`;return}
  if(!state.user){root.innerHTML=`${head}<div class="module-note">برای مشاهدهٔ تاریخچهٔ امن Agent باید وارد حساب شوی.</div><button class="primary-btn" id="agentHistorySignIn" type="button">ورود به حساب</button>`;$('#agentHistorySignIn').onclick=()=>requireAccountForProtectedApis();return}
  root.innerHTML=`${head}<div class="module-note">در حال دریافت تاریخچه از فضای ذخیره‌سازی امن حساب…</div>`;
  let data;
  try{data=await agentHistoryRequest('GET',undefined,`?limit=50&offset=${offset}`)}catch(error){
    if(error.authGate){root.innerHTML=`${head}<div class="module-note">نشست ورود معتبر نیست؛ دوباره وارد حساب شو.</div>`;return}
    root.innerHTML=`${head}<div class="module-note">${escapeHtml(error.message||'تاریخچه در دسترس نیست.')}</div><button class="secondary-btn" id="agentHistoryRetry">تلاش دوباره</button>`;
    root.querySelector('#agentHistoryRetry')?.addEventListener('click',()=>renderAgentHistoryPage(root));
    return
  }
  const pageRuns=Array.isArray(data.runs)?data.runs:[];
  const runs=[...existingRuns,...pageRuns];
  const list=runs.length?runs.map(agentHistoryRunHtml).join(''):'<div class="module-note">هنوز اجرای قابل‌ثبت برای این حساب وجود ندارد. مکالمه‌های موقت در تاریخچه ذخیره نمی‌شوند.</div>';
  root.innerHTML=`${head}<div class="module-note">حداکثر ${Number(data.maxRuns)||100} اجرا نگهداری می‌شود؛ نگهداری حداکثر ${Number(data.retentionDays)||90} روز است. متن پیام‌ها، پاسخ‌ها، محتوای فایل‌ها و آرگومان ابزارها ذخیره نمی‌شوند.</div><div class="studio-row agent-history-toolbar"><span>${runs.length} اجرا</span><span class="studio-row-spacer"></span><button class="secondary-btn" id="agentHistoryRefresh" type="button">تازه‌سازی</button><button class="secondary-btn" id="agentHistoryClear" type="button" ${runs.length?'':'disabled'}>پاک‌کردن همه</button></div><div class="module-list" id="agentHistoryList">${list}</div>${data.hasMore?'<div class="studio-row"><button class="secondary-btn" id="agentHistoryMore" type="button">نمایش اجراهای بیشتر</button></div>':''}`;
  $('#agentHistoryRefresh')?.addEventListener('click',()=>renderAgentHistoryPage(root));
  $('#agentHistoryMore')?.addEventListener('click',()=>renderAgentHistoryPage(root,{offset:offset+pageRuns.length,existingRuns:runs}));
  $('#agentHistoryClear')?.addEventListener('click',async()=>{
    if(!runs.length||!window.confirm('تمام تاریخچهٔ اجرای Agent برای این حساب پاک شود؟'))return;
    try{await agentHistoryRequest('POST',{action:'clear'});toast('تاریخچهٔ Agent پاک شد.');renderAgentHistoryPage(root)}catch(error){toast(error.message||'پاک‌کردن تاریخچه ناموفق بود.')}
  });
  $('#agentHistoryList')?.addEventListener('click',async event=>{
    const button=event.target.closest('[data-agent-run-delete]');
    if(!button)return;
    const runId=button.dataset.agentRunDelete;
    if(!runId||!window.confirm('این اجرای Agent از تاریخچهٔ حساب حذف شود؟'))return;
    try{await agentHistoryRequest('POST',{action:'delete',runId});toast('اجرای انتخاب‌شده حذف شد.');renderAgentHistoryPage(root)}catch(error){toast(error.message||'حذف اجرا ناموفق بود.')}
  });
}
