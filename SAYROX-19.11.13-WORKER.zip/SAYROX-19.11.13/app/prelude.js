// Runs before the app closure (outside the IIFE).
window.SayroxFileStudioBridge={render:window.SayroxFileStudio.render,openFile:window.SayroxFileStudio.openFile};
