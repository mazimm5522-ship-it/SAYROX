import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const source = await readFile(new URL('../src/index.js', import.meta.url), 'utf8');
const config = JSON.parse(await readFile(new URL('../wrangler.jsonc', import.meta.url), 'utf8'));

for (const route of [
  '/internal/signup', '/internal/get-user', '/internal/update-password-hash',
  '/internal/create-session', '/internal/validate-session', '/internal/delete-session',
  '/internal/memory/list', '/internal/memory/set-enabled', '/internal/memory/create',
  '/internal/memory/update', '/internal/memory/delete', '/internal/memory/clear',
  '/internal/check'
]) assert.ok(source.includes(route), `Auth storage route missing: ${route}`);

assert.match(source, /export class AccountObject extends DurableObject/);
assert.match(source, /export class AuthRateLimiter extends DurableObject/);
assert.match(source, /CREATE TABLE IF NOT EXISTS sessions/);
assert.match(source, /CREATE TABLE IF NOT EXISTS memories/);
assert.match(source, /CREATE TABLE IF NOT EXISTS rate_buckets/);
assert.deepEqual(config.migrations[0].new_sqlite_classes.sort(), ['AccountObject', 'AuthRateLimiter']);
assert.equal(config.name, 'sayrox-auth-storage');
assert.doesNotMatch(JSON.stringify(config), /d1_databases/i);
console.log('Auth storage contract passed: account/session/memory/rate-limit routes and SQLite Durable Object migration');
