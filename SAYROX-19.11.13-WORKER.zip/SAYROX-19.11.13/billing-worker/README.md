# SAYROX Billing Storage — staging

این Worker فقط مالک دفتر پرداخت و چرخه اشتراک است.

## مسئولیت‌ها

- یک `BillingAccountObject` SQLite Durable Object برای هر `accountKey`.
- نگهداری سفارش، Authority، RefID، وضعیت تأیید تراکنش و سوابق اشتراک.
- قیمت پلن‌ها در سرور تعیین می‌شود؛ مرورگر فقط `planId` می‌فرستد.
- `idempotency_key`، `authority`، `ref_id` و `source_order_id` یکتا هستند.
- تأیید تراکنش و ایجاد اشتراک در یک `transactionSync` اتمیک انجام می‌شود.
- callback تکراری همان سفارش/اشتراک را برمی‌گرداند و اشتراک دوم نمی‌سازد.
- خرید جدید در صورت وجود اشتراک معتبر، پس از پایان بیشترین تاریخ اعتبار قبلی زمان‌بندی می‌شود.

## جداسازی مسئولیت‌ها

شمارنده‌های مصرف در `../usage-worker/` و کلاس `UsageAccountObject` نگهداری می‌شوند. این طراحی، دفتر مالی را از عملیات پرتکرار چت، جست‌وجو و صدا جدا می‌کند. Pages Worker اشتراک فعال را از `BILLING_ACCOUNT` می‌خواند و snapshot معتبر سمت سرور را به `USAGE_ACCOUNT` می‌دهد. کلاینت امکان تعیین tier، محدودیت یا دوره‌ی سهمیه را ندارد.

## استقرار

```bash
npx wrangler deploy --config billing-worker/wrangler.jsonc
```

پس از ساخت namespace، شناسه‌ی همان namespace فقط به binding `BILLING_ACCOUNT` در Pages Staging وصل می‌شود.

## امنیت

هیچ Merchant ID، API key یا secret در این Worker قرار نمی‌گیرد. راز callback و تنظیمات زرین‌پال متعلق به Pages Worker است و باید فقط به‌صورت Cloudflare Secret نگهداری شود. endpoint عمومی این Worker عمداً فقط 404 می‌دهد.
