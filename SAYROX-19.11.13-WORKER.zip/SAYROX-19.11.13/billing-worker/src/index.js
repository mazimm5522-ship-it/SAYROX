import { DurableObject } from 'cloudflare:workers';

const PLANS = Object.freeze({
  'plus-1m': { months: 1, amountToman: 1371000, tier: 'start' },
  'plus-3m': { months: 3, amountToman: 4113000, tier: 'advanced' },
  'plus-9m': { months: 9, amountToman: 13710000, tier: 'pro' },
  'plus-12m': { months: 12, amountToman: 21936000, tier: 'ultra' },
});
const QUOTA_FEATURES = new Set(['chat', 'search', 'tts', 'live_voice', 'images']);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const AUTHORITY = /^[A-Za-z0-9_-]{20,64}$/;
const REF_ID = /^\d{1,32}$/;

function orderShape(row) {
  if (!row) return null;
  return { orderId: row.order_id, planId: row.plan_id, months: row.months,
    amountToman: row.amount_toman, amountRial: row.amount_rial, status: row.status,
    authority: row.authority, refId: row.ref_id, createdAt: row.created_at,
    expiresAt: row.expires_at, verifiedAt: row.verified_at };
}
function addMonthsClamped(timestamp, months) {
  const start = new Date(timestamp), day = start.getUTCDate();
  const result = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + months, 1,
    start.getUTCHours(), start.getUTCMinutes(), start.getUTCSeconds(), start.getUTCMilliseconds()));
  const lastDay = new Date(Date.UTC(result.getUTCFullYear(), result.getUTCMonth() + 1, 0)).getUTCDate();
  result.setUTCDate(Math.min(day, lastDay));
  return result.getTime();
}

export class BillingAccountObject extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    ctx.blockConcurrencyWhile(async () => {
      this.ctx.storage.sql.exec(`
        CREATE TABLE IF NOT EXISTS billing_orders (
          order_id TEXT PRIMARY KEY,
          idempotency_key TEXT NOT NULL UNIQUE,
          plan_id TEXT NOT NULL,
          months INTEGER NOT NULL,
          amount_toman INTEGER NOT NULL,
          amount_rial INTEGER NOT NULL,
          status TEXT NOT NULL CHECK(status IN ('creating','pending','cancelled','failed','paid')),
          authority TEXT UNIQUE,
          ref_id TEXT UNIQUE,
          created_at INTEGER NOT NULL,
          expires_at INTEGER NOT NULL,
          verified_at INTEGER
        );
        CREATE INDEX IF NOT EXISTS idx_billing_orders_status_created ON billing_orders(status, created_at);
        CREATE TABLE IF NOT EXISTS billing_subscriptions (
          subscription_id TEXT PRIMARY KEY,
          plan_id TEXT NOT NULL,
          tier TEXT NOT NULL,
          months INTEGER NOT NULL,
          starts_at INTEGER NOT NULL,
          expires_at INTEGER NOT NULL,
          status TEXT NOT NULL CHECK(status IN ('scheduled','active','expired')),
          source_order_id TEXT NOT NULL UNIQUE REFERENCES billing_orders(order_id),
          entitlements_json TEXT NOT NULL,
          created_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_billing_subscriptions_period ON billing_subscriptions(starts_at, expires_at);
      `);
    });
  }

  async createOrder(input) {
    if (!input || !UUID.test(String(input.orderId || '')) || !UUID.test(String(input.idempotencyKey || ''))) return { ok: false, code: 'INVALID_ORDER' };
    const plan = PLANS[String(input.planId || '')];
    if (!plan) return { ok: false, code: 'INVALID_PLAN' };
    const now = Date.now();
    return this.ctx.storage.transactionSync(() => {
      const existing = this.ctx.storage.sql.exec('SELECT * FROM billing_orders WHERE idempotency_key = ?', input.idempotencyKey).toArray()[0];
      if (existing) {
        if (existing.plan_id !== input.planId) return { ok: false, code: 'IDEMPOTENCY_CONFLICT' };
        if (existing.status === 'pending' && existing.authority) return { ok: true, reused: true, order: orderShape(existing) };
        if (existing.status === 'paid') return { ok: true, alreadyPaid: true, order: orderShape(existing) };
        return { ok: false, code: 'REQUEST_IN_PROGRESS' };
      }
      const expiresAt = now + 86400000;
      this.ctx.storage.sql.exec(`INSERT INTO billing_orders
        (order_id,idempotency_key,plan_id,months,amount_toman,amount_rial,status,created_at,expires_at)
        VALUES (?,?,?,?,?,?,'creating',?,?)`, input.orderId, input.idempotencyKey,
        input.planId, plan.months, plan.amountToman, plan.amountToman * 10, now, expiresAt);
      return { ok: true, reused: false, order: { orderId: input.orderId, planId: input.planId,
        months: plan.months, amountToman: plan.amountToman, amountRial: plan.amountToman * 10,
        status: 'creating', authority: null, createdAt: now, expiresAt } };
    });
  }

  async attachAuthority(orderId, authority) {
    if (!UUID.test(String(orderId || '')) || !AUTHORITY.test(String(authority || ''))) return { ok: false, code: 'INVALID_AUTHORITY' };
    return this.ctx.storage.transactionSync(() => {
      const row = this.ctx.storage.sql.exec('SELECT * FROM billing_orders WHERE order_id = ?', orderId).toArray()[0];
      if (!row) return { ok: false, code: 'ORDER_NOT_FOUND' };
      if (row.status === 'pending' && row.authority === authority) return { ok: true, order: orderShape(row) };
      if (row.status !== 'creating') return { ok: false, code: 'ORDER_NOT_CREATING' };
      try { this.ctx.storage.sql.exec("UPDATE billing_orders SET authority=?,status='pending' WHERE order_id=? AND status='creating'", authority, orderId); }
      catch { return { ok: false, code: 'AUTHORITY_ALREADY_USED' }; }
      return { ok: true, order: orderShape(this.ctx.storage.sql.exec('SELECT * FROM billing_orders WHERE order_id=?', orderId).toArray()[0]) };
    });
  }

  async failOrder(orderId) {
    return this.ctx.storage.transactionSync(() => {
      this.ctx.storage.sql.exec("UPDATE billing_orders SET status='failed' WHERE order_id=? AND status='creating'", orderId);
      return { ok: true };
    });
  }

  async getOrder(orderId) {
    return orderShape(this.ctx.storage.sql.exec('SELECT * FROM billing_orders WHERE order_id=?', orderId).toArray()[0]);
  }

  async cancelOrder(orderId, authority) {
    return this.ctx.storage.transactionSync(() => {
      const row = this.ctx.storage.sql.exec('SELECT * FROM billing_orders WHERE order_id=?', orderId).toArray()[0];
      if (!row) return { ok: false, code: 'ORDER_NOT_FOUND' };
      if (row.status === 'paid') return { ok: true, alreadyPaid: true, order: orderShape(row) };
      if (row.status === 'pending' && row.authority === authority)
        this.ctx.storage.sql.exec("UPDATE billing_orders SET status='cancelled' WHERE order_id=? AND status='pending'", orderId);
      return { ok: true, order: orderShape(this.ctx.storage.sql.exec('SELECT * FROM billing_orders WHERE order_id=?', orderId).toArray()[0]) };
    });
  }

  async settleVerified(orderId, authority, refId) {
    if (!UUID.test(String(orderId || '')) || !AUTHORITY.test(String(authority || '')) || !REF_ID.test(String(refId || ''))) return { ok: false, code: 'INVALID_VERIFICATION' };
    const now = Date.now();
    return this.ctx.storage.transactionSync(() => {
      const row = this.ctx.storage.sql.exec('SELECT * FROM billing_orders WHERE order_id=?', orderId).toArray()[0];
      if (!row) return { ok: false, code: 'ORDER_NOT_FOUND' };
      if (row.status === 'paid') {
        const sub = this.ctx.storage.sql.exec('SELECT * FROM billing_subscriptions WHERE source_order_id=?', orderId).toArray()[0];
        return { ok: true, duplicate: true, order: orderShape(row), subscription: this.subscriptionShape(sub) };
      }
      const plan = PLANS[row.plan_id];
      if (row.status !== 'pending' || row.authority !== authority || row.expires_at < now ||
          !plan || row.months !== plan.months || row.amount_toman !== plan.amountToman || row.amount_rial !== row.amount_toman * 10)
        return { ok: false, code: 'ORDER_NOT_SETTLEABLE' };
      const latest = this.ctx.storage.sql.exec('SELECT MAX(expires_at) AS expires_at FROM billing_subscriptions WHERE expires_at > ?', now).toArray()[0];
      const startsAt = Math.max(now, Number(latest?.expires_at || 0));
      const expiresAt = addMonthsClamped(startsAt, plan.months);
      const subscriptionId = crypto.randomUUID();
      this.ctx.storage.sql.exec("UPDATE billing_orders SET status='paid',ref_id=?,verified_at=? WHERE order_id=? AND status='pending'", refId, now, orderId);
      this.ctx.storage.sql.exec(`INSERT INTO billing_subscriptions
        (subscription_id,plan_id,tier,months,starts_at,expires_at,status,source_order_id,entitlements_json,created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?)`, subscriptionId, row.plan_id, plan.tier, plan.months,
        startsAt, expiresAt, startsAt > now ? 'scheduled' : 'active', orderId, JSON.stringify({ tier: plan.tier, limits: PLAN_LIMITS[plan.tier] }), now);
      const updatedOrder = this.ctx.storage.sql.exec('SELECT * FROM billing_orders WHERE order_id=?', orderId).toArray()[0];
      const sub = this.ctx.storage.sql.exec('SELECT * FROM billing_subscriptions WHERE subscription_id=?', subscriptionId).toArray()[0];
      return { ok: true, duplicate: false, order: orderShape(updatedOrder), subscription: this.subscriptionShape(sub) };
    });
  }

  subscriptionShape(row) {
    if (!row) return null;
    const now = Date.now();
    return { subscriptionId: row.subscription_id, planId: row.plan_id, tier: row.tier,
      months: row.months, startsAt: row.starts_at, expiresAt: row.expires_at,
      status: row.expires_at <= now ? 'expired' : row.starts_at > now ? 'scheduled' : 'active',
      entitlements: JSON.parse(row.entitlements_json), sourceOrderId: row.source_order_id };
  }

  async getSubscriptionSnapshot() {
    const now = Date.now();
    const current = this.ctx.storage.sql.exec('SELECT * FROM billing_subscriptions WHERE starts_at<=? AND expires_at>? ORDER BY expires_at DESC LIMIT 1', now, now).toArray()[0];
    const upcoming = this.ctx.storage.sql.exec('SELECT * FROM billing_subscriptions WHERE starts_at>? AND expires_at>? ORDER BY starts_at ASC LIMIT 5', now, now).toArray().map(row => this.subscriptionShape(row));
    const payments = this.ctx.storage.sql.exec(`SELECT order_id,plan_id,months,amount_toman,status,created_at,verified_at,ref_id
      FROM billing_orders ORDER BY created_at DESC LIMIT 10`).toArray().map(row => ({
        orderId: row.order_id, planId: row.plan_id, months: row.months, amountToman: row.amount_toman,
        status: row.status, createdAt: row.created_at, verifiedAt: row.verified_at, refId: row.ref_id,
      }));
    return { ok: true, current: this.subscriptionShape(current), upcoming, payments };
  }
}

export default {
  async fetch() {
    return new Response('Not found', { status: 404, headers: { 'cache-control': 'no-store' } });
  },
};
