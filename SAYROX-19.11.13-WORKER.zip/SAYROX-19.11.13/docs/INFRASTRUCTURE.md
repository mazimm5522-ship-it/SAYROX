# زیرساخت SAYROX 19.11.13 — اکانت Cloudflare تازه

این سند معماری انتشار مستقل SAYROX را مشخص می‌کند. تمام Workerها و Durable Object Namespaceها در همان اکانت Cloudflare تازه ساخته می‌شوند. هیچ ارجاعی به Workerهای اکانت قبلی یا پروژهٔ قبلی لازم نیست.

## Workerها و Bindingها

| Worker | مسئولیت | Durable Object class / Binding |
|---|---|---|
| `sayrox` | API اصلی، رابط و Static Assets | `AUTH_ACCOUNTS`, `AUTH_RATE_LIMITER`, `BILLING_ACCOUNT`, `USAGE_ACCOUNT`, `TASKS_ACCOUNT` |
| `sayrox-auth-storage` | حساب‌ها، نشست‌ها، حافظه و محدودیت ورود | `AccountObject`, `AuthRateLimiter` |
| `sayrox-billing-storage` | سفارش و اشتراک | `BillingAccountObject` |
| `sayrox-usage-storage` | سهمیه، تاریخچه Agent و مجوزهای یک‌بارمصرف | `UsageAccountObject` |
| `sayrox-tasks-storage` | زمان‌بندی و اجرای Alarm | `TaskAccountObject` |

Worker اصلی متصل می‌شود به کلاس‌های Durable Object از Workerهای بالا با `script_name`. Deploy Kit ابتدا Workerهای ذخیره‌سازی را منتشر می‌کند و سپس Worker اصلی را؛ بنابراین Bindingها به اسکریپت‌های تازهٔ همان اکانت اشاره می‌کنند.

## قانون D1

هیچ فایل Wrangler در این پروژه `d1_databases` تعریف نمی‌کند و هیچ D1 migration وجود ندارد. جداول داخلی هر Durable Object در SQLite داخلی همان Durable Object نگهداری می‌شوند؛ این سرویس Cloudflare D1 نیست.

## تنظیمات انتشار

Deploy Kit پنج فایل در ریشهٔ مخزن خصوصی GitHub دارد. متغیر Build به نام `SAYROX_APP_ORIGIN` باید دقیقاً برابر Origin عمومی Worker اصلی باشد، مانند `https://sayrox.SUBDOMAIN.workers.dev`، بدون اسلش انتهایی. این مقدار برای `APP_ORIGIN` در Worker زمان‌بندی استفاده می‌شود و باید از صفحه Overview کپی شود.

اسکریپت Deploy پیش از هرگونه انتشار، Origin را اعتبارسنجی می‌کند. سپس ترتیب زیر را اجرا می‌کند:

1. `sayrox-auth-storage`
2. `sayrox-billing-storage`
3. `sayrox-usage-storage`
4. `sayrox-tasks-storage`
5. `sayrox`

اگر Build، تست‌ها یا اعتبارسنجی Origin شکست بخورد، Deploy متوقف می‌شود.

## Secrets

Secretها فقط در تنظیمات Cloudflare Worker ثبت می‌شوند؛ هرگز در ZIP یا GitHub قرار نمی‌گیرند.

- Worker `sayrox`: `GAPGPT_API_KEY`, `AUTH_SESSION_SECRET`, `TASKS_INTERNAL_SECRET`
- Worker `sayrox-tasks-storage`: همان `TASKS_INTERNAL_SECRET`
- اختیاری در `sayrox`: `TAVILY_API_KEY`, `ELEVENLABS_API_KEY`
- `GAPGPT_DEFAULT_MODEL` باید شناسهٔ واقعی مدلی باشد که در حساب GapGPT فعال است.

`PAYMENTS_ENABLED=false` باقی می‌ماند تا Callback و Verify زرین‌پال جداگانه آزمایش شوند. Sandbox اجرای کد در این انتشار عمداً غیرفعال باقی می‌ماند و برای فعال‌سازی به راه‌اندازی مستقل نیاز دارد.

## محدودیت‌ها و تأیید پس از انتشار

- حساب‌ها و فضای ذخیره‌سازی از صفر ایجاد می‌شوند؛ داده‌ای از اکانت قبلی منتقل نمی‌شود.
- ایجاد Workerها و Namespaceها به دسترسی Deploy مجاز در Cloudflare نیاز دارد.
- تست‌های محلی جای تست زندهٔ API گپ، Secrets، ثبت‌نام، ورود، نشست، سهمیه و زمان‌بندی را نمی‌گیرند.
- تا پیش از ثبت Secretها و انجام Smoke Test، سایت را آمادهٔ عرضهٔ عمومی تلقی نکن.
