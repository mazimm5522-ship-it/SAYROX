# صوت در SAYROX

دو مسیر مستقل صوتی داریم:

| قابلیت | مسیر | وابستگی | سهمیه |
|---|---|---|---|
| دیکتهٔ فارسی (میکروفون کادر نوشتار) | WebSocket مستقیم به ElevenLabs Scribe realtime با AudioWorklet | بدون SDK/CDN | `voice_input` — یک واحد برای هر نشست |
| مکالمهٔ زنده (Live) | SDK رسمی `@elevenlabs/client` با WebRTC + Speech Engine متصل به Worker | bundle محلی `site/vendor/elevenlabs-client.mjs` و یک Speech Engine با شناسهٔ `seng_...` | `live_voice` — یک واحد برای هر نشست |

## پیش‌نیازهای حساب ElevenLabs و Cloudflare

در Cloudflare Worker `sayrox` این موارد لازم‌اند:

- Secret: `ELEVENLABS_API_KEY` — کلید API الون‌لبز؛ هرگز در کد مرورگر، فایل ZIP یا Git قرار نگیرد.
- Variable یا Secret: `ELEVENLABS_SPEECH_ENGINE_ID` — شناسه‌ای که هنگام ساخت Speech Engine برمی‌گردد و باید با `seng_` شروع شود.

در تنظیمات Speech Engine مقدار WebSocket باید دقیقاً این باشد:

`wss://YOUR_PUBLIC_DOMAIN/api/voice/upstream`

`YOUR_PUBLIC_DOMAIN` را با دامنهٔ عمومی نهایی SAYROX جایگزین کن؛ مسیر `/api/voice/upstream` را تغییر نده. منبع باید به همان Workerای وصل شود که این مسیر در آن منتشر شده است.

## ترتیب امن راه‌اندازی روی Worker مستقل

Worker جدید `sayrox` در حساب Cloudflare ساخته شده است، اما در زمان نگارش این نسخه فقط Hello World دارد و Secretهای Provider هنوز تنظیم نشده‌اند. بنابراین Speech Engine را تا وقتی نسخهٔ برنامه واقعاً منتشر و مسیر API آزموده نشده، نساز.

ترتیب درست:

1. ابتدا Workerهای وابسته را طبق `docs/INFRASTRUCTURE.md` آماده کن و سپس Worker اصلی `sayrox` را روی محیط آزمایشی مستقر کن؛ آدرس Worker را از اکانت تازه بردار و برای ساخت Speech Engine استفاده کن.
2. در Cloudflare → Workers & Pages → `sayrox` → Settings → Variables and Secrets، Secretهای `ELEVENLABS_API_KEY` و `GAPGPT_API_KEY` را در محیط موردنظر ثبت کن. مقدار Secretها را از منبع امن خودت بردار؛ کلید را در چت یا فایل ZIP نفرست.
3. پس از استقرار موفق و پاسخ‌دادن مسیر `/api/voice/upstream`، مقدار `ws_url` در درخواست ساخت موتور باید `wss://sayrox.account-subdomain.workers.dev/api/voice/upstream (نمونه؛ مقدار واقعی را از Overview کپی کن)` باشد؛ پس از اتصال دامنه جدید، این نشانی با دامنهٔ نهایی جایگزین می‌شود.
4. `speech_engine_id` برگشتی را در همان Worker با نام `ELEVENLABS_SPEECH_ENGINE_ID` ذخیره کن.
5. بعد از تست واقعی میکروفون، بلندگو، پاسخ فارسی و امکان قطع‌کردن صحبت، دربارهٔ اتصال دامنهٔ نهایی و انتشار عمومی تصمیم بگیر.

## ساخت Speech Engine در ElevenLabs

Speech Engine با Agent معمولی یکی نیست. API رسمی ElevenLabs برای ایجاد آن `POST https://api.elevenlabs.io/v1/speech-engine` است و پاسخ، شناسه‌ای مانند `seng_...` می‌دهد. نمونهٔ زیر فقط الگوی درخواست است؛ کلید واقعی نباید در فایل یا پیام قرار بگیرد.

```bash
curl -X POST 'https://api.elevenlabs.io/v1/speech-engine' \
  -H 'xi-api-key: '"$ELEVENLABS_API_KEY" \
  -H 'Content-Type: application/json' \
  --data '{
    "name": "SAYROX Live",
    "speech_engine": {
      "ws_url": "wss://YOUR_PUBLIC_DOMAIN/api/voice/upstream"
    },
    "language": "fa",
    "asr": {
      "provider": "elevenlabs",
      "quality": "high",
      "user_input_audio_format": "pcm_16000"
    },
    "tts": {
      "model_id": "eleven_v4_turbo",
      "voice_id": "IsLN9xDFXCtAgmdMDUEQ",
      "agent_output_audio_format": "pcm_16000",
      "stability": 0.5,
      "similarity_boost": 0.8
    },
    "conversation": {
      "max_duration_seconds": 180,
      "client_events": ["audio", "interruption", "agent_response", "user_transcript"]
    },
    "privacy": {
      "record_voice": false
    }
  }'
```

برای شروع، شناسهٔ صدای «Mr O – Warm & Natural Voice» قرار داده شده که در فهرست صداهای فارسی حساب با لهجهٔ ایرانی و لحن گرم و محاوره‌ای دیده شده بود. این انتخاب اولیه است؛ بعداً می‌توان آن را با هر صدای فارسی مجاز دیگری جایگزین کرد.

پس از موفقیت، مقدار `speech_engine_id` در پاسخ را بدون تغییر در Cloudflare Worker `sayrox` به‌عنوان `ELEVENLABS_SPEECH_ENGINE_ID` ثبت کن. خود `ELEVENLABS_API_KEY` همان Secret موجود باقی می‌ماند و لازم نیست دوباره وارد یا ارسال شود.

**مدل گفتار:** `eleven_v4_turbo` انتخاب شده چون فارسی را در گروه زبان‌های پشتیبانی‌شده دارد و برای مکالمهٔ بلادرنگ طراحی شده است. مدل قدیمی `eleven_flash_v2` انگلیسی‌محور است و برای موتور فارسی انتخاب مناسبی نیست. تنظیم `optimize_streaming_latency` هم برای این مدل استفاده نشده است؛ در عوض تنظیمات پایداری و شباهت صدا ثبت شده‌اند.

`record_voice: false` ضبط صوت مکالمه را غیرفعال می‌کند؛ این گزینه به‌تنهایی به معنی حذف transcript یا فعال بودن Zero Retention نیست. تنظیمات نگهداری متن و داده‌های مکالمه را جداگانه در سیاست حریم خصوصی ElevenLabs بررسی کن.

## ساخت bundle محلی SDK

در محیطی با دسترسی به npm:

```bash
npm install
npm run build
npm test
```

`npm run build` فایل `site/vendor/elevenlabs-client.mjs` را می‌سازد و سپس صحت `site/` را بررسی می‌کند. پس از اولین نصب، `package-lock.json` را نگه دار و برای نصب‌های بعدی از `npm ci` استفاده کن. پوشهٔ `site/vendor/` خروجی ساخت است و در Git نگهداری نمی‌شود.

## رفتار و ایمنی

- پیش از هر نشست زنده، SDK محلی بارگیری می‌شود؛ اگر موجود نباشد، نه مجوز میکروفون درخواست می‌شود و نه توکن سهمیه‌دار گرفته می‌شود.
- fallback به CDN پیش‌فرض خاموش است. فقط برای عیب‌یابی موقت و با آگاهی از وابستگی خارجی می‌توان `window.SAYROX_ALLOW_REMOTE_VOICE_SDK_FALLBACK = true` را صریحاً فعال کرد.
- Worker توکن مکالمه را از API رسمی ElevenLabs می‌گیرد و در پاسخ با `cache-control: no-store` برمی‌گرداند. کلید API در مرورگر قرار نمی‌گیرد.
- Worker امضای JWT مخصوص Speech Engine را با کلید API سمت سرور اعتبارسنجی می‌کند، پیام `init` را قبل از transcript اجباری می‌داند و طول نشست WebSocket را سمت سرور به ۱۸۰ ثانیه محدود می‌کند.
- SDK رسمی از callback مستند `onMessage` برای دریافت هم رونوشت نهایی کاربر و هم پاسخ متنی SAYROX استفاده می‌کند. پاسخ متنی از مسیر اصلی مدل SAYROX / GapGPT stream می‌شود و به Speech Engine تحویل داده می‌شود؛ سرویس صوتی جایگزین مدل اصلی گفتگو نمی‌شود.
- اگر کاربر وسط پاسخ دوباره صحبت کند، رویداد جدید اولویت می‌گیرد و جریان قبلی لغو می‌شود.

## وضعیت آزمون

تست‌های خودکار، منطق مسیرها و قراردادهای داخلی را با Mock بررسی می‌کنند؛ آن‌ها جای آزمایش واقعی حساب ElevenLabs را نمی‌گیرند. برای تأیید نهایی باید bundle واقعی ساخته شود و یک نشست WebRTC با Speech Engine واقعی روی Preview، به‌همراه میکروفون و بلندگوی Android/iOS، آزمایش شود.

## مراجع رسمی

- [ایجاد Speech Engine](https://elevenlabs.io/docs/api-reference/speech-engine/create)
- [راهنمای SDK جاوااسکریپت Speech Engine](https://elevenlabs.io/docs/eleven-api/resources/libraries/speech-engine/javascript-sdk-reference)
- [فهرست مدل‌ها و زبان‌های پشتیبانی‌شده](https://elevenlabs.io/docs/overview/models)
- [راهنمای callbackهای SDK مکالمه](https://elevenlabs.io/docs/eleven-agents/libraries/javascript)
