export const MAX_REQUEST_BYTES = 12_500;
export const MAX_CODE_CHARS = 8_000;
export const MAX_OUTPUT_BYTES = 24_000;
export const MAX_CLOCK_SKEW_MS = 60_000;

const encoder = new TextEncoder();

export async function readBoundedText(request, maxBytes = MAX_REQUEST_BYTES) {
  if (!request.body) return "";
  const reader = request.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel("body_too_large").catch(() => {});
        throw new Error("REQUEST_TOO_LARGE");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const combined = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { combined.set(chunk, offset); offset += chunk.byteLength; }
  return new TextDecoder("utf-8", { fatal: true }).decode(combined);
}

function decodeBase64Url(value) {
  if (typeof value !== "string" || !/^[A-Za-z0-9_-]{43}$/.test(value)) return null;
  try {
    const base64 = value.replace(/-/g, "+").replace(/_/g, "/") + "=";
    const binary = atob(base64);
    const bytes = Uint8Array.from(binary, char => char.charCodeAt(0));
    return bytes.byteLength === 32 ? bytes : null;
  } catch { return null; }
}

export async function verifyInternalSignature(secret, timestamp, rawBody, signature) {
  if (typeof secret !== "string" || secret.length < 32) return false;
  if (!/^\d{13}$/.test(String(timestamp || ""))) return false;
  const parsedTimestamp = Number(timestamp);
  if (!Number.isSafeInteger(parsedTimestamp) || Math.abs(Date.now() - parsedTimestamp) > MAX_CLOCK_SKEW_MS) return false;
  const signatureBytes = decodeBase64Url(signature);
  if (!signatureBytes) return false;
  try {
    const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
    return await crypto.subtle.verify("HMAC", key, signatureBytes, encoder.encode(`${timestamp}.${rawBody}`));
  } catch { return false; }
}

export function validateExecutionPayload(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return { ok: false, code: "INVALID_PAYLOAD" };
  const keys = Object.keys(value);
  if (keys.some(key => !["version", "jobId", "language", "code"].includes(key))) return { ok: false, code: "INVALID_PAYLOAD" };
  if (value.version !== 1 || value.language !== "python") return { ok: false, code: "UNSUPPORTED_RUNTIME" };
  if (typeof value.jobId !== "string" || !/^[a-f0-9]{64}$/.test(value.jobId)) return { ok: false, code: "INVALID_JOB_ID" };
  if (typeof value.code !== "string" || !value.code.trim() || value.code.length > MAX_CODE_CHARS || encoder.encode(value.code).byteLength > 12_000) return { ok: false, code: "INVALID_CODE" };
  return { ok: true, payload: { version: 1, jobId: value.jobId, language: "python", code: value.code } };
}

export async function readProcessStreamLimited(stream, sharedState, killProcess) {
  if (!stream || typeof stream.getReader !== "function") return "";
  const reader = stream.getReader();
  const chunks = [];
  let length = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      const remaining = Math.max(0, MAX_OUTPUT_BYTES - sharedState.total);
      const accepted = value.byteLength > remaining ? value.subarray(0, remaining) : value;
      if (accepted.byteLength) {
        chunks.push(accepted);
        length += accepted.byteLength;
        sharedState.total += accepted.byteLength;
      }
      if (accepted.byteLength < value.byteLength) {
        sharedState.truncated = true;
        try { killProcess?.(); } catch { }
        await reader.cancel("output_limit_reached").catch(() => {});
        break;
      }
    }
  } finally {
    try { reader.releaseLock(); } catch { }
  }
  const combined = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) { combined.set(chunk, offset); offset += chunk.byteLength; }
  return new TextDecoder().decode(combined);
}
