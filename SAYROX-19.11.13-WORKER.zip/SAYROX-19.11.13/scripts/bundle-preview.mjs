// Builds ONE self-contained HTML file for quick preview (no server needed).
//   node scripts/bundle-preview.mjs [out.html]
import { readFile, writeFile } from 'node:fs/promises';
const root = new URL('../site/', import.meta.url);
const read = p => readFile(new URL(p, root), 'utf8');
let html = await read('index.html');
const swap = async (re, wrap) => {
  for (const m of [...html.matchAll(re)]) {
    const body = (await read(m[1])).replace(/<\/script/gi, '<\\/script');
    html = html.replace(m[0], () => wrap(body));
  }
};
await swap(/<link rel="stylesheet" href="([^"]+)">/g, body => `<style>\n${body}\n</style>`);
await swap(/<script src="([^"]+)"><\/script>/g, body => `<script>\n${body}\n</script>`);
html = html.replace(/<link rel="manifest"[^>]*>\n?/, '');
await writeFile(process.argv[2] || 'SAYROX-preview.html', html);
console.log('wrote', process.argv[2] || 'SAYROX-preview.html', html.length, 'bytes');
