// Deployment guard: the Scheduler Worker must never be published with its template origin.
// Configure APP_ORIGIN in tasks-worker/wrangler.jsonc before `npm run deploy:tasks`.
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

const root = fileURLToPath(new URL('..', import.meta.url));
const configPath = join(root, 'tasks-worker/wrangler.jsonc');
const config = await readFile(configPath, 'utf8');
const match = config.match(/"APP_ORIGIN"\s*:\s*"([^"]+)"/);

function stop(message) {
  console.error(`tasks deploy blocked: ${message}`);
  process.exit(1);
}

if (!match) stop('vars.APP_ORIGIN is missing from tasks-worker/wrangler.jsonc.');
const value = match[1];
if (!value || /REPLACE|YOUR-|example\.com/i.test(value)) {
  stop('replace the APP_ORIGIN template with the exact HTTPS SAYROX Worker origin before deployment.');
}
let origin;
try { origin = new URL(value); }
catch { stop('APP_ORIGIN is not a valid URL.'); }
if (origin.protocol !== 'https:' || origin.username || origin.password || origin.pathname !== '/' || origin.search || origin.hash || value.endsWith('/')) {
  stop('APP_ORIGIN must be an HTTPS origin only (no path, query, fragment, credentials, or trailing slash).');
}
console.log(`tasks deploy config OK — APP_ORIGIN=${origin.origin}`);
