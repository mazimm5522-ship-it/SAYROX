(() => {
  'use strict';

  function normalizeSearchText(value) {
    return String(value ?? '')
      .normalize('NFKC')
      .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g, '')
      .replace(/[يى]/g, 'ی')
      .replace(/ك/g, 'ک')
      .toLocaleLowerCase('fa-IR')
      .trim();
  }

  function searchChats(chats, query) {
    const needle = normalizeSearchText(query);
    const source = Array.isArray(chats) ? chats : [];
    if (!needle) return source.map(chat => ({ chat, titleMatch: false, messageMatch: null }));

    const results = [];
    for (const chat of source) {
      if (!chat || !Array.isArray(chat.messages)) continue;
      const title = String(chat.title || 'گفتگوی جدید');
      const titleMatch = normalizeSearchText(title).includes(needle);
      let messageMatch = null;
      if (!titleMatch) {
        for (const message of chat.messages) {
          if (!message || message.internal || message.role !== 'user' && message.role !== 'assistant') continue;
          const content = String(message.content || '');
          const normalized = normalizeSearchText(content);
          const index = normalized.indexOf(needle);
          if (index >= 0) {
            const start = Math.max(0, index - 42);
            const end = Math.min(content.length, index + needle.length + 72);
            messageMatch = { role: message.role, excerpt: `${start ? '…' : ''}${content.slice(start, end)}${end < content.length ? '…' : ''}` };
            break;
          }
        }
      }
      if (titleMatch || messageMatch) results.push({ chat, titleMatch, messageMatch });
    }
    return results;
  }

  function editUserMessage(chat, index, nextContent) {
    if (!chat || !Array.isArray(chat.messages) || !Number.isInteger(index)) return false;
    const message = chat.messages[index];
    const previousFirstMessage = chat.messages.find(item => item?.role === 'user' && !item.internal);
    const previousFirstContent = previousFirstMessage ? String(previousFirstMessage.content || '') : '';
    const content = String(nextContent ?? '').trim();
    if (!message || message.role !== 'user' || message.internal || !content || content.length > 24000) return false;
    message.content = content;
    message.editedAt = Date.now();
    chat.messages = chat.messages.slice(0, index + 1);
    if (message === previousFirstMessage) chat.title = `${content.slice(0, 36)}${content.length > 36 ? '…' : ''}`;
    chat.updated = Date.now();
    return true;
  }

  function exportableChats(chats) {
    return (Array.isArray(chats) ? chats : []).filter(Boolean).map(chat => ({
      ...chat,
      messages: (Array.isArray(chat.messages) ? chat.messages : []).filter(message => !message?.internal)
    }));
  }

  function appendContinuationInstruction(chat, index) {
    if (!chat || !Array.isArray(chat.messages) || !Number.isInteger(index)) return null;
    const message = chat.messages[index];
    if (!message || message.role !== 'assistant' || message.internal) return null;
    if (chat.messages.length !== index + 1) return null;
    const prompt = 'ادامه‌ی پاسخ قبلی را از همان نقطه ادامه بده. بخش‌های قبلی را تکرار نکن؛ اگر پاسخ قبلی نیمه‌تمام مانده، دقیقاً ادامه‌ی منطقی آن را بنویس.';
    chat.messages = chat.messages.slice(0, index + 1);
    chat.messages.push({
      id: (globalThis.crypto?.randomUUID?.() || `internal-${Date.now()}-${Math.random().toString(16).slice(2)}`),
      role: 'user',
      content: prompt,
      internal: true,
      at: Date.now()
    });
    chat.updated = Date.now();
    return prompt;
  }

  globalThis.SayroxChatActions = Object.freeze({ normalizeSearchText, searchChats, editUserMessage, appendContinuationInstruction, exportableChats });
})();
