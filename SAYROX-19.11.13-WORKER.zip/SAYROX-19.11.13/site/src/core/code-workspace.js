// Local code-block workspace: safe highlighting, line numbers, editing and isolated HTML preview.
(function attachCodeWorkspace(root){
  'use strict';
  const aliases=Object.freeze({js:'javascript',jsx:'javascript',mjs:'javascript',cjs:'javascript',ts:'typescript',tsx:'typescript',py:'python',sh:'bash',shell:'bash',yml:'yaml',htm:'html',xhtml:'html',txt:'text',plain:'text'});
  const labels=Object.freeze({javascript:'JavaScript',typescript:'TypeScript',python:'Python',html:'HTML',css:'CSS',json:'JSON',bash:'Bash',sql:'SQL',yaml:'YAML',java:'Java',c:'C',cpp:'C++',csharp:'C#',php:'PHP',go:'Go',rust:'Rust',ruby:'Ruby',text:'Text'});
  const keywordSets={
    javascript:'as async await break case catch class const continue debugger default delete do else export extends finally for from function get if import in instanceof let new of return set static super switch this throw try typeof var void while yield true false null undefined NaN Infinity',
    typescript:'abstract any as async await boolean break case catch class const constructor continue declare default delete do else enum export extends false finally for from function get if implements import in instanceof interface keyof let module namespace never new null number object of package private protected public readonly require return set static string super switch this throw true try type typeof undefined unknown var void while yield',
    python:'and as assert async await break class continue def del elif else except False finally for from global if import in is lambda None nonlocal not or pass raise return True try while with yield',
    css:'important inherit initial unset revert auto none block flex grid inline relative absolute fixed sticky transparent currentColor',
    json:'true false null',
    sql:'add all alter analyze and any as asc begin between by case cast check column commit constraint create cross current_date current_timestamp database default delete desc distinct drop else end except exists explain false fetch for from full grant group having if in index inner insert intersect into is join key left like limit not null offset on only or order outer primary references rename replace returning right rollback row select set table then to true union unique update using values view when where with',
    bash:'case do done elif else esac fi for function if in select then time until while',
    yaml:'true false null yes no on off',
    default:'break case catch class const continue default delete do else export extends false finally for function if import in let new null return super switch this throw true try typeof var void while'
  };
  const hashCommentLanguages=new Set(['python','bash','yaml','ruby']);
  const htmlLanguages=new Set(['html']);
  const htmlTokenPattern=/(<!--[\s\S]*?-->|<\/?[A-Za-z][\w:-]*|\/?>|[A-Za-z_:][\w:.-]*(?=\s*=)|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')/g;

  function normalizeLanguage(value){
    const raw=String(value??'').trim().toLowerCase().replace(/^language-/,'');
    return aliases[raw]||raw||'text';
  }
  function classifyHtmlToken(value){
    if(value.startsWith('<!--'))return 'comment';
    if(value.startsWith('<'))return 'tag';
    if(value==='>'||value==='/>'||value==='/')return 'punctuation';
    if(value.startsWith('"')||value.startsWith("'"))return 'string';
    return 'attribute';
  }
  function tokenizeLine(value,language='text'){
    const line=String(value??''),lang=normalizeLanguage(language);
    if(!line)return [{type:'plain',value:''}];
    const tokens=[];
    let cursor=0;
    const add=(type,text)=>{if(text)tokens.push({type,value:text})};
    const pattern=htmlLanguages.has(lang)?htmlTokenPattern:(()=>{
      const keywords=(keywordSets[lang]||keywordSets.default).split(/\s+/).join('|');
      const comments=hashCommentLanguages.has(lang)?'#[^\\n]*|\\/\\*.*?\\*/':'\\/\\*.*?\\*\\/|\\/\\/.*$';
      const templateLiteral=String.raw`\x60(?:\\.|[^\x60\\])*\x60`;
      return new RegExp(`"(?:\\\\.|[^"\\\\])*"|'(?:\\\\.|[^'\\\\])*'|${templateLiteral}|${comments}|\\b\\d+(?:\\.\\d+)?(?:e[+-]?\\d+)?\\b|\\b(?:${keywords})\\b|\\b[A-Za-z_$][\\w$]*(?=\\s*\\()`, 'gi');
    })();
    for(const match of line.matchAll(pattern)){
      const token=match[0],index=match.index??0;
      if(index>cursor)add('plain',line.slice(cursor,index));
      let type='plain';
      if(htmlLanguages.has(lang))type=classifyHtmlToken(token);
      else if(token.startsWith('"')||token.startsWith("'")||token.startsWith('`'))type='string';
      else if(token.startsWith('//')||token.startsWith('/*')||token.startsWith('#'))type='comment';
      else if(/^\d/.test(token))type='number';
      else if((keywordSets[lang]||keywordSets.default).split(/\s+/).includes(token))type='keyword';
      else type='function';
      add(type,token);
      cursor=index+token.length;
    }
    if(cursor<line.length)add('plain',line.slice(cursor));
    return tokens.length?tokens:[{type:'plain',value:line}];
  }
  function appendHighlightedLine(parent,line,language,documentRef){
    const tokens=tokenizeLine(line,language);
    for(const token of tokens){
      const span=documentRef.createElement('span');
      span.className=`cw-token cw-token-${token.type}`;
      span.textContent=token.value||'\u200b';
      parent.appendChild(span);
    }
  }
  function createBlock(options={}){
    const doc=root.document;
    if(!doc?.createElement)throw new Error('محیط مرورگر برای ساخت ویرایشگر کد در دسترس نیست.');
    let current=String(options.source??'').replace(/\r\n?/g,'\n');
    const language=normalizeLanguage(options.language);
    const title=labels[language]||language.toUpperCase();
    const details=doc.createElement('details');details.className='code-disclosure cw-block';
    const summary=doc.createElement('summary');summary.textContent=`کد آماده است · ${title} — برای مشاهده باز کن`;
    const panel=doc.createElement('section');panel.className='cw-panel';
    const header=doc.createElement('div');header.className='cw-header';
    const lang=doc.createElement('span');lang.className='cw-language';lang.textContent=title;
    const actions=doc.createElement('div');actions.className='cw-actions';
    const makeButton=(label,action,aria)=>{const button=doc.createElement('button');button.type='button';button.className='cw-action';button.textContent=label;button.setAttribute('aria-label',aria||label);button.addEventListener('click',action);return button};
    const pre=doc.createElement('pre');pre.className='cw-pre';
    const gutter=doc.createElement('code');gutter.className='cw-gutter';gutter.setAttribute('aria-hidden','true');
    const code=doc.createElement('code');code.className='cw-code';code.setAttribute('aria-label',`کد ${title}`);
    pre.append(gutter,code);
    const editorPanel=doc.createElement('div');editorPanel.className='cw-editor-panel';editorPanel.hidden=true;
    const editor=doc.createElement('textarea');editor.className='cw-editor';editor.value=current;editor.maxLength=200000;editor.rows=12;editor.spellcheck=false;editor.wrap='off';editor.setAttribute('aria-label','ویرایش کد');editor.setAttribute('dir','ltr');
    const editorActions=doc.createElement('div');editorActions.className='cw-editor-actions';
    const editorStatus=doc.createElement('span');editorStatus.className='cw-editor-status';editorStatus.setAttribute('role','status');editorStatus.setAttribute('aria-live','polite');
    const previewPanel=doc.createElement('div');previewPanel.className='cw-preview-panel';previewPanel.hidden=true;
    const status=doc.createElement('span');status.className='cw-workspace-status';status.setAttribute('role','status');status.setAttribute('aria-live','polite');

    function renderCode(){
      gutter.replaceChildren();code.replaceChildren();
      const lines=current.split('\n');
      lines.forEach((line,index)=>{
        const number=doc.createElement('span');number.className='cw-line-number';number.textContent=String(index+1);gutter.appendChild(number);
        const row=doc.createElement('span');row.className='cw-line';appendHighlightedLine(row,line,language,doc);code.appendChild(row);
      });
      details.dataset.lineCount=String(lines.length);
    }
    function closeEditor(){editorPanel.hidden=true;editorStatus.textContent='';editorButton.setAttribute('aria-expanded','false')}
    function openEditor(){editor.value=current;editorPanel.hidden=false;previewPanel.hidden=true;previewButton?.setAttribute('aria-expanded','false');editorButton.setAttribute('aria-expanded','true');editor.focus()}
    function updatePreview(){
      const helper=root.SayroxSecureHtmlPreview;
      previewPanel.replaceChildren();
      if(!helper?.createFrame){status.textContent='موتور پیش‌نمایش امن در دسترس نیست.';return false}
      try{
        const frame=helper.createFrame(current,{className:'cw-preview-frame',title:'پیش‌نمایش ایزولهٔ کد HTML'});
        previewPanel.appendChild(frame);previewPanel.hidden=false;return true;
      }catch(error){status.textContent=error?.message||'ساخت پیش‌نمایش ناموفق بود.';return false}
    }
    function saveEditor(){
      const next=String(editor.value).replace(/\r\n?/g,'\n');
      if(next.length>200000){editorStatus.textContent='حداکثر ۲۰۰ هزار نویسه مجاز است.';return}
      if(next.includes('```')){editorStatus.textContent='برای حفظ ساختار پیام، کد نباید شامل سه علامت backtick متوالی باشد.';return}
      try{
        const accepted=typeof options.onSave==='function'?options.onSave(next):true;
        if(accepted===false){editorStatus.textContent='ذخیرهٔ تغییرات در گفتگو انجام نشد.';return}
        current=next;renderCode();closeEditor();status.textContent='ویرایش کد در گفتگو ذخیره شد.';
        if(!previewPanel.hidden)updatePreview();
      }catch(error){editorStatus.textContent=error?.message||'ذخیرهٔ تغییرات انجام نشد.'}
    }
    renderCode();
    const copyButton=makeButton('کپی کد',async()=>{
      try{await root.navigator.clipboard.writeText(current);status.textContent='کد کپی شد.'}
      catch{status.textContent='کپی در این مرورگر در دسترس نیست.'}
    });
    const editorButton=makeButton('ویرایش',openEditor,'ویرایش کد');editorButton.setAttribute('aria-expanded','false');
    actions.append(copyButton,editorButton);
    let previewButton=null;
    if(htmlLanguages.has(language)){
      previewButton=makeButton('پیش‌نمایش HTML',()=>{
        if(!previewPanel.hidden){previewPanel.hidden=true;previewButton.setAttribute('aria-expanded','false');return}
        if(updatePreview())previewButton.setAttribute('aria-expanded','true');
      },'بازکردن پیش‌نمایش ایزوله HTML');
      previewButton.setAttribute('aria-expanded','false');actions.appendChild(previewButton);
    }
    const saveButton=makeButton('ذخیره در گفتگو',saveEditor,'ذخیرهٔ کد و به‌روزرسانی پیام');
    const cancelButton=makeButton('لغو',closeEditor,'لغو ویرایش کد');
    editorActions.append(saveButton,cancelButton,editorStatus);
    editorPanel.append(editor,editorActions);
    editor.addEventListener('keydown',event=>{
      if(event.key==='Escape'){event.preventDefault();closeEditor()}
      else if(event.key==='Enter'&&(event.ctrlKey||event.metaKey)){event.preventDefault();saveEditor()}
    });
    header.append(lang,actions);
    panel.append(header,pre,editorPanel,previewPanel,status);
    details.append(summary,panel);
    return details;
  }

  root.SayroxCodeWorkspace=Object.freeze({normalizeLanguage,tokenizeLine,createBlock,isHtmlLanguage:value=>htmlLanguages.has(normalizeLanguage(value)),maxEditorChars:200000});
})(window);
