(function (global) {
  'use strict';
  class NavigationStack {
    constructor(initial = 'settings-home') { this.stack = [initial]; this.listeners = new Set(); }
    get current() { return this.stack[this.stack.length - 1]; }
    get depth() { return this.stack.length; }
    push(route) { if (!route || route === this.current) return this.current; this.stack.push(route); this.emit('push'); return route; }
    pop() { if (this.stack.length <= 1) return this.current; const removed = this.stack.pop(); this.emit('pop', removed); return this.current; }
    reset(route = 'settings-home') { this.stack = [route]; this.emit('reset'); }
    subscribe(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
    emit(action, removed) { this.listeners.forEach(fn => { try { fn({ action, current: this.current, depth: this.depth, removed }); } catch {} }); }
  }
  global.SayroxCore = global.SayroxCore || {};
  global.SayroxCore.NavigationStack = NavigationStack;
})(globalThis);
