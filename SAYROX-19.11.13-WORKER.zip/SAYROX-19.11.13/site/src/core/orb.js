/* SAYROX Orb — a calm, perfectly centred glass sphere drawn with raw WebGL (no libraries, works offline).
 *
 *  SayroxOrb.mount(host, { accent, glow, state, energy, seed })  -> controller
 *  SayroxOrb.get(host)       -> controller | null
 *  SayroxOrb.mountAll(root)  -> mounts every [data-orb] host inside root
 *  SayroxOrb.unmountIn(root) -> destroys every orb inside root
 *
 *  controller: setColors(accent, glow) · setState(name) · setEnergy(0..1) · setSeed(key) · destroy()
 *  States: idle · listening · thinking · speaking · loading · searching · coding · processing
 *
 *  Design rules (keep them when editing the shader):
 *   1. Everything is concentric. The silhouette is a true circle; voice energy only scales it uniformly.
 *   2. No noise, no random wobble. The sphere is mirror-symmetric left/right; light comes from the top.
 *   3. One hairline ring, concentric with the sphere. In "thinking"/"loading" two opposite light arcs travel
 *      along it (point-symmetric); in "listening"/"speaking" soft ripples radiate outward.
 *   4. Colour comes only from the two persona colours (accent = light, glow = deep).
 *  Without WebGL the host gets the class `xorb-fallback` and a CSS-only orb with the same layout is shown.
 */
(function (global) {
  'use strict';

  const VERT = 'attribute vec2 a;varying vec2 v;void main(){v=a;gl_Position=vec4(a,0.,1.);}';

  const FRAG = `
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
varying vec2 v;
uniform float uT, uEnergy, uPx, uRings, uSeed, uPulse, uSweep, uRipple;
uniform vec3 uA, uG;

const float PI = 3.14159265;
float max3(vec3 c){ return max(max(c.r, c.g), c.b); }

void main(){
  vec2 p = v;
  float t = uT;
  float E = clamp(uEnergy, 0., 1.);
  float R = .54;
  float r = length(p);

  // Silhouette: a true circle. Breathing and voice energy scale it uniformly (never deform it).
  float Re = R * (1. + E*.055 + sin(t*.9)*.010 + uPulse*.022);
  vec2 q = p / Re;
  float rr = dot(q, q);
  float edge = 1. - smoothstep(Re - uPx*1.2, Re + uPx*1.2, r);

  // ---- soft outer glow (concentric) -------------------------------------------------------------
  float d = max(r - Re, 0.);
  float gI = exp(-d*5.2) * (.20 + E*.62) + exp(-d*15.) * .30;
  vec3 gCol = mix(uG, uA, .35 + .15*sin(t*.35 + uSeed));
  vec3 outCol = gCol * gI * (1. - smoothstep(.62, .98, r));

  // ---- the glass sphere -------------------------------------------------------------------------
  vec3 sph = vec3(0.);
  if (rr < 1.2) {
    float z = sqrt(max(1. - rr, 0.));
    float rho = sqrt(rr);
    float breathe = .5 + .5*sin(t*.45 + rho*2.6 + uSeed);

    // saturated deep edge -> bright luminous centre (no near-black, works on light and dark pages)
    vec3 edgeCol = uG*.40 + vec3(0., 0., .02);
    vec3 body = mix(edgeCol, uG, smoothstep(0., .55, z));
    body = mix(body, mix(uG, uA, .62), smoothstep(.30, 1., z) * (.78 + .18*breathe));

    // light from above: brighter top, deeper bottom (mirror-symmetric)
    body *= .84 + .30*(q.y*.5 + .5);

    // luminous core
    body += mix(uA, vec3(1.), .45) * pow(z, 5.) * (.12 + E*.28 + uPulse*.10);

    // light focused by the glass: a soft crescent along the bottom inside edge
    float low = clamp(-q.y / max(rho, 1e-3), 0., 1.);
    float band = exp(-pow((rho - .80)/.16, 2.));
    body += mix(uA, uG, .30) * band * pow(low, 2.2) * .38;

    // thin rim in the accent colour
    body += uA * pow(1. - z, 4.) * (.65 + E*.40);

    // broad soft sheen on top + a fine reflected crescent just inside the rim (both centred on the vertical axis)
    float sheen = 1. - smoothstep(0., 1., length((q - vec2(0., .64)) / vec2(.66, .30)));
    body += mix(uA, vec3(1.), .5) * sheen * .13;
    float crescent = exp(-pow((rho - .90)/.035, 2.)) * smoothstep(.45, .92, q.y / max(rho, 1e-3));
    body += vec3(1.) * crescent * .34;

    sph = body;
  }

  vec3 col = sph * edge + outCol * (1. - edge);

  // ---- hairline ring, travelling arcs and ripples ----------------------------------------------
  if (uRings > .01) {
    float Rr = R * 1.34;
    float dr = abs(r - Rr);
    float line = 1. - smoothstep(0., uPx*1.5, dr - uPx*.55);   // crisp 1px line at any size
    float soft = exp(-(dr*dr) / (uPx*uPx*30.));
    vec3 tint = mix(uG, uA, .55);

    // two opposite arcs (point-symmetric); each has a long tail and a bright head
    float ang = atan(p.y, p.x);
    float a1 = t*1.1 + uSeed*1.3;
    float dl = mod(a1 - ang, PI);
    float trail = exp(-dl*1.9) * smoothstep(0., .05, dl) * uSweep;

    vec3 fx = tint * (line*(.17 + trail*.95) + soft*trail*.22);
    for (int i = 0; i < 2; i++) {
      float a = a1 + float(i)*PI;
      vec2 dd = p - Rr*vec2(cos(a), sin(a));
      float s2 = R*R*.0011;
      fx += (mix(tint, vec3(1.), .55)*exp(-dot(dd,dd)/s2) + tint*.50*exp(-dot(dd,dd)/(s2*12.))) * uSweep;
    }

    // ripples: leave the sphere, travel to the ring and dissolve there (two phases per cycle)
    for (int k = 0; k < 2; k++) {
      float ph = fract(t*.20 + float(k)*.5);
      float rad = mix(Re*1.05, Rr, ph);
      float g = exp(-pow((r - rad)/(.007 + .007*ph), 2.));
      fx += tint * g * pow(1. - ph, 1.4) * uRipple * (.16 + E*.70);
    }
    col += fx * uRings;
  }

  // soft tonemap + static dithering against banding
  col = col / (1. + col*.30);
  col += (fract(52.9829189 * fract(dot(gl_FragCoord.xy, vec2(.06711056, .00583715)))) - .5) / 255.;
  col = max(col, 0.);
  float a = clamp(max(edge, max3(col)), 0., 1.);
  gl_FragColor = vec4(min(col, vec3(1.)), a);
}`;

  // Per-state targets: time speed, resting energy, ring brightness, core pulse, travelling arcs, ripples
  const STATES = {
    idle:      { speed: .55, base: .08, rings: .85, pulse: 0,  sweep: .35, ripple: 0   },
    listening: { speed: .95, base: .20, rings: 1.0, pulse: 0,  sweep: 0,   ripple: .55 },
    thinking:  { speed: 1.9, base: .26, rings: 1.1, pulse: 1,  sweep: 1,   ripple: 0   },
    speaking:  { speed: 1.2, base: .30, rings: 1.05, pulse: 0, sweep: 0,   ripple: 1   },
    loading:   { speed: 2.4, base: .22, rings: 1.1, pulse: .6, sweep: 1,   ripple: 0   },
    searching: { speed: 1.65, base: .23, rings: 1.15, pulse: .45, sweep: 1,   ripple: .12 },
    coding:    { speed: 1.45, base: .24, rings: 1.0, pulse: .5, sweep: .55, ripple: .28 },
    processing:{ speed: 1.15, base: .23, rings: 1.0, pulse: .55, sweep: .25, ripple: .65 }
  };

  const registry = new WeakMap();
  const reduced = () => { try { return global.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch { return false; } };

  function hex(value, fallback) {
    let s = String(value || '').trim();
    if (!/^#?[0-9a-f]{3,8}$/i.test(s)) s = fallback;
    s = s.replace('#', '');
    if (s.length === 3) s = s.split('').map(ch => ch + ch).join('');
    const n = parseInt(s.slice(0, 6), 16);
    return [((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255];
  }
  function seedOf(key) {
    let h = 7;
    for (const ch of String(key || 'ara')) h = (h * 31 + ch.charCodeAt(0)) % 997;
    return (h % 97) / 97 * 6;
  }
  const lerp = (a, b, k) => a + (b - a) * k;

  class Orb {
    constructor(host, options = {}) {
      this.host = host;
      this.opts = options;
      this.state = STATES[options.state || host.dataset.state] ? (options.state || host.dataset.state) : 'idle';
      this.level = Math.max(0, Math.min(1, Number(options.energy) || 0));
      this.energy = 0;
      this.seed = seedOf(options.seed || host.dataset.orbSeed);
      this.time = 2 + this.seed;
      this.accent = hex(options.accent || host.dataset.orbAccent, '#b59aff');
      this.glow = hex(options.glow || host.dataset.orbGlow, '#825dff');
      this.curA = this.accent.slice(); this.curG = this.glow.slice();
      const cfg = STATES[this.state];
      this.speed = cfg.speed; this.rings = cfg.rings; this.sweep = cfg.sweep; this.ripple = cfg.ripple; this.pulse = 0;
      this.ringScale = (options.rings === 0 || host.dataset.orbRings === '0') ? 0 : 1;
      this.last = 0; this.raf = 0; this.visible = true; this.dead = false;
      this.reduced = reduced();
      if (this.reduced) this.energy = cfg.base;
      this.canvas = document.createElement('canvas');
      this.canvas.className = 'xorb-canvas';
      this.canvas.setAttribute('aria-hidden', 'true');
      host.classList.add('xorb');
      host.appendChild(this.canvas);
      this.loop = this.loop.bind(this);
      if (!this.initGL()) { this.fallback(); return; }
      this.bindEvents();
      this.resize();
      this.raf = requestAnimationFrame(this.loop);
    }

    initGL() {
      let gl = null;
      try { gl = this.canvas.getContext('webgl', { alpha: true, premultipliedAlpha: true, antialias: false, powerPreference: 'low-power', preserveDrawingBuffer: false }) || this.canvas.getContext('experimental-webgl'); } catch { gl = null; }
      if (!gl) return false;
      const compile = (type, src) => { const sh = gl.createShader(type); gl.shaderSource(sh, src); gl.compileShader(sh); if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) { const log = gl.getShaderInfoLog(sh); gl.deleteShader(sh); throw new Error(log || 'shader'); } return sh; };
      try {
        const prog = gl.createProgram();
        gl.attachShader(prog, compile(gl.VERTEX_SHADER, VERT));
        gl.attachShader(prog, compile(gl.FRAGMENT_SHADER, FRAG));
        gl.linkProgram(prog);
        if (!gl.getProgramParameter(prog, gl.LINK_STATUS)) return false;
        gl.useProgram(prog);
        const buf = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, buf);
        gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
        const loc = gl.getAttribLocation(prog, 'a');
        gl.enableVertexAttribArray(loc);
        gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
        this.u = {};
        ['uT', 'uEnergy', 'uPx', 'uRings', 'uSeed', 'uPulse', 'uSweep', 'uRipple', 'uA', 'uG'].forEach(name => { this.u[name] = gl.getUniformLocation(prog, name); });
        this.gl = gl; this.prog = prog;
        gl.clearColor(0, 0, 0, 0);
        return true;
      } catch (error) {
        if (global.console) console.warn('[SayroxOrb] WebGL disabled:', error.message);
        return false;
      }
    }

    fallback() {
      this.dead = false;
      this.canvas.remove();
      this.host.classList.add('xorb-fallback');
      this.host.insertAdjacentHTML('beforeend', '<span class="xorb-fb xorb-fb-aura"></span><span class="xorb-fb xorb-fb-ring"></span><span class="xorb-fb xorb-fb-ball"><i></i></span>');
      this.applyCssVars();
    }
    applyCssVars() {
      const css = rgb => '#' + rgb.map(x => Math.round(Math.max(0, Math.min(1, x)) * 255).toString(16).padStart(2, '0')).join('');
      this.host.style.setProperty('--orb-a', css(this.accent));
      this.host.style.setProperty('--orb-g', css(this.glow));
    }

    bindEvents() {
      const host = this.host;
      this.onResize = () => this.resize();
      if ('ResizeObserver' in global) { this.ro = new ResizeObserver(this.onResize); this.ro.observe(host); } else global.addEventListener('resize', this.onResize);
      if ('IntersectionObserver' in global) { this.io = new IntersectionObserver(entries => { this.visible = entries.some(e => e.isIntersecting); this.kick(); }); this.io.observe(host); }
      this.onVis = () => this.kick();
      document.addEventListener('visibilitychange', this.onVis);
      this.canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); cancelAnimationFrame(this.raf); this.raf = 0; this.host.classList.add('xorb-lost'); });
      this.canvas.addEventListener('webglcontextrestored', () => { this.host.classList.remove('xorb-lost'); if (this.initGL()) { this.resize(); this.kick(); } else this.fallback(); });
    }

    resize() {
      if (!this.gl) return;
      const b = this.host.getBoundingClientRect();
      const dpr = Math.min(global.devicePixelRatio || 1, 2) * (this.opts.quality || 1);
      const size = Math.max(32, Math.round(Math.max(b.width, b.height) * dpr));
      if (this.canvas.width !== size || this.canvas.height !== size) { this.canvas.width = size; this.canvas.height = size; }
      this.gl.viewport(0, 0, size, size);
      this.px = 2 / size;
      this.draw(0);
    }

    kick() { if (!this.raf && !this.dead && this.gl) this.raf = requestAnimationFrame(this.loop); }

    loop(now) {
      this.raf = 0;
      if (this.dead || !this.gl) return;
      if (!this.host.isConnected) { this.destroy(); return; }
      if (document.hidden || !this.visible || !this.host.offsetWidth) { this.last = 0; return; }
      const dt = this.last ? Math.min((now - this.last) / 1000, .05) : .016;
      this.last = now;
      this.draw(dt);
      if (!this.reduced || this.needsFrame) this.raf = requestAnimationFrame(this.loop);
      else this.last = 0;
    }

    draw(dt) {
      const gl = this.gl; if (!gl || gl.isContextLost()) return;
      const cfg = STATES[this.state] || STATES.idle;
      const k = this.reduced ? 1 : Math.min(1, dt * 5);
      this.speed = this.reduced ? cfg.speed : lerp(this.speed, cfg.speed, k);
      this.rings = this.reduced ? cfg.rings : lerp(this.rings, cfg.rings, k);
      this.sweep = this.reduced ? cfg.sweep : lerp(this.sweep, cfg.sweep, k);
      this.ripple = this.reduced ? cfg.ripple : lerp(this.ripple, cfg.ripple, k);
      this.pulse = this.reduced ? 0 : lerp(this.pulse, cfg.pulse ? (.5 + .5 * Math.sin(this.time * 2.6)) * cfg.pulse : 0, Math.min(1, dt * 8));
      if (!this.reduced) this.time += dt * this.speed;
      let target = Math.max(cfg.base, this.level);
      if (this.state === 'speaking' && this.level < .05) target += this.reduced ? .1 : .2 * (.5 + .5 * Math.sin(this.time * 7.3) * Math.sin(this.time * 3.1 + 1));
      if (this.reduced) this.energy = target;
      else this.energy += (target - this.energy) * Math.min(1, dt * (target > this.energy ? 14 : 3.2));
      const ck = this.reduced ? 1 : Math.min(1, dt * 4.5);
      let moving = false;
      for (let i = 0; i < 3; i++) {
        this.curA[i] = lerp(this.curA[i], this.accent[i], ck); this.curG[i] = lerp(this.curG[i], this.glow[i], ck);
        if (Math.abs(this.curA[i] - this.accent[i]) > .004 || Math.abs(this.curG[i] - this.glow[i]) > .004) moving = true;
      }
      this.needsFrame = !this.reduced && moving;
      const u = this.u;
      gl.uniform1f(u.uT, this.time);
      gl.uniform1f(u.uEnergy, this.energy);
      gl.uniform1f(u.uPx, this.px || .004);
      gl.uniform1f(u.uRings, this.rings * this.ringScale);
      gl.uniform1f(u.uSeed, this.seed);
      gl.uniform1f(u.uPulse, this.pulse);
      gl.uniform1f(u.uSweep, this.sweep);
      gl.uniform1f(u.uRipple, this.ripple);
      gl.uniform3f(u.uA, this.curA[0], this.curA[1], this.curA[2]);
      gl.uniform3f(u.uG, this.curG[0], this.curG[1], this.curG[2]);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
    }

    setColors(accent, glow) {
      if (accent) this.accent = hex(accent, '#b59aff');
      if (glow) this.glow = hex(glow, '#825dff');
      if (this.reduced) { this.curA = this.accent.slice(); this.curG = this.glow.slice(); }
      if (!this.gl) this.applyCssVars();
      this.needsFrame = !this.reduced; this.kick();
    }
    setSeed(key) { this.seed = seedOf(key); this.kick(); }
    setState(name) {
      if (!STATES[name] || name === this.state) return;
      this.state = name; this.host.dataset.state = name;
      if (this.reduced) {
        const target = STATES[name];
        this.speed = target.speed; this.rings = target.rings; this.sweep = target.sweep; this.ripple = target.ripple; this.pulse = 0;
        this.energy = Math.max(target.base, this.level); this.needsFrame = false;
      }
      this.kick();
    }
    setEnergy(value) {
      this.level = Math.max(0, Math.min(1, Number(value) || 0));
      if (this.reduced) { this.energy = Math.max(STATES[this.state]?.base ?? 0, this.level); this.kick(); }
    }
    destroy() {
      this.dead = true; cancelAnimationFrame(this.raf); this.raf = 0;
      this.ro?.disconnect(); this.io?.disconnect();
      global.removeEventListener('resize', this.onResize); document.removeEventListener('visibilitychange', this.onVis);
      try { this.gl?.getExtension('WEBGL_lose_context')?.loseContext(); } catch {}
      this.canvas.remove(); this.host.classList.remove('xorb', 'xorb-fallback', 'xorb-lost');
      this.host.querySelectorAll('.xorb-fb').forEach(node => node.remove());
      registry.delete(this.host);
    }
  }

  function mount(host, options) {
    if (!host) return null;
    const existing = registry.get(host);
    if (existing) { if (options?.accent || options?.glow) existing.setColors(options.accent, options.glow); if (options?.state) existing.setState(options.state); return existing; }
    const orb = new Orb(host, options || {});
    registry.set(host, orb);
    return orb;
  }
  const get = host => registry.get(host) || null;
  function mountAll(root) {
    (root || document).querySelectorAll('[data-orb]').forEach(host => {
      const style = getComputedStyle(host);
      mount(host, {
        accent: host.dataset.orbAccent || style.getPropertyValue('--voice-accent').trim() || style.getPropertyValue('--active-voice-accent').trim(),
        glow: host.dataset.orbGlow || style.getPropertyValue('--voice-glow').trim() || style.getPropertyValue('--active-voice-glow').trim(),
        seed: host.dataset.orbSeed, state: host.dataset.state || 'idle', quality: Number(host.dataset.orbQuality) || 1
      });
    });
  }
  function unmountIn(root) {
    if (!root) return;
    root.querySelectorAll('.xorb').forEach(host => registry.get(host)?.destroy());
  }
  global.SayroxOrb = Object.freeze({ mount, get, mountAll, unmountIn, states: Object.keys(STATES) });
})(globalThis);
