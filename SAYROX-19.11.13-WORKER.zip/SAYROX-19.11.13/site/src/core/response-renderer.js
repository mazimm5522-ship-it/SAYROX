// Safe ChatGPT-style response renderer for SAYROX.
// Reuses the shared Markdown block parser and the existing code workspace.
(function installSayroxResponseRenderer(root) {
  'use strict';

  const MATH_NS = 'http://www.w3.org/1998/Math/MathML';
  const GREEK = Object.freeze({
    alpha:'α', beta:'β', gamma:'γ', delta:'δ', epsilon:'ε', theta:'θ', lambda:'λ', mu:'μ',
    pi:'π', sigma:'σ', phi:'φ', omega:'ω', Gamma:'Γ', Delta:'Δ', Theta:'Θ', Lambda:'Λ',
    Pi:'Π', Sigma:'Σ', Phi:'Φ', Omega:'Ω'
  });
  const SYMBOLS = Object.freeze({
    times:'×', cdot:'·', pm:'±', mp:'∓', div:'÷', le:'≤', leq:'≤', ge:'≥', geq:'≥',
    neq:'≠', ne:'≠', approx:'≈', sim:'∼', infty:'∞', partial:'∂', nabla:'∇',
    sum:'∑', prod:'∏', int:'∫', rightarrow:'→', leftarrow:'←', leftrightarrow:'↔',
    to:'→', mapsto:'↦', ell:'ℓ', degree:'°', percent:'%'
  });

  function safeUrl(value) {
    try {
      const url = new URL(String(value), root.location?.href || 'https://sayrox.invalid/');
      return ['http:', 'https:', 'mailto:'].includes(url.protocol) && !url.username && !url.password ? url.href : null;
    } catch { return null; }
  }

  function appendText(parent, value) {
    if (value) parent.appendChild(root.document.createTextNode(String(value)));
  }

  function mathNode(tag, text) {
    const node = root.document.createElementNS(MATH_NS, tag);
    if (text !== undefined) node.textContent = String(text);
    node.setAttribute('data-sayrox-math-node', tag);
    return node;
  }

  function renderMath(source, display = false) {
    const input = String(source ?? '').slice(0, 1200);
    const rootMath = mathNode('math');
    rootMath.setAttribute('display', display ? 'block' : 'inline');
    rootMath.setAttribute('role', 'math');
    rootMath.setAttribute('aria-label', input.replace(/\\([A-Za-z]+)/g, '$1').slice(0, 500));
    let index = 0;

    const command = () => {
      if (index >= input.length) return '';
      if (!/[A-Za-z]/.test(input[index])) return input[index++];
      const start = index;
      while (index < input.length && /[A-Za-z]/.test(input[index])) index++;
      return input.slice(start, index);
    };
    const group = () => {
      while (/\s/.test(input[index] || '')) index++;
      if (input[index] === '{') {
        index++;
        const value = sequence('}');
        if (input[index] === '}') index++;
        return value;
      }
      return atom();
    };
    const atom = () => {
      if (index >= input.length) return mathNode('mrow');
      const char = input[index++];
      if (char === '{') {
        const value = sequence('}');
        if (input[index] === '}') index++;
        return value;
      }
      if (char === '\\') {
        const name = command();
        if (name === 'frac') {
          const numerator = group();
          const denominator = group();
          const fraction = mathNode('mfrac');
          fraction.append(numerator, denominator);
          return fraction;
        }
        if (name === 'sqrt') {
          const square = mathNode('msqrt');
          square.appendChild(group());
          return square;
        }
        if (name === 'text' || name === 'mathrm' || name === 'mathbf') {
          const value = group();
          const wrapper = mathNode(name === 'text' ? 'mtext' : 'mi');
          wrapper.textContent = value.textContent || '';
          return wrapper;
        }
        if (name === 'left' || name === 'right' || name === 'displaystyle' || name === 'quad' || name === 'qquad') return mathNode('mspace');
        if (name === ',' || name === ';' || name === ':' || name === '!') return mathNode('mspace');
        if (Object.hasOwn(GREEK, name)) return mathNode('mi', GREEK[name]);
        if (Object.hasOwn(SYMBOLS, name)) return mathNode('mo', SYMBOLS[name]);
        return mathNode('mtext', `\\${name}`);
      }
      if (/\d/.test(char)) {
        let value = char;
        while (index < input.length && /[\d.,]/.test(input[index])) value += input[index++];
        return mathNode('mn', value);
      }
      if (/[A-Za-z]/.test(char)) return mathNode('mi', char);
      if (/\s/.test(char)) return mathNode('mspace');
      return mathNode('mo', char);
    };
    const sequence = (stop = '') => {
      const entries = [];
      while (index < input.length && (!stop || input[index] !== stop)) {
        if (input[index] === '^' || input[index] === '_') {
          const kind = input[index++];
          const value = group();
          const last = entries[entries.length - 1];
          if (last) last[kind === '^' ? 'sup' : 'sub'] = value;
          else entries.push({ node: mathNode('mtext', kind), sub: null, sup: value });
          continue;
        }
        entries.push({ node: atom(), sub: null, sup: null });
      }
      const row = mathNode('mrow');
      for (const entry of entries) {
        let node = entry.node;
        if (entry.sub && entry.sup) {
          const combined = mathNode('msubsup'); combined.append(node, entry.sub, entry.sup); node = combined;
        } else if (entry.sub) {
          const combined = mathNode('msub'); combined.append(node, entry.sub); node = combined;
        } else if (entry.sup) {
          const combined = mathNode('msup'); combined.append(node, entry.sup); node = combined;
        }
        row.appendChild(node);
      }
      return row;
    };

    rootMath.appendChild(sequence());
    rootMath.classList?.add(display ? 'sayrox-math-display' : 'sayrox-math-inline');
    return rootMath;
  }

  function appendInline(parent, value) {
    const source = String(value ?? '');
    const pattern = /\$\$([\s\S]+?)\$\$|\\\[([\s\S]+?)\\\]|\\\(([\s\S]+?)\\\)|(?<!\\)\$([^$\n]+?)\$|\[([^\]\n]{1,300})\]\((https?:\/\/[^\s)]+|mailto:[^\s)]+)\)|`([^`\n]+)`|\*\*([^*\n]+)\*\*|__([^_\n]+)__|~~([^~\n]+)~~|(?<!\*)\*([^*\n]+)\*(?!\*)|(?<!_)_([^_\n]+)_(?!_)/g;
    let cursor = 0, match;
    while ((match = pattern.exec(source))) {
      appendText(parent, source.slice(cursor, match.index));
      if (match[1] !== undefined || match[2] !== undefined) {
        const expression = match[1] ?? match[2];
        const display = root.document.createElement('span');
        display.className = 'sayrox-math-block';
        display.appendChild(renderMath(expression, true));
        parent.appendChild(display);
      } else if (match[3] !== undefined || match[4] !== undefined) {
        const expression = match[3] ?? match[4];
        parent.appendChild(renderMath(expression, false));
      } else if (match[5] !== undefined) {
        const url = safeUrl(match[6]);
        if (url) {
          const link = root.document.createElement('a');
          link.href = url; link.target = '_blank'; link.rel = 'noopener noreferrer';
          link.textContent = match[5]; parent.appendChild(link);
        } else appendText(parent, `${match[5]} (${match[6]})`);
      } else if (match[7] !== undefined) {
        const code = root.document.createElement('code');
        code.className = 'sayrox-inline-code'; code.textContent = match[7];
        code.setAttribute('dir', 'ltr'); parent.appendChild(code);
      } else {
        const strong = match[8] ?? match[9];
        const strike = match[10];
        const emphasis = match[11] ?? match[12];
        const node = root.document.createElement(strong !== undefined ? 'strong' : strike !== undefined ? 'del' : 'em');
        node.textContent = strong ?? strike ?? emphasis;
        parent.appendChild(node);
      }
      cursor = match.index + match[0].length;
    }
    appendText(parent, source.slice(cursor));
  }

  function renderCodeBlock(parent, block, blockIndex, options) {
    const code = String(block.text ?? '');
    if (!options.streaming && root.SayroxCodeWorkspace?.createBlock) {
      const workspace = root.SayroxCodeWorkspace;
      const editable = workspace.createBlock({
        language: block.language || 'text', source: code,
        onSave: nextCode => typeof options.onCodeSave === 'function' ? options.onCodeSave(blockIndex, nextCode) : false
      });
      parent.appendChild(editable);
      return;
    }
    const details = root.document.createElement('details'); details.className = 'code-disclosure sayrox-code-block';
    const summary = root.document.createElement('summary');
    summary.textContent = `کد · ${String(block.language || 'text').toUpperCase()} — برای مشاهده باز کن`;
    const pre = root.document.createElement('pre');
    const codeNode = root.document.createElement('code');
    codeNode.textContent = code; codeNode.setAttribute('dir', 'ltr');
    if (block.language) codeNode.className = `language-${String(block.language).replace(/[^\w+-]/g, '')}`;
    pre.appendChild(codeNode); details.append(summary, pre);
    const copy = root.document.createElement('button'); copy.type = 'button';
    copy.className = 'code-copy'; copy.textContent = 'کپی کد';
    copy.addEventListener('click', async () => {
      try { await root.navigator.clipboard.writeText(code); copy.textContent = 'کپی شد'; }
      catch { copy.textContent = 'کپی در دسترس نیست'; }
    });
    details.appendChild(copy); parent.appendChild(details);
  }

  function render(container, raw, options = {}) {
    if (!container?.replaceChildren) return false;
    const markdown = root.SayroxMarkdown;
    if (!markdown?.parseBlocks) {
      container.textContent = String(raw ?? '');
      return false;
    }
    const blocks = markdown.parseBlocks(String(raw ?? ''));
    container.replaceChildren();
    let codeIndex = 0;
    for (const block of blocks) {
      let node;
      switch (block.type) {
        case 'heading':
          node = root.document.createElement(`h${Math.min(4, Math.max(2, Number(block.level) || 2))}`);
          appendInline(node, block.text); container.appendChild(node); break;
        case 'paragraph':
          node = root.document.createElement('p'); node.className = 'sayrox-markdown-paragraph';
          node.setAttribute('dir', 'auto'); appendInline(node, block.text); container.appendChild(node); break;
        case 'list': {
          node = root.document.createElement(block.ordered ? 'ol' : 'ul');
          for (const item of block.items || []) { const li = root.document.createElement('li'); appendInline(li, item); node.appendChild(li); }
          container.appendChild(node); break;
        }
        case 'quote':
          node = root.document.createElement('blockquote');
          for (const line of block.lines || []) { const p = root.document.createElement('p'); appendInline(p, line); node.appendChild(p); }
          container.appendChild(node); break;
        case 'table': {
          const wrap = root.document.createElement('div'); wrap.className = 'sayrox-table-wrap';
          const table = root.document.createElement('table'); table.className = 'sayrox-response-table';
          const rows = block.rows || [];
          if (rows.length) {
            const thead = root.document.createElement('thead'), tr = root.document.createElement('tr');
            for (const cell of rows[0]) { const th = root.document.createElement('th'); appendInline(th, cell); tr.appendChild(th); }
            thead.appendChild(tr); table.appendChild(thead);
            const tbody = root.document.createElement('tbody');
            for (const row of rows.slice(1)) { const bodyRow = root.document.createElement('tr'); for (let i=0;i<rows[0].length;i++) { const td = root.document.createElement('td'); appendInline(td, row[i] ?? ''); bodyRow.appendChild(td); } tbody.appendChild(bodyRow); }
            table.appendChild(tbody);
          }
          wrap.appendChild(table); container.appendChild(wrap); break;
        }
        case 'code': renderCodeBlock(container, block, codeIndex++, options); break;
        case 'rule': node = root.document.createElement('hr'); container.appendChild(node); break;
        default: node = root.document.createElement('p'); node.textContent = String(block.text ?? ''); container.appendChild(node);
      }
    }
    container.classList?.add('sayrox-response-content');
    container.setAttribute('data-render-mode', options.streaming ? 'streaming' : 'complete');
    return true;
  }

  root.SayroxResponseRenderer = Object.freeze({ render, renderMath, appendInline, safeUrl });
})(globalThis);
