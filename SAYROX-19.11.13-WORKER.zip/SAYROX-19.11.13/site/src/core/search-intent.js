(function installSayroxSearchIntent(root) {
  'use strict';

  const EXPLICIT_SEARCH = /(?:سرچ\s*کن|جست[\s‌-]*وجو\s*کن|در\s+اینترنت\s+پیدا\s+کن|توی\s+وب\s+بگرد|در\s+وب\s+بگرد|منبع(?:\s+معتبر)?\s+بده|منابع\s+معتبر|لینک\s+منبع|با\s+استناد|search\s+(?:the\s+)?web|look\s+up|browse\s+(?:the\s+)?web|find\s+(?:this\s+)?online|search\s+online|cite\s+(?:your\s+)?sources|give\s+me\s+sources)/i;
  const NO_SEARCH = /(?:بدون\s+(?:سرچ|جست[\s‌-]*وجو)|سرچ\s+نکن|جست[\s‌-]*وجو\s+نکن|از\s+دانش\s+خودت|نیازی\s+به\s+اینترنت\s+نیست|don't\s+search|do\s+not\s+search|no\s+web|without\s+web\s+search)/i;
  const NEWS = /(?:خبر(?:ها|های)?(?![آ-ی])|اخبار(?![آ-ی])|خبر\s+فوری|تحولات|اتفاقات\s+امروز|امروز\s+چه\s+اتفاقی\s+افتاده|چه\s+خبر|رویدادهای\s+امروز|انتخابات|درگیری|جنگ\s+امروز|زلزله|سیل|آتش[‌ -]?سوزی|latest\s+news|breaking\s+news|news\s+today|what\s+happened\s+today|recent\s+developments|election\s+results|current\s+events)/i;
  const FINANCE_ASSET = /(?:دلار|یورو|پوند|تتر|بیت[‌ -]?کوین|اتریوم|ارز|سهام|بورس|طلا|سکه|bitcoin|\bbtc\b|ethereum|\beth\b|usd|eur|gbp|gold|silver|stock|share|crypto|cryptocurrency)/i;
  const FINANCE_PRICE = /(?:قیمت|نرخ|ارزش|exchange\s+rate|stock\s+price|share\s+price|gold\s+price|bitcoin\s+price|crypto\s+price|market\s+price|currency\s+rate|interest\s+rate|price\s+of|how\s+much|\bworth\b)/i;
  const GENERAL_PRICE = /(?:قیمت|هزینه|گران[‌ -]?تر|ارزان[‌ -]?تر|price\s+of|how\s+much|\bcost\b)/i;
  const FINANCE = /(?:نرخ.{0,18}(?:دلار|یورو|پوند|تتر|بیت[‌ -]?کوین|اتریوم|ارز|بهره)|ارزش.{0,18}(?:دلار|یورو|پوند|تتر|بیت[‌ -]?کوین|اتریوم|طلا|سکه)|بازار\s+(?:ارز|بورس|سهام|مالی)|بورس|سهام|ارز\s+دیجیتال|نرخ\s+تبدیل|interest\s+rate|exchange\s+rate|stock\s+price|share\s+price|gold\s+price|bitcoin\s+price|crypto\s+price|market\s+price|currency\s+rate)/i;
  const WEATHER = /(?:آب[‌ -]?و[‌ -]?هوا|هواشناسی|پیش[‌ -]?بینی\s+هوا|دمای\s+(?:هوا|امروز)|بارندگی|احتمال\s+باران|weather\s+(?:in|for|today|tomorrow)|weather\s+forecast|temperature\s+in|will\s+it\s+rain)/i;
  const LOCAL = /(?:نزدیک\s+من|اطراف\s+من|نزدیک\s+اینجا|الان\s+باز(?:\s+است|ه)?|ساعت\s+کاری|ساعات\s+کاری|شماره\s+تماس|نوبت\s+خالی|رزرو\s+(?:امروز|فردا|برای)|open\s+now|opening\s+hours|business\s+hours|near\s+me|nearby|availability\s+today|(?:best|recommend)\s+(?:restaurants?|cafes?|hotels?)|(?:بهترین|معرفی\s+کن)\s+.{0,20}(?:رستوران|کافه|هتل|داروخانه|فروشگاه))/i;
  const RECENT = /(?:امروز|الان|همین\s+الان|در\s+حال\s+حاضر|فعلی|کنونی|تازه|جدیدترین|آخرین|به[‌ -]?روز|بروز|این\s+هفته|هفته[‌ -]?ی\s+اخیر|این\s+ماه|ماه[‌ -]?ی\s+اخیر|سال\s+جاری|اخیراً|اخيرا|دیروز|فردا|نسخه\s+جدید|نسخه\s+فعلی|آپدیت\s+جدید|update|latest|newest|current|currently|right\s+now|today|yesterday|tomorrow|this\s+week|this\s+month|recent(?:ly)?|up[ -]?to[ -]?date|latest\s+version|new\s+release|release\s+date)/i;
  const CURRENT_DOMAIN = /(?:رئیس[‌ -]?جمهور|نخست[‌ -]?وزیر|وزیر|مدیرعامل|مدیر\s+عامل|مالک|مدیر\s+فعلی|قوانین?|مقررات|بخشنامه|شرایط\s+جدید|سیاست\s+رسمی|نسخه|ورژن|انتشار|عرضه|امنیت|آسیب[‌ -]?پذیری|قابلیت\s+جدید|مدل\s+هوش\s+مصنوعی|مدل[‌ -]?های\s+جدید|رویداد|مسابقه|بازی\s+امروز|نتیجه|امتیاز|برنامه\s+زمان[‌ -]?بندی|پرواز|قطار|کنسرت|فستیوال|گوشی|لپ[‌ -]?تاپ|تبلت|محصول|فناوری|نرم[‌ -]?افزار|سیستم[‌ -]?عامل|اپلیکیشن|آیفون|سامسونگ|president|prime\s+minister|ceo|current\s+leader|law|regulation|policy|software|framework|library|version|release|security\s+patch|vulnerability|AI\s+model|model\s+release|match\s+result|score|schedule|flight|train|concert|festival|iphone|samsung|apple|android|ios|windows|macos|cloudflare|openai|chatgpt|gapgpt|react|node(?:\.js)?|python|javascript|typescript|flutter)/i;
  const CURRENT_ROLE = /(?:(?:who\s+is|who\'s|چه\s+کسی|کی)\s+.{0,45}(?:president|prime\s+minister|ceo|رئیس[‌ -]?جمهور|نخست[‌ -]?وزیر|مدیرعامل)|(?:president|prime\s+minister|ceo|رئیس[‌ -]?جمهور|نخست[‌ -]?وزیر|مدیرعامل).{0,30}(?:who|کیست|کیه|الان|فعلی))/i;
  const PRODUCT_RESEARCH = /(?:(?:بهترین|مقایسه|کدام\s+بهتر|کدوم\s+بهتر|برای\s+خرید|راهنمای\s+خرید|چه\s+مدلی).{0,55}(?:گوشی|موبایل|لپ[‌ -]?تاپ|تبلت|هوش\s+مصنوعی|مدل|نرم[‌ -]?افزار|اپلیکیشن|دوربین|خودرو|ماشین)|(?:best|compare|comparison|versus|\bvs\b|which\s+is\s+better|buying\s+guide).{0,60}(?:phone|smartphone|laptop|tablet|AI\s+model|AI\s+assistant|software|app|camera|car|vehicle))/i;
  const EXPLICIT_TIME_CONTEXT = /(?:امروز|الان|همین\s+الان|فعلی|کنونی|در\s+حال\s+حاضر|جدیدترین|آخرین|اخیر|این\s+هفته|این\s+ماه|سال\s+جاری|latest|current|currently|today|right\s+now|recent|this\s+week|this\s+month|newest)/i;
  const CREATIVE_OR_TRANSFORM = /(?:ترجمه\s+کن|ترجمه\s+این|خلاصه\s+کن|خلاصه[‌ -]?سازی|بازنویسی|ویرایش\s+کن|اصلاح\s+نگارشی|روان[‌ -]?تر\s+کن|(?:شعر|داستان|سناریو|کپشن|ایمیل|نامه|متن\s+تبریک|پرامپت).{0,24}(?:بنویس|بگو|بساز)|ایده\s+بده|کد\s+بنویس|کدنویسی|دیباگ|debug|translate\s+this|summari[sz]e\s+this|rewrite\s+this|proofread|write\s+(?:a|an|me)\s+(?:poem|story|email|letter|caption|script)|draft\s+(?:a|an|me)|fix\s+this\s+code|debug\s+this)/i;
  const PROVIDED_CONTEXT = /(?:متن\s+(?:زیر|بالا|ارسالی)|این\s+متن|فایل\s+(?:بالا|پیوست)|تصویر\s+(?:بالا|پیوست)|کد\s+(?:زیر|بالا)|همین\s+گفتگو|مکالمه[‌ -]?ی\s+بالا|the\s+text\s+below|the\s+attached\s+file|the\s+code\s+below|this\s+conversation)/i;
  const STATIC_DEFINITION = /(?:چیست(?:؟|\s|$)|یعنی\s+چه|چه\s+مفهومی\s+دارد|what\s+is\s+.{0,50}\?|what\s+are\s+.{0,50}\?|define\s+|definition\s+of\s+|how\s+does\s+.{0,50}\s+work\??)/i;

  function normalize(value) {
    return String(value ?? '')
      .normalize('NFKC')
      .replace(/[يى]/g, 'ی')
      .replace(/ك/g, 'ک')
      .replace(/[\u064B-\u065F\u0670]/g, '')
      .replace(/[۰-۹]/g, digit => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)))
      .replace(/\s+/g, ' ')
      .trim();
  }

  function timeRangeFor(query, topic) {
    if (/(?:امروز|همین\s+الان|فوری|today|right\s+now|breaking)/i.test(query)) return 'day';
    if (/(?:این\s+هفته|هفته[‌ -]?ی\s+اخیر|هفت\s+روز|this\s+week|past\s+week)/i.test(query)) return 'week';
    if (/(?:این\s+ماه|ماه[‌ -]?ی\s+اخیر|this\s+month|past\s+month)/i.test(query)) return 'month';
    if (/(?:سال\s+جاری|امسال|this\s+year|past\s+year)/i.test(query)) return 'year';
    return topic === 'news' ? 'week' : undefined;
  }

  function result(shouldSearch, topic, reason, confidence, query, mode = 'auto') {
    return Object.freeze({
      shouldSearch,
      topic,
      reason,
      confidence,
      mode,
      ...(shouldSearch && timeRangeFor(query, topic) ? { timeRange: timeRangeFor(query, topic) } : {})
    });
  }

  function classifySearchIntent(input) {
    const query = normalize(input);
    if (query.length < 3) return result(false, 'general', 'پیام کوتاه یا احوال‌پرسی', 0.99, query);
    if (NO_SEARCH.test(query)) return result(false, 'general', 'کاربر جست‌وجو را غیرفعال کرده است', 1, query);
    if (EXPLICIT_SEARCH.test(query)) {
      const topic = (FINANCE.test(query) || (FINANCE_PRICE.test(query) && FINANCE_ASSET.test(query)) || (RECENT.test(query) && FINANCE_ASSET.test(query))) ? 'finance' : NEWS.test(query) ? 'news' : 'general';
      return result(true, topic, 'درخواست صریح جست‌وجوی اینترنت', 1, query);
    }

    const providedContext = PROVIDED_CONTEXT.test(query);
    const creative = CREATIVE_OR_TRANSFORM.test(query);
    if (providedContext && !RECENT.test(query)) return result(false, 'general', 'پردازش متن یا فایل ارائه‌شده', 0.97, query);
    if (STATIC_DEFINITION.test(query) && !RECENT.test(query) && !FINANCE.test(query) && !FINANCE_PRICE.test(query) && !GENERAL_PRICE.test(query) && !WEATHER.test(query) && !LOCAL.test(query)) return result(false, 'general', 'پرسش تعریفی و پایدار؛ بدون نیاز به وب', 0.95, query);
    if (creative && !EXPLICIT_TIME_CONTEXT.test(query) && !NEWS.test(query) && !FINANCE.test(query)) {
      return result(false, 'general', 'درخواست نوشتاری یا ویرایشی؛ بدون نیاز به وب', 0.96, query);
    }

    if (NEWS.test(query)) {
      return result(true, 'news', 'خبر یا رویداد وابسته به اطلاعات تازه', 0.94, query);
    }
    if (FINANCE.test(query) || (FINANCE_PRICE.test(query) && FINANCE_ASSET.test(query)) || (RECENT.test(query) && FINANCE_ASSET.test(query))) {
      return result(true, 'finance', 'قیمت، نرخ یا اطلاعات بازار', 0.93, query);
    }
    if (GENERAL_PRICE.test(query)) {
      return result(true, 'general', 'قیمت یا هزینه‌ی متغیر', 0.88, query);
    }
    if (WEATHER.test(query)) {
      return result(true, 'general', 'هواشناسی و پیش‌بینی متغیر', 0.92, query);
    }
    if (LOCAL.test(query)) {
      return result(true, 'general', 'اطلاعات محلی، ساعات کاری یا دسترس‌پذیری', 0.88, query);
    }
    if (PRODUCT_RESEARCH.test(query)) {
      return result(true, 'general', 'مقایسه یا پیشنهاد خرید وابسته به گزینه‌های موجود', 0.86, query);
    }
    if (CURRENT_ROLE.test(query) || (RECENT.test(query) && CURRENT_DOMAIN.test(query))) {
      const topic = (FINANCE.test(query) || (FINANCE_PRICE.test(query) && FINANCE_ASSET.test(query)) || (RECENT.test(query) && FINANCE_ASSET.test(query))) ? 'finance' : NEWS.test(query) ? 'news' : 'general';
      return result(true, topic, 'اطلاعات زمان‌مند یا در حال تغییر', 0.86, query);
    }
    if (EXPLICIT_TIME_CONTEXT.test(query) && /(?:قانون|قوانین|مقررات|شرایط|قیمت|نرخ|مدل|نسخه|انتشار|آپدیت|ریلیز|وضعیت|مسئول|مدیر|رئیس|امتیاز|نتیجه|جدول|برنامه|پرواز|مسابقه|law|regulation|price|rate|model|version|release|update|status|leader|result|score|schedule|flight|match)/i.test(query)) {
      const topic = (FINANCE.test(query) || (FINANCE_PRICE.test(query) && FINANCE_ASSET.test(query)) || (RECENT.test(query) && FINANCE_ASSET.test(query))) ? 'finance' : NEWS.test(query) ? 'news' : 'general';
      return result(true, topic, 'نیاز به راستی‌آزمایی اطلاعات روز', 0.82, query);
    }

    return result(false, 'general', 'دانش پایدار یا کار قابل انجام بدون اینترنت', 0.9, query);
  }

  function resolveSearchPlan(input, mode = 'auto', manualTopic = 'general') {
    const detected = classifySearchIntent(input);
    if (detected.reason === 'کاربر جست‌وجو را غیرفعال کرده است') return { ...detected, mode: 'auto' };
    if (mode === 'off') return { shouldSearch: false, topic: 'general', mode: 'off', reason: 'جست‌وجوی اینترنت در تنظیمات خاموش است', confidence: 1 };
    if (mode === 'always') {
      const topic = manualTopic === 'news' ? 'news' : 'general';
      return { shouldSearch: true, topic, ...(topic === 'news' ? { timeRange: 'week' } : {}), mode: 'manual', reason: 'جست‌وجوی دستی به انتخاب کاربر', confidence: 1 };
    }
    return { ...detected, mode: 'auto' };
  }

  root.SayroxSearchIntent = Object.freeze({ classify: classifySearchIntent, resolve: resolveSearchPlan, normalize });
})(globalThis);
