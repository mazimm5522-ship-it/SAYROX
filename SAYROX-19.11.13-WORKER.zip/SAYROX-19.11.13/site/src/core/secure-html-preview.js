// Shared isolated HTML preview for chat code blocks and the local file studio.
// Do not loosen this sandbox or add allow-same-origin without a separate security review.
(function attachSecureHtmlPreview(root){
  'use strict';
  const MAX_HTML_CHARS=500_000;
  const CSP="default-src 'none'; img-src data: blob:; media-src data: blob:; style-src 'unsafe-inline'; script-src 'unsafe-inline'; connect-src 'none'; form-action 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'; font-src data:; worker-src 'none'; manifest-src 'none'; navigate-to 'none'";
  const POLICY_META=`<meta http-equiv="Content-Security-Policy" content="${CSP}">`;
  const CHARSET_META='<meta charset="utf-8">';

  function createPreviewDocument(value){
    const source=String(value??'').replace(/^\uFEFF/,'');
    if(source.length>MAX_HTML_CHARS)throw new RangeError(`پیش‌نمایش HTML حداکثر ${MAX_HTML_CHARS.toLocaleString('fa-IR')} نویسه را می‌پذیرد.`);
    if(/<head\b[^>]*>/i.test(source)){
      return source.replace(/<head\b[^>]*>/i,match=>`${match}${CHARSET_META}${POLICY_META}`);
    }
    if(/<html\b[^>]*>/i.test(source)){
      return source.replace(/<html\b[^>]*>/i,match=>`${match}<head>${CHARSET_META}${POLICY_META}</head>`);
    }
    const doctype=source.match(/^\s*<!doctype\s+html\s*>/i)?.[0]||'<!doctype html>';
    const body=source.slice(doctype.length);
    return `${doctype}<html lang="fa" dir="rtl"><head>${CHARSET_META}${POLICY_META}</head><body>${body}</body></html>`;
  }

  function createFrame(value,options={}){
    if(!root.document?.createElement)throw new Error('محیط مرورگر برای ساخت پیش‌نمایش در دسترس نیست.');
    const frame=root.document.createElement('iframe');
    frame.className=String(options.className||'sx-code-preview-frame');
    frame.title=String(options.title||'پیش‌نمایش ایزوله HTML');
    frame.setAttribute('sandbox','allow-scripts');
    frame.setAttribute('referrerpolicy','no-referrer');
    frame.setAttribute('loading','lazy');
    frame.srcdoc=createPreviewDocument(value);
    return frame;
  }

  root.SayroxSecureHtmlPreview=Object.freeze({createFrame,createPreviewDocument,maxHtmlChars:MAX_HTML_CHARS,policy:CSP});
})(window);
