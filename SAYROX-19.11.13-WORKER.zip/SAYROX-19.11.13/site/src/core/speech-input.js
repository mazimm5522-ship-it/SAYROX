/* SAYROX Speech Input — first-party real-time Scribe transport.
 * Uses a short-lived token from the authenticated Worker; the API key never reaches the browser.
 * Captures mono audio, downsamples it to PCM16/16 kHz and streams it over the documented WSS API.
 */
(function (global) {
  'use strict';

  const TARGET_RATE = 16000;
  const DEFAULT_MAX_DURATION = 180000;

  function downsampleToPcm16(input, inputRate, outputRate = TARGET_RATE) {
    if (!(input instanceof Float32Array) || !Number.isFinite(inputRate) || inputRate <= 0 ||
        !Number.isFinite(outputRate) || outputRate <= 0) {
      throw new TypeError('Invalid audio buffer or sample rate');
    }
    if (inputRate < outputRate) throw new RangeError('Input sample rate must be at least 16 kHz');
    if (input.length === 0) return new Int16Array(0);
    const ratio = inputRate / outputRate;
    const outputLength = Math.floor(input.length / ratio);
    const output = new Int16Array(outputLength);
    for (let outIndex = 0; outIndex < outputLength; outIndex += 1) {
      const start = Math.floor(outIndex * ratio);
      const end = Math.min(input.length, Math.floor((outIndex + 1) * ratio));
      let sum = 0;
      for (let i = start; i < end; i += 1) sum += input[i];
      const sample = Math.max(-1, Math.min(1, sum / Math.max(1, end - start)));
      output[outIndex] = sample < 0 ? Math.round(sample * 32768) : Math.round(sample * 32767);
    }
    return output;
  }

  function pcm16ToBase64(samples) {
    if (!(samples instanceof Int16Array)) throw new TypeError('PCM samples must be Int16Array');
    const bytes = new Uint8Array(samples.length * 2);
    const view = new DataView(bytes.buffer);
    for (let i = 0; i < samples.length; i += 1) view.setInt16(i * 2, samples[i], true);
    let binary = '';
    const chunkSize = 0x6000;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      const slice = bytes.subarray(i, Math.min(bytes.length, i + chunkSize));
      binary += String.fromCharCode(...slice);
    }
    return global.btoa(binary);
  }

  function waitForSocket(socket, timeoutMs, phase) {
    return new Promise((resolve, reject) => {
      const timer = global.setTimeout(() => reject(new Error(`Scribe ${phase} timeout`)), timeoutMs);
      const cleanup = () => {
        global.clearTimeout(timer);
        socket.removeEventListener('open', onOpen);
        socket.removeEventListener('error', onError);
        socket.removeEventListener('close', onClose);
      };
      const onOpen = () => { cleanup(); resolve(); };
      const onError = () => { cleanup(); reject(new Error('Scribe websocket connection failed')); };
      const onClose = () => { cleanup(); reject(new Error('Scribe websocket closed before startup')); };
      socket.addEventListener('open', onOpen, { once: true });
      socket.addEventListener('error', onError, { once: true });
      socket.addEventListener('close', onClose, { once: true });
    });
  }

  function waitForSession(socket, timeoutMs, setHandler) {
    return new Promise((resolve, reject) => {
      const timer = global.setTimeout(() => reject(new Error('Scribe session initialization timed out')), timeoutMs);
      const onMessage = event => {
        let data;
        try { data = JSON.parse(event.data); } catch { return; }
        if (data?.message_type === 'session_started') {
          global.clearTimeout(timer);
          socket.removeEventListener('message', onMessage);
          setHandler?.(data);
          resolve(data);
        } else if (data?.message_type === 'error' || data?.message_type === 'rate_limited') {
          global.clearTimeout(timer);
          socket.removeEventListener('message', onMessage);
          reject(new Error(data.error || (data.message_type === 'rate_limited' ? 'سقف درخواست گفتار پر شده است.' : 'موتور تشخیص گفتار خطا داد.')));
        }
      };
      const onClose = () => {
        global.clearTimeout(timer);
        socket.removeEventListener('message', onMessage);
        reject(new Error('Scribe connection closed during initialization'));
      };
      socket.addEventListener('message', onMessage);
      socket.addEventListener('close', onClose, { once: true });
    });
  }

  async function start(options = {}) {
    const token = String(options.token || '').trim();
    if (!token) throw new Error('توکن موقت تشخیص گفتار دریافت نشد.');
    if (!global.navigator?.mediaDevices?.getUserMedia) throw new Error('این مرورگر به ورودی میکروفون دسترسی نمی‌دهد.');
    const AudioContextCtor = global.AudioContext || global.webkitAudioContext;
    if (typeof global.WebSocket !== 'function' || typeof AudioContextCtor !== 'function') {
      throw new Error('مرورگر از اتصال زندهٔ صوتی پشتیبانی کافی ندارد.');
    }

    // The UI can obtain permission before requesting a billable single-use token.
    const stream = options.stream || await global.navigator.mediaDevices.getUserMedia({
      audio: { channelCount: 1, echoCancellation: true, noiseSuppression: true, autoGainControl: true }
    });
    let socket = null;
    let audioContext = null;
    let source = null;
    let processor = null;
    let processorMode = 'none';
    let silentGain = null;
    let durationTimer = 0;
    let stopped = false;

    const release = () => {
      if (stopped) return;
      stopped = true;
      global.clearTimeout(durationTimer);
      if (processor) {
        if (processor.port) { processor.port.onmessage = null; try { processor.port.postMessage({ type: 'stop' }); } catch {} }
        if ('onaudioprocess' in processor) processor.onaudioprocess = null;
        try { processor.disconnect(); } catch {}
      }
      try { source?.disconnect(); } catch {}
      try { silentGain?.disconnect(); } catch {}
      stream.getTracks().forEach(track => { try { track.stop(); } catch {} });
      if (socket && socket.readyState < global.WebSocket.CLOSING) {
        try { socket.close(1000, 'dictation stopped'); } catch {}
      }
      if (audioContext && audioContext.state !== 'closed') void audioContext.close().catch(() => {});
    };

    try {
      const url = new URL('wss://api.elevenlabs.io/v1/speech-to-text/realtime');
      url.searchParams.set('model_id', 'scribe_v2_realtime');
      url.searchParams.set('token', token);
      url.searchParams.set('audio_format', 'pcm_16000');
      url.searchParams.set('sample_rate', String(TARGET_RATE));
      url.searchParams.set('language_code', String(options.languageCode || 'fa'));
      url.searchParams.set('commit_strategy', 'vad');
      url.searchParams.set('vad_silence_threshold_secs', '1.1');
      socket = new global.WebSocket(url.toString());
      socket.addEventListener('close', () => {
        if (!stopped) {
          release();
          options.onError?.(new Error('اتصال تشخیص گفتار قطع شد.'));
        }
      });
      await waitForSocket(socket, 12000, 'socket');
      await waitForSession(socket, 12000, options.onSession);

      audioContext = new AudioContextCtor({ latencyHint: 'interactive' });
      if (audioContext.sampleRate < TARGET_RATE) throw new Error('نرخ نمونه‌برداری این دستگاه برای Scribe کافی نیست.');
      source = audioContext.createMediaStreamSource(stream);
      silentGain = audioContext.createGain();
      silentGain.gain.value = 0;

      const sendAudioSamples = input => {
        if (stopped || socket.readyState !== global.WebSocket.OPEN || socket.bufferedAmount > 256000) return;
        try {
          const pcm = downsampleToPcm16(input, audioContext.sampleRate, TARGET_RATE);
          if (!pcm.length) return;
          socket.send(JSON.stringify({ message_type: 'input_audio_chunk', audio_base_64: pcm16ToBase64(pcm) }));
        } catch (error) {
          options.onError?.(error);
          release();
        }
      };

      // Prefer AudioWorklet so audio capture does not run on the UI thread.
      if (audioContext.audioWorklet && typeof global.AudioWorkletNode === 'function') {
        try {
          const workletUrl = options.workletUrl || new URL('/src/core/speech-pcm-worklet.js', global.location.origin).toString();
          await audioContext.audioWorklet.addModule(workletUrl);
          processor = new global.AudioWorkletNode(audioContext, 'xynora-pcm-capture', {
            numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [1],
            channelCount: 1, channelCountMode: 'explicit', channelInterpretation: 'speakers',
            processorOptions: { chunkSize: 2048 }
          });
          processor.port.onmessage = event => {
            if (event.data instanceof ArrayBuffer) sendAudioSamples(new Float32Array(event.data));
          };
          processorMode = 'audio-worklet';
        } catch (workletError) {
          // Older browsers and restrictive CSP configurations retain a bounded legacy fallback.
          options.onFallback?.(workletError);
        }
      }

      if (!processor) {
        if (typeof audioContext.createScriptProcessor !== 'function') {
          throw new Error('پردازش صوت این مرورگر پشتیبانی نمی‌شود.');
        }
        processor = audioContext.createScriptProcessor(2048, 1, 1);
        processor.onaudioprocess = event => sendAudioSamples(event.inputBuffer.getChannelData(0));
        processorMode = 'script-processor-fallback';
      }

      source.connect(processor);
      processor.connect(silentGain);
      silentGain.connect(audioContext.destination);
      await audioContext.resume();

      socket.addEventListener('message', event => {
        if (stopped) return;
        let data;
        try { data = JSON.parse(event.data); } catch { return; }
        if (data?.message_type === 'partial_transcript') options.onPartial?.(String(data.text || ''));
        else if (data?.message_type === 'committed_transcript' || data?.message_type === 'final_transcript') options.onCommitted?.(String(data.text || ''));
        else if (data?.message_type === 'error' || data?.message_type === 'rate_limited') {
          const error = new Error(data.error || 'موتور تشخیص گفتار خطا داد.');
          release();
          options.onError?.(error);
        }
      });
      const maxDuration = Math.max(30000, Math.min(DEFAULT_MAX_DURATION, Number(options.maxDurationMs) || DEFAULT_MAX_DURATION));
      durationTimer = global.setTimeout(() => {
        release();
        options.onLimit?.();
      }, maxDuration);
      options.onState?.('listening');
      return Object.freeze({ stop: release, get active() { return !stopped; }, get processorMode() { return processorMode; } });
    } catch (error) {
      release();
      throw error;
    }
  }

  global.SayroxSpeechInput = Object.freeze({ start, downsampleToPcm16, pcm16ToBase64, TARGET_RATE, DEFAULT_MAX_DURATION });
})(window);
