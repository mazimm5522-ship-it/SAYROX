/* SAYROX PCM capture worklet.
 * Runs audio capture off the main thread and transfers 2048-sample Float32 chunks.
 */
class SayroxPcmCaptureProcessor extends AudioWorkletProcessor {
  constructor(options = {}) {
    super();
    const requested = Number(options.processorOptions?.chunkSize) || 2048;
    this.chunkSize = Math.max(512, Math.min(4096, Math.trunc(requested)));
    this.buffer = new Float32Array(this.chunkSize);
    this.offset = 0;
    this.stopped = false;
    this.port.onmessage = event => {
      if (event.data?.type === 'stop') this.stopped = true;
    };
  }

  process(inputs, outputs) {
    const output = outputs[0]?.[0];
    if (output) output.fill(0);
    if (this.stopped) return false;
    const input = inputs[0]?.[0];
    if (!input?.length) return true;

    let sourceOffset = 0;
    while (sourceOffset < input.length) {
      const count = Math.min(this.chunkSize - this.offset, input.length - sourceOffset);
      this.buffer.set(input.subarray(sourceOffset, sourceOffset + count), this.offset);
      this.offset += count;
      sourceOffset += count;
      if (this.offset === this.chunkSize) {
        const transferable = this.buffer.buffer;
        this.port.postMessage(transferable, [transferable]);
        this.buffer = new Float32Array(this.chunkSize);
        this.offset = 0;
      }
    }
    return true;
  }
}

registerProcessor('xynora-pcm-capture', SayroxPcmCaptureProcessor);
