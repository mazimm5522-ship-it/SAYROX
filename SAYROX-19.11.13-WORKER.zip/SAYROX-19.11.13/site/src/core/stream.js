(function installSayroxStream(root) {
  'use strict';

  function eventError(data, eventName) {
    let parsed;
    try { parsed = JSON.parse(data); } catch { parsed = null; }
    const message = parsed?.error?.message || parsed?.message ||
      (eventName === 'error' ? 'جریان پاسخ از سرویس هوش مصنوعی با خطا متوقف شد.' : 'پاسخ جریانی نامعتبر از سرور دریافت شد.');
    return new Error(String(message).slice(0, 500));
  }

  function textFromContent(value) {
    if (typeof value === 'string') return value;
    if (!Array.isArray(value)) return '';
    return value.map(part => typeof part === 'string' ? part : (typeof part?.text === 'string' ? part.text : '')).join('');
  }

  async function readEventStream(response, onUpdate = () => {}, onEvent = () => {}) {
    if (!response?.body?.getReader) throw new Error('جریان پاسخ در دسترس نیست.');
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let answer = '';

    async function consume(frame) {
      let eventName = 'message';
      const dataLines = [];
      for (const line of frame.split(/\r?\n/)) {
        if (!line || line.startsWith(':')) continue;
        if (line.startsWith('event:')) eventName = line.slice(6).trim();
        else if (line.startsWith('data:')) dataLines.push(line.slice(5).replace(/^ /, ''));
      }
      if (!dataLines.length) return;
      const data = dataLines.join('\n');
      if (eventName === 'error') throw eventError(data, eventName);
      if (data === '[DONE]') return;
      let payload;
      try { payload = JSON.parse(data); } catch { throw eventError(data, eventName); }
      if (payload?.error) throw eventError(data, eventName);
      if (eventName !== 'message') {
        await onEvent(eventName, payload);
        return;
      }
      const delta = textFromContent(payload?.choices?.[0]?.delta?.content ?? payload?.choices?.[0]?.message?.content);
      if (delta) {
        answer += delta;
        onUpdate(delta, answer);
      }
    }

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true }).replace(/\r\n/g, '\n').replace(/\r/g, '\n');
        let boundary;
        while ((boundary = buffer.indexOf('\n\n')) !== -1) {
          const frame = buffer.slice(0, boundary);
          buffer = buffer.slice(boundary + 2);
          await consume(frame);
        }
      }
      buffer += decoder.decode();
      if (buffer.trim()) await consume(buffer);
      return answer;
    } catch (error) {
      try { await reader.cancel(error); } catch {}
      throw error;
    } finally {
      try { reader.releaseLock(); } catch {}
    }
  }

  root.SayroxStream = Object.freeze({ readEventStream });
})(globalThis);
