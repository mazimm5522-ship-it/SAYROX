/* Small lifecycle primitive for invalidating stale asynchronous voice callbacks. */
(function (global) {
  function createAttemptGate() {
    let current = 0;
    return Object.freeze({
      begin() { current += 1; return current; },
      invalidate() { current += 1; return current; },
      isCurrent(attempt) { return Number.isSafeInteger(attempt) && attempt === current; }
    });
  }

  global.SayroxVoiceLifecycle = Object.freeze({ createAttemptGate });
})(globalThis);
