(function SayroxChatImageInput(){
'use strict';

const POLICY = Object.freeze({
  maxFiles: 4,
  maxSourceBytes: 12 * 1024 * 1024,
  maxOutputBytes: 1_250_000,
  maxTotalOutputBytes: 4_750_000,
  maxDimension: 2560,
  acceptedTypes: new Set(['image/jpeg', 'image/png', 'image/webp', 'image/gif'])
});

const formatBytes=window.SayroxFilePolicy.formatBytes;

function normalizedImageType(file){
  const supplied=String(file?.type||'').toLowerCase();
  if(supplied==='image/jpg')return 'image/jpeg';
  if(supplied)return supplied;
  const extension=String(file?.name||'').toLowerCase().split('.').pop();
  return ({jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webp:'image/webp',gif:'image/gif'})[extension]||'';
}

function validateImageFile(file){
  if(!file||typeof file!=='object'||typeof file.name!=='string')throw new TypeError('فایل تصویر معتبر نیست.');
  const type=normalizedImageType(file);
  if(!POLICY.acceptedTypes.has(type))throw new Error('فقط تصویرهای JPEG، PNG، WebP و GIF پشتیبانی می‌شوند.');
  if(!Number.isFinite(file.size)||file.size<=0)throw new Error('فایل تصویر خالی یا نامعتبر است.');
  if(file.size>POLICY.maxSourceBytes)throw new Error('حجم تصویر اولیه نباید از ۱۲ مگابایت بیشتر باشد.');
  return true;
}

async function loadBitmap(file){
  if(typeof createImageBitmap==='function'){try{return await createImageBitmap(file,{imageOrientation:'from-image'});}catch{return createImageBitmap(file)}}
  return new Promise((resolve,reject)=>{
    const url=URL.createObjectURL(file),image=new Image();
    image.onload=()=>{URL.revokeObjectURL(url);resolve({width:image.naturalWidth,height:image.naturalHeight,draw:(ctx,width,height)=>ctx.drawImage(image,0,0,width,height)});};
    image.onerror=()=>{URL.revokeObjectURL(url);reject(new Error('مرورگر نتوانست تصویر را باز کند.'));};
    image.src=url;
  });
}

function canvasBlob(canvas,quality){
  return new Promise((resolve,reject)=>canvas.toBlob(blob=>blob?resolve(blob):reject(new Error('بهینه‌سازی تصویر ناموفق بود.')),'image/jpeg',quality));
}

async function fileToDataUrl(blob){
  return new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onload=()=>typeof reader.result==='string'?resolve(reader.result):reject(new Error('خواندن تصویر ناموفق بود.'));
    reader.onerror=()=>reject(new Error('خواندن تصویر ناموفق بود.'));
    reader.readAsDataURL(blob);
  });
}

async function prepareImage(file){
  validateImageFile(file);
  const bitmap=await loadBitmap(file);
  try{
    const width=Number(bitmap.width)||0,height=Number(bitmap.height)||0;
    if(!width||!height||width*height>80_000_000)throw new Error('ابعاد تصویر معتبر یا قابل پردازش نیست.');
    const scale=Math.min(1,POLICY.maxDimension/Math.max(width,height));
    const canvas=document.createElement('canvas');
    canvas.width=Math.max(1,Math.round(width*scale));canvas.height=Math.max(1,Math.round(height*scale));
    const context=canvas.getContext('2d',{alpha:false});
    if(!context)throw new Error('مرورگر امکان آماده‌سازی تصویر را فراهم نکرد.');
    context.fillStyle='#fff';context.fillRect(0,0,canvas.width,canvas.height);
    if(bitmap.draw)bitmap.draw(context,canvas.width,canvas.height);else context.drawImage(bitmap,0,0,canvas.width,canvas.height);
    let outputCanvas=canvas;
    let blob=await canvasBlob(canvas,.91);
    for(const quality of [.86,.80,.74]){
      if(blob.size<=POLICY.maxOutputBytes)break;
      blob=await canvasBlob(canvas,quality);
    }
    if(blob.size>POLICY.maxOutputBytes){
      const smaller=document.createElement('canvas');
      const shrink=Math.sqrt(POLICY.maxOutputBytes/blob.size)*.92;
      smaller.width=Math.max(1,Math.floor(canvas.width*shrink));smaller.height=Math.max(1,Math.floor(canvas.height*shrink));
      const smallerContext=smaller.getContext('2d',{alpha:false});
      if(!smallerContext)throw new Error('بهینه‌سازی تصویر ناموفق بود.');
      smallerContext.fillStyle='#fff';smallerContext.fillRect(0,0,smaller.width,smaller.height);smallerContext.drawImage(canvas,0,0,smaller.width,smaller.height);
      blob=await canvasBlob(smaller,.78);
      outputCanvas=smaller;
    }
    if(blob.size>POLICY.maxOutputBytes)throw new Error('این تصویر پس از فشرده‌سازی هنوز بزرگ است؛ تصویر کوچک‌تری انتخاب کن.');
    return Object.freeze({
      id:globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random().toString(16).slice(2)}`,
      name:String(file.name).slice(0,180),mimeType:'image/jpeg',size:blob.size,
      width:outputCanvas.width,height:outputCanvas.height,dataUrl:await fileToDataUrl(blob)
    });
  } finally { if(typeof bitmap.close==='function')bitmap.close(); }
}

function validateBatch(images,existingCount=0,existingBytes=0){
  const incoming=Array.from(images||[]);
  if(existingCount+incoming.length>POLICY.maxFiles)throw new Error('در هر پیام حداکثر ۴ تصویر می‌توانی پیوست کنی.');
  const bytes=incoming.reduce((sum,item)=>sum+(Number(item?.size)||0),existingBytes);
  if(bytes>POLICY.maxTotalOutputBytes)throw new Error('حجم مجموع تصویرهای پیام نباید از ۴٫۷۵ مگابایت بیشتر شود.');
  return true;
}

window.SayroxChatImageInput=Object.freeze({POLICY,formatBytes,normalizedImageType,validateImageFile,prepareImage,validateBatch});
})();
