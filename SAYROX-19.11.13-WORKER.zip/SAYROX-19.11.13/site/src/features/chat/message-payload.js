(function SayroxChatPayload(){
'use strict';
const FILE_POLICY=window.SayroxFilePolicy?.FILE_POLICY||{};
const DEFAULT_DOCUMENT_COUNT=FILE_POLICY.maxChatDocuments||2;
const DEFAULT_DOCUMENT_CONTEXT_CHARS=FILE_POLICY.maxChatDocumentContextChars||100000;
const MAX_SINGLE_DOCUMENT_CHARS=FILE_POLICY.maxChatDocumentTextChars||60000;

function buildChatMessages(messages,imagePayloadsByMessage,maxImages=4){
 const history=(Array.isArray(messages)?messages:[]).filter(message=>message&&['user','assistant'].includes(message.role)).slice(-20),selected=new Map();let remaining=maxImages;
 for(let i=history.length-1;i>=0&&remaining>0;i--){
  const message=history[i];if(message.role!=='user'||!Array.isArray(message.attachments)||!message.attachments.length)continue;
  const payloads=imagePayloadsByMessage?.get(message.id)||[];if(!payloads.length)continue;
  const picked=payloads.slice(0,remaining);if(picked.length){selected.set(message.id,picked);remaining-=picked.length}
 }
 return history.map(message=>{
  if(message.role!=='user')return {role:message.role,content:message.content};
  const images=selected.get(message.id)||[];
  if(images.length)return {role:'user',content:[{type:'text',text:message.content},...images.map(image=>({type:'image_url',image_url:{url:image.dataUrl,detail:'high'}}))]};
  const missing=Array.isArray(message.attachments)&&message.attachments.length&&!images.length
    ? `\n[این پیام قبلاً ${message.attachments.length} تصویر پیوست داشته است؛ داده‌ی تصویر در این نشست مرورگر در دسترس نیست و برای تحلیل دوباره باید دوباره پیوست شود.]` : '';
  return {role:'user',content:String(message.content||'')+missing};
 });
}

function fitContextMessages(source,maxBytes=7_300_000){
 const encoder=new TextEncoder(),measure=item=>encoder.encode(JSON.stringify(item)).byteLength;
 const history=(Array.isArray(source)?source:[]).filter(message=>message&&['user','assistant'].includes(message.role));
 let budget=maxBytes;
 if(budget<0)throw new Error('حجم پیام‌های گفتگو از سقف مجاز درخواست بیشتر شده است.');
 const kept=[];
 for(let i=history.length-1;i>=0;i--){
  const item=history[i],size=measure(item);
  if(size<=budget){kept.unshift(item);budget-=size;continue}
  if(Array.isArray(item.content))throw new Error('حجم تصویرهای این گفتگو از سقف امن درخواست بیشتر است؛ تصویرهای قدیمی‌تر را از گفتگو حذف کن.');
  if(i===history.length-1&&budget>0){
   let cut=item.content;
   while(cut&&measure({...item,content:cut})>budget)cut=cut.slice(0,Math.max(1,Math.ceil(cut.length/20)));
   if(cut)kept.unshift({...item,content:cut});
  }
  break;
 }
 return kept;
}

function buildDocumentContext(messages,documentTextPayloadsByMessage,maxDocuments=DEFAULT_DOCUMENT_COUNT,maxChars=DEFAULT_DOCUMENT_CONTEXT_CHARS){
 const history=(Array.isArray(messages)?messages:[]).filter(message=>message&&message.role==='user').slice(-20);
 const selected=[],seen=new Set();let remaining=maxChars,unavailableCount=0,omittedCount=0;
 for(let i=history.length-1;i>=0;i--){
  const message=history[i],metadata=Array.isArray(message.documents)?message.documents:[];
  if(!metadata.length)continue;
  const payloads=documentTextPayloadsByMessage?.get(message.id)||[];
  if(!payloads.length){unavailableCount+=metadata.length;continue}
  if(payloads.length<metadata.length)unavailableCount+=metadata.length-payloads.length;
  for(let index=payloads.length-1;index>=0;index--){
   const payload=payloads[index];if(!payload||typeof payload.text!=='string'||!payload.text.trim())continue;
   const key=`${message.id}:${index}`;if(seen.has(key))continue;seen.add(key);
   if(selected.length>=maxDocuments||remaining<=0){omittedCount++;continue}
   const source=payload.text,content=source.slice(0,Math.min(remaining,MAX_SINGLE_DOCUMENT_CHARS));
   selected.push({kind:payload.kind||metadata[index]?.kind||'pdf',name:String(payload.name||metadata[index]?.name||'سند پیوست‌شده').slice(0,180),text:content,truncated:Boolean(payload.truncated)||content.length<source.length,extension:payload.extension||metadata[index]?.extension||''});
   remaining-=content.length;
   if(content.length<source.length)omittedCount++;
  }
 }
 selected.reverse();
 return {documents:selected,unavailableCount,omittedCount};
}

window.SayroxChatPayload=Object.freeze({buildChatMessages,buildDocumentContext,fitContextMessages});
})();
