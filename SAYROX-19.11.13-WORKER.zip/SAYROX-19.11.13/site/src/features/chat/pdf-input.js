(function SayroxChatPdfInput(){
'use strict';
const FILE_POLICY=window.SayroxFilePolicy?.FILE_POLICY||{};
const POLICY=Object.freeze({maxFileBytes:FILE_POLICY.maxFileBytes||20*1024*1024,maxTextChars:FILE_POLICY.maxChatDocumentTextChars||60000});
function validatePdfFile(file){
  if(!file||typeof file!=='object'||typeof file.name!=='string')throw new TypeError('فایل PDF معتبر نیست.');
  const policy=window.SayroxFilePolicy;
  if(!policy?.validateFile)throw new Error('سیاست امنیتی فایل‌ها بارگیری نشده است. صفحه را تازه‌سازی کن.');
  const info=policy.validateFile(file);
  if(info.extension!=='pdf')throw new Error('در گفتگو فقط فایل PDF به‌عنوان سند قابل پیوست است.');
  if(!Number.isFinite(file.size)||file.size<=0)throw new Error('فایل PDF خالی یا نامعتبر است.');
  if(file.size>POLICY.maxFileBytes)throw new Error('حجم PDF نباید از ۲۰ مگابایت بیشتر باشد.');
  return true;
}
function trimAtPageBoundary(source,limit){
  if(source.length<=limit)return source;
  const cut=source.slice(0,limit),boundary=cut.lastIndexOf('\n\n');
  return (boundary>limit*.70?cut.slice(0,boundary):cut).trimEnd();
}
async function preparePdfFile(file,{extractor}={}){
  validatePdfFile(file);
  const extract=extractor||window.SayroxPdfText?.extractPdfText;
  if(typeof extract!=='function')throw new Error('موتور استخراج متن PDF در دسترس نیست. استودیو فایل را تازه‌سازی کن.');
  let raw='';
  try{raw=String(await extract(file)||'')}
  catch(error){
    const message=String(error?.message||'');
    if(/متنی از PDF استخراج نشد|اسکن|تصویرمحور/i.test(message))throw new Error('از این PDF متن قابل استخراج پیدا نشد؛ احتمالاً اسکن‌شده است. از استودیو فایل، گزینهٔ OCR فارسی/انگلیسی را اجرا کن.');
    throw error;
  }
  raw=raw.replace(/\u0000/g,'').replace(/\r\n?/g,'\n').replace(/[\u0001-\u0008\u000B\u000C\u000E-\u001F\u007F]/g,'').trim();
  if(!raw)throw new Error('متن قابل خواندن در PDF پیدا نشد؛ برای فایل اسکن‌شده از OCR فارسی/انگلیسی استفاده کن.');
  const text=trimAtPageBoundary(raw,POLICY.maxTextChars);
  if(!text)throw new Error('متن PDF پس از پاک‌سازی خالی شد.');
  return Object.freeze({
    id:globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random().toString(16).slice(2)}`,
    name:String(file.name).slice(0,180),mimeType:'application/pdf',size:file.size,
    text,sourceChars:raw.length,includedChars:text.length,truncated:text.length<raw.length
  });
}
window.SayroxChatPdfInput=Object.freeze({POLICY,validatePdfFile,preparePdfFile,trimAtPageBoundary});
})();
