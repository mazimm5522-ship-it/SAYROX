(function SayroxChatSpreadsheetInput(){
'use strict';
const FILE_POLICY=window.SayroxFilePolicy?.FILE_POLICY||{};
const POLICY=Object.freeze({maxFileBytes:FILE_POLICY.maxFileBytes||20*1024*1024,maxTextChars:FILE_POLICY.maxChatDocumentTextChars||60000});
const SUPPORTED=new Set(['csv','xlsx','xlsm']);
const cleanCell=value=>{
  if(value&&typeof value==='object'&&typeof value.formula==='string'){
    const cached=value.value===null||value.value===undefined?'':`؛ مقدار ذخیره‌شده: ${String(value.value)}`;
    return `[فرمول محاسبه‌نشده: ${value.formula}${cached}]`;
  }
  return String(value??'');
};
function trimAtRowBoundary(source,limit,force=false){
  const marker='\n[ادامه‌ی داده‌ها به‌دلیل محدودیت حجم زمینه ارسال نشد.]';
  if(source.length<=limit&&!force)return source;
  const budget=Math.max(0,limit-marker.length),cut=source.slice(0,budget),boundary=cut.lastIndexOf('\n');
  const content=(boundary>budget*.65?cut.slice(0,boundary):cut).trimEnd();
  return (content+marker).slice(0,limit);
}
function workbookText(sheets){
  let out='',sourceChars=0,truncated=false;
  const append=line=>{sourceChars+=line.length;if(!truncated&&out.length+line.length<=POLICY.maxTextChars)out+=line;else truncated=true};
  for(const sheet of sheets){
    append(`برگه: ${String(sheet.name||'Sheet').slice(0,31)}\n`);
    for(let rowIndex=0;rowIndex<sheet.rows.length;rowIndex++){
      const row=sheet.rows[rowIndex]||[];
      if(!row.some(value=>value!==''&&value!==null&&value!==undefined))continue;
      const content=row.slice(0,200).map(value=>cleanCell(value).replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g,'').replace(/\r\n?/g,' ').replace(/\n/g,' ').replace(/\t/g,' ').slice(0,8000)).join(' | ');
      append(`ردیف ${rowIndex+1}: ${content}\n`);
    }
    append('\n');
  }
  const text=truncated?trimAtRowBoundary(out.trimEnd(),POLICY.maxTextChars,true).slice(0,POLICY.maxTextChars):out.trim();
  return {text,sourceChars,includedChars:text.length,truncated};
}
function validateSpreadsheetFile(file){
  if(!file||typeof file!=='object'||typeof file.name!=='string')throw new TypeError('فایل صفحه‌گسترده معتبر نیست.');
  const policy=window.SayroxFilePolicy;
  if(!policy?.validateFile)throw new Error('سیاست امنیتی فایل‌ها بارگیری نشده است. صفحه را تازه‌سازی کن.');
  const info=policy.validateFile(file);
  if(!SUPPORTED.has(info.extension))throw new Error('فقط فایل‌های CSV، XLSX و XLSM در گفتگوی اصلی پشتیبانی می‌شوند.');
  if(!Number.isFinite(file.size)||file.size<=0)throw new Error('فایل صفحه‌گسترده خالی یا نامعتبر است.');
  if(file.size>POLICY.maxFileBytes)throw new Error('حجم فایل صفحه‌گسترده نباید از ۲۰ مگابایت بیشتر باشد.');
  return info.extension;
}
async function prepareSpreadsheetFile(file,{csvParser,xlsxReader}={}){
  const extension=validateSpreadsheetFile(file);
  const parseCsv=csvParser||window.SayroxSpreadsheet?.parseCSV;
  const readWorkbook=xlsxReader||window.SayroxSpreadsheet?.readXlsxWorkbook;
  let sheets;
  if(extension==='csv'){
    if(typeof parseCsv!=='function')throw new Error('موتور CSV در دسترس نیست؛ صفحه را تازه‌سازی کن.');
    const text=await file.text();
    if(!text.trim())throw new Error('فایل CSV خالی است.');
    sheets=[{name:'CSV',rows:parseCsv(text)}];
  }else{
    if(typeof readWorkbook!=='function')throw new Error('موتور Excel در دسترس نیست؛ صفحه را تازه‌سازی کن.');
    sheets=await readWorkbook(file);
  }
  if(!Array.isArray(sheets)||!sheets.length)throw new Error('هیچ برگه یا داده‌ی قابل‌خواندنی در فایل پیدا نشد.');
  const converted=workbookText(sheets);
  if(!converted.text.trim())throw new Error('داده‌ی قابل تحلیل در فایل پیدا نشد.');
  return Object.freeze({
    id:globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random().toString(16).slice(2)}`,
    kind:'spreadsheet',name:String(file.name).slice(0,180),mimeType:extension==='csv'?'text/csv':extension==='xlsm'?'application/vnd.ms-excel.sheet.macroEnabled.12':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    extension,size:file.size,text:converted.text,sourceChars:converted.sourceChars,includedChars:converted.text.length,
    truncated:converted.truncated,sheetCount:sheets.length,rowCount:sheets.reduce((sum,sheet)=>sum+sheet.rows.length,0),
    macrosIgnored:extension==='xlsm'
  });
}
window.SayroxChatSpreadsheetInput=Object.freeze({POLICY,validateSpreadsheetFile,prepareSpreadsheetFile,workbookText,trimAtRowBoundary});
})();
