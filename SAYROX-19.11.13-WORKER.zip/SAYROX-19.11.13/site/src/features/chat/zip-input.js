(function SayroxChatZipInput(){
'use strict';
const FILE_POLICY=window.SayroxFilePolicy?.FILE_POLICY||{};
const POLICY=Object.freeze({
  maxFileBytes:FILE_POLICY.maxFileBytes||20*1024*1024,
  maxTextChars:FILE_POLICY.maxChatDocumentTextChars||60000,
  maxFiles:FILE_POLICY.maxChatArchiveFiles||20,
  maxSourceBytes:FILE_POLICY.maxChatArchiveSourceBytes||5*1024*1024
});
const TEXT_EXTENSIONS=new Set(['txt','md','csv','json','xml','html','htm','css','js','mjs','ts','tsx','jsx','py','java','c','cpp','h','cs','php','rb','go','rs','sql','yaml','yml']);
const cleanText=value=>String(value||'').replace(/\u0000/g,'').replace(/\r\n?/g,'\n').replace(/[\u0001-\u0008\u000B\u000C\u000E-\u001F\u007F]/g,'').trim();
function extensionOf(path){const name=String(path||'').split('/').pop()||'',dot=name.lastIndexOf('.');return dot>0?name.slice(dot+1).toLowerCase():''}
function validateZipFile(file){
  if(!file||typeof file!=='object'||typeof file.name!=='string')throw new TypeError('فایل ZIP معتبر نیست.');
  const policy=window.SayroxFilePolicy;
  if(!policy?.validateFile)throw new Error('سیاست امنیتی فایل‌ها بارگیری نشده است. صفحه را تازه‌سازی کن.');
  const info=policy.validateFile(file);
  if(info.extension!=='zip')throw new Error('در گفتگو فقط فایل ZIP به‌عنوان آرشیو قابل پیوست است.');
  if(!Number.isFinite(file.size)||file.size<=0)throw new Error('فایل ZIP خالی یا نامعتبر است.');
  if(file.size>POLICY.maxFileBytes)throw new Error('حجم ZIP نباید از ۲۰ مگابایت بیشتر باشد.');
  return true;
}
function trimArchiveText(text,limit){
  if(text.length<=limit)return{text,truncated:false};
  const marker='\n[ادامه‌ی آرشیو به‌دلیل محدودیت حجم زمینه ارسال نشد.]';
  const budget=Math.max(0,limit-marker.length),cut=text.slice(0,budget),boundary=cut.lastIndexOf('\n');
  const content=(boundary>budget*.65?cut.slice(0,boundary):cut).trimEnd();
  return{text:(content+marker).slice(0,limit),truncated:true};
}
async function prepareZipFile(file){
  validateZipFile(file);
  const zip=window.SayroxZip;
  if(typeof zip?.readZip!=='function')throw new Error('موتور ZIP در دسترس نیست؛ صفحه را تازه‌سازی کن.');
  const index=await zip.readZip(file,{extract:false});
  if(!Array.isArray(index)||!index.length)throw new Error('هیچ فایل قابل استخراجی در ZIP پیدا نشد.');
  const candidates=[];let plannedBytes=0,skipped=[];
  for(const entry of index){
    const extension=extensionOf(entry.name);
    if(!TEXT_EXTENSIONS.has(extension)){skipped.push({name:entry.name,reason:'نوع غیرمتنی یا پشتیبانی‌نشده'});continue}
    if(candidates.length>=POLICY.maxFiles){skipped.push({name:entry.name,reason:'تعداد فایل‌های قابل تحلیل به سقف مجاز رسید'});continue}
    if(plannedBytes+entry.uncompressedSize>POLICY.maxSourceBytes){skipped.push({name:entry.name,reason:'حجم متن‌های انتخاب‌شده به سقف ۵ مگابایت رسید'});continue}
    candidates.push(entry);plannedBytes+=entry.uncompressedSize;
  }
  if(!candidates.length)throw new Error('در این ZIP فایل متنی پشتیبانی‌شده پیدا نشد. فرمت‌های متنی مانند TXT، MD، CSV، JSON، XML، HTML و کد قابل تحلیل هستند.');
  const extracted=await zip.readZip(file,{selectedNames:candidates.map(entry=>entry.name)});
  const extractedByName=new Map(extracted.map(entry=>[entry.name,entry]));
  const sections=[`آرشیو ZIP: ${String(file.name).slice(0,180)}`,`تعداد فایل‌های آرشیو: ${index.length}`,`فایل‌های متنی استخراج‌شده: ${extracted.length}`];
  let sourceChars=sections.join('\n').length;
  for(const entry of candidates){
    const item=extractedByName.get(entry.name);
    if(!item)continue;
    let content;
    try{content=new TextDecoder('utf-8',{fatal:true}).decode(item.bytes)}
    catch{skipped.push({name:entry.name,reason:'کدگذاری UTF-8 قابل‌خواندن نیست'});continue}
    content=cleanText(content);
    if(!content)continue;
    sections.push(`\n--- فایل: ${entry.name} ---\n${content}`);
    sourceChars+=entry.name.length+content.length+12;
  }
  if(sections.length===3)throw new Error('فایل متنی با کدگذاری UTF-8 و محتوای قابل خواندن در ZIP پیدا نشد.');
  if(skipped.length){
    sections.push(`\n--- فایل‌های کنارگذاشته‌شده: ${skipped.length} ---`);
    for(const item of skipped.slice(0,30))sections.push(`${item.name} — ${item.reason}`);
  }
  const raw=sections.join('\n');
  const bounded=trimArchiveText(raw,POLICY.maxTextChars);
  return Object.freeze({
    id:globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random().toString(16).slice(2)}`,
    kind:'archive',name:String(file.name).slice(0,180),mimeType:'application/zip',extension:'zip',size:file.size,
    text:bounded.text,sourceChars:Math.max(sourceChars,raw.length),includedChars:bounded.text.length,
    truncated:bounded.truncated||skipped.length>0,fileCount:index.length,processedFiles:extracted.length,skippedFiles:skipped.length
  });
}
window.SayroxChatZipInput=Object.freeze({POLICY,TEXT_EXTENSIONS,validateZipFile,prepareZipFile,trimArchiveText});
})();
