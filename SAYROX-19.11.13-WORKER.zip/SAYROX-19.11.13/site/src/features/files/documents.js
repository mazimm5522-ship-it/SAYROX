(function SayroxFileModule(){
'use strict';
const {FILE_POLICY}=window.SayroxFilePolicy;
const {createZip,readZip}=window.SayroxZip;
const {parseBlocks,tableToMarkdown}=window.SayroxMarkdown;
const PPTX_MAX_SLIDES=30,PPTX_MAX_LINES_PER_SHAPE=24,PPTX_MAX_CHARS_PER_CHUNK=1200;
const xml=value=>String(value??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
function decodeXml(value){return String(value??'').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&amp;/g,'&').replace(/&#(\d+);/g,(_,n)=>String.fromCodePoint(Number(n))).replace(/&#x([\da-f]+);/gi,(_,n)=>String.fromCodePoint(parseInt(n,16)))}
function readTags(source,tag){return [...String(source).matchAll(new RegExp(`<${tag}\\b[^>]*>([\\s\\S]*?)<\\/${tag}>`,'g'))].map(match=>match[1])}
function normalizeText(source){const text=String(source??'').replace(/\r\n?/g,'\n');if(!text.trim())throw new Error('متن سند خالی است.');if(text.length>FILE_POLICY.maxTextChars)throw new Error('متن سند از سقف مجاز این نسخه بیشتر است؛ متن را کوتاه‌تر یا به چند فایل تقسیم کن.');return text}
function inlineRunXml(source){
  const pattern=/\*\*([^*]+)\*\*|(?<!\*)\*([^*]+)\*|`([^`]+)`/g;let html='',last=0,match;
  const run=(text,{bold=false,italic=false,code=false}={})=>`<w:r><w:rPr><w:rFonts w:ascii="${code?'Consolas':'Arial'}" w:hAnsi="${code?'Consolas':'Arial'}" w:cs="Arial"/><w:rtl/>${bold?'<w:b/>':''}${italic?'<w:i/>':''}${code?'<w:shd w:fill="F1F3F5"/>':''}</w:rPr><w:t xml:space="preserve">${xml(text)}</w:t></w:r>`;
  while((match=pattern.exec(source))){if(match.index>last)html+=run(source.slice(last,match.index));if(match[1]!==undefined)html+=run(match[1],{bold:true});else if(match[2]!==undefined)html+=run(match[2],{italic:true});else html+=run(match[3],{code:true});last=pattern.lastIndex}
  if(last<source.length)html+=run(source.slice(last));return html||run('');
}
function paragraphXml(text,{style='',listId=0,keepNext=false,quote=false}={}){
  const pStyle=style?`<w:pStyle w:val="${style}"/>`:'';
  const list=listId?`<w:numPr><w:ilvl w:val="0"/><w:numId w:val="${listId}"/></w:numPr>`:'';
  return `<w:p><w:pPr><w:bidi/><w:jc w:val="right"/>${pStyle}${list}${keepNext?'<w:keepNext/>':''}${quote?'<w:ind w:right="360" w:left="0"/><w:shd w:fill="F2F5F9"/>':''}<w:spacing w:after="${style.startsWith('Heading')?'180':'120'}"/></w:pPr>${inlineRunXml(text)}</w:p>`;
}
function wordTableXml(rows){
  if(!Array.isArray(rows)||!rows.length)return '';
  const columns=Math.max(1,...rows.map(row=>row.length));
  const columnWidth=Math.max(500,Math.floor(9360/columns));
  const grid=Array.from({length:columns},()=>`<w:gridCol w:w="${columnWidth}"/>`).join('');
  const borders='<w:tblBorders><w:top w:val="single" w:sz="4" w:color="D8E0E8"/><w:left w:val="single" w:sz="4" w:color="D8E0E8"/><w:bottom w:val="single" w:sz="4" w:color="D8E0E8"/><w:right w:val="single" w:sz="4" w:color="D8E0E8"/><w:insideH w:val="single" w:sz="4" w:color="D8E0E8"/><w:insideV w:val="single" w:sz="4" w:color="D8E0E8"/></w:tblBorders>';
  const body=rows.map((row,rowIndex)=>`<w:tr>${Array.from({length:columns},(_,column)=>{
    const value=String(row[column]??'');
    const shading=rowIndex===0?'<w:shd w:fill="EAF1F8"/>':'';
    const bold=rowIndex===0?'<w:b/>':'';
    return `<w:tc><w:tcPr><w:tcW w:w="${columnWidth}" w:type="dxa"/>${shading}<w:vAlign w:val="center"/></w:tcPr><w:p><w:pPr><w:bidi/><w:jc w:val="right"/></w:pPr><w:r><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:rtl/>${bold}</w:rPr><w:t xml:space="preserve">${xml(value)}</w:t></w:r></w:p></w:tc>`;
  }).join('')}</w:tr>`).join('');
  return `<w:tbl><w:tblPr><w:tblStyle w:val="TableGrid"/><w:tblW w:w="0" w:type="auto"/><w:bidiVisual/>${borders}<w:tblLayout w:type="autofit"/></w:tblPr><w:tblGrid>${grid}</w:tblGrid>${body}</w:tbl>`;
}
function markdownParagraphs(text){
  const output=[];
  for(const block of parseBlocks(text)){
    if(block.type==='heading')output.push(paragraphXml(block.text,{style:`Heading${Math.min(3,block.level)}`,keepNext:true}));
    else if(block.type==='paragraph')output.push(paragraphXml(block.text));
    else if(block.type==='list')for(const item of block.items)output.push(paragraphXml(item,{style:'ListParagraph',listId:block.ordered?2:1}));
    else if(block.type==='quote')for(const line of block.lines)output.push(paragraphXml(line,{quote:true}));
    else if(block.type==='code')for(const line of block.text.split('\n'))output.push(paragraphXml(line));
    else if(block.type==='table')output.push(wordTableXml(block.rows));
    else if(block.type==='rule')output.push(paragraphXml('────────────────────────────────'));
  }
  return output.join('');
}
async function createDocx(source,{title='سند ساخته‌شده با SAYROX',pageSize='A4',orientation='portrait'}={}){
  const text=normalizeText(source);if(text.split('\n').length>10000)throw new Error('تعداد سطرهای سند از حد مجاز بیشتر است.');
  const size=pageSize==='Letter'?{w:12240,h:15840}:{w:11906,h:16838};const landscape=orientation==='landscape';
  const document=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>${markdownParagraphs(text)}<w:sectPr><w:pgSz w:w="${landscape?size.h:size.w}" w:h="${landscape?size.w:size.h}" w:orient="${landscape?'landscape':'portrait'}"/><w:pgMar w:top="1134" w:right="1134" w:bottom="1134" w:left="1134" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>`;
  const styles='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial" w:cs="Arial"/><w:lang w:val="fa-IR" w:eastAsia="fa-IR" w:bidi="fa-IR"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:bidi/><w:jc w:val="right"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:qFormat/></w:style><w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:qFormat/><w:rPr><w:b/><w:color w:val="245B8F"/><w:sz w:val="32"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:qFormat/><w:rPr><w:b/><w:color w:val="287A78"/><w:sz w:val="26"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/><w:basedOn w:val="Normal"/><w:qFormat/><w:rPr><w:b/><w:sz w:val="22"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="ListParagraph"><w:name w:val="List Paragraph"/><w:basedOn w:val="Normal"/><w:pPr><w:ind w:right="720"/></w:pPr></w:style></w:styles>';
  const numbering='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:numbering xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:abstractNum w:abstractNumId="0"><w:multiLevelType w:val="singleLevel"/><w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="bullet"/><w:lvlText w:val="•"/><w:lvlJc w:val="right"/><w:pPr><w:ind w:right="720" w:hanging="360"/></w:pPr><w:rPr><w:rFonts w:ascii="Arial" w:hAnsi="Arial"/></w:rPr></w:lvl></w:abstractNum><w:abstractNum w:abstractNumId="1"><w:multiLevelType w:val="singleLevel"/><w:lvl w:ilvl="0"><w:start w:val="1"/><w:numFmt w:val="decimal"/><w:lvlText w:val="%1."/><w:lvlJc w:val="right"/><w:pPr><w:ind w:right="720" w:hanging="360"/></w:pPr></w:lvl></w:abstractNum><w:num w:numId="1"><w:abstractNumId w:val="0"/></w:num><w:num w:numId="2"><w:abstractNumId w:val="1"/></w:num></w:numbering>';
  const core=`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><dc:title>${xml(String(title).slice(0,200))}</dc:title><dc:creator>SAYROX</dc:creator></cp:coreProperties>`;
  return createZip([
    {name:'[Content_Types].xml',text:'<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/><Override PartName="/word/numbering.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/></Types>'},
    {name:'_rels/.rels',text:'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/></Relationships>'},
    {name:'word/document.xml',text:document},{name:'word/styles.xml',text:styles},{name:'word/numbering.xml',text:numbering},
    {name:'word/_rels/document.xml.rels',text:'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/numbering" Target="numbering.xml"/></Relationships>'},
    {name:'docProps/core.xml',text:core}
  ]);
}
function decodePackageXml(bytes,label){
  try{return new TextDecoder('utf-8',{fatal:true}).decode(bytes).replace(/^\uFEFF/,'')}
  catch{throw new Error(`ساختار متنی ${label} معتبر نیست یا با UTF-8 ذخیره نشده است.`)}
}
function extractWordParagraph(paragraph){
  let text='';
  const tokens=/<w:t(?:\s[^>]*)?>([\s\S]*?)<\/w:t>|<w:tab\b[^>]*\/>|<w:br\b[^>]*\/>|<w:cr\b[^>]*\/>/g;
  for(const token of paragraph.matchAll(tokens)){
    if(token[1]!==undefined)text+=decodeXml(token[1]);
    else if(/^<w:tab\b/.test(token[0]))text+='\t';
    else text+='\n';
  }
  return text;
}
function extractWordParagraphMarkdown(paragraph){
  const text=extractWordParagraph(paragraph);
  const style=(paragraph.match(/<w:pStyle\b[^>]*\bw:val\s*=\s*["']([^"']+)["']/)||[])[1]||'';
  const heading=style.match(/^Heading([1-3])$/i);
  if(heading)return `${'#'.repeat(Number(heading[1]))} ${text}`;
  const listId=(paragraph.match(/<w:numId\b[^>]*\bw:val\s*=\s*["'](\d+)["']/)||[])[1];
  if(listId==='2')return `1. ${text}`;
  if(listId)return `- ${text}`;
  return text;
}
async function readDocx(input){
  const files=await readZip(input),map=new Map(files.map(file=>[file.name,file]));
  const contentTypes=map.get('[Content_Types].xml'),entry=map.get('word/document.xml');
  if(!contentTypes||!entry)throw new Error('ساختار اصلی فایل Word معتبر نیست؛ بخش اصلی سند پیدا نشد.');
  const types=decodePackageXml(contentTypes.bytes,'فهرست نوع‌های Word');
  if(!types.includes('wordprocessingml.document.main+xml'))throw new Error('نوع سند Word در بسته تأیید نشد.');
  const source=decodePackageXml(entry.bytes,'متن اصلی Word');
  if(!/<w:document\b/.test(source))throw new Error('ریشهٔ XML سند Word معتبر نیست.');
  const body=(source.match(/<w:body\b[^>]*>([\s\S]*?)<\/w:body>/)||[])[1];
  if(!body)throw new Error('بدنهٔ سند Word پیدا نشد.');
  const blocks=[];
  for(const match of body.matchAll(/<w:p\b[^>]*>[\s\S]*?<\/w:p>|<w:tbl\b[^>]*>[\s\S]*?<\/w:tbl>/g)){
    const block=match[0];
    if(/^<w:tbl\b/.test(block)){
      if((block.match(/<w:tbl\b/g)||[]).length>1)throw new Error('جدول‌های تو‌در‌تو در سند Word در این نسخه پشتیبانی نمی‌شوند؛ ابتدا آن‌ها را در Word به جدول ساده تبدیل کن.');
      const rows=readTags(block,'w:tr').map(row=>readTags(row,'w:tc').map(cell=>readTags(cell,'w:p').map(extractWordParagraph).join(' ').trim()));
      if(rows.length)blocks.push(tableToMarkdown(rows));
    }else blocks.push(extractWordParagraphMarkdown(block));
  }
  const text=blocks.filter(Boolean).join('\n');
  if(text.length>FILE_POLICY.maxTextChars)throw new Error('متن استخراج‌شده از Word بیش از حد مجاز است.');
  if(!text.trim())throw new Error('در فایل Word متن قابل استخراجی پیدا نشد.');
  return text;
}
function resolvePackagePart(sourcePath,target){
  const raw=String(target||'');
  if(!raw||raw.startsWith('/')||raw.startsWith('\\')||raw.includes('\\')||/^[a-z][a-z0-9+.-]*:/i.test(raw)||/[?#\u0000-\u001f]/.test(raw))throw new Error('مسیر ارجاع‌شده در فایل PowerPoint معتبر نیست.');
  const base=sourcePath.split('/').slice(0,-1),stack=[...base];
  for(const rawSegment of raw.split('/')){
    let segment;try{segment=decodeURIComponent(rawSegment)}catch{throw new Error('کدگذاری مسیر اسلاید معتبر نیست.');}
    if(!segment||segment==='.')continue;
    if(segment==='..'){if(!stack.length)throw new Error('مسیر اسلاید از محدودهٔ بسته خارج می‌شود.');stack.pop();continue;}
    if(segment.includes('/')||segment.includes('\\')||/[\u0000-\u001f]/.test(segment))throw new Error('نام مسیر اسلاید معتبر نیست.');
    stack.push(segment);
  }
  const resolved=stack.join('/');
  if(!/^ppt\/slides\/[^/]+\.xml$/i.test(resolved))throw new Error('ارجاع اسلاید خارج از پوشهٔ مجاز PowerPoint است.');
  return resolved;
}
function relationshipAttributes(source){
  const result=new Map();
  for(const match of String(source).matchAll(/<Relationship\b([^>]*?)\/?\s*>/g)){
    const attrs=Object.fromEntries([...match[1].matchAll(/([A-Za-z_:][\w:.-]*)\s*=\s*(?:"([^"]*)"|'([^']*)')/g)].map(item=>[item[1],decodeXml(item[2]??item[3]??'')]));
    if(!attrs.Id||result.has(attrs.Id))throw new Error('شناسهٔ ارتباط‌ها در فایل PowerPoint تکراری یا نامعتبر است.');
    result.set(attrs.Id,attrs);
  }
  return result;
}
function extractSlideParagraph(paragraph){
  const runs=[...paragraph.matchAll(/<a:t(?:\s[^>]*)?>([\s\S]*?)<\/a:t>|<a:br\b[^>]*\/>/g)];
  return runs.map(run=>run[1]!==undefined?decodeXml(run[1]):'\n').join('');
}
async function readPptx(input){
  const files=await readZip(input),map=new Map(files.map(file=>[file.name,file]));
  const presentation=map.get('ppt/presentation.xml'),relationships=map.get('ppt/_rels/presentation.xml.rels');
  if(!presentation||!relationships)throw new Error('ساختار ارائهٔ PowerPoint ناقص است.');
  const presentationXml=decodePackageXml(presentation.bytes,'فهرست اسلایدهای PowerPoint');
  const relationshipXml=decodePackageXml(relationships.bytes,'ارتباط‌های PowerPoint');
  if(!/<p:presentation\b/.test(presentationXml))throw new Error('ریشهٔ XML ارائهٔ PowerPoint معتبر نیست.');
  const relMap=relationshipAttributes(relationshipXml),slidePaths=[],seen=new Set();
  for(const slide of presentationXml.matchAll(/<p:sldId\b([^>]*?)\/?\s*>/g)){
    const id=(slide[1].match(/\br:id\s*=\s*"([^"]+)"/)||[])[1];
    if(!id||!relMap.has(id))throw new Error('یکی از اسلایدهای ارائه به ارتباط معتبر متصل نیست.');
    const relation=relMap.get(id);
    if(!String(relation.Type||'').endsWith('/slide')||String(relation.TargetMode||'').toLowerCase()==='external')throw new Error('ارتباط یکی از اسلایدها در PowerPoint داخلی و معتبر نیست.');
    const path=resolvePackagePart('ppt/presentation.xml',relation.Target);
    if(seen.has(path))throw new Error('یک اسلاید در فهرست PowerPoint چند بار ارجاع شده است.');
    seen.add(path);slidePaths.push(path);
  }
  if(!slidePaths.length)throw new Error('هیچ اسلاید معتبری در فایل PowerPoint پیدا نشد.');
  if(slidePaths.length>PPTX_MAX_SLIDES)throw new Error(`تعداد اسلایدهای فایل بیشتر از سقف ${PPTX_MAX_SLIDES} مورد است.`);
  const result=[];
  for(const path of slidePaths){
    const file=map.get(path);if(!file)throw new Error(`فایل اسلاید پیدا نشد: ${path}`);
    const source=decodePackageXml(file.bytes,'محتوای اسلاید PowerPoint');
    if(!/<p:sld\b/.test(source))throw new Error(`ساختار اسلاید معتبر نیست: ${path}`);
    const paragraphs=readTags(source,'a:p').map(extractSlideParagraph).filter(value=>value.trim());
    result.push(paragraphs.join('\n'));
  }
  const text=result.join('\n\n');
  if(text.length>FILE_POLICY.maxTextChars)throw new Error('متن استخراج‌شده از PowerPoint بیش از حد مجاز است.');
  if(!text.trim())throw new Error('در فایل PowerPoint متن قابل استخراجی پیدا نشد.');
  return text;
}
function shapeXml(id,name,text,x,y,cx,cy,fontSize,color,bold=false){
  const paras=String(text).split('\n').slice(0,PPTX_MAX_LINES_PER_SHAPE).map(raw=>{const line=raw.trim(),bullet=/^[-*•+]\s+/.test(line),numbered=/^\d+[.)]\s+/.test(line),value=line.replace(/^[-*•+]\s+|^\d+[.)]\s+/,''),pPr=bullet?'<a:pPr rtl="1" algn="r" marR="360000" indent="-180000"><a:buChar char="•"/></a:pPr>':numbered?'<a:pPr rtl="1" algn="r" marR="360000" indent="-180000"><a:buAutoNum type="arabicPeriod"/></a:pPr>':'<a:pPr rtl="1" algn="r"><a:buNone/></a:pPr>';return `<a:p>${pPr}<a:r><a:rPr lang="fa-IR" sz="${fontSize}" b="${bold?'1':'0'}"><a:solidFill><a:srgbClr val="${color}"/></a:solidFill><a:latin typeface="Arial"/><a:ea typeface="Arial"/><a:cs typeface="Arial"/></a:rPr><a:t xml:space="preserve">${xml(value)}</a:t></a:r><a:endParaRPr lang="fa-IR"/></a:p>`}).join('');
  return `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="${xml(name)}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="${x}" y="${y}"/><a:ext cx="${cx}" cy="${cy}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/><a:ln><a:noFill/></a:ln></p:spPr><p:txBody><a:bodyPr wrap="square" rtlCol="1"><a:spAutoFit/></a:bodyPr><a:lstStyle/>${paras}</p:txBody></p:sp>`;
}
function splitLongSlideLine(value,maxChars=PPTX_MAX_CHARS_PER_CHUNK){
  const parts=[];let rest=String(value);
  while(rest.length>maxChars){let cut=rest.lastIndexOf(' ',maxChars);if(cut<Math.floor(maxChars*.55))cut=maxChars;else cut+=1;parts.push(rest.slice(0,cut));rest=rest.slice(cut)}
  parts.push(rest);return parts;
}
function splitSlideBody(body,{maxChars=PPTX_MAX_CHARS_PER_CHUNK,maxLines=PPTX_MAX_LINES_PER_SHAPE}={}){
  const lines=String(body).split('\n').flatMap(line=>splitLongSlideLine(line,maxChars));
  const chunks=[];let current=[],length=0;
  for(const line of lines){
    if(current.length&&(current.length>=maxLines||length+line.length+1>maxChars)){chunks.push(current.join('\n'));current=[];length=0}
    current.push(line);length+=line.length+1;
  }
  if(current.length)chunks.push(current.join('\n'));
  return chunks;
}
function splitSlides(source){
  const blocks=normalizeText(source).split(/\n\s*\n/).map(s=>s.trim()).filter(Boolean);const slides=[];
  for(let i=0;i<blocks.length;i++){
    const lines=blocks[i].split('\n');let title=`بخش ${slides.length+1}`,body=blocks[i];
    if(lines[0].startsWith('#')){title=lines.shift().replace(/^#+\s*/,'').trim().slice(0,100)||title;body=lines.join('\n')||title}
    else if(lines.length>1&&lines[0].length<=100){title=lines.shift().trim();body=lines.join('\n')}
    const chunks=splitSlideBody(body);
    for(let j=0;j<chunks.length;j++)slides.push({title:j?`${title} (${j+1})`:title,body:chunks[j]});
  }
  if(!slides.length)slides.push({title:'ارائه‌ی SAYROX',body:normalizeText(source)});
  if(slides.length>PPTX_MAX_SLIDES)throw new Error(`برای حفظ کیفیت، ساخت حداکثر ${PPTX_MAX_SLIDES} اسلاید در هر فایل مجاز است. متن را به چند ارائه تقسیم کن.`);return slides;
}
const THEME='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="SAYROX"><a:themeElements><a:clrScheme name="SAYROX"><a:dk1><a:srgbClr val="172033"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="245B8F"/></a:dk2><a:lt2><a:srgbClr val="F2F5F9"/></a:lt2><a:accent1><a:srgbClr val="245B8F"/></a:accent1><a:accent2><a:srgbClr val="36A6A0"/></a:accent2><a:accent3><a:srgbClr val="E0A84F"/></a:accent3><a:accent4><a:srgbClr val="8064A2"/></a:accent4><a:accent5><a:srgbClr val="C0504D"/></a:accent5><a:accent6><a:srgbClr val="70AD47"/></a:accent6><a:hlink><a:srgbClr val="0563C1"/></a:hlink><a:folHlink><a:srgbClr val="954F72"/></a:folHlink></a:clrScheme><a:fontScheme name="SAYROX"><a:majorFont><a:latin typeface="Arial"/><a:ea typeface="Arial"/><a:cs typeface="Arial"/></a:majorFont><a:minorFont><a:latin typeface="Arial"/><a:ea typeface="Arial"/><a:cs typeface="Arial"/></a:minorFont></a:fontScheme><a:fmtScheme name="SAYROX"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst><a:lnStyleLst><a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>';
function emptyGroupTree(){return '<p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>'}
function slideXml(slide,index){
  const title=shapeXml(2,'عنوان',slide.title,500000,300000,8140000,900000,3000,'245B8F',true);
  const body=shapeXml(3,'متن',slide.body,600000,1450000,7940000,3450000,1900,'172033');
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld name="SAYROX ${index+1}"><p:bg><p:bgPr><a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill><a:effectLst/></p:bgPr></p:bg><p:spTree>${emptyGroupTree()}${title}${body}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>`;
}
async function createPptx(source,{title='ارائه‌ی ساخته‌شده با SAYROX'}={}){
  const slides=splitSlides(source),slideOverrides=slides.map((_,i)=>`<Override PartName="/ppt/slides/slide${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/>`).join('');
  const slideIds=slides.map((_,i)=>`<p:sldId id="${256+i}" r:id="rId${i+2}"/>`).join('');
  const presRels=slides.map((_,i)=>`<Relationship Id="rId${i+2}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${i+1}.xml"/>`).join('');
  const entries=[
    {name:'[Content_Types].xml',text:`<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/ppt/presentation.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"/><Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"/><Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"/><Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>${slideOverrides}</Types>`},
    {name:'_rels/.rels',text:'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="ppt/presentation.xml"/></Relationships>'},
    {name:'ppt/presentation.xml',text:`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:presentation xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:sldIdLst>${slideIds}</p:sldIdLst><p:sldSz cx="9144000" cy="5143500" type="screen16x9"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>`},
    {name:'ppt/_rels/presentation.xml.rels',text:`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="slideMasters/slideMaster1.xml"/>${presRels}</Relationships>`},
    {name:'ppt/slideMasters/slideMaster1.xml',text:`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sldMaster xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"><p:cSld><p:spTree>${emptyGroupTree()}</p:spTree></p:cSld><p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/><p:sldLayoutIdLst><p:sldLayoutId id="1" r:id="rId1"/></p:sldLayoutIdLst><p:txStyles><p:titleStyle/><p:bodyStyle/><p:otherStyle/></p:txStyles></p:sldMaster>`},
    {name:'ppt/slideMasters/_rels/slideMaster1.xml.rels',text:'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="../theme/theme1.xml"/></Relationships>'},
    {name:'ppt/slideLayouts/slideLayout1.xml',text:`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sldLayout xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" type="blank" preserve="1"><p:cSld name="Blank"><p:spTree>${emptyGroupTree()}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>`},
    {name:'ppt/slideLayouts/_rels/slideLayout1.xml.rels',text:'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideMaster" Target="../slideMasters/slideMaster1.xml"/></Relationships>'},
    {name:'ppt/theme/theme1.xml',text:THEME},
    ...slides.flatMap((slide,i)=>[
      {name:`ppt/slides/slide${i+1}.xml`,text:slideXml(slide,i)},
      {name:`ppt/slides/_rels/slide${i+1}.xml.rels`,text:'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/></Relationships>'}
    ])
  ];
  const blob=await createZip(entries);return blob;
}
window.SayroxDocuments=Object.freeze({createDocx,readDocx,createPptx,readPptx});
})();
