(function SayroxFileLibraryStore(){
'use strict';
const DB_NAME='sayrox-file-library';
const DB_VERSION=1;
const STORE='files';
const LIMITS=Object.freeze({maxFiles:100,maxBytes:100*1024*1024,maxFileBytes:20*1024*1024,maxNameChars:120});
let databasePromise=null;
const imageTypes=Object.freeze({
  jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',webp:'image/webp',gif:'image/gif'
});
function extensionOf(name){const clean=String(name||'').split(/[\\/]/).pop()||'',dot=clean.lastIndexOf('.');return dot>0?clean.slice(dot+1).toLowerCase():''}
function categoryOf(extension){
  if(['jpg','jpeg','png','webp','gif','avif','svg'].includes(extension))return 'image';
  if(extension==='pdf')return 'pdf';
  if(['xlsx','xlsm','csv'].includes(extension))return 'spreadsheet';
  if(extension==='zip')return 'archive';
  if(['docx','pptx'].includes(extension))return 'office';
  return 'text';
}
function open(){
  if(databasePromise)return databasePromise;
  databasePromise=new Promise((resolve,reject)=>{
    if(!globalThis.indexedDB){reject(new Error('ذخیره‌سازی محلی فایل در این مرورگر پشتیبانی نمی‌شود.'));databasePromise=null;return}
    let request;
    try{request=indexedDB.open(DB_NAME,DB_VERSION)}catch(error){databasePromise=null;reject(error);return}
    request.onupgradeneeded=()=>{
      const db=request.result;
      if(!db.objectStoreNames.contains(STORE)){
        const store=db.createObjectStore(STORE,{keyPath:'id'});
        store.createIndex('addedAt','addedAt',{unique:false});
        store.createIndex('nameLower','nameLower',{unique:false});
        store.createIndex('extension','extension',{unique:false});
        store.createIndex('category','category',{unique:false});
        store.createIndex('fingerprint','fingerprint',{unique:false});
      }
    };
    request.onsuccess=()=>{const db=request.result;db.onversionchange=()=>{db.close();databasePromise=null};resolve(db)};
    request.onerror=()=>{databasePromise=null;reject(request.error||new Error('بازکردن کتابخانه فایل ناموفق بود.'))};
    request.onblocked=()=>{databasePromise=null;reject(new Error('یک برگهٔ دیگر مرورگر مانع به‌روزرسانی کتابخانه شده است؛ برگه‌های دیگر SAYROX را ببند و دوباره تلاش کن.'))};
  });
  return databasePromise;
}
function transactionDone(tx){return new Promise((resolve,reject)=>{tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error||new Error('ذخیره‌سازی فایل انجام نشد.'));tx.onabort=()=>reject(tx.error||new Error('عملیات کتابخانه لغو شد.'))})}
function requestValue(request){return new Promise((resolve,reject)=>{request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error||new Error('خواندن دادهٔ کتابخانه ناموفق بود.'))})}
function safeName(name){
  const input=String(name||'').normalize('NFKC').trim();
  if(!input)throw new Error('نام فایل نمی‌تواند خالی باشد.');
  if(/[\\/\u0000-\u001f\u007f]/.test(input))throw new Error('نام فایل معتبر نیست و نباید شامل مسیر یا نویسهٔ کنترلی باشد.');
  const raw=input;
  if(raw.length>LIMITS.maxNameChars)throw new Error('نام فایل نباید بیشتر از ۱۲۰ نویسه باشد.');
  return raw;
}
function validate(file){
  if(!file||typeof file!=='object'||typeof file.name!=='string'||typeof file.size!=='number')throw new TypeError('فایل معتبر نیست.');
  if(!Number.isFinite(file.size)||file.size<=0)throw new Error('فایل خالی یا نامعتبر است.');
  if(file.size>LIMITS.maxFileBytes)throw new Error('حجم هر فایل نباید از ۲۰ مگابایت بیشتر باشد.');
  const extension=extensionOf(file.name);
  const imageMime=imageTypes[extension];
  if(imageMime){if(file.type&&file.type!==imageMime&&!(extension==='jpg'&&file.type==='image/jpeg'))throw new Error('نوع تصویر با پسوند فایل هماهنگ نیست.');return {name:safeName(file.name),extension,mime:imageMime,category:'image'}}
  const policy=window.SayroxFilePolicy;
  if(!policy?.validateFile)throw new Error('سیاست امنیتی فایل‌ها بارگیری نشده است. صفحه را تازه‌سازی کن.');
  const info=policy.validateFile(file);
  return {name:safeName(file.name),extension:info.extension,mime:info.mime||file.type||'application/octet-stream',category:categoryOf(info.extension)};
}
async function fingerprint(file,info){
  // Do not silently collapse different files that merely share name, size and timestamp.
  // If Web Crypto is unavailable, skip deduplication rather than risk losing a file.
  if(!globalThis.crypto?.subtle?.digest)return null;
  const digest=await crypto.subtle.digest('SHA-256',await file.arrayBuffer());
  const hex=[...new Uint8Array(digest)].map(byte=>byte.toString(16).padStart(2,'0')).join('');
  return `${info.name.toLocaleLowerCase()}|${file.size}|${hex}`;
}
function metadata(record){return {id:record.id,name:record.name,extension:record.extension,mime:record.mime,size:record.size,lastModified:record.lastModified,addedAt:record.addedAt,updatedAt:record.updatedAt,source:record.source,category:record.category}}
function asFile(record){return typeof File==='function'&&(!(record.blob instanceof File)||record.blob.name!==record.name)?new File([record.blob],record.name,{type:record.mime,lastModified:record.lastModified}):record.blob}
async function list(){
  const db=await open(),tx=db.transaction(STORE,'readonly'),records=await requestValue(tx.objectStore(STORE).getAll());
  await transactionDone(tx);
  return records.map(metadata).sort((a,b)=>b.updatedAt-a.updatedAt);
}
async function get(id){
  const db=await open(),tx=db.transaction(STORE,'readonly'),record=await requestValue(tx.objectStore(STORE).get(String(id)));
  await transactionDone(tx);
  return record?{...metadata(record),file:asFile(record)}:null;
}
async function all(){
  const db=await open(),tx=db.transaction(STORE,'readonly'),records=await requestValue(tx.objectStore(STORE).getAll());
  await transactionDone(tx);
  return records.map(record=>({...metadata(record),file:asFile(record)})).sort((a,b)=>b.updatedAt-a.updatedAt);
}
async function stats(){const items=await list();return {count:items.length,bytes:items.reduce((sum,item)=>sum+item.size,0),maxFiles:LIMITS.maxFiles,maxBytes:LIMITS.maxBytes}}
async function add(file,{source='library'}={}){
  const info=validate(file),key=await fingerprint(file,info),db=await open();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(STORE,'readwrite'),store=tx.objectStore(STORE),allRequest=store.getAll();
    let result=null,failed=false;
    allRequest.onsuccess=()=>{
      const rows=allRequest.result||[];
      const existing=key?rows.find(row=>row.fingerprint===key):null;
      if(existing){result={...metadata(existing),duplicate:true};return}
      const total=rows.reduce((sum,row)=>sum+row.size,0);
      if(rows.length>=LIMITS.maxFiles){failed=true;tx.abort();reject(new Error('کتابخانه حداکثر ۱۰۰ فایل نگهداری می‌کند.'));return}
      if(total+file.size>LIMITS.maxBytes){failed=true;tx.abort();reject(new Error('حجم کل کتابخانه از سقف ۱۰۰ مگابایت عبور می‌کند؛ ابتدا فایل‌های غیرضروری را حذف کن.'));return}
      const now=Date.now(),id=globalThis.crypto?.randomUUID?.()||`file-${now}-${Math.random().toString(36).slice(2,10)}`;
      const record={id,name:info.name,nameLower:info.name.toLocaleLowerCase(),extension:info.extension,mime:info.mime,size:file.size,lastModified:Number(file.lastModified)||now,addedAt:now,updatedAt:now,source:String(source).slice(0,24),category:info.category,fingerprint:key,blob:file};
      store.add(record);result=metadata(record);
    };
    tx.oncomplete=()=>{if(!failed){notify('added',result);resolve(result)}};
    tx.onerror=()=>{if(!failed)reject(tx.error||new Error('ذخیرهٔ فایل ناموفق بود؛ ممکن است فضای دستگاه کافی نباشد.'))};
    tx.onabort=()=>{if(!failed)reject(tx.error||new Error('ذخیرهٔ فایل لغو شد.'))};
  });
}
async function addMany(files,{source='library'}={}){const results=[],errors=[];for(const file of files){try{results.push(await add(file,{source}))}catch(error){errors.push({name:file?.name||'فایل',message:error.message})}}return {results,errors}}
async function remove(ids){const values=[...new Set((Array.isArray(ids)?ids:[ids]).map(String).filter(Boolean))];if(!values.length)return 0;const db=await open(),tx=db.transaction(STORE,'readwrite'),store=tx.objectStore(STORE);for(const id of values)store.delete(id);await transactionDone(tx);notify('removed',values);return values.length}
async function rename(id,nextName){
  const name=safeName(nextName),db=await open();
  return new Promise((resolve,reject)=>{
    const tx=db.transaction(STORE,'readwrite'),store=tx.objectStore(STORE),request=store.get(String(id));let result=null,failed=false;
    request.onsuccess=()=>{
      const record=request.result;if(!record){failed=true;tx.abort();reject(new Error('فایل در کتابخانه پیدا نشد.'));return}
      if(extensionOf(name)!==record.extension){failed=true;tx.abort();reject(new Error('برای حفظ تشخیص نوع و امنیت فایل، پسوند قابل تغییر نیست.'));return}
      record.name=name;record.nameLower=name.toLocaleLowerCase();
      if(record.fingerprint){const digest=record.fingerprint.slice(record.fingerprint.lastIndexOf('|')+1);record.fingerprint=`${record.nameLower}|${record.size}|${digest}`}
      record.updatedAt=Date.now();store.put(record);result=metadata(record);
    };
    tx.oncomplete=()=>{if(!failed){notify('renamed',result);resolve(result)}};
    tx.onerror=()=>{if(!failed)reject(tx.error||new Error('تغییر نام فایل انجام نشد.'))};
    tx.onabort=()=>{if(!failed)reject(tx.error||new Error('تغییر نام لغو شد.'))};
  });
}
function notify(type,detail){try{window.dispatchEvent(new CustomEvent('sayrox:file-library-change',{detail:{type,detail}}))}catch{}}
const api=Object.freeze({open,list,get,all,stats,add,addMany,remove,rename,limits:LIMITS,categoryOf,extensionOf});
window.SayroxFileLibrary=api;
})();
