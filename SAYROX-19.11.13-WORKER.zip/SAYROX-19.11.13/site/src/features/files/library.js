(function SayroxFileLibraryUI(){
'use strict';
const $=(root,selector)=>root.querySelector(selector);
const formatBytes=value=>window.SayroxFilePolicy?.formatBytes(value)||`${value} بایت`;
const iconFor=category=>({image:'▧',pdf:'PDF',spreadsheet:'XLS',archive:'ZIP',office:'DOC',text:'TXT'}[category]||'FILE');
let activeInstance=null;
const ACCEPT='.jpg,.jpeg,.png,.webp,.gif,.pdf,.zip,.xlsx,.xlsm,.csv,.docx,.pptx,.txt,.md,.json,.xml,.html,.htm,.css,.js,.mjs,.ts,.tsx,.jsx,.py,.java,.c,.cpp,.h,.cs,.php,.rb,.go,.rs,.sql,.yaml,.yml';
function create(tag,className,text){const node=document.createElement(tag);if(className)node.className=className;if(text!==undefined)node.textContent=text;return node}
function download(blob,name){const url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=window.SayroxFilePolicy.safeOutputName(name);link.rel='noopener';document.body.appendChild(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),30000)}
function render(root,{onOpenFile,onSendToChat}={}){
  activeInstance?.destroy?.();activeInstance=null;
  const store=window.SayroxFileLibrary;
  if(!store){root.textContent='موتور کتابخانه فایل بارگیری نشده است؛ صفحه را تازه‌سازی کن.';return}
  root.innerHTML=`<section class="sayrox-library" aria-label="کتابخانه فایل SAYROX">
    <div class="sl-hero"><div class="sl-mark" aria-hidden="true">▤</div><div><h2>کتابخانه فایل SAYROX</h2><p>یک محل واحد برای فایل‌ها؛ ذخیره‌سازی فقط روی همین دستگاه و مرورگر.</p></div></div>
    <div class="sl-usage"><div><strong data-library-count>۰ فایل</strong><span data-library-size>۰ بایت از ۱۰۰ مگابایت</span></div><div class="sl-meter" role="progressbar" aria-label="فضای مصرف‌شده" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><i data-library-meter></i></div></div>
    <div class="sl-toolbar"><label class="sl-search"><span aria-hidden="true">⌕</span><input type="search" data-library-search placeholder="جستجو بر اساس نام فایل" aria-label="جستجوی فایل‌ها"></label><label class="sl-filter-label"><span class="sr-only">فیلتر نوع فایل</span><select data-library-filter aria-label="فیلتر نوع فایل"><option value="all">همهٔ فایل‌ها</option><option value="image">تصاویر</option><option value="pdf">PDF</option><option value="spreadsheet">Excel و CSV</option><option value="archive">ZIP</option><option value="office">Word و PowerPoint</option><option value="text">متن و کد</option></select></label><button type="button" class="primary-btn" data-library-add>افزودن فایل</button></div>
    <input type="file" data-library-input multiple hidden accept="${ACCEPT}">
    <div class="sl-bulk" data-library-bulk hidden><span data-library-selected>۰ انتخاب</span><button type="button" class="secondary-btn" data-library-select-all>انتخاب همه</button><button type="button" class="secondary-btn" data-library-download>دانلود انتخاب‌ها (ZIP)</button><button type="button" class="secondary-btn" data-library-delete>حذف انتخاب‌ها</button></div>
    <div class="sl-status" data-library-status role="status" aria-live="polite">در حال خواندن کتابخانه…</div>
    <div class="sl-list" data-library-list></div>
    <p class="sl-footnote">فایل‌ها با رمزگذاری یا ارسال خودکار به سرور ذخیره نمی‌شوند؛ محتوای باینری داخل IndexedDB همین مرورگر باقی می‌ماند. پاک‌کردن داده‌های سایت یا مرورگر می‌تواند فایل‌ها را حذف کند. برای استفاده از دستگاه دیگر، باید فایل را دوباره وارد کنی.</p>
  </section>`;
  const list=$ (root,'[data-library-list]'),search=$(root,'[data-library-search]'),filter=$(root,'[data-library-filter]'),status=$(root,'[data-library-status]'),bulk=$(root,'[data-library-bulk]'),input=$(root,'[data-library-input]');
  const selected=new Set();let records=[];
  const announce=(message,kind='info')=>{status.textContent=message;status.dataset.kind=kind};
  const updateUsage=async()=>{
    try{const usage=await store.stats(),percent=Math.min(100,usage.bytes/usage.maxBytes*100);$(root,'[data-library-count]').textContent=`${usage.count.toLocaleString('fa-IR')} فایل`;$(root,'[data-library-size]').textContent=`${formatBytes(usage.bytes)} از ${formatBytes(usage.maxBytes)}`;const meter=$(root,'[data-library-meter]');meter.style.width=`${percent}%`;const bar=meter.parentElement;bar.setAttribute('aria-valuenow',String(Math.round(percent)))}catch(error){announce(error.message,'error')}
  };
  const updateBulk=()=>{bulk.hidden=selected.size===0;$(root,'[data-library-selected]').textContent=`${selected.size.toLocaleString('fa-IR')} انتخاب`;};
  const refresh=async()=>{
    try{records=await store.list();for(const id of [...selected])if(!records.some(item=>item.id===id))selected.delete(id);draw();await updateUsage();announce(records.length?`${records.length.toLocaleString('fa-IR')} فایل در کتابخانه موجود است.`:'کتابخانه خالی است؛ فایل‌ها پس از افزودن در همین مرورگر باقی می‌مانند.','info')}
    catch(error){announce(error.message||'خواندن کتابخانه ناموفق بود.','error')}
  };
  const draw=()=>{
    list.replaceChildren();const query=search.value.trim().toLocaleLowerCase(),type=filter.value;
    const visible=records.filter(item=>(type==='all'||item.category===type)&&(!query||item.name.toLocaleLowerCase().includes(query)));
    if(!visible.length){const empty=create('div','sl-empty',records.length?'فایلی با این جستجو یا فیلتر پیدا نشد.':'هنوز فایلی اضافه نکرده‌ای. از دکمهٔ «افزودن فایل» شروع کن.');list.appendChild(empty);updateBulk();return}
    for(const item of visible){
      const row=create('article','sl-row');row.dataset.fileId=item.id;
      const check=create('input','sl-check');check.type='checkbox';check.checked=selected.has(item.id);check.setAttribute('aria-label',`انتخاب ${item.name}`);check.addEventListener('change',()=>{check.checked?selected.add(item.id):selected.delete(item.id);updateBulk()});
      const badge=create('span','sl-type',iconFor(item.category));badge.setAttribute('aria-hidden','true');
      const info=create('div','sl-info');const name=create('strong','sl-name',item.name);const meta=create('small','sl-meta',`${item.extension.toUpperCase()} · ${formatBytes(item.size)} · ${new Date(item.addedAt).toLocaleDateString('fa-IR')}`);info.append(name,meta);
      const actions=create('div','sl-actions');
      const action=(label,fn)=>{const button=create('button','secondary-btn',label);button.type='button';button.addEventListener('click',fn);actions.appendChild(button)};
      action('بازبینی',()=>onOpenFile?.(item.id));
      if(onSendToChat&&['image','pdf','spreadsheet','archive','text'].includes(item.category))action('ارسال به چت',()=>onSendToChat(item.id));
      action('دانلود',async()=>{try{const file=await store.get(item.id);if(!file)throw new Error('فایل پیدا نشد.');download(file.file,file.name)}catch(error){announce(error.message,'error')}});
      action('تغییر نام',async()=>{const next=window.prompt('نام جدید فایل (پسوند حفظ می‌شود):',item.name);if(next===null)return;try{const clean=String(next).trim();const dot=item.name.lastIndexOf('.'),ext=dot>0?item.name.slice(dot):'';const candidate=ext&& !clean.toLowerCase().endsWith(ext.toLowerCase())?`${clean}${ext}`:clean;await store.rename(item.id,candidate);await refresh();announce('نام فایل تغییر کرد.','success')}catch(error){announce(error.message,'error')}});
      action('حذف',async()=>{try{await store.remove(item.id);selected.delete(item.id);await refresh();announce('فایل از کتابخانهٔ همین دستگاه حذف شد.','success')}catch(error){announce(error.message,'error')}});
      row.append(check,badge,info,actions);list.appendChild(row);
    }
    updateBulk();
  };
  $(root,'[data-library-add]').addEventListener('click',()=>input.click());
  input.addEventListener('change',async()=>{
    const files=[...input.files];if(!files.length)return;announce(`در حال افزودن ${files.length.toLocaleString('fa-IR')} فایل…`);
    const result=await store.addMany(files,{source:'library'});input.value='';await refresh();
    const message=`${result.results.length} فایل ذخیره شد${result.errors.length?`؛ ${result.errors.length} فایل رد شد: ${result.errors.map(item=>`${item.name}: ${item.message}`).join(' | ')}`:''}`;
    announce(message,result.errors.length?'error':'success');
  });
  search.addEventListener('input',draw);filter.addEventListener('change',draw);
  $(root,'[data-library-select-all]').addEventListener('click',()=>{const query=search.value.trim().toLocaleLowerCase(),type=filter.value;for(const item of records)if((type==='all'||item.category===type)&&(!query||item.name.toLocaleLowerCase().includes(query)))selected.add(item.id);draw()});
  $(root,'[data-library-delete]').addEventListener('click',async()=>{if(!selected.size)return;if(!window.confirm(`آیا ${selected.size} فایل انتخاب‌شده از این مرورگر حذف شوند؟`))return;try{const count=await store.remove([...selected]);selected.clear();await refresh();announce(`${count} فایل حذف شد.`,'success')}catch(error){announce(error.message,'error')}});
  $(root,'[data-library-download]').addEventListener('click',async()=>{
    if(!selected.size)return;const button=$(root,'[data-library-download]');button.disabled=true;
    try{
      const entries=[];let total=0;for(const id of selected){const item=await store.get(id);if(!item)continue;total+=item.size;if(total>20*1024*1024)throw new Error('حجم مجموع ZIP انتخابی نباید از ۲۰ مگابایت بیشتر شود. برای دریافت فایل‌های بیشتر، آن‌ها را در چند نوبت انتخاب کن.');entries.push({name:item.name,bytes:new Uint8Array(await item.file.arrayBuffer())})}
      if(!entries.length)throw new Error('فایل معتبری برای دانلود انتخاب نشده است.');const archive=await window.SayroxZip.createZip(entries);download(archive,'sayrox-library-selection.zip');announce(`آرشیو دانلود با ${entries.length} فایل ساخته شد.`,'success');
    }catch(error){announce(error.message||'ساخت ZIP انتخابی ناموفق بود.','error')}
    finally{button.disabled=false}
  });
  const onChange=()=>refresh();window.addEventListener('sayrox:file-library-change',onChange);
  const instance={refresh,destroy(){window.removeEventListener('sayrox:file-library-change',onChange);if(activeInstance===instance)activeInstance=null}};
  activeInstance=instance;refresh();return instance;
}
window.SayroxFileLibraryUI=Object.freeze({render,destroy(){activeInstance?.destroy?.()}});
})();
