(function SayroxMarkdownModule(){
'use strict';
const escapeHtml=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
function splitTableRow(line){
  const source=String(line??'').trim();let text=source.startsWith('|')?source.slice(1):source;if(text.endsWith('|')&&!text.endsWith('\\|'))text=text.slice(0,-1);
  const cells=[];let cell='';
  for(let index=0;index<text.length;index++){
    const char=text[index];
    if(char==='\\'&&index+1<text.length&&(text[index+1]==='|'||text[index+1]==='\\')){cell+=text[++index];continue}
    if(char==='|'){cells.push(cell.trim());cell='';continue}
    cell+=char;
  }
  cells.push(cell.trim());return cells;
}
function isTableSeparator(line){
  const cells=splitTableRow(line);return cells.length>1&&cells.every(cell=>/^:?-{3,}:?$/.test(cell));
}
function parseTableAt(lines,index){
  if(index+1>=lines.length||!String(lines[index]).includes('|')||!isTableSeparator(lines[index+1]))return null;
  const header=splitTableRow(lines[index]);if(header.length<2)return null;
  const width=header.length,rows=[header];let cursor=index+2;
  while(cursor<lines.length&&String(lines[cursor]).trim()&&String(lines[cursor]).includes('|')){
    const row=splitTableRow(lines[cursor]);rows.push(Array.from({length:width},(_,column)=>row[column]??''));cursor++;
  }
  return {rows,nextIndex:cursor};
}
function parseBlocks(source){
  const lines=String(source??'').replace(/\r\n?/g,'\n').split('\n'),blocks=[];let paragraph=[],list=null,quote=[],code=[],inCode=false,codeLanguage='';
  const flushParagraph=()=>{if(paragraph.length){blocks.push({type:'paragraph',text:paragraph.join(' ')});paragraph=[]}};
  const flushList=()=>{if(list){blocks.push({type:'list',ordered:list.ordered,items:list.items});list=null}};
  const flushQuote=()=>{if(quote.length){blocks.push({type:'quote',lines:quote});quote=[]}};
  const flushCode=()=>{if(inCode){blocks.push({type:'code',language:codeLanguage,text:code.join('\n')});code=[];inCode=false;codeLanguage=''}};
  for(let index=0;index<lines.length;index++){
    const line=lines[index],fence=line.match(/^\s*```([a-z0-9_-]{0,24})\s*$/i);
    if(fence){if(inCode)flushCode();else{flushParagraph();flushList();flushQuote();inCode=true;codeLanguage=fence[1]}continue}
    if(inCode){code.push(line);continue}
    if(!line.trim()){flushParagraph();flushList();flushQuote();continue}
    const table=parseTableAt(lines,index);
    if(table){flushParagraph();flushList();flushQuote();blocks.push({type:'table',rows:table.rows});index=table.nextIndex-1;continue}
    const heading=line.match(/^\s{0,3}(#{1,6})\s+(.+?)\s*#*\s*$/);
    if(heading){flushParagraph();flushList();flushQuote();blocks.push({type:'heading',level:heading[1].length,text:heading[2]});continue}
    if(/^\s{0,3}(?:---+|\*\*\*|___)\s*$/.test(line)){flushParagraph();flushList();flushQuote();blocks.push({type:'rule'});continue}
    const quoteLine=line.match(/^\s{0,3}>\s?(.*)$/);
    if(quoteLine){flushParagraph();flushList();quote.push(quoteLine[1]);continue}else flushQuote();
    const item=line.match(/^\s*(?:([-*+])\s+|(\d+)[.)]\s+)(.*)$/);
    if(item){flushParagraph();const ordered=!!item[2];if(list&&list.ordered!==ordered)flushList();if(!list)list={ordered,items:[]};list.items.push(item[3]);continue}
    flushList();paragraph.push(line.trim());
  }
  if(inCode)flushCode();flushParagraph();flushList();flushQuote();return blocks;
}
function inlineHtml(value){
  const source=String(value??'');let output='',cursor=0;
  const pattern=/\[([^\]\n]{1,300})\]\((https?:\/\/[^\s)]+|mailto:[^\s)]+)\)|`([^`\n]+)`|\*\*([^*\n]+)\*\*|(?<!\*)\*([^*\n]+)\*(?!\*)/g;
  for(const match of source.matchAll(pattern)){
    output+=escapeHtml(source.slice(cursor,match.index));
    if(match[1]!==undefined){let safe=false;try{const url=new URL(match[2]);safe=['http:','https:','mailto:'].includes(url.protocol)&&!url.username&&!url.password}catch{}output+=safe?`<a href="${escapeHtml(match[2])}" rel="noopener noreferrer" target="_blank">${escapeHtml(match[1])}</a>`:`${escapeHtml(match[1])} (${escapeHtml(match[2])})`}
    else if(match[3]!==undefined)output+=`<code>${escapeHtml(match[3])}</code>`;
    else if(match[4]!==undefined)output+=`<strong>${escapeHtml(match[4])}</strong>`;
    else output+=`<em>${escapeHtml(match[5])}</em>`;
    cursor=match.index+match[0].length;
  }
  return output+escapeHtml(source.slice(cursor));
}
function renderTableHtml(rows){
  if(!Array.isArray(rows)||!rows.length)return '';
  const header=rows[0]||[],body=rows.slice(1);
  return `<div class="table-wrap"><table><thead><tr>${header.map(cell=>`<th>${inlineHtml(cell)}</th>`).join('')}</tr></thead><tbody>${body.map(row=>`<tr>${header.map((_,column)=>`<td>${inlineHtml(row[column]??'')}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
}
function renderHtml(source,title='SAYROX'){
  const blocks=parseBlocks(source),content=blocks.map(block=>{
    if(block.type==='heading')return `<h${block.level}>${inlineHtml(block.text)}</h${block.level}>`;
    if(block.type==='paragraph')return `<p>${inlineHtml(block.text)}</p>`;
    if(block.type==='list'){const tag=block.ordered?'ol':'ul';return `<${tag}>${block.items.map(item=>`<li>${inlineHtml(item)}</li>`).join('')}</${tag}>`}
    if(block.type==='quote')return `<blockquote>${block.lines.map(line=>`<p>${inlineHtml(line)}</p>`).join('')}</blockquote>`;
    if(block.type==='code')return `<pre><code${block.language?` class="language-${escapeHtml(block.language)}"`:''}>${escapeHtml(block.text)}</code></pre>`;
    if(block.type==='table')return renderTableHtml(block.rows);
    if(block.type==='rule')return '<hr>';
    return '';
  }).join('\n');
  const safeTitle=escapeHtml(title||'SAYROX');
  return `<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${safeTitle}</title><style>body{font-family:Arial,sans-serif;line-height:1.95;max-width:900px;margin:36px auto;padding:0 20px;color:#172033}h1,h2,h3,h4,h5,h6{line-height:1.5;color:#245b8f}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f2f5f9;padding:14px;border-radius:10px;direction:ltr;text-align:left}code{font-family:Consolas,monospace;background:#f2f5f9;padding:2px 5px;border-radius:4px}blockquote{margin:16px 0;padding:8px 16px;border-right:3px solid #36a6a0;background:#f5f8fb}.table-wrap{overflow-x:auto}table{border-collapse:collapse;width:100%;margin:18px 0}th,td{border:1px solid #d8e0e8;padding:8px 10px;text-align:right}th{background:#eef3f8}a{color:#245b8f}hr{border:0;border-top:1px solid #d8e0e8;margin:24px 0}</style></head><body><main><h1>${safeTitle}</h1>${content}</main></body></html>`;
}
function toPlainText(source){
  return parseBlocks(source).map(block=>{
    if(block.type==='heading')return block.text;
    if(block.type==='paragraph')return block.text;
    if(block.type==='list')return block.items.map((item,index)=>`${block.ordered?`${index+1}.`:'•'} ${item}`).join('\n');
    if(block.type==='quote')return block.lines.join('\n');
    if(block.type==='code')return block.text;
    if(block.type==='table')return block.rows.map(row=>row.join('\t')).join('\n');
    if(block.type==='rule')return '────────────────────────────────';
    return '';
  }).filter(Boolean).join('\n\n').replace(/\*\*([^*]+)\*\*/g,'$1').replace(/(?<!\*)\*([^*]+)\*(?!\*)/g,'$1').replace(/`([^`]+)`/g,'$1').replace(/\[([^\]]+)\]\((?:https?:\/\/|mailto:)[^\s)]+\)/g,'$1');
}
function tableToMarkdown(rows){
  if(!Array.isArray(rows)||!rows.length)return '';
  const cells=rows.map(row=>row.map(value=>String(value??'').replace(/\\/g,'\\\\').replace(/\|/g,'\\|').replace(/\r?\n/g,' ')));
  const width=Math.max(1,...cells.map(row=>row.length));const normalized=cells.map(row=>Array.from({length:width},(_,index)=>row[index]??''));
  return [normalized[0].map(value=>`| ${value} `).join('')+'|',normalized[0].map(()=> '| --- ').join('')+'|',...normalized.slice(1).map(row=>row.map(value=>`| ${value} `).join('')+'|')].join('\n');
}
window.SayroxMarkdown=Object.freeze({parseBlocks,parseTableRow:splitTableRow,tableToMarkdown,toPlainText,renderHtml,escapeHtml});
})();
