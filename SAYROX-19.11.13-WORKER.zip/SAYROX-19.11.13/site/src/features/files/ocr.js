(function SayroxFileModule(){
'use strict';
const {FILE_POLICY}=window.SayroxFilePolicy;
const DEFAULTS=Object.freeze({
  pdfJsUrl:'https://cdn.jsdelivr.net/npm/pdfjs-dist@6.5.438/build/pdf.mjs',
  pdfWorkerUrl:'https://cdn.jsdelivr.net/npm/pdfjs-dist@6.5.438/build/pdf.worker.mjs',
  tesseractScriptUrl:'https://cdn.jsdelivr.net/npm/tesseract.js@7.0.0/dist/tesseract.min.js',
  tesseractWorkerUrl:'https://cdn.jsdelivr.net/npm/tesseract.js@7.0.0/dist/worker.min.js',
  tesseractCorePath:null,
  tesseractLangPath:null
});
const config=()=>({...DEFAULTS,...(window.SayroxOcrAssets||{})});
let pdfPromise=null, tesseractPromise=null;
function loadScript(url){
  if(window.Tesseract?.createWorker)return Promise.resolve(window.Tesseract);
  if(tesseractPromise)return tesseractPromise;
  tesseractPromise=new Promise((resolve,reject)=>{
    const script=document.createElement('script');script.src=url;script.async=true;script.crossOrigin='anonymous';script.referrerPolicy='no-referrer';
    const timer=setTimeout(()=>{script.remove();reject(new Error('بارگیری موتور OCR بیش از زمان مجاز طول کشید. اتصال CDN را بررسی کن.'))},30000);
    script.onload=()=>{clearTimeout(timer);if(window.Tesseract?.createWorker)resolve(window.Tesseract);else reject(new Error('موتور OCR بارگیری شد اما API موردنیاز در دسترس نیست.'))};
    script.onerror=()=>{clearTimeout(timer);script.remove();reject(new Error('بارگیری موتور OCR ناموفق بود؛ اتصال به CDN یا مسیر محلی OCR را بررسی کن.'))};
    document.head.appendChild(script);
  }).catch(error=>{tesseractPromise=null;throw error});
  return tesseractPromise;
}
async function loadPdfJs(){
  if(pdfPromise)return pdfPromise;
  pdfPromise=import(config().pdfJsUrl).then(module=>{
    const pdfjs=module.default?.getDocument?module.default:module;
    if(!pdfjs?.getDocument)throw new Error('کتابخانه‌ی PDF.js معتبر نیست.');
    pdfjs.GlobalWorkerOptions.workerSrc=config().pdfWorkerUrl;
    return pdfjs;
  }).catch(error=>{pdfPromise=null;throw new Error(`بارگیری موتور PDF ناموفق بود: ${error.message}`)});
  return pdfPromise;
}
function assertPdfInput(input){
  if(!input||typeof input.arrayBuffer!=='function')throw new TypeError('فایل PDF معتبر نیست.');
  if(!Number.isFinite(input.size)||input.size<1||input.size>FILE_POLICY.maxFileBytes)throw new Error('حجم PDF باید بین ۱ بایت تا ۲۰ مگابایت باشد.');
}
function progress(onProgress,stage,percent,detail=''){try{onProgress?.({stage,percent:Math.max(0,Math.min(100,percent)),detail})}catch{}}
async function recognizePdf(input,options={}){
  const {pdfjs,tesseract,onProgress=()=>{},canvasFactory}=options;
  const requestedPages=Number.isInteger(options.maxPages)&&options.maxPages>0?options.maxPages:20;
  const requestedPixels=Number.isInteger(options.maxPagePixels)&&options.maxPagePixels>0?options.maxPagePixels:4000000;
  const maxPages=Math.min(20,requestedPages),maxPagePixels=Math.min(4000000,requestedPixels);
  const requestedScale=Number.isFinite(options.scale)?options.scale:1.5;
  const scale=Math.min(2,Math.max(.5,requestedScale));
  assertPdfInput(input);
  const pdfLibrary=pdfjs||await loadPdfJs();
  const ocrLibrary=tesseract||await loadScript(config().tesseractScriptUrl);
  if(typeof ocrLibrary?.createWorker!=='function')throw new Error('موتور Tesseract.js در دسترس نیست.');
  const loading=pdfLibrary.getDocument({data:new Uint8Array(await input.arrayBuffer()),isEvalSupported:false,useSystemFonts:true,disableFontFace:false});
  const pdf=await (loading.promise||loading);
  const pageCount=Number(pdf.numPages)||0;
  if(!pageCount)throw new Error('هیچ صفحه‌ای در PDF پیدا نشد.');
  if(pageCount>maxPages)throw new Error(`این PDF ${pageCount} صفحه دارد؛ OCR در هر نوبت حداکثر ${maxPages} صفحه را پردازش می‌کند. فایل را تقسیم کن.`);
  let worker=null,totalPixels=0;
  const pages=[];
  try{
    progress(onProgress,'loading',2,'آماده‌سازی موتور OCR فارسی و انگلیسی');
    const ocrConfig=config();
    const workerOptions={workerPath:ocrConfig.tesseractWorkerUrl,logger:message=>{
      if(message&&Number.isFinite(message.progress))progress(onProgress,'recognizing',Math.round(message.progress*100),message.status||'تشخیص متن');
    }};
    if(ocrConfig.tesseractCorePath)workerOptions.corePath=ocrConfig.tesseractCorePath;
    if(ocrConfig.tesseractLangPath)workerOptions.langPath=ocrConfig.tesseractLangPath;
    worker=await ocrLibrary.createWorker('fas+eng',1,workerOptions);
    for(let pageNumber=1;pageNumber<=pageCount;pageNumber++){
      progress(onProgress,'rendering',Math.round((pageNumber-1)/pageCount*90),`آماده‌سازی صفحه‌ی ${pageNumber} از ${pageCount}`);
      const page=await pdf.getPage(pageNumber),base=page.getViewport({scale:1});
      let factor=Math.min(scale,2200/Math.max(base.width,base.height));
      factor=Math.min(factor,Math.sqrt(maxPagePixels/(base.width*base.height)));
      const viewport=page.getViewport({scale:factor}),width=Math.max(1,Math.ceil(viewport.width)),height=Math.max(1,Math.ceil(viewport.height));
      const pixels=width*height;totalPixels+=pixels;
      if(pixels>maxPagePixels||totalPixels>24000000)throw new Error('حجم تصویری صفحات PDF برای OCR بیش از حد مجاز است. فایل را به بخش‌های کوچک‌تر تقسیم کن.');
      const canvas=canvasFactory?canvasFactory(width,height):document.createElement('canvas');canvas.width=width;canvas.height=height;
      const context=canvas.getContext('2d',{alpha:false,willReadFrequently:true});if(!context)throw new Error('ساخت بوم پردازش PDF در این مرورگر ممکن نیست.');
      await page.render({canvasContext:context,viewport,background:'#ffffff'}).promise;
      progress(onProgress,'recognizing',Math.round((pageNumber-1)/pageCount*90)+3,`تشخیص متن صفحه‌ی ${pageNumber} از ${pageCount}`);
      const recognized=await worker.recognize(canvas);
      const text=String(recognized?.data?.text||'').replace(/\r/g,'').trim();
      pages.push(text||`[در صفحه‌ی ${pageNumber} متنی تشخیص داده نشد]`);
      canvas.width=0;canvas.height=0;page.cleanup?.();
    }
    const result=pages.map((text,index)=>`--- صفحه ${index+1} ---\n${text}`).join('\n\n');
    if(result.length>FILE_POLICY.maxTextChars)throw new Error('متن OCR از سقف ۵۰۰٬۰۰۰ نویسه عبور کرده است.');
    if(!result.replace(/--- صفحه \d+ ---/g,'').trim())throw new Error('متنی از تصویرهای PDF تشخیص داده نشد. کیفیت یا زبان سند را بررسی کن.');
    progress(onProgress,'complete',100,`${pageCount} صفحه با موفقیت پردازش شد`);
    return result;
  }finally{
    try{await worker?.terminate()}catch{}
    try{await pdf.destroy?.()}catch{}
    try{await loading.destroy?.()}catch{}
  }
}
window.SayroxPdfOcr=Object.freeze({recognizePdf,defaults:DEFAULTS,assertPdfInput});
})();
