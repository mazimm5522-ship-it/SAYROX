(function SayroxFileModule(){
'use strict';
const {FILE_POLICY}=window.SayroxFilePolicy;
const decoder=new TextDecoder('windows-1252');
function latin1(bytes){let out='';const step=0x8000;for(let i=0;i<bytes.length;i+=step)out+=String.fromCharCode(...bytes.subarray(i,i+step));return out}
function hexBytes(value){const clean=String(value).replace(/\s/g,'');const even=clean.length%2?clean+'0':clean;const out=new Uint8Array(even.length/2);for(let i=0;i<out.length;i++)out[i]=parseInt(even.slice(i*2,i*2+2),16);return out}
function utf16Hex(hex){const bytes=hexBytes(hex);let out='';for(let i=0;i+1<bytes.length;i+=2)out+=String.fromCharCode(bytes[i]*256+bytes[i+1]);return out}
function parseCMap(source){
  const map=new Map();let match;
  const bfchar=/beginbfchar([\s\S]*?)endbfchar/g;
  while((match=bfchar.exec(source))){for(const pair of match[1].matchAll(/<([\da-f]+)>\s*<([\da-f]+)>/gi))map.set(pair[1].toUpperCase(),utf16Hex(pair[2]))}
  const bfrange=/beginbfrange([\s\S]*?)endbfrange/g;
  while((match=bfrange.exec(source))){
    const lineRegex=/<([\da-f]+)>\s*<([\da-f]+)>\s*(\[[^\]]*\]|<([\da-f]+)>)/gi;let line;
    while((line=lineRegex.exec(match[1]))){const start=parseInt(line[1],16),end=parseInt(line[2],16),width=line[1].length;
      if(line[3].startsWith('[')){const dest=[...line[3].matchAll(/<([\da-f]+)>/gi)].map(x=>utf16Hex(x[1]));for(let n=start;n<=end&&n-start<dest.length;n++)map.set(n.toString(16).toUpperCase().padStart(width,'0'),dest[n-start])}
      else{const base=parseInt(line[4],16);for(let n=start;n<=end&&n-start<4096;n++){let value=(base+n-start).toString(16);if(value.length%4)value=value.padStart(Math.ceil(value.length/4)*4,'0');map.set(n.toString(16).toUpperCase().padStart(width,'0'),utf16Hex(value))}}
    }
  }
  return map;
}
function decodeMapped(bytes,map){
  if(bytes.length>=2&&bytes[0]===0xfe&&bytes[1]===0xff)return utf16Hex([...bytes.subarray(2)].map(b=>b.toString(16).padStart(2,'0')).join(''));
  if(!map?.size)return decoder.decode(bytes);
  const lengths=[...new Set([...map.keys()].map(key=>key.length/2))].sort((a,b)=>b-a);let out='',i=0;
  while(i<bytes.length){let found=false;for(const len of lengths){if(i+len>bytes.length)continue;let key='';for(let j=0;j<len;j++)key+=bytes[i+j].toString(16).padStart(2,'0');const value=map.get(key.toUpperCase());if(value!==undefined){out+=value;i+=len;found=true;break}}
    if(!found){out+=decoder.decode(bytes.subarray(i,i+1));i++}}
  return out;
}
function decodeAscii85(bytes){
  let source=latin1(bytes).replace(/\s/g,'');if(source.startsWith('<~'))source=source.slice(2);source=source.replace(/~>$/,'');
  const out=[];let group=[];
  const emit=values=>{const number=values.reduce((n,v)=>n*85+v,0)>>>0;out.push((number>>>24)&255,(number>>>16)&255,(number>>>8)&255,number&255)};
  for(const char of source){if(char==='z'){if(group.length)throw new Error('جریان ASCII85 در PDF معتبر نیست.');out.push(0,0,0,0);continue}const code=char.charCodeAt(0);if(code<33||code>117)throw new Error('کاراکتر نامعتبر در جریان ASCII85 PDF.');group.push(code-33);if(group.length===5){emit(group);group=[]}}
  if(group.length===1)throw new Error('طول پایانی جریان ASCII85 PDF معتبر نیست.');if(group.length>1){const count=group.length;while(group.length<5)group.push(84);emit(group);out.length-=5-count}
  return new Uint8Array(out);
}
function decodeLiteral(content){
  const out=[];for(let i=1;i<content.length-1;i++){let c=content.charCodeAt(i)&255;if(c===92){const next=content[++i];if(next===undefined)break;const map={n:10,r:13,t:9,b:8,f:12,'(':40,')':41,'\\':92};if(next in map)out.push(map[next]);else if(next==='\r'||next==='\n'){if(next==='\r'&&content[i+1]==='\n')i++}else if(/[0-7]/.test(next)){let oct=next;for(let n=0;n<2&&/[0-7]/.test(content[i+1]||'');n++)oct+=content[++i];out.push(parseInt(oct,8)&255)}else out.push(next.charCodeAt(0)&255)}else out.push(c)}return new Uint8Array(out);
}
function decodeStringToken(token,map){return token[0]==='('?decodeMapped(decodeLiteral(token),map):decodeMapped(hexBytes(token.slice(1,-1)),map)}
function tokenizeContent(source){
  const tokens=[];let i=0;
  const isSpace=char=>char!==undefined&&/[\x00\x09\x0a\x0c\x0d\x20]/.test(char);
  const isDelimiter=char=>char!==undefined&&/[()<>\[\]{}\/%]/.test(char);
  const read=()=>{
    while(i<source.length){if(isSpace(source[i])){i++;continue}if(source[i]==='%'){while(i<source.length&&source[i]!=='\n'&&source[i]!=='\r')i++;continue}break}
    if(i>=source.length)return null;
    const start=i,char=source[i++];
    if(char==='('){let depth=1;while(i<source.length&&depth){const current=source[i++];if(current==='\\'){if(i<source.length){if(source[i]==='\r'&&source[i+1]==='\n')i+=2;else i++}continue}if(current==='(')depth++;else if(current===')')depth--}return {type:'string',raw:source.slice(start,i)}}
    if(char==='<'){
      if(source[i]==='<'){i++;return {type:'word',raw:'<<'}}
      while(i<source.length&&source[i]!=='>')i++;if(i<source.length)i++;return {type:'hex',raw:source.slice(start,i)}
    }
    if(char==='['){const items=[];while(i<source.length){while(isSpace(source[i]))i++;if(source[i]===']'){i++;break}const item=read();if(!item)break;items.push(item)}return {type:'array',items,raw:source.slice(start,i)}}
    if(char==='/'){while(i<source.length&&!isSpace(source[i])&&!isDelimiter(source[i]))i++;return {type:'name',raw:source.slice(start,i)}}
    if(char===']'||char==='>'||char==='}'||char==='{')return {type:'delimiter',raw:char};
    while(i<source.length&&!isSpace(source[i])&&!isDelimiter(source[i]))i++;
    return {type:/^[+-]?(?:\d+\.?\d*|\.\d+)$/.test(source.slice(start,i))?'number':'word',raw:source.slice(start,i)};
  };
  while(i<source.length){const token=read();if(!token)break;tokens.push(token)}return tokens;
}
function extractContentText(source,fontMaps){
  const tokens=tokenizeContent(source);let font='',out='';
  for(let index=0;index<tokens.length;index++){
    const token=tokens[index],next=tokens[index+1];
    if(token.type==='word'&&token.raw==='Tf'&&index>=2&&tokens[index-1].type==='number'&&tokens[index-2].type==='name'){font=tokens[index-2].raw.slice(1);continue}
    const map=fontMaps[font];
    if((token.type==='string'||token.type==='hex')&&next?.type==='word'&&['Tj',"'",'"'].includes(next.raw)){out+=decodeStringToken(token.raw,map)+' ';index++;continue}
    if(token.type==='array'&&next?.type==='word'&&next.raw==='TJ'){for(const part of token.items)if(part.type==='string'||part.type==='hex')out+=decodeStringToken(part.raw,map);out+=' ';index++}
  }
  return out;
}
async function inflatePdfStream(bytes){
  if(typeof DecompressionStream==='undefined')throw new Error('این مرورگر امکان بازکردن محتوای فشرده‌ی PDF را ندارد.');
  const stream=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('deflate'));const reader=stream.getReader(),chunks=[];let total=0;
  try{while(true){const {done,value}=await reader.read();if(done)break;total+=value.byteLength;if(total>FILE_POLICY.maxExpandedBytes){await reader.cancel();throw new Error('حجم بازشده‌ی PDF از سقف ۵۰ مگابایت عبور می‌کند.')}chunks.push(value)}}finally{reader.releaseLock?.()}
  const out=new Uint8Array(total);let offset=0;for(const chunk of chunks){out.set(chunk,offset);offset+=chunk.length}return out;
}
async function extractPdfText(input){
  if(!input||typeof input.arrayBuffer!=='function')throw new TypeError('فایل PDF معتبر نیست.');
  if(input.size>FILE_POLICY.maxFileBytes)throw new Error('حجم PDF از ۲۰ مگابایت بیشتر است.');
  const bytes=new Uint8Array(await input.arrayBuffer());if(bytes.length<8||latin1(bytes.subarray(0,8)).indexOf('%PDF-')<0)throw new Error('ساختار PDF معتبر نیست.');
  const raw=latin1(bytes),objects=new Map();if(/\/Encrypt\b/.test(raw))throw new Error('PDF رمزگذاری‌شده پشتیبانی نمی‌شود.');let match;const objectPattern=/(\d+)\s+(\d+)\s+obj\b/g;
  while((match=objectPattern.exec(raw))){const id=Number(match[1]),start=objectPattern.lastIndex,end=raw.indexOf('endobj',start);if(end<0)break;objects.set(id,{body:raw.slice(start,end),start,bytes});if(objects.size>10000)throw new Error('تعداد ساختارهای PDF از سقف ۱۰٬۰۰۰ شیء بیشتر است.');objectPattern.lastIndex=end+6}
  if(!objects.size)throw new Error('ساختار شیءهای PDF قابل خواندن نیست.');
  const streams=new Map();let totalDecodedStreams=0;
  for(const [id,obj] of objects){const marker=obj.body.search(/\bstream\r?\n/);if(marker<0)continue;const markerMatch=/\bstream\r?\n/.exec(obj.body.slice(marker));const dataStart=obj.start+marker+markerMatch[0].length;let dataEnd=raw.indexOf('endstream',dataStart);const declaredLength=Number((obj.body.slice(0,marker).match(/\/Length\s+(\d+)(?!\s+\d+\s+R)/)||[])[1]);if(Number.isFinite(declaredLength)&&declaredLength>=0&&dataStart+declaredLength<=bytes.length)dataEnd=dataStart+declaredLength;if(dataEnd<0||dataEnd>bytes.length)continue;while(dataEnd>dataStart&&(bytes[dataEnd-1]===10||bytes[dataEnd-1]===13))dataEnd--;let data=bytes.subarray(dataStart,dataEnd);const dict=obj.body.slice(0,marker);
    const filters=(dict.match(/\/Filter\s*\[([^\]]+)\]/s)||[])[1];const filterNames=filters?[...filters.matchAll(/\/([A-Za-z0-9]+)/g)].map(item=>item[1]):((dict.match(/\/Filter\s*\/([A-Za-z0-9]+)/)||[])[1]?[dict.match(/\/Filter\s*\/([A-Za-z0-9]+)/)[1]]:[]);
    let supported=true;for(const filter of filterNames){if(filter==='ASCII85Decode'||filter==='A85')data=decodeAscii85(data);else if(filter==='ASCIIHexDecode'||filter==='AHx'){const hex=latin1(data).replace(/\s|>.*$/gs,'');data=hexBytes(hex)}else if(filter==='FlateDecode'||filter==='Fl'){data=await inflatePdfStream(data)}else{supported=false;break}}
    if(!supported||/\/DCTDecode|\/JPXDecode|\/CCITTFaxDecode/.test(dict))continue;
    totalDecodedStreams+=data.byteLength;if(totalDecodedStreams>FILE_POLICY.maxExpandedBytes)throw new Error('حجم مجموع جریان‌های بازشده‌ی PDF از سقف ۵۰ مگابایت بیشتر است.');
    streams.set(id,{dict,data,text:latin1(data)});
  }
  const cmapByFont=new Map();
  for(const [id,obj] of objects){if(!/\/Type\s*\/Font\b/.test(obj.body))continue;const toUnicode=(obj.body.match(/\/ToUnicode\s+(\d+)\s+\d+\s+R/)||[])[1];if(toUnicode&&streams.has(Number(toUnicode)))cmapByFont.set(id,parseCMap(streams.get(Number(toUnicode)).text))}
  const getResourceFontMap=resourceId=>{
    const body=resourceId?objects.get(Number(resourceId))?.body||'':'';const map={};const fontBlock=(body.match(/\/Font\s*<<(.*?)>>/s)||[])[1]||'';
    for(const item of fontBlock.matchAll(/\/(\S+)\s+(\d+)\s+\d+\s+R/g))map[item[1]]=cmapByFont.get(Number(item[2]))||null;return map;
  };
  const pageObjects=[...objects.entries()].filter(([,obj])=>/\/Type\s*\/Page\b/.test(obj.body));if(!pageObjects.length)throw new Error('صفحه‌ای در این PDF پیدا نشد.');
  const orderedPages=[],visited=new Set();const catalog=[...objects.values()].find(obj=>/\/Type\s*\/Catalog\b/.test(obj.body));const rootPages=(catalog?.body.match(/\/Pages\s+(\d+)\s+\d+\s+R/)||[])[1];
  const visitPageTree=(id,depth=0)=>{if(depth>32||visited.has(id))return;visited.add(id);const obj=objects.get(id);if(!obj)return;if(/\/Type\s*\/Page\b/.test(obj.body)){orderedPages.push([id,obj]);return}const kids=(obj.body.match(/\/Kids\s*\[([\s\S]*?)\]/)||[])[1]||'';for(const ref of kids.matchAll(/(\d+)\s+\d+\s+R/g))visitPageTree(Number(ref[1]),depth+1)};
  if(rootPages)visitPageTree(Number(rootPages));const pageList=orderedPages.length?orderedPages:pageObjects;
  if(pageList.length>500)throw new Error('PDF بیش از ۵۰۰ صفحه دارد؛ برای پردازش باید فایل را تقسیم کنی.');
  const pages=[];
  for(const [pageId,obj] of pageList){let body=obj.body,resourceMatch=body.match(/\/Resources\s+(\d+)\s+\d+\s+R/);if(!resourceMatch){let parent=body.match(/\/Parent\s+(\d+)\s+\d+\s+R/);for(let depth=0;parent&&depth<8;depth++){const parentBody=objects.get(Number(parent[1]))?.body||'';resourceMatch=parentBody.match(/\/Resources\s+(\d+)\s+\d+\s+R/);if(resourceMatch)break;parent=parentBody.match(/\/Parent\s+(\d+)\s+\d+\s+R/)}}
    let resources=resourceMatch?objects.get(Number(resourceMatch[1]))?.body||'':(body.match(/\/Resources\s*<<(.*?)>>/s)||[])[1]||'';const fonts={};let fontBlock=(resources.match(/\/Font\s*<<(.*?)>>/s)||[])[1]||'';
    if(!fontBlock){const fontResource=(resources.match(/\/Font\s+(\d+)\s+\d+\s+R/)||[])[1];if(fontResource)fontBlock=(objects.get(Number(fontResource))?.body||'').replace(/^\s*<<|>>\s*$/g,'')}
    for(const item of fontBlock.matchAll(/\/(\S+)\s+(\d+)\s+\d+\s+R/g))fonts[item[1]]=cmapByFont.get(Number(item[2]))||null;
    let refs=[];const contentsMatch=body.match(/\/Contents\s+(\d+)\s+\d+\s+R/);if(contentsMatch)refs=[Number(contentsMatch[1])];else{const arrayMatch=body.match(/\/Contents\s*\[([^\]]+)\]/);if(arrayMatch)refs=[...arrayMatch[1].matchAll(/(\d+)\s+\d+\s+R/g)].map(m=>Number(m[1]))}
    let pageText='';for(const ref of refs){const stream=streams.get(ref);if(!stream)continue;pageText+=extractContentText(stream.text,fonts)}
    if(pageText.trim())pages.push(pageText.replace(/[\t ]+/g,' ').trim());
  }
  const result=pages.join('\n\n');if(!result.trim())throw new Error('متنی از PDF استخراج نشد. احتمالاً فایل اسکن‌شده یا تصویرمحور است؛ برای استخراج متن، گزینه‌ی OCR فارسی/انگلیسی را اجرا کن.');
  if(result.length>FILE_POLICY.maxTextChars)throw new Error('متن استخراج‌شده از PDF از سقف ۵۰۰٬۰۰۰ نویسه عبور کرده است.');return result;
}
window.SayroxPdfText=Object.freeze({extractPdfText,parseCMap,decodeMapped,decodeAscii85});
})();
