(function SayroxFileModule(){
'use strict';
const {FILE_POLICY}=window.SayroxFilePolicy;
const encoder=new TextEncoder();
const concat=parts=>{const size=parts.reduce((sum,part)=>sum+part.length,0);const out=new Uint8Array(size);let offset=0;for(const part of parts){out.set(part,offset);offset+=part.length}return out};
const ascii=value=>encoder.encode(value);

/** Assemble image-backed PDF pages. Raster pages preserve browser shaping for Persian/Arabic text. */
function assembleImagePdf(pages,{pageWidth=595,pageHeight=842}={}){
  if(!Array.isArray(pages)||!pages.length)throw new Error('PDF باید دست‌کم یک صفحه داشته باشد.');
  const objects=[];
  objects[1]=ascii('<< /Type /Catalog /Pages 2 0 R >>');
  const kids=[];
  pages.forEach((page,index)=>{
    const pageId=3+index*3,imageId=pageId+1,contentId=pageId+2;kids.push(`${pageId} 0 R`);
    const jpeg=page.jpeg instanceof Uint8Array?page.jpeg:new Uint8Array(page.jpeg);
    objects[pageId]=ascii(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageWidth} ${pageHeight}] /Resources << /XObject << /Im0 ${imageId} 0 R >> >> /Contents ${contentId} 0 R >>`);
    objects[imageId]=concat([ascii(`<< /Type /XObject /Subtype /Image /Width ${page.width} /Height ${page.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpeg.length} >>\nstream\n`),jpeg,ascii('\nendstream')]);
    const stream=ascii(`q\n${pageWidth} 0 0 ${pageHeight} 0 0 cm\n/Im0 Do\nQ`);
    objects[contentId]=concat([ascii(`<< /Length ${stream.length} >>\nstream\n`),stream,ascii('\nendstream')]);
  });
  objects[2]=ascii(`<< /Type /Pages /Kids [${kids.join(' ')}] /Count ${kids.length} >>`);
  const chunks=[ascii('%PDF-1.4\n%SAYROX\n')],offsets=[0];let offset=chunks[0].length;
  for(let id=1;id<objects.length;id++){
    offsets[id]=offset;const part=concat([ascii(`${id} 0 obj\n`),objects[id],ascii('\nendobj\n')]);chunks.push(part);offset+=part.length;
  }
  const xrefOffset=offset;let xref=`xref\n0 ${objects.length}\n0000000000 65535 f \n`;
  for(let id=1;id<objects.length;id++)xref+=`${String(offsets[id]).padStart(10,'0')} 00000 n \n`;
  xref+=`trailer\n<< /Size ${objects.length} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`;
  chunks.push(ascii(xref));return new Blob([concat(chunks)],{type:'application/pdf'});
}

function wrapLines(ctx,text,maxWidth){
  const lines=[];
  for(const paragraph of String(text).replace(/\r/g,'').split('\n')){
    if(!paragraph){lines.push('');continue}
    const words=paragraph.split(/\s+/);let line='';
    for(const word of words){
      const candidate=line?`${line} ${word}`:word;
      if(line&&ctx.measureText(candidate).width>maxWidth){lines.push(line);line=word}else line=candidate;
      if(ctx.measureText(line).width>maxWidth){let fragment='';for(const char of line){if(fragment&&ctx.measureText(fragment+char).width>maxWidth){lines.push(fragment);fragment=char}else fragment+=char}line=fragment}
    }
    lines.push(line);
  }
  return lines;
}

/** Create a Persian-capable PDF locally through canvas rasterization; the source text stays on-device. */
async function createTextPdf(text,{title='سند ساخته‌شده با SAYROX',fontSize=18}={}){
  if(typeof document==='undefined')throw new Error('ساخت PDF به محیط مرورگر نیاز دارد.');
  const content=String(text??'');if(!content.trim())throw new Error('متن PDF خالی است.');if(content.length>FILE_POLICY.maxTextChars)throw new Error('متن PDF از سقف مجاز بیشتر است؛ متن را به چند فایل تقسیم کن.');
  const scale=2,width=595,height=842,pixelWidth=width*scale,pixelHeight=height*scale;
  const canvas=document.createElement('canvas');canvas.width=pixelWidth;canvas.height=pixelHeight;const ctx=canvas.getContext('2d');
  if(!ctx)throw new Error('Canvas در این مرورگر در دسترس نیست.');
  ctx.scale(scale,scale);
  const margin=44,lineHeight=Math.max(20,Math.min(32,fontSize*1.55));
  ctx.font=`700 23px system-ui, "Noto Naskh Arabic", sans-serif`;const titleLines=wrapLines(ctx,title,width-margin*2);
  ctx.font=`${Math.max(12,Math.min(26,fontSize))}px system-ui, "Noto Naskh Arabic", sans-serif`;const lines=wrapLines(ctx,content,width-margin*2);
  const all=[...titleLines,'',...lines],usable=height-margin*2,perPage=Math.max(1,Math.floor((usable-56)/lineHeight));
  if(Math.ceil(all.length/perPage)>50)throw new Error('این متن برای ساخت یک PDF بیش از ۵۰ صفحه می‌شود؛ متن را کوتاه‌تر کن.');
  const pages=[];
  for(let start=0;start<all.length;start+=perPage){
    ctx.setTransform(1,0,0,1,0,0);ctx.fillStyle='#ffffff';ctx.fillRect(0,0,pixelWidth,pixelHeight);ctx.setTransform(scale,0,0,scale,0,0);
    ctx.direction='rtl';ctx.textAlign='right';ctx.textBaseline='top';let y=margin;
    ctx.font='700 23px system-ui, "Noto Naskh Arabic", sans-serif';ctx.fillStyle='#171717';
    for(const line of all.slice(start,start+perPage)){
      if(y===margin&&line&&start===0){ctx.fillText(line,width-margin,y);y+=lineHeight*1.45;continue}
      if(y>margin+lineHeight*1.3&&start===0&&line==='') {y+=lineHeight*.45;continue}
      ctx.font=`${Math.max(12,Math.min(26,fontSize))}px system-ui, "Noto Naskh Arabic", sans-serif`;ctx.fillStyle='#242424';ctx.fillText(line,width-margin,y);y+=lineHeight;
    }
    ctx.direction='ltr';ctx.textAlign='left';ctx.font='10px system-ui';ctx.fillStyle='#777';ctx.fillText(`SAYROX · ${pages.length+1}`,margin,height-26);
    const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',.88));if(!blob)throw new Error('تبدیل صفحه‌ی PDF به تصویر ناموفق بود.');
    pages.push({jpeg:new Uint8Array(await blob.arrayBuffer()),width:pixelWidth,height:pixelHeight});
  }
  return assembleImagePdf(pages,{pageWidth:width,pageHeight:height});
}

window.SayroxPdf=Object.freeze({assembleImagePdf,createTextPdf});

})();
