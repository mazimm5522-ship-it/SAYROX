(function SayroxFileModule(){
'use strict';
/** Shared browser-side file safety policy. No file is uploaded or persisted by this module. */
const FILE_POLICY = Object.freeze({
  maxFileBytes: 20 * 1024 * 1024,
  maxZipArchiveBytes: 20 * 1024 * 1024,
  maxBatchBytes: 40 * 1024 * 1024,
  maxZipEntries: 100,
  maxSessionFiles: 100,
  maxBatchConvertFiles: 10,
  maxExpandedBytes: 50 * 1024 * 1024,
  maxCompressionRatio: 100,
  maxSheetRows: 20000,
  maxSheetColumns: 200,
  maxWorkbookRows: 40000,
  maxWorkbookCells: 200000,
  maxChatDocumentTextChars: 60000,
  maxChatArchiveFiles: 20,
  maxChatArchiveSourceBytes: 5 * 1024 * 1024,
  maxChatDocuments: 2,
  maxChatDocumentContextChars: 100000,
  maxCellChars: 32000,
  maxTextChars: 500000
});

const ALLOWED_EXTENSIONS = Object.freeze(new Set([
  'txt','md','csv','json','xml','html','htm','css','js','mjs','ts','tsx','jsx','py','java','c','cpp','h','cs','php','rb','go','rs','sql','yaml','yml',
  'pdf','zip','xlsx','xlsm','docx','pptx'
]));

const MIME_BY_EXTENSION = Object.freeze({
  txt:'text/plain', md:'text/markdown', csv:'text/csv', json:'application/json', xml:'application/xml',
  html:'text/html', htm:'text/html', css:'text/css', js:'text/javascript', mjs:'text/javascript',
  pdf:'application/pdf', zip:'application/zip', xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  xlsm:'application/vnd.ms-excel.sheet.macroEnabled.12',
  docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation'
});

function formatBytes(value) {
  const bytes=Math.max(0,Number(value)||0);
  if(bytes<1024)return `${bytes} بایت`;
  if(bytes<1024*1024)return `${(bytes/1024).toFixed(0)} کیلوبایت`;
  return `${(bytes/1024/1024).toFixed(1)} مگابایت`;
}

function extensionOf(name='') {
  const clean = String(name).split(/[\\/]/).pop() || '';
  const index = clean.lastIndexOf('.');
  return index > 0 ? clean.slice(index + 1).toLowerCase() : '';
}

function validateFile(file, { batchBytes=0 } = {}) {
  if (!file || typeof file !== 'object' || typeof file.name !== 'string') throw new TypeError('فایل معتبر نیست.');
  const ext = extensionOf(file.name);
  if (!ALLOWED_EXTENSIONS.has(ext)) throw new Error(`پسوند .${ext || '?'} پشتیبانی نمی‌شود.`);
  if (!Number.isFinite(file.size) || file.size < 0) throw new Error('اندازه‌ی فایل معتبر نیست.');
  if (file.size > FILE_POLICY.maxFileBytes) throw new Error('حجم هر فایل نباید از ۲۰ مگابایت بیشتر باشد.');
  if (batchBytes + file.size > FILE_POLICY.maxBatchBytes) throw new Error('حجم مجموع فایل‌های انتخاب‌شده نباید از ۴۰ مگابایت بیشتر باشد.');
  return { extension: ext, mime: MIME_BY_EXTENSION[ext] || 'application/octet-stream' };
}

function assertSafeArchivePath(path) {
  const value = String(path || '').replace(/\\/g, '/');
  if (!value || value.startsWith('/') || /^[a-z]:/i.test(value) || value.includes('\0')) throw new Error('مسیر فایل داخل ZIP معتبر نیست.');
  const parts = value.split('/');
  if (parts.some(part => part === '..' || part === '.')) throw new Error('مسیر ZIP شامل پیمایش پوشه‌ی غیرمجاز است.');
  if (parts.some(part => part.length > 180)) throw new Error('نام یکی از فایل‌های ZIP بیش از حد طولانی است.');
  return value;
}

function safeOutputName(name, fallback='sayrox-file') {
  const clean = String(name || '').normalize('NFKC').replace(/[\\/:*?"<>|\u0000-\u001f]/g, '-').replace(/\s+/g, '-').replace(/\.\.+/g, '.').slice(0, 100);
  return clean || fallback;
}

window.SayroxFilePolicy=Object.freeze({FILE_POLICY,ALLOWED_EXTENSIONS,extensionOf,validateFile,assertSafeArchivePath,safeOutputName,formatBytes});

})();
