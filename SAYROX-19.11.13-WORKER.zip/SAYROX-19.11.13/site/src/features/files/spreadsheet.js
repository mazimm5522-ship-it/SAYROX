(function SayroxFileModule(){
'use strict';
const {FILE_POLICY}=window.SayroxFilePolicy;
const {createZip,readZip}=window.SayroxZip;

function parseCSV(input, delimiter) {
  const source=String(input??'').replace(/^\uFEFF/,'');
  if(source.length>FILE_POLICY.maxTextChars) throw new Error('متن CSV از سقف مجاز بزرگ‌تر است.');
  const firstLine=source.split(/\r?\n/,1)[0]||'';
  const sep=delimiter||([',',';','\t'].sort((a,b)=>firstLine.split(b).length-firstLine.split(a).length)[0]);
  const rows=[];let row=[],cell='',quoted=false,totalCells=0;
  for(let i=0;i<source.length;i++){
    const ch=source[i];
    if(quoted){if(ch==='"'&&source[i+1]==='"'){cell+='"';i++}else if(ch==='"')quoted=false;else cell+=ch;continue}
    if(ch==='"'&&cell===''){quoted=true;continue}
    if(ch===sep){row.push(cell);cell='';totalCells++;if(totalCells>FILE_POLICY.maxWorkbookCells)throw new Error('تعداد سلول‌های CSV از ۲۰۰٬۰۰۰ بیشتر است.');continue}
    if(ch==='\n'||ch==='\r'){
      if(ch==='\r'&&source[i+1]==='\n')i++;
      row.push(cell);cell='';totalCells++;if(totalCells>FILE_POLICY.maxWorkbookCells)throw new Error('تعداد سلول‌های CSV از ۲۰۰٬۰۰۰ بیشتر است.');if(row.some(value=>value!==''))rows.push(row);row=[];continue;
    }
    cell+=ch;
  }
  if(quoted) throw new Error('یکی از فیلدهای CSV بسته نشده است.');
  row.push(cell);totalCells++;if(totalCells>FILE_POLICY.maxWorkbookCells)throw new Error('تعداد سلول‌های CSV از ۲۰۰٬۰۰۰ بیشتر است.');if(row.some(value=>value!==''))rows.push(row);
  if(rows.length>FILE_POLICY.maxSheetRows)throw new Error('تعداد ردیف‌های CSV از ۲۰٬۰۰۰ بیشتر است.');
  if(rows.some(values=>values.length>FILE_POLICY.maxSheetColumns))throw new Error('تعداد ستون‌های CSV از ۲۰۰ بیشتر است.');
  return rows;
}

function stringifyCSV(rows, delimiter=','){
  if(!Array.isArray(rows))throw new TypeError('داده‌ی جدولی معتبر نیست.');
  return rows.map(row=>row.map(value=>{const text=String(value??'');return /["\r\n,;\t]/.test(text)||text.includes(delimiter)?`"${text.replace(/"/g,'""')}"`:text}).join(delimiter)).join('\r\n');
}

const xml=value=>String(value??'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&apos;');
const colName=n=>{let s='';while(n){const r=(n-1)%26;s=String.fromCharCode(65+r)+s;n=Math.floor((n-1)/26)}return s};
const colIndex=ref=>{const letters=(String(ref).match(/^[A-Z]+/i)||['A'])[0].toUpperCase();let value=0;for(const c of letters)value=value*26+c.charCodeAt(0)-64;return value-1};
function isSafeFormula(value){
  const formula=String(value||'').replace(/^=/,'').trim();
  return /^(?:SUM|AVERAGE|MIN|MAX|COUNT|COUNTA|PRODUCT)\([A-Z]{1,3}[1-9][0-9]*(?::[A-Z]{1,3}[1-9][0-9]*)?\)$/i.test(formula);
}
function safeSheetName(value,index,used){
  let base=String(value||`Sheet${index+1}`).replace(/[\\/?*\[\]:\u0000-\u001f]/g,' ').trim().replace(/^'+|'+$/g,'').slice(0,31)||`Sheet${index+1}`;
  let name=base,n=2;while(used.has(name.toLowerCase())){const suffix=` (${n++})`;name=base.slice(0,31-suffix.length)+suffix}
  used.add(name.toLowerCase());return name;
}
function normalizeWorkbook(input,options={}){
  let sheets;
  if(Array.isArray(input)&&input.length&&input.every(item=>item&&typeof item==='object'&&!Array.isArray(item)&&Array.isArray(item.rows)))sheets=input;
  else if(input&&Array.isArray(input.sheets))sheets=input.sheets;
  else if(Array.isArray(input))sheets=[{name:options.sheetName||'Sheet1',rows:input}];
  else throw new Error('ساختار داده‌ی Excel معتبر نیست.');
  if(!sheets.length||sheets.length>20)throw new Error('فایل Excel باید بین ۱ تا ۲۰ برگه داشته باشد.');
  const used=new Set();let totalRows=0,totalCells=0;
  const normalized=sheets.map((sheet,index)=>{
    if(!sheet||!Array.isArray(sheet.rows)||!sheet.rows.length)throw new Error(`داده‌ی برگه‌ی ${index+1} خالی یا نامعتبر است.`);
    if(sheet.rows.length>FILE_POLICY.maxSheetRows||sheet.rows.some(row=>!Array.isArray(row)||row.length>FILE_POLICY.maxSheetColumns))throw new Error('ابعاد یکی از برگه‌ها از محدودیت فایل بیشتر است.');
    const rowCount=sheet.rows.length;totalRows+=rowCount;
    if(totalRows>FILE_POLICY.maxWorkbookRows)throw new Error('مجموع ردیف‌های فایل Excel از ۴۰٬۰۰۰ بیشتر است.');
    for(const row of sheet.rows)for(const cell of row){totalCells++;if(totalCells>FILE_POLICY.maxWorkbookCells)throw new Error('تعداد کل سلول‌های فایل Excel از ۲۰۰٬۰۰۰ بیشتر است.');if(typeof cell==='string'&&cell.length>FILE_POLICY.maxCellChars)throw new Error('یکی از سلول‌ها از سقف ۳۲٬۰۰۰ نویسه بیشتر است.');if(typeof cell==='string'&&/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/.test(cell))throw new Error('یکی از سلول‌ها نویسه‌ی کنترلی غیرمجاز XML دارد.');if(cell&&typeof cell==='object'&&typeof cell.formula==='string'&&!isSafeFormula(cell.formula))throw new Error('فرمول Excel مجاز نیست؛ فقط SUM، AVERAGE، MIN، MAX، COUNT، COUNTA و PRODUCT با یک محدوده پشتیبانی می‌شوند.')}
    const chart=sheet.chart?normalizeChart(sheet.chart,sheet.rows):null;
    return {name:safeSheetName(sheet.name,index,used),rows:sheet.rows,chart};
  });
  return normalized;
}
const STYLES_XML='<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Aptos"/><family val="2"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Aptos"/><family val="2"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF245B8F"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border><border><left style="thin"><color rgb="FFD7E0EA"/></left><right style="thin"><color rgb="FFD7E0EA"/></right><top style="thin"><color rgb="FFD7E0EA"/></top><bottom style="thin"><color rgb="FFD7E0EA"/></bottom><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>';
function normalizeChart(chart,rows){
  const type=String(chart.type||'bar').toLowerCase();
  if(!['bar','line','pie'].includes(type))throw new Error('نوع نمودار فقط bar، line یا pie است.');
  const categoryColumn=Number.isInteger(chart.categoryColumn)?chart.categoryColumn:0;
  const headerRow=Number.isInteger(chart.headerRow)?chart.headerRow:0;
  const dataStartRow=Number.isInteger(chart.dataStartRow)?chart.dataStartRow:headerRow+1;
  const dataEndRow=Number.isInteger(chart.dataEndRow)?chart.dataEndRow:rows.length-1;
  const seriesColumns=Array.isArray(chart.seriesColumns)?[...new Set(chart.seriesColumns)]:[1];
  if(categoryColumn<0||categoryColumn>=FILE_POLICY.maxSheetColumns||headerRow<0||headerRow>=rows.length||dataStartRow<=headerRow||dataEndRow<dataStartRow||dataEndRow>=rows.length)throw new Error('محدوده‌ی داده‌های نمودار معتبر نیست.');
  if(!seriesColumns.length||seriesColumns.length>(type==='pie'?1:8)||seriesColumns.some(index=>!Number.isInteger(index)||index<0||index>=FILE_POLICY.maxSheetColumns||index===categoryColumn))throw new Error('ستون‌های سری نمودار معتبر نیستند.');
  const points=dataEndRow-dataStartRow+1;if(points<2||points>1000)throw new Error('نمودار باید بین ۲ تا ۱۰۰۰ ردیف داده داشته باشد.');
  for(const col of seriesColumns){if(!rows.slice(dataStartRow,dataEndRow+1).some(row=>{const value=row[col]?.value??row[col];return typeof value==='number'?Number.isFinite(value):typeof value==='string'&&value.trim()!==''&&Number.isFinite(Number(value))}))throw new Error(`ستون ${col+1} داده‌ی عددی برای نمودار ندارد.`);}
  return {type,title:String(chart.title||'نمودار SAYROX').slice(0,120),categoryColumn,headerRow,dataStartRow,dataEndRow,seriesColumns};
}
function sheetXml(rows,hasChart=false){
  const maxCols=Math.max(1,...rows.map(row=>Math.min(row.length,FILE_POLICY.maxSheetColumns)));
  const maxRow=rows.length;
  const body=rows.map((row,r)=>`<row r="${r+1}"${r===0?' ht="24" customHeight="1"':''}>${row.slice(0,FILE_POLICY.maxSheetColumns).map((value,c)=>{
    const ref=`${colName(c+1)}${r+1}`,style=r===0?' s="1"':'';
    if(value&&typeof value==='object'&&typeof value.formula==='string'&&isSafeFormula(value.formula))return `<c r="${ref}"${style}><f>${xml(value.formula.replace(/^=/,'').trim())}</f>${Number.isFinite(Number(value.value))?`<v>${Number(value.value)}</v>`:''}</c>`;
    if(typeof value==='number'&&Number.isFinite(value))return `<c r="${ref}"${style}><v>${value}</v></c>`;
    if(typeof value==='boolean')return `<c r="${ref}" t="b"${style}><v>${value?1:0}</v></c>`;
    const text=String(value??'');return `<c r="${ref}" t="inlineStr"${style}><is><t xml:space="preserve">${xml(text.slice(0,FILE_POLICY.maxCellChars))}</t></is></c>`;
  }).join('')}</row>`).join('');
  const widths=Array.from({length:maxCols},(_,i)=>{const max=Math.max(10,...rows.slice(0,100).map(row=>String(row[i]??'').length));return `<col min="${i+1}" max="${i+1}" width="${Math.min(40,Math.max(12,max+2))}" customWidth="1"/>`}).join('');
  const lastRef=`${colName(maxCols)}${maxRow}`;
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/><selection pane="bottomLeft" activeCell="A2" sqref="A2"/></sheetView></sheetViews><sheetFormatPr defaultRowHeight="18"/><cols>${widths}</cols><sheetData>${body}</sheetData>${maxRow>1?`<autoFilter ref="A1:${lastRef}"/>`:''}${hasChart?'<drawing r:id="rId1"/>':''}</worksheet>`;
}
function chartFormula(sheetName,column,startRow,endRow){const safe=String(sheetName).replace(/'/g,"''");return `'${safe}'!$${colName(column+1)}$${startRow+1}:$${colName(column+1)}$${endRow+1}`}
function chartTitleXml(title){return `<c:title><c:tx><c:rich><a:bodyPr/><a:lstStyle/><a:p><a:pPr><a:defRPr/></a:pPr><a:r><a:rPr lang="fa-IR" sz="1500" b="1"/><a:t>${xml(title)}</a:t></a:r><a:endParaRPr lang="fa-IR"/></a:p></c:rich></c:tx><c:overlay val="0"/></c:title>`}
function chartSeriesXml(sheet,chart,seriesIndex,column){
  const rows=sheet.rows,header=String(rows[chart.headerRow][column]??`سری ${seriesIndex+1}`),categoryFormula=chartFormula(sheet.name,chart.categoryColumn,chart.dataStartRow,chart.dataEndRow),valueFormula=chartFormula(sheet.name,column,chart.dataStartRow,chart.dataEndRow),categoryValues=rows.slice(chart.dataStartRow,chart.dataEndRow+1).map((row,index)=>`<c:pt idx="${index}"><c:v>${xml(row[chart.categoryColumn]??'')}</c:v></c:pt>`).join(''),numericValues=rows.slice(chart.dataStartRow,chart.dataEndRow+1).map((row,index)=>`<c:pt idx="${index}"><c:v>${Number(row[column]?.value??row[column])||0}</c:v></c:pt>`).join('');
  return `<c:ser><c:idx val="${seriesIndex}"/><c:order val="${seriesIndex}"/><c:tx><c:strRef><c:f>'${String(sheet.name).replace(/'/g,"''")}'!$${colName(column+1)}$${chart.headerRow+1}</c:f><c:strCache><c:ptCount val="1"/><c:pt idx="0"><c:v>${xml(header)}</c:v></c:pt></c:strCache></c:strRef></c:tx><c:cat><c:strRef><c:f>${xml(categoryFormula)}</c:f><c:strCache><c:ptCount val="${chart.dataEndRow-chart.dataStartRow+1}"/>${categoryValues}</c:strCache></c:strRef></c:cat><c:val><c:numRef><c:f>${xml(valueFormula)}</c:f><c:numCache><c:formatCode>General</c:formatCode><c:ptCount val="${chart.dataEndRow-chart.dataStartRow+1}"/>${numericValues}</c:numCache></c:numRef></c:val></c:ser>`;
}
function chartXml(sheet,chart){
  const series=chart.seriesColumns.map((column,index)=>chartSeriesXml(sheet,chart,index,column)).join('');
  let plot='';
  if(chart.type==='pie')plot=`<c:pieChart><c:varyColors val="1"/>${series}<c:firstSliceAng val="0"/></c:pieChart>`;
  else if(chart.type==='line')plot=`<c:lineChart><c:grouping val="standard"/>${series}<c:marker val="1"/><c:smooth val="0"/><c:axId val="123456"/><c:axId val="123457"/></c:lineChart><c:catAx><c:axId val="123456"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="b"/><c:tickLblPos val="nextTo"/><c:crossAx val="123457"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/></c:catAx><c:valAx><c:axId val="123457"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="l"/><c:majorGridlines/><c:numFmt formatCode="General" sourceLinked="1"/><c:tickLblPos val="nextTo"/><c:crossAx val="123456"/><c:crosses val="autoZero"/><c:crossBetween val="between"/></c:valAx>`;
  else plot=`<c:barChart><c:barDir val="col"/><c:grouping val="clustered"/><c:varyColors val="0"/>${series}<c:gapWidth val="150"/><c:overlap val="0"/><c:axId val="123456"/><c:axId val="123457"/></c:barChart><c:catAx><c:axId val="123456"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="b"/><c:tickLblPos val="nextTo"/><c:crossAx val="123457"/><c:crosses val="autoZero"/><c:auto val="1"/><c:lblAlgn val="ctr"/><c:lblOffset val="100"/></c:catAx><c:valAx><c:axId val="123457"/><c:scaling><c:orientation val="minMax"/></c:scaling><c:delete val="0"/><c:axPos val="l"/><c:majorGridlines/><c:numFmt formatCode="General" sourceLinked="1"/><c:tickLblPos val="nextTo"/><c:crossAx val="123456"/><c:crosses val="autoZero"/><c:crossBetween val="between"/></c:valAx>`;
  const legend=chart.type==='pie'||chart.seriesColumns.length>1?'<c:legend><c:legendPos val="b"/><c:layout/><c:overlay val="0"/></c:legend>':'';
  return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><c:chartSpace xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><c:date1904 val="0"/><c:lang val="fa-IR"/><c:roundedCorners val="1"/><c:chart>${chartTitleXml(chart.title)}<c:plotArea><c:layout/>${plot}</c:plotArea>${legend}<c:plotVisOnly val="1"/><c:dispBlanksAs val="gap"/></c:chart><c:printSettings><c:headerFooter/><c:pageMargins b="0.75" l="0.7" r="0.7" t="0.75" header="0.3" footer="0.3"/><c:pageSetup/></c:printSettings></c:chartSpace>`;
}
function drawingXml(){return `<?xml version="1.0" encoding="UTF-8" standalone="yes"?><xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><xdr:twoCellAnchor editAs="oneCell"><xdr:from><xdr:col>4</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>1</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:to><xdr:col>15</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>20</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:to><xdr:graphicFrame macro=""><xdr:nvGraphicFramePr><xdr:cNvPr id="2" name="SAYROX Chart"/><xdr:cNvGraphicFramePr/></xdr:nvGraphicFramePr><xdr:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/></xdr:xfrm><a:graphic><a:graphicData uri="http://schemas.openxmlformats.org/drawingml/2006/chart"><c:chart xmlns:c="http://schemas.openxmlformats.org/drawingml/2006/chart" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" r:id="rId1"/></a:graphicData></a:graphic></xdr:graphicFrame><xdr:clientData/></xdr:twoCellAnchor></xdr:wsDr>`}
async function createXlsx(input,options={}){
  const sheets=normalizeWorkbook(input,options),chartSheets=sheets.map((sheet,index)=>sheet.chart?index:-1).filter(index=>index>=0);
  const overrides=sheets.map((_,i)=>`<Override PartName="/xl/worksheets/sheet${i+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`).join('');
  const chartOverrides=chartSheets.map(index=>`<Override PartName="/xl/drawings/drawing${index+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/><Override PartName="/xl/charts/chart${index+1}.xml" ContentType="application/vnd.openxmlformats-officedocument.drawingml.chart+xml"/>`).join('');
  const workbookSheets=sheets.map((sheet,i)=>`<sheet name="${xml(sheet.name)}" sheetId="${i+1}" r:id="rId${i+1}"/>`).join('');
  const rels=sheets.map((_,i)=>`<Relationship Id="rId${i+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet${i+1}.xml"/>`).join('')+`<Relationship Id="rId${sheets.length+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>`;
  const entries=[
    {name:'[Content_Types].xml',text:`<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>${overrides}${chartOverrides}</Types>`},
    {name:'_rels/.rels',text:'<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'},
    {name:'xl/workbook.xml',text:`<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><bookViews><workbookView/></bookViews><sheets>${workbookSheets}</sheets><calcPr calcId="191029" fullCalcOnLoad="1" forceFullCalc="1"/></workbook>`},
    {name:'xl/_rels/workbook.xml.rels',text:`<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${rels}</Relationships>`},
    {name:'xl/styles.xml',text:STYLES_XML},
    ...sheets.map((sheet,i)=>({name:`xl/worksheets/sheet${i+1}.xml`,text:sheetXml(sheet.rows,Boolean(sheet.chart))})),
    ...chartSheets.flatMap(index=>[
      {name:`xl/worksheets/_rels/sheet${index+1}.xml.rels`,text:'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing'+(index+1)+'.xml"/></Relationships>'},
      {name:`xl/drawings/drawing${index+1}.xml`,text:drawingXml()},
      {name:`xl/drawings/_rels/drawing${index+1}.xml.rels`,text:'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart" Target="../charts/chart'+(index+1)+'.xml"/></Relationships>'},
      {name:`xl/charts/chart${index+1}.xml`,text:chartXml(sheets[index],sheets[index].chart)}
    ])
  ];
  return createZip(entries);
}
function decodeXml(text){const safeCodePoint=value=>Number.isInteger(value)&&value>=1&&value<=0x10ffff&&!(value>=0xd800&&value<=0xdfff)?String.fromCodePoint(value):'\uFFFD';return String(text).replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'\"').replace(/&apos;/g,"'").replace(/&amp;/g,'&').replace(/&#(\d+);/g,(_,n)=>safeCodePoint(Number(n))).replace(/&#x([\da-f]+);/gi,(_,n)=>safeCodePoint(parseInt(n,16)))}
function attr(source,name){const match=source.match(new RegExp(`(?:^|\\s)${name}="([^"]*)"`));return match?decodeXml(match[1]):''}
function parseXmlTagContent(source,tag){return [...source.matchAll(new RegExp(`<${tag}\\b([^>]*?)(?:\\/\\s*>|>([\\s\\S]*?)<\\/${tag}\\s*>)`,'g'))].map(match=>({attrs:match[1],body:match[2]||''}))}
function relationshipPath(target){const raw=String(target||'');if(!raw||/^[a-z]+:/i.test(raw)||/[?#]/.test(raw))throw new Error('مسیر رابطه‌ی داخلی Excel معتبر نیست.');const absolute=raw.startsWith('/'),parts=absolute?[]:['xl'];for(const part of raw.replace(/\\/g,'/').split('/')){if(!part||part==='.')continue;if(part==='..'){if(!parts.length)throw new Error('رابطه‌ی Excel از محدوده‌ی فایل خارج می‌شود.');parts.pop()}else parts.push(part)}const resolved=parts.join('/');if(!resolved.startsWith('xl/worksheets/'))throw new Error('رابطه‌ی برگه‌ی Excel باید به یک فایل worksheet داخلی اشاره کند.');return resolved}
async function readXlsxWorkbook(input){
  const files=await readZip(input);const map=new Map(files.map(file=>[file.name,file.bytes]));
  const workbookBytes=map.get('xl/workbook.xml'),relsBytes=map.get('xl/_rels/workbook.xml.rels');
  if(!workbookBytes||!relsBytes)throw new Error('ساختار اصلی فایل Excel ناقص است.');
  const workbook=new TextDecoder('utf-8',{fatal:true}).decode(workbookBytes),rels=new TextDecoder('utf-8',{fatal:true}).decode(relsBytes);
  const relMap=new Map(parseXmlTagContent(rels,'Relationship').map(r=>[attr(r.attrs,'Id'),attr(r.attrs,'Target')]));
  const sharedBytes=map.get('xl/sharedStrings.xml');
  const shared=[];let totalTextChars=0,totalRows=0,totalCells=0;
  if(sharedBytes){
    const sharedXml=new TextDecoder('utf-8',{fatal:true}).decode(sharedBytes);
    for(const item of parseXmlTagContent(sharedXml,'si')){
      const value=[...item.body.matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)].map(m=>decodeXml(m[1])).join('');
      if(value.length>FILE_POLICY.maxCellChars)throw new Error('یکی از متن‌های مشترک Excel از سقف ۳۲٬۰۰۰ نویسه بیشتر است.');
      totalTextChars+=value.length;if(totalTextChars>FILE_POLICY.maxTextChars)throw new Error('متن فایل Excel از سقف ۵۰۰٬۰۰۰ نویسه بیشتر است.');
      shared.push(value);if(shared.length>FILE_POLICY.maxWorkbookCells)throw new Error('تعداد متن‌های مشترک Excel از سقف مجاز بیشتر است.');
    }
  }
  const sheetNodes=parseXmlTagContent(workbook,'sheet');if(!sheetNodes.length||sheetNodes.length>20)throw new Error('تعداد برگه‌های Excel خالی یا بیش از حد مجاز است.');
  const result=[];
  for(const node of sheetNodes){
    const name=attr(node.attrs,'name')||`Sheet${result.length+1}`,target=relMap.get(attr(node.attrs,'r:id'));
    if(!target)throw new Error(`مسیر برگه‌ی ${name} در روابط Excel پیدا نشد.`);
    const path=relationshipPath(target);const sheetBytes=map.get(path);if(!sheetBytes)throw new Error(`محتوای برگه‌ی ${name} پیدا نشد.`);
    const text=new TextDecoder('utf-8',{fatal:true}).decode(sheetBytes),rows=[],seenRows=new Set();let sequentialRow=0;
    for(const rowNode of parseXmlTagContent(text,'row')){
      const rowNumberText=attr(rowNode.attrs,'r');
      const rowNumber=rowNumberText?Number(rowNumberText):sequentialRow+1;
      if(!Number.isSafeInteger(rowNumber)||rowNumber<1||rowNumber>FILE_POLICY.maxSheetRows)throw new Error(`شماره‌ی یکی از ردیف‌های برگه‌ی ${name} خارج از محدوده است.`);
      const rowIndex=rowNumber-1;if(seenRows.has(rowIndex))throw new Error(`ردیف تکراری در برگه‌ی ${name} پیدا شد.`);seenRows.add(rowIndex);sequentialRow=rowNumber;
      totalRows++;if(totalRows>FILE_POLICY.maxWorkbookRows)throw new Error('تعداد کل ردیف‌های فایل Excel از سقف مجاز بیشتر است.');
      const row=[];
      for(const cell of parseXmlTagContent(rowNode.body,'c')){
        const reference=attr(cell.attrs,'r'),cellMatch=reference.match(/^([A-Z]{1,3})([1-9][0-9]*)$/i);
        if(!cellMatch)throw new Error(`نشانی یکی از سلول‌های برگه‌ی ${name} معتبر نیست.`);
        const index=colIndex(reference);if(index<0||index>=FILE_POLICY.maxSheetColumns)throw new Error('تعداد ستون‌های Excel از ۲۰۰ بیشتر است.');
        if(Number(cellMatch[2])!==rowNumber)throw new Error(`نشانی سلول با ردیف ${rowNumber} در برگه‌ی ${name} هماهنگ نیست.`);
        totalCells++;if(totalCells>FILE_POLICY.maxWorkbookCells)throw new Error('تعداد کل سلول‌های فایل Excel از ۲۰۰٬۰۰۰ بیشتر است.');
        const type=attr(cell.attrs,'t'),value=(cell.body.match(/<v>([\s\S]*?)<\/v>/)||[])[1]??'';let parsed='';
        if(type==='inlineStr')parsed=[...cell.body.matchAll(/<t(?:\s[^>]*)?>([\s\S]*?)<\/t>/g)].map(m=>decodeXml(m[1])).join('');
        else if(type==='s'){
          const sharedIndex=Number(value);if(!Number.isInteger(sharedIndex)||sharedIndex<0||sharedIndex>=shared.length)throw new Error(`ارجاع متن مشترک در سلول ${reference} معتبر نیست.`);parsed=shared[sharedIndex];
        }
        else if(type==='b'){if(value!=='0'&&value!=='1')throw new Error(`مقدار بولی سلول ${reference} معتبر نیست.`);parsed=value==='1'}
        else if(value!==''&&Number.isFinite(Number(value)))parsed=Number(value);
        else parsed=decodeXml(value);
        const formula=(cell.body.match(/<f(?:\s[^>]*)?>([\s\S]*?)<\/f>/)||[])[1];
        const cellValue=formula?{formula:decodeXml(formula),value:parsed}:parsed;
        const valueLength=typeof parsed==='string'?parsed.length:formula?.length||0;
        if(valueLength>FILE_POLICY.maxCellChars)throw new Error(`محتوای سلول ${reference} از سقف ۳۲٬۰۰۰ نویسه بیشتر است.`);
        totalTextChars+=valueLength;if(totalTextChars>FILE_POLICY.maxTextChars)throw new Error('متن فایل Excel از سقف ۵۰۰٬۰۰۰ نویسه بیشتر است.');
        row[index]=cellValue;
      }
      rows[rowIndex]=row;
    }
    const finalRows=rows.map(row=>row||[]);
    result.push({name,rows:finalRows});
  }
  return result;
}
async function readXlsx(input){const workbook=await readXlsxWorkbook(input);return workbook[0]?.rows||[]}

window.SayroxSpreadsheet=Object.freeze({parseCSV,stringifyCSV,createXlsx,readXlsx,readXlsxWorkbook,isSafeFormula});
})();
