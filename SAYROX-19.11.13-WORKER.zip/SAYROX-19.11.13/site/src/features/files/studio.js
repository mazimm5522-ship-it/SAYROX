(function SayroxFileModule(){
'use strict';
const {FILE_POLICY,validateFile,safeOutputName,extensionOf}=window.SayroxFilePolicy;
const {createZip,readZip}=window.SayroxZip;
const {renderHtml:markdownToHtml,tableToMarkdown:markdownTable,toPlainText:markdownToPlainText}=window.SayroxMarkdown;
const {parseCSV,stringifyCSV,createXlsx,readXlsxWorkbook}=window.SayroxSpreadsheet;
const {createTextPdf}=window.SayroxPdf;
const {extractPdfText}=window.SayroxPdfText;
const {recognizePdf}=window.SayroxPdfOcr;
const {createDocx,readDocx,createPptx,readPptx}=window.SayroxDocuments;

const sessionFiles=[];
const objectUrls=new Set();
let batchCancelRequested=false;
let batchRunning=false;
let batchSelectionInitialized=false;
let activeStudioRoot=null;
let nextOpenFileId=null;
const $=(root,selector)=>root.querySelector(selector);
const esc=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
function toast(message){const node=document.querySelector('#toast');if(node){node.textContent=message;node.classList.add('show');clearTimeout(toast.timer);toast.timer=setTimeout(()=>node.classList.remove('show'),3200)}}
function rememberUrl(url){objectUrls.add(url);return url}
function revokeUrls(){for(const url of objectUrls)URL.revokeObjectURL(url);objectUrls.clear()}
function download(blob,name,remember=false){const safeName=safeOutputName(name),url=rememberUrl(URL.createObjectURL(blob));const link=document.createElement('a');link.href=url;link.download=safeName;link.rel='noopener';document.body.appendChild(link);link.click();link.remove();setTimeout(()=>{URL.revokeObjectURL(url);objectUrls.delete(url)},30000);if(remember&&window.SayroxFileLibrary&&typeof File==='function'){const file=new File([blob],safeName,{type:blob.type||'application/octet-stream',lastModified:Date.now()});window.SayroxFileLibrary.add(file,{source:'generated'}).catch(error=>toast(`دانلود انجام شد اما فایل در کتابخانه ذخیره نشد: ${error.message}`))}}
function appendLocalDownloadLink(root,parent,blob,name){
  const url=rememberUrl(URL.createObjectURL(blob)),wrap=document.createElement('div');wrap.className='fs-local-download';
  const title=document.createElement('strong');title.textContent='لینک دریافت محلی آماده است';
  const link=document.createElement('a');link.href=url;link.download=safeOutputName(name);link.rel='noopener';link.textContent=`دانلود ${name}`;
  const input=document.createElement('input');input.type='text';input.readOnly=true;input.value=url;input.dir='ltr';input.setAttribute('aria-label','لینک دانلود محلی');
  const copy=document.createElement('button');copy.type='button';copy.className='secondary-btn';copy.textContent='کپی لینک';
  copy.addEventListener('click',async()=>{
    try{if(!navigator.clipboard?.writeText)throw new Error('clipboard-unavailable');await navigator.clipboard.writeText(url);addNotice(root,'لینک محلی کپی شد؛ فقط در همین مرورگر و تا پایان این نشست معتبر است.','success')}
    catch{input.focus();input.select();addNotice(root,'مرورگر اجازه‌ی کپی خودکار نداد؛ لینک داخل کادر را دستی کپی کن. این لینک عمومی نیست.','info')}
  });
  const note=document.createElement('small');note.textContent='این لینک فقط در همین مرورگر و نشست باز است؛ برای اشتراک‌گذاری با دیگران باید فایل روی فضای ذخیره‌سازی آنلاین قرار بگیرد.';
  wrap.append(title,link,input,copy,note);parent.appendChild(wrap);return url;
}
function blobFor(file){return new Blob([file.bytes],{type:'application/octet-stream'})}
function addNotice(root,message,kind='info'){$(root,'[data-status]').textContent=message;$(root,'[data-status]').dataset.kind=kind}
async function addSessionFiles(files){
  const library=window.SayroxFileLibrary;if(!library)throw new Error('ذخیره‌ساز کتابخانه در دسترس نیست. صفحه را تازه‌سازی کن.');
  let batch=sessionFiles.reduce((sum,item)=>sum+item.file.size,0);const added=[];
  for(const file of files){
    try{
      if(sessionFiles.length>=FILE_POLICY.maxSessionFiles)throw new Error('حداکثر ۱۰۰ فایل در کتابخانه قابل نگهداری است.');
      if(batch+file.size>FILE_POLICY.maxBatchBytes)throw new Error('حجم مجموع فایل‌های انتخاب‌شده نباید از ۴۰ مگابایت بیشتر باشد.');
      const saved=await library.add(file,{source:'studio'}),stored=await library.get(saved.id);
      if(!stored)throw new Error('فایل ذخیره شد اما بازیابی آن موفق نبود.');
      batch+=file.size;
      if(!sessionFiles.some(item=>item.id===saved.id)){
        const item={id:saved.id,file:stored.file,extension:saved.extension,mime:saved.mime};sessionFiles.push(item);added.push(item);
      }
    }catch(error){toast(`${file?.name||'فایل'}: ${error.message}`)}
  }
  return added;
}
async function loadLibraryFiles(root){
  const library=window.SayroxFileLibrary;if(!library)return;
  try{
    const stored=await library.all(),items=stored.map(entry=>({id:entry.id,file:entry.file,extension:entry.extension,mime:entry.mime}));
    sessionFiles.splice(0,sessionFiles.length,...items);
    if(root?.isConnected){renderFileList(root);if(nextOpenFileId){const item=sessionFiles.find(entry=>entry.id===nextOpenFileId);nextOpenFileId=null;if(item)previewFile(root,item);else addNotice(root,'فایل در کتابخانه پیدا نشد.','error')}}
  }catch(error){if(root?.isConnected)addNotice(root,`خواندن کتابخانه ناموفق بود: ${error.message}`,'error')}
}
window.addEventListener('sayrox:file-library-change',()=>{if(activeStudioRoot?.isConnected)loadLibraryFiles(activeStudioRoot)});

function renderFileList(root){
  const list=$(root,'[data-file-list]');list.replaceChildren();
  if(!sessionFiles.length){const empty=document.createElement('div');empty.className='fs-empty';empty.textContent='کتابخانه خالی است. فایل‌های اضافه‌شده در همین مرورگر ذخیره می‌شوند و پس از بازکردن دوبارهٔ صفحه در دسترس‌اند.';list.appendChild(empty);updateConversionSources(root);updateBatchSources(root);return}
  for(const item of sessionFiles){
    const row=document.createElement('div');row.className='fs-file';
    const meta=document.createElement('div');meta.className='fs-file-meta';
    const name=document.createElement('strong');name.textContent=item.file.name;
    const details=document.createElement('small');details.textContent=`${item.extension.toUpperCase()} · ${(item.file.size/1024).toFixed(1)} KB`;
    meta.append(name,details);
    const actions=document.createElement('div');actions.className='fs-file-actions';
    const action=(label,fn)=>{const b=document.createElement('button');b.type='button';b.className='secondary-btn';b.textContent=label;b.addEventListener('click',fn);actions.appendChild(b)};
    action('بازبینی',()=>previewFile(root,item));
    if(conversionTargets(item.extension).length)action('تبدیل',()=>selectConversionSource(root,item));
    if(item.extension==='pdf'){action('استخراج متن',()=>extractPdfFile(root,item));action('OCR فارسی/انگلیسی',()=>runPdfOcr(root,item))}
    if(item.extension==='docx'||item.extension==='pptx'){
      action('استخراج متن',()=>extractOfficeFile(root,item));
      action('ویرایش متن',()=>loadDocumentIntoEditor(root,item));
    }
    if(item.extension==='pdf')action('ویرایش متن',()=>loadDocumentIntoEditor(root,item));
    if(['txt','md','csv','json','xml','html','htm','css','js','mjs','ts','tsx','jsx','py','java','c','cpp','h','cs','php','rb','go','rs','sql','yaml','yml'].includes(item.extension)) action('ویرایشگر',async()=>{try{const text=ensureTextLimit(await item.file.text());$(root,'[data-title]').value=item.file.name.replace(/\.[^.]+$/,'');$(root,'[data-editor]').value=text;addNotice(root,`محتوای ${item.file.name} به ویرایشگر منتقل شد.`,'success');$(root,'[data-editor]').focus()}catch(error){addNotice(root,error.message,'error')}});
    action('دانلود',()=>download(item.file,item.file.name));
    action('حذف',async()=>{try{await window.SayroxFileLibrary.remove(item.id);const index=sessionFiles.findIndex(f=>f.id===item.id);if(index>=0)sessionFiles.splice(index,1);renderFileList(root);addNotice(root,'فایل از کتابخانهٔ همین دستگاه حذف شد.','success')}catch(error){addNotice(root,error.message,'error')}});
    row.append(meta,actions);list.appendChild(row);
  }
  updateConversionSources(root);
  updateBatchSources(root);
}
function showText(root,text,title='پیش‌نمایش فایل'){
  const preview=$(root,'[data-preview]');preview.replaceChildren();
  const heading=document.createElement('h3');heading.textContent=title;
  const pre=document.createElement('pre');pre.className='fs-code-preview';pre.textContent=String(text).slice(0,FILE_POLICY.maxTextChars);
  preview.append(heading,pre);preview.scrollIntoView({behavior:'smooth',block:'nearest'});
}
function appendTable(parent,rows,title){
  const heading=document.createElement('h4');heading.textContent=title;parent.appendChild(heading);const table=document.createElement('table');table.className='fs-table';const fragment=document.createDocumentFragment();
  for(const [rowIndex,row] of rows.slice(0,100).entries()){const tr=document.createElement('tr');for(const value of row.slice(0,20)){const cell=document.createElement(rowIndex===0?'th':'td');cell.textContent=typeof value==='object'?`=${value.formula}`:String(value??'');tr.appendChild(cell)}fragment.appendChild(tr)}
  table.appendChild(fragment);const wrap=document.createElement('div');wrap.className='fs-table-wrap';wrap.appendChild(table);parent.appendChild(wrap);
}
function showTable(root,rows,title='پیش‌نمایش جدول'){const preview=$(root,'[data-preview]');preview.replaceChildren();const heading=document.createElement('h3');heading.textContent=title;preview.appendChild(heading);appendTable(preview,rows,'داده‌ها')}
function showWorkbook(root,sheets,title='پیش‌نمایش فایل Excel'){const preview=$(root,'[data-preview]');preview.replaceChildren();const heading=document.createElement('h3');heading.textContent=`${title} · ${sheets.length} برگه`;preview.appendChild(heading);for(const sheet of sheets)appendTable(preview,sheet.rows,`برگه: ${sheet.name}`);}
function previewHtml(root,html){
  const preview=$(root,'[data-preview]');preview.replaceChildren();
  const heading=document.createElement('h3');heading.textContent='پیش‌نمایش ایزوله‌ی HTML';
  const frame=window.SayroxSecureHtmlPreview?.createFrame(html,{className:'fs-preview-frame',title:'پیش‌نمایش ایزوله HTML'});
  if(!frame){const note=document.createElement('div');note.className='fs-status';note.dataset.kind='error';note.textContent='موتور پیش‌نمایش امن در دسترس نیست.';preview.append(heading,note);return}
  preview.append(heading,frame);preview.scrollIntoView({behavior:'smooth',block:'nearest'});
}
async function previewFile(root,item){
  try{
    const ext=item.extension;
    if(['jpg','jpeg','png','webp','gif'].includes(ext)){const url=rememberUrl(URL.createObjectURL(item.file)),preview=$(root,'[data-preview]');preview.replaceChildren();const heading=document.createElement('h3');heading.textContent=`پیش‌نمایش تصویر · ${item.file.name}`;const image=document.createElement('img');image.className='fs-image-preview';image.src=url;image.alt=item.file.name;image.loading='lazy';preview.append(heading,image);preview.scrollIntoView({behavior:'smooth',block:'nearest'});return}
    if(['txt','md','json','xml','html','htm','css','js','mjs','ts','tsx','jsx','py','java','c','cpp','h','cs','php','rb','go','rs','sql','yaml','yml'].includes(ext)){
      const text=await item.file.text();if(ext==='html'||ext==='htm')previewHtml(root,text);else showText(root,text,item.file.name);return;
    }
    if(ext==='csv'){showTable(root,parseCSV(await item.file.text()),item.file.name);return}
    if(ext==='xlsx'||ext==='xlsm'){showWorkbook(root,await readXlsxWorkbook(item.file),item.file.name);return}
    if(ext==='docx'){showText(root,await readDocx(item.file),`متن Word · ${item.file.name}`);return}
    if(ext==='pptx'){showText(root,await readPptx(item.file),`متن PowerPoint · ${item.file.name}`);return}
    if(ext==='zip'){
      const entries=await readZip(item.file,{extract:false});showText(root,entries.map(entry=>`${entry.name}\n${entry.uncompressedSize.toLocaleString('fa-IR')} bytes`).join('\n\n'),`فهرست ZIP · ${entries.length} فایل`);return;
    }
    if(ext==='pdf'){
      const url=rememberUrl(URL.createObjectURL(item.file));const preview=$(root,'[data-preview]');preview.replaceChildren();const h=document.createElement('h3');h.textContent=`نمایش PDF · ${item.file.name}`;const frame=document.createElement('iframe');frame.className='fs-preview-frame';frame.title='نمایش فایل PDF';frame.src=url;const actions=document.createElement('div');actions.className='fs-actions';const extract=document.createElement('button');extract.type='button';extract.className='secondary-btn';extract.textContent='استخراج متن PDF';extract.addEventListener('click',()=>extractPdfFile(root,item));const ocr=document.createElement('button');ocr.type='button';ocr.className='secondary-btn';ocr.textContent='OCR فارسی/انگلیسی';ocr.addEventListener('click',()=>runPdfOcr(root,item));actions.append(extract,ocr);preview.append(h,actions,frame);return;
    }
  }catch(error){addNotice(root,error.message,'error')}
}
async function textToPdf(root){
  const input=$(root,'[data-editor]');try{addNotice(root,'در حال ساخت PDF روی همین دستگاه…');const blob=await createTextPdf(input.value,{title:$(root,'[data-title]').value||'سند ساخته‌شده با SAYROX'});download(blob,`${safeOutputName($(root,'[data-title]').value||'sayrox-document')}.pdf`,true);addNotice(root,'PDF ساخته شد و دانلود آن آغاز شد. فایل متن به سرور ارسال نشد.','success')}catch(error){addNotice(root,error.message,'error')}
}
function htmlDocument(source,title){
  const name=esc(title||'SAYROX HTML');
  if(/<!doctype\s+html|<html[\s>]/i.test(source))return source;
  return `<!doctype html>\n<html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${name}</title></head><body>\n${source}\n</body></html>`;
}
function createHtml(root){const source=$(root,'[data-editor]').value;if(!source.trim()){addNotice(root,'کد یا متن HTML را وارد کن.','error');return}const html=htmlDocument(source,$(root,'[data-title]').value);download(new Blob([html],{type:'text/html;charset=utf-8'}),`${safeOutputName($(root,'[data-title]').value||'sayrox-page')}.html`,true);previewHtml(root,html);addNotice(root,'فایل HTML ساخته شد؛ پیش‌نمایش داخل محیط ایزوله اجرا می‌شود.','success')}
async function csvToXlsx(root){
  try{const rows=parseCSV($(root,'[data-editor]').value),title=$(root,'[data-title]').value||'sayrox-sheet',chartType=$(root,'[data-chart-type]').value;let chart=null;if(chartType!=='none'){const seriesColumns=rows[0].map((_,index)=>index).filter(index=>index!==0&&rows.slice(1).some(row=>String(row[index]??'').trim()!==''&&Number.isFinite(Number(row[index]))));if(chartType==='pie'&&seriesColumns.length>1)seriesColumns.splice(1);chart={type:chartType,title:`${title} · نمودار`,categoryColumn:0,seriesColumns}}const blob=await createXlsx([{name:title,rows,chart}]);download(blob,`${safeOutputName(title)}.xlsx`,true);showTable(root,rows,'پیش‌نمایش فایل Excel ساخته‌شده');addNotice(root,chart?`فایل XLSX همراه نمودار ${chartType} ساخته شد.`:'فایل Excel استاندارد XLSX ساخته و آماده‌ی دانلود شد.','success')}catch(error){addNotice(root,error.message,'error')}
}

async function extractPdfFile(root,item){try{addNotice(root,'در حال استخراج متن PDF روی همین دستگاه…');const text=await extractPdfText(item.file);showText(root,text,`متن استخراج‌شده از PDF · ${item.file.name}`);download(new Blob([text],{type:'text/plain;charset=utf-8'}),`${safeOutputName(item.file.name.replace(/\.pdf$/i,''))}-text.txt`,true);addNotice(root,'متن PDF استخراج شد و فایل متنی آماده‌ی دانلود است.','success')}catch(error){addNotice(root,`${error.message} برای اسناد اسکن‌شده، گزینه‌ی OCR فارسی/انگلیسی را اجرا کن.`,'error')}}
async function runPdfOcr(root,item){
  if(!window.confirm('برای OCR، موتور PDF.js و Tesseract.js و مدل زبان فارسی/انگلیسی از CDN بارگیری می‌شوند. خود فایل PDF در همین مرورگر پردازش می‌شود و به سرویس بیرونی ارسال نمی‌شود؛ فایل مدل زبان ممکن است در IndexedDB مرورگر cache شود. ادامه می‌دهی؟'))return;
  try{const text=await recognizePdf(item.file,{onProgress:event=>{const detail=event.detail?` · ${event.detail}`:'';addNotice(root,`${event.stage==='complete'?'OCR کامل شد':event.stage==='loading'?'بارگیری موتور OCR':event.stage==='rendering'?'تبدیل صفحه به تصویر':'تشخیص متن'} · ${event.percent}%${detail}`)}});showText(root,text,`متن OCR شده · ${item.file.name}`);download(new Blob([text],{type:'text/plain;charset=utf-8'}),`${safeOutputName(item.file.name.replace(/\.pdf$/i,''))}-ocr.txt`,true);addNotice(root,'OCR تمام صفحات با موفقیت انجام شد؛ فایل متنی آماده‌ی دانلود است.','success')}catch(error){addNotice(root,error.message,'error')}
}
async function extractOfficeFile(root,item){try{addNotice(root,'در حال خواندن سند روی همین دستگاه…');const text=item.extension==='docx'?await readDocx(item.file):await readPptx(item.file);showText(root,text,`متن استخراج‌شده · ${item.file.name}`);addNotice(root,'متن سند استخراج شد؛ فایل اصلی تغییری نکرد.','success')}catch(error){addNotice(root,error.message,'error')}}
async function loadDocumentIntoEditor(root,item){
  try{
    addNotice(root,'در حال انتقال متن سند به ویرایشگر…');
    const text=item.extension==='pdf'?await extractPdfText(item.file):item.extension==='docx'?await readDocx(item.file):await readPptx(item.file);
    const editor=$(root,'[data-editor]'),title=$(root,'[data-title]');
    editor.value=text;title.value=safeOutputName(item.file.name.replace(/\.[^.]+$/,''));
    editor.scrollIntoView({behavior:'smooth',block:'center'});editor.focus();
    addNotice(root,'متن استخراج‌شده وارد ویرایشگر شد؛ فایل اصلی بدون تغییر در کتابخانه باقی ماند.','success');
  }catch(error){addNotice(root,`${error.message}${item.extension==='pdf'?' برای PDF اسکن‌شده ابتدا OCR را اجرا کن.':''}`,'error')}
}

const TEXT_EXTENSIONS=new Set(['txt','md','json','xml','css','js','mjs','ts','tsx','jsx','py','java','c','cpp','h','cs','php','rb','go','rs','sql','yaml','yml']);
const CONVERSION_TARGETS=Object.freeze({
  pdf:[['txt','متن ساده (TXT)'],['md','Markdown (MD)'],['docx','Word (DOCX)']],
  docx:[['txt','متن ساده (TXT)'],['md','Markdown (MD)'],['pdf','PDF'],['pptx','PowerPoint (PPTX)'],['html','صفحه HTML']],
  pptx:[['txt','متن ساده (TXT)'],['md','Markdown (MD)'],['pdf','PDF'],['docx','Word (DOCX)'],['html','صفحه HTML']],
  xlsx:[['csv','CSV / ZIP چندبرگه‌ای'],['json','JSON چندبرگه‌ای'],['md','Markdown (MD)'],['pdf','گزارش PDF'],['txt','متن ساده (TXT)']],
  xlsm:[['csv','CSV / ZIP چندبرگه‌ای'],['json','JSON چندبرگه‌ای'],['md','Markdown (MD)'],['pdf','گزارش PDF'],['txt','متن ساده (TXT)']],
  csv:[['xlsx','Excel (XLSX)'],['json','JSON'],['txt','متن ساده (TXT)'],['md','Markdown (MD)'],['pdf','گزارش PDF'],['html','جدول HTML']],
  html:[['txt','متن ساده (TXT)'],['md','Markdown (MD)'],['docx','Word (DOCX)'],['pdf','PDF']],
  htm:[['txt','متن ساده (TXT)'],['md','Markdown (MD)'],['docx','Word (DOCX)'],['pdf','PDF']]
});
function conversionTargets(extension){return CONVERSION_TARGETS[extension]|| (TEXT_EXTENSIONS.has(extension)?[...(extension==='txt'?[]:[['txt','متن ساده (TXT)']]),['pdf','PDF'],...(extension==='md'?[]:[['md','Markdown (MD)']]),['docx','Word (DOCX)'],['pptx','PowerPoint (PPTX)'],['html','صفحه HTML']]:[])}
function cellForExport(value){
  if(value&&typeof value==='object'&&typeof value.formula==='string')return `[فرمول محاسبه‌نشده: ${value.formula}]`;
  return value===null||value===undefined?'':String(value);
}
function safeCsvRows(rows){
  return rows.map(row=>row.map(value=>{
    const text=cellForExport(value);
    // Prevent spreadsheet applications from interpreting exported text as a formula.
    return typeof value==='string'&&(/^[\t\r ]*[=+@]/.test(text)||(/^[\t\r ]*-/.test(text)&&!/^\s*-?(?:\d+\.?\d*|\.\d+)$/.test(text)))?`'${text}`:text;
  }));
}
function ensureTextLimit(value,label='متن سند'){const text=String(value??'');if(text.length>FILE_POLICY.maxTextChars)throw new Error(`${label} از سقف ۵۰۰٬۰۰۰ نویسه بیشتر است؛ سند را به چند فایل تقسیم کن.`);return text}
function tableToText(rows){return ensureTextLimit(rows.map(row=>row.map(cellForExport).join(' | ')).join('\n'),'جدول') }
function workbookToText(sheets){return ensureTextLimit(sheets.map(sheet=>`برگه: ${sheet.name}\n${tableToText(sheet.rows)}`).join('\n\n'),'متن کل برگه‌ها')}
function htmlToPlainText(source){
  if(typeof DOMParser!=='undefined'){
    const parsed=new DOMParser().parseFromString(String(source),'text/html');
    for(const node of parsed.querySelectorAll('script,style,noscript,template,svg,canvas,iframe,object,embed'))node.remove();
    return ensureTextLimit((parsed.body?.innerText||parsed.body?.textContent||'').replace(/[\t\u00a0 ]+\n/g,'\n').replace(/\n{3,}/g,'\n\n').trim(),'متن HTML');
  }
  const stripped=String(source).replace(/<(script|style|noscript|template|svg|iframe|object|embed)\b[^>]*>[\s\S]*?<\/\1\s*>/gi,'').replace(/<br\s*\/?>|<\/(?:p|div|h[1-6]|li|tr|section|article)>/gi,'\n').replace(/<[^>]*>/g,' ');
  return ensureTextLimit(stripped.replace(/&nbsp;/gi,' ').replace(/&lt;/gi,'<').replace(/&gt;/gi,'>').replace(/&quot;/gi,'"').replace(/&#39;|&apos;/gi,"'").replace(/&amp;/gi,'&').replace(/[ \t]+\n/g,'\n').replace(/\n{3,}/g,'\n\n').trim(),'متن HTML');
}
function tableToHtml(rows,title){
  const head=rows[0]||[],body=rows.slice(1);
  return `<main><h1>${esc(title)}</h1><div class="table-wrap"><table><thead><tr>${head.map(value=>`<th>${esc(cellForExport(value))}</th>`).join('')}</tr></thead><tbody>${body.map(row=>`<tr>${head.map((_,i)=>`<td>${esc(cellForExport(row[i]))}</td>`).join('')}</tr>`).join('')}</tbody></table></div></main>`;
}

async function readConversionSource(item){
  const ext=item.extension||extensionOf(item.file?.name||'');
  if(ext==='pdf')return {kind:'text',format:ext,text:await extractPdfText(item.file)};
  if(ext==='docx')return {kind:'text',format:ext,text:await readDocx(item.file)};
  if(ext==='pptx')return {kind:'text',format:ext,text:await readPptx(item.file)};
  if(ext==='xlsx'||ext==='xlsm')return {kind:'workbook',format:ext,sheets:await readXlsxWorkbook(item.file)};
  if(ext==='csv')return {kind:'table',format:ext,rows:parseCSV(await item.file.text())};
  if(ext==='html'||ext==='htm')return {kind:'text',format:ext,text:htmlToPlainText(await item.file.text())};
  if(TEXT_EXTENSIONS.has(ext))return {kind:'text',format:ext,text:ensureTextLimit(await item.file.text())};
  throw new Error('تبدیل این نوع فایل در این نسخه پشتیبانی نمی‌شود.');
}
async function convertSelectedFile(item,target){
  const ext=item.extension||extensionOf(item.file?.name||'');
  const allowed=conversionTargets(ext).map(option=>option[0]);
  if(!allowed.includes(target))throw new Error('قالب خروجی انتخاب‌شده برای این فایل مجاز نیست.');
  const originalName=item.file?.name||`sayrox-file.${ext}`;
  const base=safeOutputName(originalName.replace(/\.[^.]+$/,''))||'sayrox-converted';
  const source=await readConversionSource(item);
  let blob,filename,preview='',previewKind='text',warning='';
  if(target==='csv'&&source.kind==='workbook'){
    const sheets=source.sheets,usedCsvNames=new Set();
    const entries=sheets.map((sheet,index)=>{
      const stem=safeOutputName(sheet.name||`Sheet${index+1}`);let name=`${stem}.csv`,suffix=2;
      while(usedCsvNames.has(name.toLocaleLowerCase()))name=`${stem.slice(0,90)}-${suffix++}.csv`;
      usedCsvNames.add(name.toLocaleLowerCase());return {name,text:ensureTextLimit(stringifyCSV(safeCsvRows(sheet.rows)),'خروجی CSV')};
    });
    if(entries.length===1){blob=new Blob([entries[0].text],{type:'text/csv;charset=utf-8'});filename=`${base}.csv`}
    else{blob=await createZip(entries);filename=`${base}-sheets-csv.zip`;warning='هر برگه به یک CSV جدا تبدیل شده است؛ فایل اصلی و فرمول‌ها تغییر نکرده‌اند.'}
    preview=workbookToText(sheets);warning=warning||'فرمول‌ها اجرا نشده‌اند و به‌صورت متنِ توضیحی صادر شده‌اند.';
  }else if(target==='xlsx'&&source.kind==='table'){
    blob=await createXlsx([{name:base,rows:source.rows}]);filename=`${base}.xlsx`;preview=tableToText(source.rows);previewKind='table';
  }else if(target==='json'&&(source.kind==='workbook'||source.kind==='table')){
    const data=source.kind==='workbook'?{sheets:source.sheets}:{rows:source.rows};
    const json=ensureTextLimit(JSON.stringify(data,null,2),'خروجی JSON');
    blob=new Blob([json],{type:'application/json;charset=utf-8'});filename=`${base}.json`;preview=json;
    warning=source.kind==='workbook'?'مقادیر فرمول‌ها به‌صورت metadata ذخیره می‌شوند و محاسبه نمی‌شوند.':'';
  }else{
    let text=source.kind==='workbook'?workbookToText(source.sheets):source.kind==='table'?tableToText(source.rows):source.text;
    if(!String(text||'').trim())throw new Error('محتوای قابل تبدیل پیدا نشد.');
    const markdownSource=source.format==='md'||source.format==='docx';
    const plainText=markdownSource?markdownToPlainText(text):text;
    if(target==='txt'){blob=new Blob([plainText],{type:'text/plain;charset=utf-8'});filename=`${base}.txt`;preview=plainText}
    else if(target==='md'){const markdown=ensureTextLimit(source.kind==='table'?markdownTable(source.rows):source.kind==='workbook'?source.sheets.map(sheet=>`## ${sheet.name}\n\n${markdownTable(sheet.rows)}`).join('\n\n'):text,'خروجی Markdown');blob=new Blob([markdown],{type:'text/markdown;charset=utf-8'});filename=`${base}.md`;preview=markdown;warning='فقط متن و ساختار ساده منتقل می‌شود؛ قالب‌بندی پیچیده، نمودارها و محتوای تصویری حفظ نمی‌شوند.'}
    else if(target==='pdf'){blob=await createTextPdf(plainText,{title:base});filename=`${base}.pdf`;preview=plainText;warning='PDF خروجی تصویرمحور است؛ صفحه‌آرایی، تصاویر، نمودارها و قالب‌بندی اصلی حفظ نمی‌شوند.'}
    else if(target==='docx'){blob=await createDocx(text,{title:base});filename=`${base}.docx`;warning='فقط متن استخراج‌شده منتقل می‌شود؛ تصاویر و صفحه‌آرایی پیچیده‌ی فایل اصلی حفظ نمی‌شوند.'}
    else if(target==='pptx'){blob=await createPptx(text,{title:base});filename=`${base}.pptx`;warning='اسلایدها از متن استخراج‌شده ساخته می‌شوند؛ قالب، تصاویر، انیمیشن و چیدمان اصلی حفظ نمی‌شوند.'}
    else if(target==='html'){
      const html=ensureTextLimit(source.kind==='table'?htmlDocument(tableToHtml(source.rows,base),base):markdownSource?markdownToHtml(text,base):htmlDocument(`<main><h1>${esc(base)}</h1><pre style="white-space:pre-wrap;direction:auto">${esc(text)}</pre></main>`,base),'خروجی HTML');
      blob=new Blob([html],{type:'text/html;charset=utf-8'});filename=`${base}.html`;preview=html;previewKind='html';warning='خروجی HTML جدید از محتوای متنی ساخته شده؛ کد اجرایی فایل مبدأ منتقل نمی‌شود.';
    }else throw new Error('مسیر تبدیل برای این فرمت تعریف نشده است.');
    if(!preview)preview=text;
    if(source.kind==='workbook'&&target!=='json'&&target!=='csv')warning=warning||'برگه‌ها به متن تبدیل شده‌اند؛ فرمول‌ها، نمودارها و قالب‌بندی Excel در خروجی متنی حفظ نمی‌شوند.';
    if(ext==='xlsm')warning=`ماکروها و کدهای VBA در خروجی حفظ یا اجرا نمی‌شوند. ${warning}`.trim();
  }
  if(blob.size>FILE_POLICY.maxFileBytes)throw new Error('حجم فایل خروجی از سقف ۲۰ مگابایت بیشتر است.');
  return {blob,filename,preview,previewKind,warning,sourceExtension:ext,target};
}
function updateConversionTargets(root){
  const sourceSelect=$(root,'[data-convert-source]'),targetSelect=$(root,'[data-convert-target]'),runButton=$(root,'[data-convert-run]');
  if(!sourceSelect||!targetSelect||!runButton)return;
  const item=sessionFiles.find(file=>file.id===sourceSelect.value);
  targetSelect.replaceChildren();
  const targets=item?conversionTargets(item.extension):[];
  for(const [value,label] of targets){const option=document.createElement('option');option.value=value;option.textContent=label;targetSelect.appendChild(option)}
  const sourceBusy=batchRunning;sourceSelect.disabled=sourceBusy;targetSelect.disabled=sourceBusy||!targets.length;runButton.disabled=sourceBusy||!targets.length;
  if(!targets.length){const option=document.createElement('option');option.value='';option.textContent='قالب خروجی موجود نیست';targetSelect.appendChild(option)}
}
function updateConversionSources(root,selectedId){
  const select=$(root,'[data-convert-source]');if(!select)return;
  const previous=selectedId||select.value;select.replaceChildren();
  for(const item of sessionFiles){if(!conversionTargets(item.extension).length)continue;const option=document.createElement('option');option.value=item.id;option.textContent=`${item.file.name} (${item.extension.toUpperCase()})`;select.appendChild(option)}
  if(sessionFiles.some(item=>item.id===previous&&conversionTargets(item.extension).length))select.value=previous;
  updateConversionTargets(root);
}
function selectConversionSource(root,item){
  updateConversionSources(root,item.id);
  const panel=$(root,'[data-conversion-panel]');panel?.scrollIntoView({behavior:'smooth',block:'center'});
  addNotice(root,'فایل مبدا انتخاب شد؛ قالب خروجی را مشخص کن.','info');
}
async function runConversion(root){
  if(batchRunning)return;
  const sourceId=$(root,'[data-convert-source]').value,target=$(root,'[data-convert-target]').value,item=sessionFiles.find(file=>file.id===sourceId),button=$(root,'[data-convert-run]');
  if(!item||!target){addNotice(root,'ابتدا فایل مبدا و قالب خروجی را انتخاب کن.','error');return}
  button.disabled=true;addNotice(root,'در حال تبدیل فایل در همین مرورگر…','info');
  try{
    const result=await convertSelectedFile(item,target);download(result.blob,result.filename,true);
    if(result.previewKind==='html')previewHtml(root,result.preview);else if(result.previewKind==='table'&&item.extension==='csv')showTable(root,parseCSV(await item.file.text()),'پیش‌نمایش محتوای تبدیل‌شده');else showText(root,result.preview,`پیش‌نمایش تبدیل · ${result.filename}`);
    addNotice(root,`تبدیل انجام شد و دانلود ${result.filename} آغاز شد. ${result.warning||'محتوای فایل در دستگاه شما پردازش شد.'}`,'success');
  }catch(error){const scan=/اسکن|OCR|تصویرمحور/i.test(error.message);addNotice(root,scan?`${error.message} ابتدا از دکمه‌ی OCR فارسی/انگلیسی روی فایل استفاده کن.`:error.message,'error')}
  finally{button.disabled=false;updateConversionTargets(root)}
}

function commonConversionTargets(items){
  if(!Array.isArray(items)||!items.length)return [];
  const first=conversionTargets(items[0].extension).map(([extension,label])=>({extension,label}));
  return first.filter(target=>items.every(item=>conversionTargets(item.extension).some(([extension])=>extension===target.extension)));
}
function uniqueBatchName(name,used){
  const clean=safeOutputName(name),dot=clean.lastIndexOf('.'),stem=dot>0?clean.slice(0,dot):clean,ext=dot>0?clean.slice(dot):'';
  let candidate=clean,index=2;
  while(used.has(candidate.toLocaleLowerCase()))candidate=`${stem}-${index++}${ext}`;
  used.add(candidate.toLocaleLowerCase());return candidate;
}
async function convertBatchFiles(items,target,{onProgress=()=>{},shouldCancel=()=>false}={}){
  if(!Array.isArray(items)||!items.length)throw new Error('برای تبدیل گروهی دست‌کم یک فایل انتخاب کن.');
  if(items.length>FILE_POLICY.maxBatchConvertFiles)throw new Error(`در هر نوبت حداکثر ${FILE_POLICY.maxBatchConvertFiles} فایل قابل تبدیل است.`);
  let totalInputBytes=0;
  for(const item of items){const info=validateFile(item?.file,{batchBytes:totalInputBytes});if(item.extension&&item.extension!==info.extension)throw new Error('پسوند ثبت‌شده‌ی فایل با نام واقعی آن مطابقت ندارد.');totalInputBytes+=item.file.size;}
  if(!commonConversionTargets(items).some(option=>option.extension===target))throw new Error('قالب انتخاب‌شده برای همه‌ی فایل‌های صف مشترک و سازگار نیست.');
  const entries=[],failures=[],usedNames=new Set();let outputBytes=0,cancelled=false;
  for(let index=0;index<items.length;index++){
    const item=items[index];
    if(shouldCancel()){cancelled=true;break}
    let fileFailed=false;
    try{
      onProgress({index:index+1,total:items.length,file:item.file.name,status:'در حال تبدیل'});
      const result=await convertSelectedFile(item,target);
      const bytes=new Uint8Array(await result.blob.arrayBuffer());
      if(outputBytes+bytes.byteLength+(entries.length+1)*256>FILE_POLICY.maxZipArchiveBytes)throw new Error('حجم مجموع خروجی‌های ZIP از سقف ۲۰ مگابایت عبور می‌کند.');
      outputBytes+=bytes.byteLength;
      entries.push({name:uniqueBatchName(result.filename,usedNames),bytes,warning:result.warning||''});
    }catch(error){fileFailed=true;failures.push({name:item.file?.name||'فایل بدون نام',message:error.message||'تبدیل ناموفق بود.'})}
    onProgress({index:index+1,total:items.length,file:item.file.name,status:fileFailed?'ناموفق':'پایان'});
    await new Promise(resolve=>setTimeout(resolve,0));
  }
  if(shouldCancel())cancelled=true;
  if(!entries.length)return {blob:null,filename:'',successes:[],failures,cancelled,total:items.length};
  const reportName=uniqueBatchName('sayrox-conversion-report.json',usedNames);
  const report={schemaVersion:1,generatedBy:'SAYROX 19.11.4',target,summary:{requested:items.length,succeeded:entries.length,failed:failures.length,cancelled},successes:entries.map(({name,warning})=>({output:name,warning})),failures};
  const archiveEntries=[...entries.map(({name,bytes})=>({name,bytes})),{name:reportName,text:JSON.stringify(report,null,2)}];
  const blob=await createZip(archiveEntries);
  return {blob,filename:`sayrox-batch-${target}.zip`,successes:entries,failures,cancelled,total:items.length,report};
}
function selectedBatchItems(root){
  const ids=[...$(root,'[data-batch-sources]').querySelectorAll('input[data-batch-source]:checked')].map(input=>input.value);
  return ids.map(id=>sessionFiles.find(item=>item.id===id)).filter(Boolean);
}
function updateBatchTargets(root){
  const sourceList=$(root,'[data-batch-sources]'),targetSelect=$(root,'[data-batch-target]'),runButton=$(root,'[data-batch-run]');
  if(!sourceList||!targetSelect||!runButton)return;
  const selected=selectedBatchItems(root),targets=commonConversionTargets(selected),previous=targetSelect.value;
  targetSelect.replaceChildren();
  for(const target of targets){const option=document.createElement('option');option.value=target.extension;option.textContent=target.label;targetSelect.appendChild(option)}
  if(targets.some(target=>target.extension===previous))targetSelect.value=previous;
  else if(targets.length)targetSelect.value=targets[0].extension;
  const tooMany=selected.length>FILE_POLICY.maxBatchConvertFiles;
  const totalBytes=selected.reduce((sum,item)=>sum+item.file.size,0),tooLarge=totalBytes>FILE_POLICY.maxBatchBytes;
  if(!targets.length){const option=document.createElement('option');option.value='';option.textContent='قالب مشترکی وجود ندارد';targetSelect.appendChild(option)}
  targetSelect.disabled=batchRunning||!targets.length;
  runButton.disabled=batchRunning||!selected.length||!targets.length||tooMany||tooLarge;
  const hint=$(root,'[data-batch-selection-hint]');
  if(hint)hint.textContent=tooMany?`حداکثر ${FILE_POLICY.maxBatchConvertFiles} فایل را انتخاب کن.`:tooLarge?'حجم مجموع فایل‌ها بیش از حد مجاز است.':!selected.length?'فایل‌های موردنظر را انتخاب کن.':!targets.length?'این فایل‌ها قالب خروجی مشترکی ندارند؛ ترکیب دیگری انتخاب کن.':`${selected.length} فایل انتخاب شده · ${(totalBytes/1024/1024).toFixed(1)} مگابایت`;
}
function updateBatchSources(root){
  const list=$(root,'[data-batch-sources]');if(!list)return;
  const previous=new Set([...list.querySelectorAll('input[data-batch-source]:checked')].map(input=>input.value));
  list.replaceChildren();
  const eligible=sessionFiles.filter(item=>conversionTargets(item.extension).length);
  const defaultSelected=[];
  if(!batchSelectionInitialized){for(const item of eligible){if(defaultSelected.length>=FILE_POLICY.maxBatchConvertFiles)break;if(!defaultSelected.length||commonConversionTargets([...defaultSelected,item]).length)defaultSelected.push(item)}batchSelectionInitialized=true}
  eligible.forEach(item=>{
    const label=document.createElement('label');label.className='fs-batch-file';
    const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.dataset.batchSource='';checkbox.value=item.id;checkbox.checked=previous.has(item.id)||defaultSelected.some(selected=>selected.id===item.id);checkbox.disabled=batchRunning;
    const name=document.createElement('span');name.textContent=item.file.name;
    const meta=document.createElement('small');meta.textContent=`${item.extension.toUpperCase()} · ${(item.file.size/1024).toFixed(1)} KB`;
    label.append(checkbox,name,meta);list.appendChild(label);
  });
  if(!eligible.length){const empty=document.createElement('p');empty.className='fs-hint';empty.textContent='برای صف گروهی، ابتدا چند فایل با قالب‌های پشتیبانی‌شده اضافه کن.';list.appendChild(empty)}
  updateBatchTargets(root);
}
async function runBatchConversion(root){
  if(batchRunning)return;
  const items=selectedBatchItems(root),target=$(root,'[data-batch-target]').value;
  if(!items.length||!target){addNotice(root,'فایل‌ها و قالب خروجی صف را انتخاب کن.','error');return}
  batchRunning=true;batchCancelRequested=false;
  const runButton=$(root,'[data-batch-run]'),cancelButton=$(root,'[data-batch-cancel]'),progress=$(root,'[data-batch-progress]'),summary=$(root,'[data-batch-status]');
  progress.value=0;progress.max=items.length;
  const lockedControls=[...root.querySelectorAll('button,select,input,textarea')];
  for(const control of lockedControls){control.dataset.batchDisabledBefore=control.disabled?'1':'0';control.disabled=true}
  cancelButton.disabled=false;
  updateBatchTargets(root);updateConversionTargets(root);
  try{
    const result=await convertBatchFiles(items,target,{
      shouldCancel:()=>batchCancelRequested,
      onProgress:event=>{progress.value=Math.min(items.length,event.index);summary.textContent=`${event.status}: ${event.file} · ${event.index} از ${event.total}`}
    });
    if(result.blob){download(result.blob,result.filename,true);const warnings=result.successes.filter(file=>file.warning).map(file=>`${file.name}: ${file.warning}`);addNotice(root,`صف تبدیل تمام شد: ${result.successes.length} موفق، ${result.failures.length} ناموفق${result.cancelled?'؛ صف به درخواست شما متوقف شد':''}. فایل‌های موفق در یک ZIP دانلود می‌شوند.${warnings.length?` محدودیت خروجی: ${warnings.join(' | ')}`:''}`,'success')}
    else addNotice(root,result.cancelled?'صف تبدیل متوقف شد و فایلی خروجی نشد.':'هیچ فایلی با موفقیت تبدیل نشد. خطاها را در وضعیت صف بررسی کن.','error');
    summary.textContent=`${result.successes.length} موفق · ${result.failures.length} ناموفق${result.cancelled?' · متوقف‌شده':''}${result.failures.length?` · ${result.failures.map(failure=>`${failure.name}: ${failure.message}`).join(' | ')}`:''}${result.successes.some(file=>file.warning)?` · محدودیت: ${result.successes.filter(file=>file.warning).map(file=>`${file.name}: ${file.warning}`).join(' | ')}`:''}`;
  }catch(error){addNotice(root,error.message,'error');summary.textContent=error.message}
  finally{
    batchRunning=false;batchCancelRequested=false;
    for(const control of lockedControls){control.disabled=control.dataset.batchDisabledBefore==='1';delete control.dataset.batchDisabledBefore}
    updateBatchTargets(root);updateConversionTargets(root);
  }
}
async function createWord(root){try{const title=$(root,'[data-title]').value||'sayrox-document';const blob=await createDocx($(root,'[data-editor]').value,{title});download(blob,`${safeOutputName(title)}.docx`,true);addNotice(root,'فایل Word استاندارد ساخته و آماده‌ی دانلود شد.','success')}catch(error){addNotice(root,error.message,'error')}}
async function createPowerPoint(root){try{const title=$(root,'[data-title]').value||'sayrox-presentation';const blob=await createPptx($(root,'[data-editor]').value,{title});download(blob,`${safeOutputName(title)}.pptx`,true);addNotice(root,'فایل PowerPoint ساخته شد. هر بخش جداگانه به اسلاید تبدیل می‌شود.','success')}catch(error){addNotice(root,error.message,'error')}}
function makeWorkbookTemplate(root){$(root,'[data-title]').value='sayrox-workbook';$(root,'[data-editor]').value=JSON.stringify({فروش:{rows:[['ماه','مبلغ'],['مهر',120],['آبان',180],['آذر',220]],chart:{type:'bar',title:'فروش ماهانه',categoryColumn:0,seriesColumns:[1]}},مشتریان:{rows:[['نام','وضعیت'],['علی','فعال'],['مینا','جدید']]}},null,2);addNotice(root,'قالب چندبرگه‌ای Excel آماده شد؛ برگه‌ی فروش همراه نمودار ستونی است.','success')}
async function createWorkbookFromJson(root){try{const input=JSON.parse($(root,'[data-editor]').value);let sheets;if(Array.isArray(input)){sheets=input.length&&input.every(item=>item&&typeof item==='object'&&!Array.isArray(item)&&Array.isArray(item.rows))?input:[{name:$(root,'[data-title]').value||'Sheet1',rows:input}]}else if(input&&typeof input==='object')sheets=Object.entries(input).map(([name,value])=>({name,rows:Array.isArray(value)?value:value?.rows,chart:value?.chart}));else throw new Error('ساختار JSON باید شیء نام برگه به آرایه‌ی ردیف‌ها باشد.');const blob=await createXlsx({sheets});download(blob,`${safeOutputName($(root,'[data-title]').value||'sayrox-workbook')}.xlsx`,true);addNotice(root,`فایل Excel چندبرگه‌ای با ${sheets.length} برگه ساخته شد.`,'success');showWorkbook(root,sheets.map((sheet,index)=>({name:sheet.name||`Sheet${index+1}`,rows:sheet.rows}))) }catch(error){addNotice(root,`ساخت Excel چندبرگه‌ای ناموفق بود: ${error.message}`,'error')}}

async function exportSelectedZip(root){
  try{if(!sessionFiles.length)throw new Error('ابتدا فایل انتخاب کن.');const entries=[];for(const item of sessionFiles)entries.push({name:item.file.name,bytes:new Uint8Array(await item.file.arrayBuffer())});const blob=await createZip(entries);download(blob,'sayrox-files.zip',true);const preview=$(root,'[data-preview]');preview.replaceChildren();const heading=document.createElement('h3');heading.textContent='آرشیو ZIP آماده است';preview.appendChild(heading);appendLocalDownloadLink(root,preview,blob,'sayrox-files.zip');addNotice(root,`آرشیو ZIP با ${entries.length} فایل ساخته شد و لینک محلی دریافت هم در صفحه قرار گرفت.`,'success')}catch(error){addNotice(root,error.message,'error')}
}
async function extractZip(root){
  const item=sessionFiles.find(file=>file.extension==='zip');if(!item){addNotice(root,'ابتدا یک فایل ZIP انتخاب کن.','error');return}
  try{
    addNotice(root,'در حال بررسی فهرست و ساختار امن آرشیو…');
    const entries=await readZip(item.file,{extract:false});
    if(!entries.length)throw new Error('فایل قابل استخراجی در این آرشیو پیدا نشد.');
    const preview=$(root,'[data-preview]');preview.replaceChildren();
    const heading=document.createElement('h3');heading.textContent=`محتوای آرشیو · ${entries.length} فایل`;preview.appendChild(heading);
    const note=document.createElement('p');note.className='fs-hint';note.textContent='ابتدا فهرست بررسی می‌شود؛ داده‌ی هر فایل فقط هنگام انتخاب و دانلود استخراج خواهد شد. مسیرهای خطرناک، پیوندهای نمادین و آرشیوهای بیش‌ازحد حجیم رد می‌شوند.';preview.appendChild(note);
    const controls=document.createElement('div');controls.className='fs-zip-controls';
    const count=document.createElement('span');count.className='fs-zip-selected-count';
    const selectAll=document.createElement('button');selectAll.type='button';selectAll.className='secondary-btn';selectAll.textContent='انتخاب همه';
    const clearAll=document.createElement('button');clearAll.type='button';clearAll.className='secondary-btn';clearAll.textContent='پاک‌کردن انتخاب';
    const exportSelected=document.createElement('button');exportSelected.type='button';exportSelected.className='primary-btn';exportSelected.textContent='دانلود انتخاب‌ها به‌صورت ZIP';
    controls.append(count,selectAll,clearAll,exportSelected);preview.appendChild(controls);
    const list=document.createElement('div');list.className='fs-zip-entry-list';preview.appendChild(list);
    const checkboxes=[];
    const updateCount=()=>{const chosen=checkboxes.filter(input=>input.checked).length;count.textContent=`${chosen.toLocaleString('fa-IR')} از ${entries.length.toLocaleString('fa-IR')} فایل انتخاب شده` ;exportSelected.disabled=chosen===0};
    for(const entry of entries){
      const row=document.createElement('div');row.className='fs-file fs-zip-entry';
      const checkbox=document.createElement('input');checkbox.type='checkbox';checkbox.className='fs-zip-entry-check';checkbox.checked=false;checkbox.setAttribute('aria-label',`انتخاب ${entry.name}`);checkbox.addEventListener('change',updateCount);checkboxes.push(checkbox);
      const meta=document.createElement('div');meta.className='fs-file-meta';
      const name=document.createElement('strong');name.textContent=entry.name;
      const ratio=Number.isFinite(entry.compressionRatio)?` · نسبت ${entry.compressionRatio.toFixed(1)}×`:'';
      const info=document.createElement('small');info.textContent=`${entry.uncompressedSize.toLocaleString('fa-IR')} بایت · ${entry.compressedSize.toLocaleString('fa-IR')} بایت فشرده${ratio}`;
      meta.append(name,info);
      const actions=document.createElement('div');actions.className='fs-file-actions';
      const downloadButton=document.createElement('button');downloadButton.type='button';downloadButton.className='secondary-btn';downloadButton.textContent='دانلود';
      downloadButton.addEventListener('click',async()=>{
        downloadButton.disabled=true;
        try{const result=await readZip(item.file,{selectedNames:[entry.name]});if(!result.length)throw new Error('فایل انتخاب‌شده استخراج نشد.');download(blobFor(result[0]),entry.name.split('/').pop(),true);addNotice(root,`دانلود ${entry.name} آغاز شد.`,'success')}
        catch(error){addNotice(root,error.message,'error')}
        finally{downloadButton.disabled=false}
      });
      const linkButton=document.createElement('button');linkButton.type='button';linkButton.className='secondary-btn';linkButton.textContent='ساخت لینک محلی';
      linkButton.addEventListener('click',async()=>{
        linkButton.disabled=true;
        try{const result=await readZip(item.file,{selectedNames:[entry.name]});if(!result.length)throw new Error('فایل انتخاب‌شده استخراج نشد.');appendLocalDownloadLink(root,row,blobFor(result[0]),entry.name.split('/').pop());addNotice(root,'لینک دریافت محلی ساخته شد؛ این لینک عمومی نیست.','info')}
        catch(error){addNotice(root,error.message,'error')}
        finally{linkButton.disabled=false}
      });
      actions.append(downloadButton,linkButton);row.append(checkbox,meta,actions);list.appendChild(row);
    }
    selectAll.addEventListener('click',()=>{checkboxes.forEach(input=>input.checked=true);updateCount()});
    clearAll.addEventListener('click',()=>{checkboxes.forEach(input=>input.checked=false);updateCount()});
    exportSelected.addEventListener('click',async()=>{
      const selected=checkboxes.filter(input=>input.checked).map((input,index)=>entries[checkboxes.indexOf(input)]);
      if(!selected.length)return;
      exportSelected.disabled=true;addNotice(root,'در حال استخراج فایل‌های انتخاب‌شده و ساخت ZIP…');
      try{
        const unpacked=await readZip(item.file,{selectedNames:selected.map(entry=>entry.name)});
        const blob=await createZip(unpacked.map(entry=>({name:entry.name,bytes:entry.bytes})));
        const filename=`${safeOutputName(item.file.name.replace(/\.zip$/i,''))}-selected.zip`;
        download(blob,filename,true);
        appendLocalDownloadLink(root,preview,blob,filename);
        addNotice(root,`${unpacked.length} فایل انتخاب‌شده در یک ZIP جدید آماده و دانلود آن آغاز شد. لینک محلی نیز در پایین فهرست قرار گرفت.`,'success');
      }catch(error){addNotice(root,error.message,'error')}
      finally{updateCount()}
    });
    updateCount();
    addNotice(root,`فهرست ${entries.length} فایل خوانده شد. برای دانلود تکی یا ساخت ZIP از فایل‌های انتخابی، گزینه‌ی همان فایل‌ها را بزن.`,'success');
  }catch(error){addNotice(root,error.message,'error')}
}
function makeTemplate(root){$(root,'[data-title]').value='sayrox-page';$(root,'[data-editor]').value='<!doctype html>\n<html lang="fa" dir="rtl">\n<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>صفحه‌ی من</title></head>\n<body>\n  <main><h1>سلام از SAYROX</h1><p>صفحه‌ی HTML من آماده است.</p></main>\n</body>\n</html>';addNotice(root,'قالب HTML آماده شد؛ می‌توانی آن را ویرایش و پیش‌نمایش کنی.','success')}

function render(root){
  revokeUrls();batchSelectionInitialized=false;activeStudioRoot=root;
  root.innerHTML=`<section class="file-studio">
    <div class="fs-hero"><div class="fs-mark">X</div><div><h2>استودیو فایل SAYROX</h2><p>ساخت و تبدیل فایل روی دستگاه شما؛ بدون ارسال فایل‌ها به سرور.</p></div></div>
    <div class="fs-security"><strong>حریم خصوصی و ایمنی</strong><span>فایل‌ها در کتابخانهٔ محلی همین مرورگر نگهداری می‌شوند؛ سقف هر فایل ۲۰ مگابایت، کل کتابخانه ۱۰۰ مگابایت و استخراج ZIP حداکثر ۵۰ مگابایت است.</span></div>
    <div class="fs-section-head"><div><h3>فایل‌های انتخاب‌شده</h3><p>تصویر، PDF، DOCX، PPTX، XLSX، ZIP، CSV، متن و کد</p></div><button type="button" class="primary-btn" data-pick>انتخاب فایل</button></div>
    <input data-input type="file" multiple hidden accept=".jpg,.jpeg,.png,.webp,.gif,.pdf,.zip,.xlsx,.xlsm,.docx,.pptx,.csv,.txt,.md,.json,.xml,.html,.htm,.css,.js,.mjs,.ts,.tsx,.jsx,.py,.java,.c,.cpp,.h,.cs,.php,.rb,.go,.rs,.sql,.yaml,.yml">
    <div class="fs-file-list" data-file-list></div>
    <div class="fs-conversion-panel" data-conversion-panel><div><strong>تبدیل فایل انتخاب‌شده</strong><p>فایل مبدا را از فهرست بالا انتخاب کن یا دکمه‌ی «تبدیل» کنار همان فایل را بزن.</p></div><div class="fs-conversion-controls"><label class="fs-label">فایل مبدا<select data-convert-source></select></label><label class="fs-label">قالب خروجی<select data-convert-target></select></label><button type="button" class="primary-btn" data-convert-run disabled>تبدیل و دریافت فایل</button></div><p class="fs-hint">تبدیل‌ها محلی هستند. Markdown به HTML ساختاریافته تبدیل می‌شود؛ جدول‌های CSV و Excel می‌توانند به Markdown خروجی بگیرند. هنگام تبدیل PDF و Office فقط متن قابل استخراج منتقل می‌شود؛ حفظ کامل صفحه‌آرایی، تصاویر، نمودارها یا انیمیشن تضمین نمی‌شود. فایل‌های اصلی هرگز بازنویسی نمی‌شوند.</p></div>
    <div class="fs-batch-panel" data-batch-panel><div class="fs-batch-heading"><strong>صف تبدیل گروهی</strong><p>چند فایل را انتخاب کن؛ SAYROX فقط قالب‌هایی را نشان می‌دهد که برای همه‌ی فایل‌های انتخابی پشتیبانی می‌شوند.</p></div><div class="fs-batch-sources" data-batch-sources aria-label="انتخاب فایل‌ها برای تبدیل گروهی"></div><div class="fs-batch-controls"><label class="fs-label">قالب خروجی مشترک<select data-batch-target disabled><option value="">ابتدا فایل انتخاب کن</option></select></label><button type="button" class="primary-btn" data-batch-run disabled>تبدیل گروهی و دریافت ZIP</button><button type="button" class="secondary-btn" data-batch-cancel disabled>توقف بعد از فایل جاری</button></div><p class="fs-hint" data-batch-selection-hint>حداکثر ۱۰ فایل در هر نوبت؛ خروجی ZIP حداکثر ۲۰ مگابایت.</p><progress class="fs-batch-progress" data-batch-progress max="1" value="0" aria-label="پیشرفت تبدیل گروهی"></progress><div class="fs-batch-status" data-batch-status role="status" aria-live="polite">آماده‌ی تبدیل گروهی؛ فایل‌های اصلی تغییر نمی‌کنند.</div></div>
    <div class="fs-section-head"><div><h3>ساخت فایل جدید</h3><p>یکی از ابزارها را انتخاب کن</p></div></div>
    <label class="fs-label">نام فایل خروجی<input data-title maxlength="80" value="sayrox-document" placeholder="نام فایل"></label>
    <label class="fs-label">متن، داده یا کد<textarea data-editor rows="9" spellcheck="false" placeholder="متن برای PDF / Word، بخش‌های ارائه با یک خط خالی، CSV یا JSON چندبرگه‌ای Excel…"></textarea></label>
    <p class="fs-hint">برای Word و PowerPoint از Markdown ساده استفاده کن: # عنوان، **متن پررنگ**، - فهرست و خط خالی برای جداکردن بخش‌ها. برای Excel چندبرگه‌ای، داده‌ها را به‌شکل JSON وارد کن؛ هر کلید نام یک برگه است و می‌تواند rows و chart داشته باشد.</p>
    <div class="fs-actions">
      <button type="button" class="secondary-btn" data-pdf>ساخت PDF از متن</button>
      <button type="button" class="secondary-btn" data-docx>ساخت Word (DOCX)</button>
      <button type="button" class="secondary-btn" data-pptx>ساخت PowerPoint (PPTX)</button>
      <button type="button" class="secondary-btn" data-html>ساخت HTML</button>
      <button type="button" class="secondary-btn" data-template>قالب HTML</button>
      <label class="fs-label fs-inline-select">نمودار CSV به Excel<select data-chart-type><option value="none">بدون نمودار</option><option value="bar">ستونی</option><option value="line">خطی</option><option value="pie">دایره‌ای</option></select></label>
      <button type="button" class="secondary-btn" data-xlsx>ساخت Excel از CSV</button>
      <button type="button" class="secondary-btn" data-xlsx-template>قالب چندبرگه‌ای</button>
      <button type="button" class="secondary-btn" data-xlsx-multi>ساخت Excel چندبرگه‌ای از JSON</button>
      <button type="button" class="secondary-btn" data-zip>فشرده‌سازی ZIP</button>
      <button type="button" class="secondary-btn" data-unzip>استخراج ZIP</button>
    </div>
    <div class="fs-status" data-status role="status" aria-live="polite">آماده. برای شروع، فایل انتخاب کن یا از کادر بالا یک خروجی بساز.</div>
    <div class="fs-preview" data-preview aria-live="polite"></div>
    <div class="fs-footer">OCR PDF پس از تأیید شما، موتورهای PDF.js و Tesseract.js و مدل‌های فارسی/انگلیسی را از CDN بارگیری می‌کند؛ سند محلی می‌ماند و آپلود نمی‌شود. PDF.js برای رندر صفحه و Tesseract.js برای OCR استفاده می‌شوند. ساخت Word از Markdown با عنوان، فهرست و سبک متن؛ PowerPoint با فهرست‌های واقعی؛ Excel چندبرگه‌ای با نمودار ستونی، خطی و دایره‌ای. فایل‌ها در مرورگر پردازش می‌شوند؛ فرمول‌های Excel اجرا یا محاسبه نمی‌شوند.</div>
  </section>`;
  const input=$(root,'[data-input]');$(root,'[data-pick]').addEventListener('click',()=>input.click());
  input.addEventListener('change',async()=>{try{const added=await addSessionFiles([...input.files]);renderFileList(root);addNotice(root,`${added.length} فایل به کتابخانهٔ محلی اضافه شد.`,'success')}catch(error){addNotice(root,error.message,'error')}finally{input.value=''}});
  $(root,'[data-convert-source]').addEventListener('change',()=>updateConversionTargets(root));
  $(root,'[data-convert-run]').addEventListener('click',()=>runConversion(root));
  $(root,'[data-batch-sources]').addEventListener('change',()=>updateBatchTargets(root));
  $(root,'[data-batch-run]').addEventListener('click',()=>runBatchConversion(root));
  $(root,'[data-batch-cancel]').addEventListener('click',()=>{batchCancelRequested=true;$(root,'[data-batch-cancel]').disabled=true;$(root,'[data-batch-status]').textContent='درخواست توقف ثبت شد؛ فایل جاری تکمیل می‌شود.'});
  $(root,'[data-pdf]').addEventListener('click',()=>textToPdf(root));
  $(root,'[data-docx]').addEventListener('click',()=>createWord(root));
  $(root,'[data-pptx]').addEventListener('click',()=>createPowerPoint(root));
  $(root,'[data-html]').addEventListener('click',()=>createHtml(root));
  $(root,'[data-template]').addEventListener('click',()=>makeTemplate(root));
  $(root,'[data-xlsx]').addEventListener('click',()=>csvToXlsx(root));
  $(root,'[data-xlsx-template]').addEventListener('click',()=>makeWorkbookTemplate(root));
  $(root,'[data-xlsx-multi]').addEventListener('click',()=>createWorkbookFromJson(root));
  $(root,'[data-zip]').addEventListener('click',()=>exportSelectedZip(root));
  $(root,'[data-unzip]').addEventListener('click',()=>extractZip(root));
  renderFileList(root);
  updateBatchSources(root);
  loadLibraryFiles(root);
}

const SayroxFileTools=Object.freeze({parseCSV,stringifyCSV,createXlsx,readXlsx:readXlsxWorkbook,createZip,readZip,createTextPdf,extractPdfText,recognizePdf,createDocx,readDocx,createPptx,readPptx,conversionTargets,convertSelectedFile,commonConversionTargets,convertBatchFiles,safeCsvRows,htmlToPlainText,markdownToHtml,markdownTable,policy:FILE_POLICY});

window.SayroxFileStudio=Object.freeze({render,openFile:id=>{nextOpenFileId=String(id)},tools:SayroxFileTools});

})();
