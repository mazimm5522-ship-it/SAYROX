(function SayroxFileModule(){
'use strict';
const {FILE_POLICY,assertSafeArchivePath,safeOutputName}=window.SayroxFilePolicy;

const encoder=new TextEncoder();
const decoder=new TextDecoder('utf-8',{fatal:true});
const CRC_TABLE=(()=>{
  const table=new Uint32Array(256);
  for(let n=0;n<256;n++){
    let value=n;
    for(let bit=0;bit<8;bit++)value=(value&1)?(0xedb88320^(value>>>1)):(value>>>1);
    table[n]=value>>>0;
  }
  return table;
})();
function crc32(bytes){let value=0xffffffff;for(const byte of bytes)value=CRC_TABLE[(value^byte)&0xff]^(value>>>8);return(value^0xffffffff)>>>0}
function u16(value){return[value&255,(value>>>8)&255]}
function u32(value){return[value&255,(value>>>8)&255,(value>>>16)&255,(value>>>24)&255]}
function concat(parts){const length=parts.reduce((sum,part)=>sum+part.length,0);const result=new Uint8Array(length);let offset=0;for(const part of parts){result.set(part,offset);offset+=part.length}return result}
function dosDateTime(date=new Date()){
  const year=Math.min(2107,Math.max(1980,date.getFullYear()));
  return{time:(date.getHours()<<11)|(date.getMinutes()<<5)|Math.floor(date.getSeconds()/2),date:((year-1980)<<9)|((date.getMonth()+1)<<5)|date.getDate()};
}
function normalizeCreatePath(value){
  const raw=String(value||'').replace(/\\/g,'/');
  assertSafeArchivePath(raw);
  const path=raw.split('/').map(part=>safeOutputName(part)).join('/');
  return assertSafeArchivePath(path);
}

/** Creates a bounded, UTF-8 ZIP archive using STORE (no compression dependency). */
async function createZip(entries){
  if(!Array.isArray(entries)||!entries.length)throw new Error('برای ساخت ZIP دست‌کم یک فایل لازم است.');
  if(entries.length>FILE_POLICY.maxZipEntries)throw new Error(`تعداد فایل‌های ZIP نباید از ${FILE_POLICY.maxZipEntries} مورد بیشتر باشد.`);
  const local=[],central=[],names=new Set();let offset=0,total=0;
  for(const entry of entries){
    if(!entry||typeof entry!=='object')throw new TypeError('یکی از ورودی‌های ZIP معتبر نیست.');
    const name=normalizeCreatePath(entry.path||entry.name||'file.bin');
    const key=name.normalize('NFKC').toLocaleLowerCase('en-US');
    if(names.has(key))throw new Error(`نام تکراری در ZIP مجاز نیست: ${name}`);
    names.add(key);
    const nameBytes=encoder.encode(name);
    if(!nameBytes.length||nameBytes.length>1024)throw new Error('مسیر فایل در ZIP باید بین ۱ تا ۱٬۰۲۴ بایت باشد.');
    let data;
    if(entry.bytes instanceof Uint8Array)data=entry.bytes;
    else if(entry.bytes instanceof ArrayBuffer)data=new Uint8Array(entry.bytes);
    else if(typeof entry.text==='string'||entry.text===undefined)data=encoder.encode(String(entry.text??''));
    else throw new TypeError(`محتوای فایل ${name} معتبر نیست.`);
    total+=data.byteLength;
    if(total>FILE_POLICY.maxZipArchiveBytes)throw new Error('حجم داده‌های ZIP ساخته‌شده نباید از ۲۰ مگابایت بیشتر باشد.');
    const crc=crc32(data),stamp=dosDateTime(entry.date instanceof Date?entry.date:new Date());
    const header=new Uint8Array([
      ...u32(0x04034b50),...u16(20),...u16(0x0800),...u16(0),...u16(stamp.time),...u16(stamp.date),
      ...u32(crc),...u32(data.length),...u32(data.length),...u16(nameBytes.length),...u16(0)
    ]);
    const localPart=concat([header,nameBytes,data]);
    local.push(localPart);
    const centralHeader=new Uint8Array([
      ...u32(0x02014b50),...u16(20),...u16(20),...u16(0x0800),...u16(0),...u16(stamp.time),...u16(stamp.date),
      ...u32(crc),...u32(data.length),...u32(data.length),...u16(nameBytes.length),...u16(0),...u16(0),...u16(0),...u16(0),...u32(0),...u32(offset)
    ]);
    central.push(concat([centralHeader,nameBytes]));
    offset+=localPart.length;
  }
  const centralBytes=concat(central),centralOffset=offset;
  const end=new Uint8Array([...u32(0x06054b50),...u16(0),...u16(0),...u16(entries.length),...u16(entries.length),...u32(centralBytes.length),...u32(centralOffset),...u16(0)]);
  const archiveSize=centralOffset+centralBytes.length+end.length;
  if(archiveSize>FILE_POLICY.maxZipArchiveBytes)throw new Error('حجم نهایی آرشیو ZIP با احتساب سربار ساختار نباید از ۲۰ مگابایت بیشتر باشد.');
  return new Blob([concat([...local,centralBytes,end])],{type:'application/zip'});
}

function readU16(bytes,offset){return bytes[offset]|(bytes[offset+1]<<8)}
function readU32(bytes,offset){return(bytes[offset]|(bytes[offset+1]<<8)|(bytes[offset+2]<<16)|(bytes[offset+3]<<24))>>>0}
function findEOCD(bytes){
  const start=Math.max(0,bytes.length-65557);
  for(let offset=bytes.length-22;offset>=start;offset--){
    if(readU32(bytes,offset)!==0x06054b50)continue;
    const commentLength=readU16(bytes,offset+20);
    if(offset+22+commentLength===bytes.length)return offset;
  }
  throw new Error('ساختار پایان ZIP پیدا نشد یا آرشیو ناقص است.');
}
function decodeName(bytes,flags){
  if(flags&0x0800)return decoder.decode(bytes);
  if(bytes.some(byte=>byte>0x7f))throw new Error('نام فایل‌های غیراستاندارد با کدگذاری قدیمی در این نسخه پشتیبانی نمی‌شوند.');
  return String.fromCharCode(...bytes);
}
async function inflateRaw(data,maxOutputBytes=FILE_POLICY.maxExpandedBytes){
  if(typeof DecompressionStream!=='function')throw new Error('استخراج ZIP فشرده در این مرورگر پشتیبانی نمی‌شود؛ ZIP بدون فشرده‌سازی قابل‌خواندن است.');
  let stream;
  try{stream=new Blob([data]).stream().pipeThrough(new DecompressionStream('deflate-raw'))}
  catch{throw new Error('مرورگر از الگوریتم استخراج این ZIP پشتیبانی نمی‌کند.');}
  const reader=stream.getReader(),chunks=[];let total=0;
  try{
    while(true){
      const{done,value}=await reader.read();if(done)break;
      total+=value.byteLength;
      if(total>maxOutputBytes){await reader.cancel();throw new Error('حجم واقعی استخراج ZIP از سقف مجاز عبور می‌کند؛ آرشیو احتمالاً مخرب است.');}
      chunks.push(value);
    }
  }finally{reader.releaseLock?.()}
  const result=new Uint8Array(total);let offset=0;for(const chunk of chunks){result.set(chunk,offset);offset+=chunk.length}return result;
}
function validateSelection(selectedNames,entries){
  if(selectedNames===null||selectedNames===undefined)return null;
  if(!Array.isArray(selectedNames)||!selectedNames.length)throw new Error('برای استخراج انتخابی، دست‌کم یک فایل باید انتخاب شود.');
  if(selectedNames.length>FILE_POLICY.maxZipEntries)throw new Error('تعداد فایل‌های انتخاب‌شده بیش از سقف مجاز است.');
  const requested=new Set();
  for(const value of selectedNames){
    const name=String(value||'');
    if(name.includes('\\'))throw new Error('مسیر انتخابی ZIP معتبر نیست.');
    assertSafeArchivePath(name);
    const key=name.normalize('NFKC').toLocaleLowerCase('en-US');
    if(requested.has(key))throw new Error('یک فایل در فهرست انتخابی ZIP تکرار شده است.');
    requested.add(key);
  }
  const available=new Set(entries.map(entry=>entry.name.normalize('NFKC').toLocaleLowerCase('en-US')));
  for(const key of requested)if(!available.has(key))throw new Error('یکی از فایل‌های انتخاب‌شده در آرشیو پیدا نشد.');
  return requested;
}

/** Parses metadata first. By default extracts every file; selectedNames limits actual decompression. */
async function readZip(input,{extract=true,selectedNames=null}={}){
  if(!(input instanceof Uint8Array)&&(!input||typeof input.arrayBuffer!=='function'))throw new TypeError('ورودی ZIP معتبر نیست.');
  if(!(input instanceof Uint8Array)&&(!Number.isFinite(input.size)||input.size>FILE_POLICY.maxZipArchiveBytes))throw new Error('حجم فایل ZIP نباید از ۲۰ مگابایت بیشتر باشد.');
  const bytes=input instanceof Uint8Array?input:new Uint8Array(await input.arrayBuffer());
  if(bytes.length>FILE_POLICY.maxZipArchiveBytes)throw new Error('حجم آرشیو ZIP نباید از ۲۰ مگابایت بیشتر باشد.');
  if(bytes.length<22)throw new Error('فایل ZIP بیش از حد کوتاه یا خراب است.');
  const end=findEOCD(bytes),disk=readU16(bytes,end+4),centralDisk=readU16(bytes,end+6),diskCount=readU16(bytes,end+8),count=readU16(bytes,end+10),centralSize=readU32(bytes,end+12),centralOffset=readU32(bytes,end+16);
  if(disk!==0||centralDisk!==0||diskCount!==count||count===0xffff||centralOffset===0xffffffff||centralSize===0xffffffff)throw new Error('ZIP چندبخشی یا ZIP64 در این نسخه پشتیبانی نمی‌شود.');
  if(count>FILE_POLICY.maxZipEntries)throw new Error(`تعداد ورودی‌های آرشیو نباید از ${FILE_POLICY.maxZipEntries} مورد بیشتر باشد.`);
  if(centralOffset+centralSize!==end||centralOffset+centralSize>bytes.length)throw new Error('محدوده‌ی فهرست مرکزی ZIP با پایان آرشیو مطابقت ندارد.');
  const entries=[],allEntries=[],names=new Set();let cursor=centralOffset,totalExpanded=0;
  for(let index=0;index<count;index++){
    if(cursor+46>centralOffset+centralSize||readU32(bytes,cursor)!==0x02014b50)throw new Error('فهرست مرکزی ZIP معتبر نیست.');
    const flags=readU16(bytes,cursor+8),method=readU16(bytes,cursor+10),crc=readU32(bytes,cursor+16),compressed=readU32(bytes,cursor+20),expanded=readU32(bytes,cursor+24),nameLength=readU16(bytes,cursor+28),extraLength=readU16(bytes,cursor+30),commentLength=readU16(bytes,cursor+32),externalAttributes=readU32(bytes,cursor+38),localOffset=readU32(bytes,cursor+42);
    if(nameLength===0||nameLength>1024||cursor+46+nameLength+extraLength+commentLength>centralOffset+centralSize)throw new Error('طول یا محدوده‌ی نام یکی از فایل‌های ZIP معتبر نیست.');
    const name=decodeName(bytes.subarray(cursor+46,cursor+46+nameLength),flags);
    cursor+=46+nameLength+extraLength+commentLength;
    if(flags&1)throw new Error('ZIP رمزگذاری‌شده پشتیبانی نمی‌شود.');
    if(flags&~0x0808)throw new Error('پرچم‌های فشرده‌سازی پیشرفته یا رمزگذاری قوی ZIP پشتیبانی نمی‌شوند.');
    if(method!==0&&method!==8)throw new Error(`روش فشرده‌سازی ${method} پشتیبانی نمی‌شود.`);
    if(name.includes('\\'))throw new Error('مسیرهای دارای بک‌اسلش در ZIP مجاز نیستند.');
    const unixType=(externalAttributes>>>16)&0xf000;
    if(unixType&&![0x8000,0x4000].includes(unixType))throw new Error('پیوند نمادین یا فایل ویژه داخل ZIP مجاز نیست.');
    const directory=name.endsWith('/')||unixType===0x4000;
    const safeName=directory?name.slice(0,-1):name;
    assertSafeArchivePath(safeName);
    const key=name.normalize('NFKC').toLocaleLowerCase('en-US');
    if(names.has(key))throw new Error(`نام تکراری در آرشیو ZIP مجاز نیست: ${name}`);
    names.add(key);
    if(directory&&(compressed!==0||expanded!==0))throw new Error('ورودی پوشه در ZIP نباید داده داشته باشد.');
    if(!directory){
      totalExpanded+=expanded;
      if(totalExpanded>FILE_POLICY.maxExpandedBytes)throw new Error('حجم اسمی بازشده‌ی ZIP از سقف ۵۰ مگابایت عبور می‌کند.');
      if(expanded>0&&expanded/Math.max(1,compressed)>FILE_POLICY.maxCompressionRatio)throw new Error('ZIP به‌دلیل نسبت فشرده‌سازی غیرعادی (احتمال ZIP Bomb) رد شد.');
      if(method===0&&compressed!==expanded)throw new Error(`اندازه‌ی داده‌ی بدون فشرده‌سازی معتبر نیست: ${name}`);
    }
    if(localOffset>=centralOffset)throw new Error('موقعیت هدر محلی یکی از فایل‌ها خارج از محدوده است.');
    const record={name,flags,method,crc,compressedSize:compressed,uncompressedSize:expanded,localOffset,compressionRatio:expanded/Math.max(1,compressed),directory};
    allEntries.push(record);
    if(!directory)entries.push(record);
  }
  if(cursor!==centralOffset+centralSize)throw new Error('اندازه‌ی فهرست مرکزی ZIP با ساختار آرشیو مطابقت ندارد.');
  if(!extract)return entries;
  const selection=validateSelection(selectedNames,entries);
  const chosen=selection?entries.filter(entry=>selection.has(entry.name.normalize('NFKC').toLocaleLowerCase('en-US'))):entries;
  const localRecords=new Map(),ranges=[];
  // Validate the local header and byte ranges for every file, even when only one is selected.
  for(const entry of allEntries){
    const offset=entry.localOffset;
    if(offset+30>centralOffset||readU32(bytes,offset)!==0x04034b50)throw new Error('هدر محلی یکی از فایل‌های ZIP معتبر نیست.');
    const localFlags=readU16(bytes,offset+6),localMethod=readU16(bytes,offset+8),localCrc=readU32(bytes,offset+14),localCompressed=readU32(bytes,offset+18),localExpanded=readU32(bytes,offset+22),nameLength=readU16(bytes,offset+26),extraLength=readU16(bytes,offset+28);
    const headerEnd=offset+30+nameLength+extraLength;
    if(headerEnd>centralOffset||nameLength===0||offset+30+nameLength>centralOffset)throw new Error('هدر محلی ZIP خارج از محدوده است.');
    const localName=decodeName(bytes.subarray(offset+30,offset+30+nameLength),localFlags);
    if(localName!==entry.name||localFlags!==entry.flags||localMethod!==entry.method)throw new Error(`مشخصات هدر ZIP با فهرست مرکزی هماهنگ نیست: ${entry.name}`);
    if(!(entry.flags&0x0008)&&(localCrc!==entry.crc||localCompressed!==entry.compressedSize||localExpanded!==entry.uncompressedSize))throw new Error(`اندازه یا CRC هدر محلی با فهرست مرکزی هماهنگ نیست: ${entry.name}`);
    if((entry.flags&0x0008)&&((localCrc&&localCrc!==entry.crc)||(localCompressed&&localCompressed!==entry.compressedSize)||(localExpanded&&localExpanded!==entry.uncompressedSize)))throw new Error(`اطلاعات هدر محلی ZIP متناقض است: ${entry.name}`);
    const dataStart=headerEnd,dataEnd=dataStart+entry.compressedSize;
    if(dataEnd>centralOffset||dataEnd>bytes.length)throw new Error('داده‌ی یکی از فایل‌های ZIP ناقص یا خارج از محدوده است.');
    let recordEnd=dataEnd;
    if(entry.flags&0x0008){
      let descriptor=dataEnd;
      if(descriptor+4<=centralOffset&&readU32(bytes,descriptor)===0x08074b50)descriptor+=4;
      if(descriptor+12>centralOffset||readU32(bytes,descriptor)!==entry.crc||readU32(bytes,descriptor+4)!==entry.compressedSize||readU32(bytes,descriptor+8)!==entry.uncompressedSize)throw new Error(`بخش کنترل صحت فایل ZIP معتبر نیست: ${entry.name}`);
      recordEnd=descriptor+12;
    }
    ranges.push({start:offset,end:recordEnd,name:entry.name});
    localRecords.set(entry.name,{dataStart,dataEnd});
  }
  ranges.sort((a,b)=>a.start-b.start);
  for(let index=1;index<ranges.length;index++)if(ranges[index].start<ranges[index-1].end)throw new Error(`بخش‌های دو فایل در آرشیو ZIP با هم تداخل دارند: ${ranges[index].name}`);
  const output=[];let actualExpanded=0;
  for(const entry of chosen){
    const record=localRecords.get(entry.name),remaining=FILE_POLICY.maxExpandedBytes-actualExpanded;
    const packed=bytes.subarray(record.dataStart,record.dataEnd);
    const data=entry.method===0?packed.slice():await inflateRaw(packed,remaining);
    actualExpanded+=data.length;
    if(actualExpanded>FILE_POLICY.maxExpandedBytes)throw new Error('حجم واقعی استخراج ZIP از سقف ۵۰ مگابایت عبور می‌کند.');
    if(data.length!==entry.uncompressedSize||crc32(data)!==entry.crc)throw new Error(`صحت فایل داخل ZIP تأیید نشد: ${entry.name}`);
    output.push({name:entry.name,bytes:data,size:data.length});
  }
  return output;
}

window.SayroxZip=Object.freeze({crc32,createZip,readZip});
})();
