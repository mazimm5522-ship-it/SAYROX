(function (global) {
  'use strict';
  const Registry = global.SayroxSettingsRegistry;
  const Pages = global.SayroxSettingsPages;
  const Personas = global.SayroxVoicePersonas;
  const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c]));
  function create(options) {
    const state = options.state;
    const adapter = options.adapter || {};
    const el = options.elements;
    const stack = new global.SayroxCore.NavigationStack('settings-home');
    let providers = { chat: false, chatPrimary: null, chatFallback: null, chatPrimaryReady: false, chatFallbackReady: false, gapgpt: null, openrouter: null, search: false, tts: false, payments: false };
    let providerRequest = null;
    const memoryState = { loaded: false, loading: false, enabled: false, items: [], error: '', editingId: null };
    let memoryRequest = null;
    let memoryEpoch = 0;
    const getPersona = () => Personas.get(state.settings.voicePersona || 'ara');
    const getStorageUsage = () => {
      try {
        let bytes = 0;
        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i) || '';
          if (key.startsWith('xynora')) bytes += (key.length + (localStorage.getItem(key) || '').length) * 2;
        }
        return bytes < 1024 * 1024 ? `${Math.max(1, Math.round(bytes / 1024))} KB` : `${(bytes / 1024 / 1024).toFixed(2)} MB`;
      } catch { return 'نامشخص'; }
    };
    function context() {
      return { state, providers: { ...providers }, authReady: Boolean(state.authReady), storageUsage: getStorageUsage(), voicePersonas: Personas.all, voiceKey: getPersona().key, memory: { ...memoryState, items: [...memoryState.items] } };
    }
    function renderList(filter = '') {
      const query = String(filter || '').trim().toLocaleLowerCase('fa');
      el.list.innerHTML = '';
      let count = 0;
      Registry.groups.forEach(group => {
        const matches = group.filter(item => !query || `${item.label} ${item.keywords || ''}`.toLocaleLowerCase('fa').includes(query));
        if (!matches.length) return;
        const section = document.createElement('div');
        section.className = 'settings-group';
        matches.forEach(item => {
          const button = document.createElement('button');
          button.type = 'button'; button.className = 'settings-row';
          button.dataset.settingsKey = item.key;
          const lead = item.avatar ? `<span class="row-avatar">${escape(adapter.userInitials?.() || 'X')}</span>` : (adapter.icon ? adapter.icon(item.icon) : '');
          const extra = item.dynamicExtra === 'name' ? (adapter.userName?.() || 'مهمان') : (item.extra || '');
          const chevron = item.noChevron ? '<span></span>' : '<svg class="chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" aria-hidden="true"><path d="m14.6 5.6-6.4 6.4 6.4 6.4"/></svg>';
          button.innerHTML = `${lead}<span class="row-label">${escape(item.label)}</span><span class="row-extra">${escape(extra)}</span>${chevron}`;
          if (item.accent) button.classList.add('is-accent-row');
          section.appendChild(button); count++;
        });
        el.list.appendChild(section);
      });
      if (!query) {
        const accountButton = document.createElement('button');
        accountButton.type = 'button'; accountButton.className = 'settings-logout';
        accountButton.classList.toggle('is-login', !state.user);
        accountButton.innerHTML = `${global.SayroxIcons.svg(state.user ? 'logout' : 'user')}<span>${state.user ? 'خروج' : 'ورود به حساب'}</span>`;
        accountButton.addEventListener('click', () => adapter.accountAction?.());
        el.list.appendChild(accountButton);
      } else if (!count) {
        const empty = document.createElement('p'); empty.className = 'sx-empty'; empty.textContent = 'تنظیمی با این عبارت پیدا نشد.'; el.list.appendChild(empty);
      }
    }
    function openHome() {
      stack.reset('settings-home');
      el.detail.classList.remove('active');
      el.view.classList.add('active');
      state.detail = null;
      renderList(el.search?.value || '');
    }
    function openPage(key) {
      const item = Registry.get(key);
      const renderer = Pages?.renderers?.[key];
      if (!item || typeof renderer !== 'function') { adapter.toast?.('این زیرصفحه در بسته‌ی فعلی موجود نیست.'); return false; }
      stack.reset('settings-home'); stack.push(key); state.detail = key;
      const title = key === 'sound' ? 'کتابخانه‌ی صداها' : item.label;
      el.title.textContent = title;
      const html = renderer(context());
      global.SayroxOrb?.unmountIn(el.content);
      el.content.innerHTML = html;
      global.SayroxOrb?.mountAll(el.content);
      el.view.classList.remove('active'); el.detail.classList.add('active');
      bindPage(key);
      if (key === 'apps') loadProviders();
      if (key === 'memory') loadMemory();
      adapter.onPageOpen?.(key);
      return true;
    }
    function back() {
      if (stack.depth > 1) stack.pop();
      global.SayroxOrb?.unmountIn(el.content);
      state.detail = null;
      el.detail.classList.remove('active');
      el.view.classList.add('active');
      renderList(el.search?.value || '');
      adapter.onPageBack?.();
    }
    function setSetting(key, value) {
      state.settings[key] = value;
      if (key === 'autoResume') state.settings['pref:اجرای خودکار آخرین گفتگو'] = value;
      if (key === 'deepDefault') { state.deepMode = Boolean(value); adapter.updateToolMenu?.(); }
      if (key === 'voicePersona') {
        const persona = Personas.get(value);
        state.settings.voiceProvider = persona.provider;
        adapter.setVoiceAccent?.(persona);
        try { localStorage.setItem('xynora-voice', persona.provider); } catch {}
        try { localStorage.setItem('xynora-voice-persona', persona.key); } catch {}
      }
      adapter.persist?.();
    }
    function bindPage(key) {
      el.content.querySelectorAll('[data-setting-theme]').forEach(button => button.addEventListener('click', () => {
        const mode = button.dataset.settingTheme;
        el.content.querySelectorAll('[data-setting-theme]').forEach(item => item.classList.toggle('is-active', item === button));
        adapter.setTheme?.(mode); adapter.toast?.('حالت نمایش ذخیره شد');
      }));
      el.content.querySelectorAll('[data-setting-toggle]').forEach(button => button.addEventListener('click', () => {
        if (button.disabled) return;
        const key = button.dataset.settingToggle;
        const next = button.getAttribute('aria-checked') !== 'true';
        button.setAttribute('aria-checked', String(next)); button.classList.toggle('is-on', next);
        setSetting(key, next);
        if (key === 'autoResume' && !next) state.active = null;
        if (key === 'autoResume' && next && state.chats.length && !state.active) state.active = [...state.chats].sort((a,b)=>b.updated-a.updated)[0].id;
        if (key === 'orbReactive') adapter.onOrbPreference?.(next);
        adapter.toast?.(next ? 'تنظیم فعال شد' : 'تنظیم غیرفعال شد');
      }));
      const model = el.content.querySelector('#settingModelSelect');
      if (model) { model.value = state.model || 'auto'; model.addEventListener('change', () => { state.model = model.value; adapter.onModelChange?.(model.value); adapter.persist?.(); adapter.toast?.('مدل پیش‌فرض ذخیره شد'); }); }
      const instructions = el.content.querySelector('#customInstructions');
      const saveInstructions = el.content.querySelector('[data-setting-action="save-instructions"]');
      if (saveInstructions && instructions) saveInstructions.addEventListener('click', () => {
        state.settings.customInstructions = instructions.value.trim().slice(0, 4000); adapter.persist?.(); adapter.toast?.('دستورالعمل‌های شخصی ذخیره شد');
      });
      el.content.querySelectorAll('[data-voice-persona]').forEach(button => button.addEventListener('click', () => {
        const persona = Personas.get(button.dataset.voicePersona); setSetting('voicePersona', persona.key);
        el.content.querySelectorAll('[data-voice-persona]').forEach(item => { const selected = item === button; item.classList.toggle('is-selected', selected); item.setAttribute('aria-pressed', String(selected)); item.querySelector('.vs-persona-indicator').textContent = selected ? '✓' : ''; });
        const studio = el.content.querySelector('[data-voice-studio]');
        studio.dataset.persona = persona.key; studio.style.setProperty('--voice-accent', persona.accent); studio.style.setProperty('--voice-glow', persona.glow); studio.style.setProperty('--voice-accent-soft', persona.soft);
        const studioOrb = global.SayroxOrb?.get(el.content.querySelector('#voiceStudioOrb')); studioOrb?.setColors(persona.accent, persona.glow); studioOrb?.setSeed(persona.key);
        el.content.querySelector('#voiceStudioSelectedName').textContent = persona.name;
        el.content.querySelector('#voiceStudioSelectedDescription').textContent = persona.description;
        const orbLabel = el.content.querySelector('.vs-orb-label'); if (orbLabel) orbLabel.textContent = persona.name;
        adapter.toast?.(`صدای ${persona.name} انتخاب شد`);
      }));
      const preview = el.content.querySelector('[data-setting-action="voice-preview"]');
      if (preview) preview.addEventListener('click', async () => {
        preview.disabled = true; preview.textContent = 'در حال آماده‌سازی نمونه…';
        const persona = getPersona();
        try { await adapter.previewVoice?.(persona, el.content.querySelector('[data-voice-studio]')); }
        catch (error) { adapter.toast?.(error?.message || 'پیش‌نمایش صدا ناموفق بود.'); }
        finally { preview.disabled = false; preview.textContent = 'پخش نمونه'; }
      });
      const rate = el.content.querySelector('#voiceRate'), volume = el.content.querySelector('#voiceVolume');
      if (rate) rate.addEventListener('input', () => { el.content.querySelector('#voiceRateValue').textContent = `${Number(rate.value).toFixed(2)}×`; state.settings.voiceRate = Number(rate.value); adapter.persist?.(); });
      if (volume) volume.addEventListener('input', () => { el.content.querySelector('#voiceVolumeValue').textContent = `${Math.round(Number(volume.value)*100)}٪`; state.settings.voiceVolume = Number(volume.value); adapter.persist?.(); });
      el.content.querySelectorAll('[data-setting-action]').forEach(button => {
        if (button.dataset.settingAction === 'voice-preview' || button.dataset.settingAction === 'save-instructions' || button.dataset.settingAction.startsWith('memory-')) return;
        button.addEventListener('click', () => handleAction(button.dataset.settingAction, button));
      });
      if (key === 'plans') bindPlusPlans();
      if (key === 'memory') bindMemoryPage();
    }
    function renderMemoryPage() {
      if (state.detail !== 'memory') return;
      const renderer = Pages?.renderers?.memory;
      if (!renderer) return;
      const scrollTop = el.content.scrollTop;
      el.content.innerHTML = renderer(context());
      el.content.scrollTop = scrollTop;
      bindMemoryPage();
    }
    async function memoryFetch(payload) {
      const response = await global.fetch('/api/memory', {
        method: payload ? 'POST' : 'GET', credentials: 'same-origin',
        headers: payload ? { 'content-type': 'application/json' } : undefined,
        body: payload ? JSON.stringify(payload) : undefined
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok || !data.ok) throw new Error(data.message || 'ارتباط با حافظه برقرار نشد.');
      return data;
    }
    async function loadMemory() {
      if (!state.user || !['http:', 'https:'].includes(global.location.protocol)) {
        memoryState.loaded = true; memoryState.loading = false; memoryState.error = '';
        renderMemoryPage(); return;
      }
      if (memoryRequest) return memoryRequest;
      const epoch = memoryEpoch;
      memoryState.loading = true; memoryState.error = ''; renderMemoryPage();
      const request = memoryFetch().then(data => {
        if (epoch !== memoryEpoch) return;
        memoryState.enabled = data.enabled === true;
        memoryState.items = Array.isArray(data.items) ? data.items.slice(0, 50) : [];
        memoryState.loaded = true; memoryState.error = '';
      }).catch(error => {
        if (epoch !== memoryEpoch) return;
        memoryState.error = error.message || 'دریافت حافظه ناموفق بود.';
        memoryState.loaded = true;
      }).finally(() => {
        if (epoch === memoryEpoch) { memoryState.loading = false; memoryRequest = null; renderMemoryPage(); }
      });
      memoryRequest = request;
      return request;
    }
    async function mutateMemory(payload, successMessage) {
      const epoch = memoryEpoch;
      try {
        const data = await memoryFetch(payload);
        // Never let a late response from a previous signed-in account update the current account UI.
        if (epoch !== memoryEpoch) return false;
        if (payload.action === 'set-enabled') memoryState.enabled = data.enabled === true;
        memoryState.error = '';
        await loadMemory();
        if (epoch !== memoryEpoch) return false;
        adapter.toast?.(successMessage);
        return true;
      } catch (error) {
        if (epoch !== memoryEpoch) return false;
        memoryState.error = error.message || 'عملیات حافظه ناموفق بود.';
        renderMemoryPage(); adapter.toast?.(memoryState.error); return false;
      }
    }
    function bindMemoryPage() {
      const toggle = el.content.querySelector('[data-memory-toggle]');
      if (toggle) toggle.addEventListener('click', () => {
        const enabled = toggle.getAttribute('aria-checked') !== 'true';
        toggle.disabled = true;
        mutateMemory({ action: 'set-enabled', enabled }, enabled ? 'حافظه روشن شد.' : 'حافظه خاموش شد.');
      });
      const bindAction = (action, callback) => el.content.querySelectorAll(`[data-setting-action="${action}"]`).forEach(button => button.addEventListener('click', callback));
      bindAction('memory-login', () => adapter.accountAction?.());
      bindAction('memory-add', async button => {
        const content = el.content.querySelector('#memoryNewContent');
        const category = el.content.querySelector('#memoryNewCategory');
        const value = content?.value.trim() || '';
        if (!value) { adapter.toast?.('ابتدا متن موردنظر را بنویس.'); return; }
        button.disabled = true;
        const ok = await mutateMemory({ action: 'add', content: value, category: category?.value || 'other' }, 'مورد جدید به حافظه اضافه شد.');
        if (!ok) button.disabled = false;
      });
      bindAction('memory-edit', button => { memoryState.editingId = button.dataset.memoryId; renderMemoryPage(); });
      bindAction('memory-cancel', () => { memoryState.editingId = null; renderMemoryPage(); });
      bindAction('memory-save', async button => {
        const item = [...el.content.querySelectorAll('[data-memory-item]')].find(node => node.dataset.memoryItem === button.dataset.memoryId);
        const content = item?.querySelector('[data-memory-edit-content]')?.value.trim() || '';
        const category = item?.querySelector('#memoryEditCategory')?.value || 'other';
        if (!content) { adapter.toast?.('متن حافظه نمی‌تواند خالی باشد.'); return; }
        button.disabled = true;
        const ok = await mutateMemory({ action: 'update', id: button.dataset.memoryId, content, category }, 'مورد حافظه به‌روزرسانی شد.');
        if (ok) memoryState.editingId = null; else button.disabled = false;
        renderMemoryPage();
      });
      bindAction('memory-delete', async button => {
        if (!global.confirm('این مورد از حافظه حذف شود؟')) return;
        await mutateMemory({ action: 'delete', id: button.dataset.memoryId }, 'مورد حافظه حذف شد.');
      });
      bindAction('memory-export', () => {
        const backup = { format: 'xynora-memory', version: 1, exportedAt: new Date().toISOString(), enabled: memoryState.enabled, items: memoryState.items };
        const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
        const url = URL.createObjectURL(blob); const link = global.document.createElement('a');
        link.href = url; link.download = `sayrox-memory-${new Date().toISOString().slice(0,10)}.json`;
        global.document.body.appendChild(link); link.click(); link.remove();
        global.setTimeout(() => URL.revokeObjectURL(url), 1000);
        adapter.toast?.('پشتیبان حافظه آماده شد.');
      });
      bindAction('memory-clear', async () => {
        if (!global.confirm('تمام موارد حافظه برای همیشه حذف شوند؟ این عملیات قابل بازگشت نیست.')) return;
        await mutateMemory({ action: 'clear' }, 'تمام موارد حافظه حذف شدند.');
      });
    }

    async function loadProviders() {
      if (!['http:', 'https:'].includes(global.location.protocol)) { providers = { chat:false, chatPrimary:null, chatFallback:null, chatPrimaryReady:false, chatFallbackReady:false, gapgpt:null, openrouter:null, search:false, tts:false, payments:false }; return; }
      if (providerRequest) return providerRequest;
      providerRequest = global.fetch('/api/health', { credentials: 'same-origin' }).then(r => r.json()).then(data => {
        providers = { chat:Boolean(data.providers?.chat), chatPrimary:data.providers?.chatPrimary || null, chatFallback:data.providers?.chatFallback || null, chatPrimaryReady:Boolean(data.providers?.chatPrimaryReady), chatFallbackReady:Boolean(data.providers?.chatFallbackReady), gapgpt:data.providers?.gapgpt || null, openrouter:data.providers?.openrouter || null, search:Boolean(data.providers?.search), tts:Boolean(data.providers?.tts), payments:Boolean(data.providers?.payments) };
        if (state.detail === 'apps') { const openKey = state.detail; if (openKey) { const old = el.content.innerHTML; const pos = el.content.scrollTop; el.content.innerHTML = Pages.renderers.apps(context()); bindPage('apps'); el.content.scrollTop = pos; } }
      }).catch(() => { providers = { chat:false, chatPrimary:null, chatFallback:null, chatPrimaryReady:false, chatFallbackReady:false, gapgpt:null, openrouter:null, search:false, tts:false, payments:false }; }).finally(() => { providerRequest = null; });
      return providerRequest;
    }
    function handleAction(action, button) {
      switch (action) {
        case 'account-auth': adapter.accountAction?.(); break;
        case 'export-data': adapter.exportData?.(); break;
        case 'clear-local-chats': adapter.clearLocalChats?.(); break;
        case 'delete-all-chats': adapter.deleteAllChats?.(); break;
        case 'notification-permission': adapter.requestNotificationPermission?.(); break;
        case 'safety-info': adapter.toast?.('کنترل‌های ایمنی مدل در سطح Provider اعمال می‌شوند.'); break;
        case 'security-sessions': adapter.toast?.('مدیریت نشست‌های چنددستگاهی هنوز به backend متصل نیست.'); break;
        default: adapter.toast?.('این عملیات هنوز به سرویس مربوطه متصل نشده است.');
      }
    }
    function bindPlusPlans() {
      const cards = [...el.content.querySelectorAll('[data-plus-plan]')];
      const selectedName = el.content.querySelector('#plusSelectedName');
      const selectedPrice = el.content.querySelector('#plusSelectedPrice');
      const purchaseButton = el.content.querySelector('#plusPurchaseButton');
      const subscriptionTitle = el.content.querySelector('#plusSubscriptionTitle');
      const subscriptionDetail = el.content.querySelector('#plusSubscriptionDetail');
      const paymentHistory = el.content.querySelector('#plusPaymentHistory');
      const usagePanel = el.content.querySelector('#plusUsagePanel');
      if (!cards.length || !selectedName || !selectedPrice) return;

      const formatToman = value => `${new Intl.NumberFormat('fa-IR').format(value)} تومان`;
      const selectPackage = card => {
        const price = Number(card.dataset.plusPrice);
        if (!Number.isSafeInteger(price) || price <= 0) return;
        cards.forEach(item => {
          const selected = item === card;
          item.classList.toggle('is-active', selected);
          item.setAttribute('aria-pressed', String(selected));
        });
        selectedName.textContent = `${card.dataset.plusName || 'SAYROX Plus'} · ${card.dataset.plusPeriod || ''}`;
        selectedPrice.textContent = formatToman(price);
      };
      cards.forEach(card => card.addEventListener('click', () => selectPackage(card)));
      selectPackage(cards.find(card => card.classList.contains('is-active')) || cards[0]);

      const setPurchaseState = (busy, label) => {
        if (!purchaseButton) return;
        purchaseButton.disabled = busy;
        purchaseButton.textContent = label || (state.user ? 'خرید بسته و پرداخت امن' : 'برای خرید وارد حساب شو');
        purchaseButton.setAttribute('aria-busy', String(busy));
      };
      const renderUsage = usage => {
        if (!usagePanel) return;
        usagePanel.replaceChildren();
        const heading = global.document.createElement('strong'); heading.textContent = usage?.isPlus ? 'سهمیه‌ی ماهانه‌ی Plus' : 'سهمیه‌ی ماهانه‌ی حساب پایه';
        usagePanel.appendChild(heading);
        const featureNames = [
          ['chat', 'گفتگو'], ['search', 'جست‌وجوی وب'], ['tts', 'تبدیل متن به صدا'],
          ['live_voice', 'مکالمه زنده'], ['images', 'تصویر']
        ];
        const grid = global.document.createElement('div'); grid.className = 'sx-plus-usage-grid';
        for (const [key, label] of featureNames) {
          const item = usage?.features?.[key];
          if (!item) continue;
          const card = global.document.createElement('div'); card.className = 'sx-plus-usage-item';
          const line = global.document.createElement('div');
          const name = global.document.createElement('span'); name.textContent = label;
          const value = global.document.createElement('strong'); value.textContent = `${new Intl.NumberFormat('fa-IR').format(item.used || 0)} از ${new Intl.NumberFormat('fa-IR').format(item.limit || 0)}`;
          line.append(name, value);
          const track = global.document.createElement('div'); track.className = 'sx-plus-usage-track';
          const fill = global.document.createElement('span');
          const percent = item.limit > 0 ? Math.min(100, Math.max(0, ((item.used + (item.reserved || 0)) / item.limit) * 100)) : 100;
          fill.style.width = `${percent}%`; track.appendChild(fill);
          card.append(line, track); grid.appendChild(card);
        }
        usagePanel.appendChild(grid);
        const reset = global.document.createElement('p'); reset.className = 'sx-plus-usage-reset';
        reset.textContent = usage?.resetAt ? `بازنشانی سهمیه: ${new Date(usage.resetAt).toLocaleDateString('fa-IR', { dateStyle: 'medium' })}` : 'سهمیه‌ها در سرور محاسبه می‌شوند.';
        usagePanel.appendChild(reset);
        const localFiles = global.document.createElement('p'); localFiles.className = 'sx-plus-usage-reset';
        localFiles.textContent = 'پردازش محلی فایل‌ها سهمیه‌ی جداگانه‌ی سروری ندارد؛ درخواست گفتگو با سهمیه‌ی گفتگو محاسبه می‌شود.';
        usagePanel.appendChild(localFiles);
      };
      const refreshSubscription = async () => {
        if (!subscriptionTitle || !subscriptionDetail) return;
        if (!state.user) {
          subscriptionTitle.textContent = 'برای مشاهده اشتراک وارد حساب شو';
          subscriptionDetail.textContent = 'اشتراک هر خرید به حساب کاربری همان خریدار متصل می‌شود.';
          if (paymentHistory) paymentHistory.querySelector('p').textContent = 'برای مشاهده سوابق، وارد حساب کاربری شو.';
          if (usagePanel) { usagePanel.replaceChildren(); const title = global.document.createElement('strong'); title.textContent = 'سهمیه‌ی مصرف این دوره'; const note = global.document.createElement('p'); note.textContent = 'برای مشاهده سهمیه، وارد حساب کاربری شو.'; usagePanel.append(title, note); }
          return;
        }
        subscriptionTitle.textContent = 'در حال بررسی اشتراک…';
        subscriptionDetail.textContent = 'وضعیت از سرور دریافت می‌شود.';
        try {
          const response = await global.fetch('/api/subscription/me', { credentials: 'same-origin', cache: 'no-store' });
          const data = await response.json().catch(() => ({}));
          if (!response.ok || !data.ok) throw new Error(data.message || 'خواندن وضعیت اشتراک ناموفق بود.');
          renderUsage(data.usage);
          if (data.current) {
            const plan = cards.find(card => card.dataset.plusPlan === data.current.planId);
            const name = plan?.dataset.plusName || data.current.planId;
            const expires = new Date(data.current.expiresAt).toLocaleDateString('fa-IR', { dateStyle: 'medium' });
            subscriptionTitle.textContent = `${name} فعال است`;
            subscriptionDetail.textContent = `اعتبار تا ${expires} · ${data.current.status === 'scheduled' ? 'در صف فعال‌سازی' : 'فعال'}`;
          } else if (Array.isArray(data.upcoming) && data.upcoming.length) {
            subscriptionTitle.textContent = 'اشتراک بعدی ثبت شده است';
            subscriptionDetail.textContent = `شروع از ${new Date(data.upcoming[0].startsAt).toLocaleDateString('fa-IR', { dateStyle: 'medium' })}`;
          } else {
            subscriptionTitle.textContent = 'در حال حاضر اشتراک فعالی نداری';
            subscriptionDetail.textContent = 'پس از تأیید پرداخت، اشتراک به همین حساب متصل می‌شود.';
          }
          if (paymentHistory) {
            paymentHistory.replaceChildren();
            const heading = global.document.createElement('strong');
            heading.textContent = 'سوابق پرداخت';
            paymentHistory.appendChild(heading);
            const records = Array.isArray(data.payments) ? data.payments : [];
            if (!records.length) {
              const empty = global.document.createElement('p');
              empty.textContent = 'هنوز پرداختی ثبت نشده است.';
              paymentHistory.appendChild(empty);
            } else {
              const statusLabels = { paid: 'موفق', pending: 'در انتظار پرداخت', creating: 'در حال ثبت', cancelled: 'لغوشده', failed: 'ناموفق' };
              records.forEach(record => {
                const row = global.document.createElement('div');
                row.className = 'sx-plus-history-row';
                const name = global.document.createElement('span');
                const planCard = cards.find(card => card.dataset.plusPlan === record.planId);
                name.textContent = `${planCard?.dataset.plusName || record.planId} · ${record.months} ماهه`;
                const amount = global.document.createElement('strong');
                amount.textContent = formatToman(record.amountToman);
                const status = global.document.createElement('small');
                status.textContent = statusLabels[record.status] || 'نامشخص';
                row.append(name, amount, status);
                paymentHistory.appendChild(row);
              });
            }
          }
        } catch (error) {
          subscriptionTitle.textContent = 'وضعیت اشتراک در دسترس نیست';
          subscriptionDetail.textContent = error?.message || 'بعداً دوباره تلاش کن.';
          if (paymentHistory) paymentHistory.textContent = 'سوابق پرداخت در دسترس نیست.';
          if (usagePanel) usagePanel.textContent = 'سهمیه‌ی مصرف در دسترس نیست؛ کنترل سهمیه در سمت سرور فعال و خطا به‌صورت بسته مدیریت می‌شود.';
        }
      };
      setPurchaseState(false);
      void refreshSubscription();
      purchaseButton?.addEventListener('click', async () => {
        if (!state.user) {
          adapter.accountAction?.();
          return;
        }
        const selected = cards.find(card => card.classList.contains('is-active')) || cards[0];
        const planId = selected?.dataset.plusPlan;
        if (!planId || !global.crypto?.randomUUID) {
          adapter.toast?.('مرورگر امکان ساخت شناسه امن سفارش را ندارد.');
          return;
        }
        setPurchaseState(true, 'در حال ثبت سفارش امن…');
        try {
          const response = await global.fetch('/api/payment/request', {
            method: 'POST', credentials: 'same-origin',
            headers: { 'content-type': 'application/json', 'Idempotency-Key': global.crypto.randomUUID() },
            body: JSON.stringify({ planId })
          });
          const data = await response.json().catch(() => ({}));
          if (!response.ok || !data.ok) throw new Error(data.message || 'ساخت درخواست پرداخت ناموفق بود.');
          if (data.alreadyPaid) {
            adapter.toast?.('این سفارش قبلاً پرداخت و ثبت شده است.');
            await refreshSubscription();
            setPurchaseState(false);
            return;
          }
          const paymentUrl = new URL(String(data.paymentUrl || ''), global.location.origin);
          if (paymentUrl.protocol !== 'https:' || !['sandbox.zarinpal.com', 'www.zarinpal.com'].includes(paymentUrl.hostname) || !paymentUrl.pathname.startsWith('/pg/StartPay/'))
            throw new Error('نشانی درگاه پرداخت معتبر نیست.');
          setPurchaseState(true, 'در حال انتقال به درگاه…');
          global.location.assign(paymentUrl.toString());
        } catch (error) {
          adapter.toast?.(error?.message || 'شروع پرداخت ناموفق بود.');
          setPurchaseState(false);
        }
      });
    }
    el.list.addEventListener('click', event => { const button = event.target.closest('[data-settings-key]'); if (button) openPage(button.dataset.settingsKey); });
    el.search?.addEventListener('input', event => renderList(event.target.value));
    el.back?.addEventListener('click', back);
    el.homeBack?.addEventListener('click', () => { stack.reset(); adapter.closeSettings?.(); });
    global.addEventListener('keydown', event => { if (event.key === 'Escape' && el.detail.classList.contains('active')) back(); });
    function refreshMemoryForAccount() {
      memoryEpoch++; memoryState.loaded = false; memoryState.loading = false; memoryState.enabled = false;
      memoryState.items = []; memoryState.error = ''; memoryState.editingId = null; memoryRequest = null;
      if (state.detail === 'memory') loadMemory();
    }
    return { renderList, openHome, openPage, back, refreshMemoryForAccount, get currentPage() { return state.detail; }, get navigationDepth() { return stack.depth; }, refreshProviders: loadProviders };
  }
  global.SayroxSettingsFeature = Object.freeze({ create });
})(globalThis);
