(function (P) {
  const e=P.escape, row=P.row, section=P.section, status=P.status, button=P.button;
  P.register('account', ctx => {
    const user=ctx.state.user;
    return `${P.head('user','حساب کاربری','اطلاعات حساب و وضعیت ورود در SAYROX.','#5b7cff')}${section('پروفایل', row('نام نمایشی','نامی که در برنامه دیده می‌شود.',`<span class="sx-value">${e(user?.displayName || 'مهمان')}</span>`) + row('ایمیل','نشانی ایمیل متصل به حساب.',`<span class="sx-value sx-ltr">${e(user?.email || '—')}</span>`) + status('نوع حساب','وضعیت فعلی نشست.',user?'حساب متصل':'حساب مهمان',user?'success':'neutral'))}${section('مدیریت حساب', row(user?'خروج از حساب':'ورود یا ساخت حساب',user?'نشست فعلی را به‌صورت امن پایان بده.':'برای همگام‌سازی حساب، وارد شو.',button('account-auth',user?'خروج از حساب':'ورود به حساب',user?'danger':'primary')))}<p class="sx-footnote">گفتگوها در این build هنوز فقط در فضای ذخیره‌سازی همین مرورگر نگهداری می‌شوند؛ همگام‌سازی ابری فعال نیست.</p>`;
  });
  P.register('workspace', ctx => `${P.head('workspace','Workspace','مدیریت پروژه‌ها و کارهای مرتبط با فضای کاری.','#e29a3a')}${section('وضعیت فعلی',row('پروژه‌های محلی','تعداد پروژه‌های ذخیره‌شده روی این دستگاه.',`<span class="sx-value">${ctx.state.projects.length}</span>`) + row('کارهای ثبت‌شده','وظایف ثبت‌شده در این مرورگر.',`<span class="sx-value">${ctx.state.tasks.length}</span>`) + status('اجرای خودکار وظایف','اجرای پس‌زمینه هنوز به Scheduler سرور متصل نیست.','نیازمند اتصال','warning'))}`);
})(globalThis.SayroxSettingsPages);
