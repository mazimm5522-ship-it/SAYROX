(function (P) {
  'use strict';

  const packages = [
    {
      id: 'plus-1m', months: 1, period: '۱ ماهه', name: 'Plus Start',
      tier: 'شروع', price: 1371000, usd: 5,
      description: 'برای آشنایی با امکانات پیشرفته‌ی SAYROX.',
      features: [
        'دسترسی به تجربه‌ی Plus و مدل‌های پیشرفته',
        'سهمیه‌ی پایه برای گفتگو و جست‌وجوی وب',
        'ابزارهای اصلی کار با فایل و تصویر'
      ]
    },
    {
      id: 'plus-3m', months: 3, period: '۳ ماهه', name: 'Plus Advanced',
      tier: 'پیشرفته', price: 4113000, usd: 15,
      description: 'برای استفاده‌ی پیوسته و پروژه‌های جدی‌تر.',
      features: [
        'تمام امکانات بسته‌ی یک‌ماهه',
        'سهمیه‌ی بیشتر برای گفتگو و جست‌وجوی وب',
        'ظرفیت بالاتر برای تفکر عمیق و کار با فایل'
      ]
    },
    {
      id: 'plus-9m', months: 9, period: '۹ ماهه', name: 'Plus Pro',
      tier: 'حرفه‌ای', price: 13710000, usd: 50,
      description: 'برای کاربرانی که مرتب با ابزارهای هوشمند کار می‌کنند.',
      features: [
        'تمام امکانات بسته‌ی سه‌ماهه',
        'سهمیه‌ی گسترده‌تر برای فایل‌ها و تصاویر',
        'سهمیه‌ی بیشتر برای قابلیت‌های صوتی',
        'ظرفیت بالاتر برای گفتگوهای طولانی و پیچیده'
      ]
    },
    {
      id: 'plus-12m', months: 12, period: '۱۲ ماهه', name: 'Plus Ultra',
      tier: 'بالاترین سطح', price: 21936000, usd: 80,
      description: 'کامل‌ترین بسته‌ی پیشنهادی SAYROX Plus.',
      featured: true,
      features: [
        'تمام امکانات بسته‌ی نه‌ماهه',
        'بالاترین سهمیه‌ی پیشنهادی گفتگو و جست‌وجو',
        'بالاترین ظرفیت پیشنهادی فایل، تصویر و صدا',
        'اولویت پردازش و دسترسی زودهنگام به قابلیت‌های جدید'
      ]
    }
  ];

  const formatToman = value => new Intl.NumberFormat('fa-IR').format(value);
  const escape = P.escape;

  function renderPackage(item, index) {
    const selected = index === 0;
    const features = item.features.map(feature =>
      `<span class="sx-plus-feature"><span class="sx-plus-check" aria-hidden="true">✓</span><span>${escape(feature)}</span></span>`
    ).join('');

    return `<button type="button" class="sx-plus-plan${item.featured ? ' is-featured' : ''}${selected ? ' is-active' : ''}"
      data-plus-plan="${escape(item.id)}" data-plus-months="${item.months}" data-plus-price="${item.price}"
      data-plus-name="${escape(item.name)}" data-plus-period="${escape(item.period)}"
      aria-pressed="${selected ? 'true' : 'false'}">
      <span class="sx-plus-plan-top">
        <span class="sx-plus-plan-title"><strong>${escape(item.name)}</strong><small>${escape(item.tier)}</small></span>
        ${item.featured ? '<span class="sx-plus-ribbon">کامل‌ترین</span>' : ''}
      </span>
      <span class="sx-plus-description">${escape(item.description)}</span>
      <span class="sx-plus-price-line"><strong>${formatToman(item.price)}</strong><small>تومان · مبلغ کل ${escape(item.period)}</small></span>
      <span class="sx-plus-divider" aria-hidden="true"></span>
      <span class="sx-plus-features-label">امکانات این بسته</span>
      <span class="sx-plus-features">${features}</span>
    </button>`;
  }

  P.register('plans', () => {
    const initial = packages[0];
    return `${P.head('spark', 'SAYROX Plus', 'یک تجربه‌ی کامل‌تر با بسته‌هایی متناسب با میزان استفاده‌ی تو.', '#c89b3c')}
      <div class="sx-plus-intro">
        <span class="sx-plus-status"><i aria-hidden="true"></i> بسته‌های اشتراک</span>
        <p>مدت بیشتر، سطح امکانات و ظرفیت پیشنهادی بالاتر. بسته‌ای را انتخاب کن که با نوع استفاده‌ات هماهنگ است.</p>
      </div>
      ${P.section('انتخاب بسته‌ی Plus', `<div class="sx-plus-grid" role="group" aria-label="بسته‌های اشتراک SAYROX Plus">${packages.map(renderPackage).join('')}</div>`)}
      ${P.section('بسته‌ی انتخاب‌شده', `<div class="sx-plus-summary" aria-live="polite">
        <div><small id="plusSelectedName">${escape(initial.name)} · ${escape(initial.period)}</small><strong id="plusSelectedPrice">${formatToman(initial.price)} تومان</strong></div>
        <span class="sx-plus-summary-caption">مبلغ کل دوره</span>
      </div>
      <div class="sx-plus-payment-state" id="plusSubscriptionState" aria-live="polite"><span class="sx-plus-lock" aria-hidden="true">⌑</span><span><strong id="plusSubscriptionTitle">وضعیت اشتراک</strong><small id="plusSubscriptionDetail">برای بررسی اشتراک فعلی، وارد حساب کاربری شو.</small></span></div>
      <div class="sx-plus-usage" id="plusUsagePanel" aria-live="polite"><strong>سهمیه‌ی مصرف این دوره</strong><p>برای مشاهده سهمیه، وارد حساب کاربری شو.</p></div>
      <div class="sx-plus-history" id="plusPaymentHistory" aria-live="polite"><strong>سوابق پرداخت</strong><p>برای مشاهده سوابق، وارد حساب کاربری شو.</p></div>
      <button type="button" class="sx-plus-purchase" id="plusPurchaseButton">خرید بسته و پرداخت امن</button>`)}
      <p class="sx-plus-note">پرداخت تنها پس از ورود به حساب و تأیید سرور از طریق زرین‌پال نهایی می‌شود. قیمت و مدت هر بسته در سرور تعیین می‌شود و مبلغ ارسالی مرورگر معتبر نیست. سهمیه‌ی مصرف در سمت سرور، متناسب با پلن و دوره‌ی فعال حساب کنترل می‌شود.</p>`;
  });
})(globalThis.SayroxSettingsPages);
