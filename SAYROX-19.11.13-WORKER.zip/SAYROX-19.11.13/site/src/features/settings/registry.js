(function (global) {
  'use strict';
  const groups = [
    [
      { key: 'account', label: 'حساب کاربری', icon: 'user', avatar: true, dynamicExtra: 'name', keywords: 'profile email login' },
      { key: 'workspace', label: 'فضای کاری', icon: 'workspace', extra: 'شخصی', noChevron: true, keywords: 'work projects tasks' },
      { key: 'plans', label: 'SAYROX Plus', icon: 'spark', extra: 'پلن‌ها و قیمت‌ها', accent: true, keywords: 'plus upgrade subscription payment zarinpal pricing' }
    ],
    [
      { key: 'personal', label: 'شخصی‌سازی', icon: 'personal', keywords: 'custom instructions theme appearance' },
      { key: 'memory', label: 'حافظه', icon: 'memory', keywords: 'memory history' },
      { key: 'reasoning', label: 'تفکر عمیق', icon: 'spark', keywords: 'deep reasoning code' },
      { key: 'apps', label: 'افزونه‌ها', icon: 'apps', keywords: 'openrouter gapgpt tavily elevenlabs' }
    ],
    [
      { key: 'general', label: 'عمومی', icon: 'general', keywords: 'theme language model' },
      { key: 'usage', label: 'میزان استفاده و محدودیت‌ها', icon: 'usage', keywords: 'usage limits quota' },
      { key: 'notifications', label: 'اعلان‌ها', icon: 'bell', keywords: 'notifications alerts' },
      { key: 'sound', label: 'صدا', icon: 'sound', keywords: 'voice orb speech audio' },
      { key: 'safety', label: 'ایمنی', icon: 'shield', keywords: 'safety protection' },
      { key: 'security', label: 'امنیت و ورود', icon: 'lock', keywords: 'security session authentication' },
      { key: 'codex', label: 'Codex', icon: 'code', keywords: 'code sandbox' },
      { key: 'storage', label: 'فضای ذخیره‌سازی', icon: 'storage', keywords: 'storage local files' },
      { key: 'privacy', label: 'مرکز حریم خصوصی', icon: 'privacy', keywords: 'privacy data' },
      { key: 'history', label: 'تاریخچه و داده‌ها', icon: 'history', keywords: 'history export delete' },
      { key: 'ads', label: 'کنترل‌های تبلیغات', icon: 'ads', keywords: 'ads advertising' },
      { key: 'about', label: 'درباره‌ی SAYROX', icon: 'info', keywords: 'version about help' }
    ]
  ];
  const byKey = new Map(groups.flat().map(item => [item.key, item]));
  global.SayroxSettingsRegistry = Object.freeze({ groups, byKey, get(key) { return byKey.get(key) || null; } });
})(globalThis);
