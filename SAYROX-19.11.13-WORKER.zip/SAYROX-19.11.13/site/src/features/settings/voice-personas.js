(function (global) {
  'use strict';
  const personas = [
    { key: 'ara', name: 'Ara', description: 'گرم و دوستانه', provider: 'aria', accent: '#b59aff', glow: '#825dff', soft: '#2a2045' },
    { key: 'eve', name: 'Eve', description: 'پرانرژی و شاداب', provider: 'nova', accent: '#53d8e8', glow: '#168fb9', soft: '#15343d' },
    { key: 'leo', name: 'Leo', description: 'مقتدر و قوی', provider: 'atlas', accent: '#7796ff', glow: '#3d56df', soft: '#1b2850' },
    { key: 'rex', name: 'Rex', description: 'با اعتمادبه‌نفس و واضح', provider: 'orion', accent: '#c2e9ff', glow: '#579bd0', soft: '#203746' },
    { key: 'sal', name: 'Sal', description: 'نرم و متعادل', provider: 'elena', accent: '#65d7b0', glow: '#279e82', soft: '#153c34' },
    { key: 'gork', name: 'Gork', description: 'آرام و بی‌عجله', provider: 'kai', accent: '#ffad70', glow: '#e4663e', soft: '#47291f' },
    { key: 'carina', name: 'Carina', description: 'نرم، همدل و آرامش‌بخش', provider: 'lyra', accent: '#f3a4d7', glow: '#a65acb', soft: '#40213f' }
  ];
  const byKey = new Map(personas.map(persona => [persona.key, persona]));
  global.SayroxVoicePersonas = Object.freeze({ all: personas, get(key) { return byKey.get(key) || personas[0]; } });
})(globalThis);
