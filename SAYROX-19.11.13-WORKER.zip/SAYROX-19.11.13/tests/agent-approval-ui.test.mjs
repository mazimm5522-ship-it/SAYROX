import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');
const app = await read('app/05-send-message.js');
const workerRoute = await read('worker/routes/api.js');
const approval = await read('worker/features/agent-approval.js');
const ticket = await read('worker/agent/approval-tickets.js');
const usage = await read('usage-worker/src/index.js');
const css = await read('site/src/styles/content.css');

assert.match(app, /function renderAgentApprovalCard\(/);
assert.match(app, /تأیید و اجرا/);
assert.match(app, /لغو عملیات/);
assert.match(app, /data\.toolId==='execute_python'/);
assert.match(app, /نتیجهٔ اجرای Python/);
assert.match(app, /textContent=String\(approval\.title/);
assert.match(app, /fetch\('\/api\/agent\/approval'/);
assert.match(app, /JSON\.stringify\(\{ticket:approval\.ticket,decision\}\)/);
assert.match(app, /eventName==='sayrox_agent'/);
assert.match(app, /type==='approval_required'/);
assert.match(app, /response\.status===409/);
assert.match(app, /is-failed/);
assert.doesNotMatch(app.slice(app.indexOf('function renderAgentApprovalCard'), app.indexOf('async function sendMessage')), /localStorage/);
assert.match(workerRoute, /url\.pathname === '\/api\/agent\/approval'/);
assert.match(workerRoute, /sessions_js_1\.authenticatedSession/);
assert.match(approval, /sessions_js_1\.sameOriginRequest/);
assert.match(approval, /consumeAgentApproval\(/);
assert.match(approval, /definition\.validateArgs\(ticket\.args\)/);
assert.match(approval, /createPythonExecutionTool/);
assert.match(approval, /execute_python/);
assert.match(ticket, /AES-GCM/);
assert.match(ticket, /TICKET_TTL_MS = 5 \* 60 \* 1000/);
assert.match(usage, /CREATE TABLE IF NOT EXISTS agent_approval_tickets/);
assert.match(usage, /transactionSync\(\(\) => \{/);
assert.match(usage, /AGENT_APPROVAL_REPLAYED/);
assert.match(css, /\.agent-approval-card\.is-failed/);

console.log('agent approval UI tests: safe card text, same-origin endpoint, account-auth route, encrypted one-use ticket and terminal failure UI passed');
