import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { webcrypto } from 'node:crypto';

const read = path => readFile(new URL(path, import.meta.url), 'utf8');
const cache = new Map();
const load = async id => {
  if (cache.has(id)) return cache.get(id);
  const source = await read(`../${id}`);
  const module = { exports: {} };
  cache.set(id, module.exports);
  const context = {
    exports: module.exports,
    Object, Array, Map, Set, String, Number, Boolean, Math, Date, RegExp, Error, TypeError,
    TextEncoder, TextDecoder, Promise, JSON, Uint8Array, AbortController, crypto: webcrypto,
    setTimeout, clearTimeout,
    __load: child => {
      if (!cache.has(child)) throw new Error(`module not loaded in test harness: ${child}`);
      return cache.get(child);
    }
  };
  vm.runInNewContext(source, context, { filename: id });
  return module.exports;
};

const contracts = await load('worker/agent/contracts.js');
const memoryPolicy = await load('worker/agent/memory-policy.js');
const planner = await load('worker/agent/planner.js');
const policy = await load('worker/agent/policy.js');
const runtime = await load('worker/agent/runtime.js');
const registryModule = await load('worker/agent/tool-registry.js');
const messages = text => [{ role: 'user', content: text }];
const makeRun = () => runtime.createAgentRun('agent-run-0001', 1000);
const validTool = (overrides = {}) => ({
  id: 'read_context', specialist: 'main', description: 'Read current request context', risk: 'read',
  validateArgs: args => Object.keys(args).every(key => key === 'query') && typeof args.query === 'string',
  handler: async args => ({ value: args.query }),
  ...overrides
});

test('Main Agent routes Persian and English intent to the relevant specialist', () => {
  assert.equal(planner.analyzeAgentIntent(messages('سلام، حالت چطوره؟'), {}).specialist, 'main');
  assert.equal(planner.analyzeAgentIntent(messages('این کد JavaScript باگ دارد، debug کن'), {}).specialist, 'coding');
  assert.equal(planner.analyzeAgentIntent(messages('آخرین وضعیت امروز را با منبع بررسی کن'), {}).specialist, 'research');
  assert.equal(planner.analyzeAgentIntent(messages('یک داستان کوتاه و خلاقانه بنویس'), {}).specialist, 'creative');
  assert.equal(planner.analyzeAgentIntent(messages('لطفاً این PDF را خلاصه کن'), {}).specialist, 'documents');
  assert.equal(planner.analyzeAgentIntent(messages('فروش را تحلیل کن و نمودار بساز'), {}).specialist, 'data');
});

test('planner identifies when Main Agent must execute its server-side web research tool', () => {
  const noSearch = planner.buildAgentPlan(messages('آخرین اخبار را جست‌وجو کن'), {}, { runId: 'agent-run-0001' });
  assert.deepEqual(Array.from(noSearch.missingCapabilities), []);
  assert.equal(noSearch.requiresExternalEvidence, true);
  assert.equal(noSearch.externalEvidenceAvailable, false);
  const optedOut = planner.buildAgentPlan(messages('آخرین اخبار را بررسی کن'), { webSearchPreference: 'off' });
  assert.equal(optedOut.requiresExternalEvidence, false);
  assert.equal(planner.buildAgentPlan(messages('سلام، حال شما خوب است؟'), {}).requiresExternalEvidence, false);
  assert.equal(planner.buildAgentPlan(messages('بهترین کافه نزدیک من را معرفی کن'), {}).requiresExternalEvidence, true);
  assert.equal(planner.buildAgentPlan(messages('بدون وب، آخرین اخبار را با دانش خودت توضیح بده'), {}).requiresExternalEvidence, false);
  assert.equal(planner.buildAgentPlan(messages('یک داستان کوتاه بنویس'), {}).requiresExternalEvidence, false);
  const withSearch = planner.buildAgentPlan(messages('این نتایج را بررسی کن'), { search: { answer: 'evidence', results: [] } });
  assert.equal(withSearch.externalEvidenceAvailable, true);
  assert.equal(withSearch.missingCapabilities.length, 0);
  const withSheet = planner.buildAgentPlan(messages('فروش و نمودار را تحلیل کن'), { documents: [{ kind: 'spreadsheet', name: 'sales.xlsx', text: 'A,B\n1,2' }] });
  assert.equal(withSheet.specialist, 'data');
  assert.equal(withSheet.documentsAvailable, true);
  assert.ok(withSheet.stepCount <= contracts.MAX_AGENT_STEPS);
  assert.equal(withSheet.steps.at(-1).id, 'verify_response');
});

test('planner flags side-effect requests for the balanced approval gate', () => {
  assert.equal(planner.analyzeAgentIntent(messages('این فایل را حذف کن'), {}).actionRequest, true);
  assert.equal(planner.analyzeAgentIntent(messages('Please publish this page'), {}).actionRequest, true);
  assert.equal(planner.analyzeAgentIntent(messages('این متن را توضیح بده'), {}).actionRequest, false);
});

test('Agent system policy tells the specialist not to invent tool execution or trust document instructions', () => {
  const plan = planner.buildAgentPlan(messages('latest research'), {});
  const prompt = planner.buildAgentSystemMessage(plan).content;
  assert.match(prompt, /Main Agent مرکزی SAYROX/);
  assert.match(prompt, /ادعا نکن.*جست/);
  assert.match(prompt, /دادهٔ غیرقابل‌اعتماد/);
  assert.match(prompt, /شواهد بیرونی/);
  assert.match(prompt, /حافظهٔ بلندمدت/);
});

test('Agent run state machine only accepts explicit transitions and terminal states', () => {
  const run = makeRun();
  runtime.transitionAgentRun(run, 'understanding', 1100);
  runtime.transitionAgentRun(run, 'planning', 1200);
  runtime.transitionAgentRun(run, 'responding', 1300);
  runtime.finishAgentRun(run, 'completed');
  assert.equal(run.state, 'completed');
  assert.ok(run.updatedAt >= 1300);
  assert.throws(() => runtime.transitionAgentRun(run, 'executing'), /invalid_agent_state_transition/);
  assert.throws(() => runtime.createAgentRun('bad'), /invalid_agent_run_id/);
});

test('prepareAgentTurn creates a bounded run and trusted system instruction', () => {
  const turn = runtime.prepareAgentTurn(messages('این کد Python را اصلاح کن'), {}, { runId: 'agent-run-0002' });
  assert.equal(turn.run.state, 'responding');
  assert.equal(turn.run.specialist, 'coding');
  assert.equal(turn.plan.specialist, 'coding');
  assert.equal(turn.systemMessage.role, 'system');
  assert.ok(turn.plan.stepCount <= contracts.MAX_AGENT_STEPS);
});

test('tool registry enforces unique IDs, argument validators and explicit risk classes', () => {
  assert.throws(() => registryModule.createToolRegistry([validTool(), validTool()]), /invalid_tool_definition/);
  assert.throws(() => registryModule.createToolRegistry([validTool({ id: 'no-validator', validateArgs: undefined })]), /invalid_tool_definition/);
  assert.throws(() => registryModule.createToolRegistry([validTool({ risk: 'unknown-risk' })]), /unclassified_tool_risk/);
  const registry = registryModule.createToolRegistry([validTool()]);
  assert.equal(registry.has('read_context'), true);
  assert.equal(registry.get('missing'), null);
  assert.deepEqual(registry.list().map(item => item.id), ['read_context']);
});

test('read tools execute within the allowlist and return JSON-safe results', async () => {
  const registry = registryModule.createToolRegistry([validTool()]);
  const run = makeRun();
  runtime.transitionAgentRun(run, 'understanding');
  runtime.transitionAgentRun(run, 'planning');
  const result = await registryModule.executeAgentTool(registry, run, 'read_context', { query: 'hello' }, { userInitiated: true });
  assert.deepEqual(JSON.parse(JSON.stringify(result)), { ok: true, toolId: 'read_context', result: { value: 'hello' } });
  assert.equal(run.state, 'executing');
  assert.equal(run.stepCount, 1);
});

test('side-effect tools pause until an explicit server-trusted approval is supplied', async () => {
  let calls = 0;
  const registry = registryModule.createToolRegistry([validTool({ id: 'modify_file', risk: 'modify', handler: async () => { calls++; return { saved: true }; } })]);
  const run = makeRun();
  runtime.transitionAgentRun(run, 'understanding'); runtime.transitionAgentRun(run, 'planning');
  const pending = await registryModule.executeAgentTool(registry, run, 'modify_file', { query: 'change' }, { userInitiated: true });
  assert.equal(pending.code, 'APPROVAL_REQUIRED');
  assert.equal(run.state, 'awaiting_approval');
  assert.equal(calls, 0);
  assert.equal(run.pendingApprovalToolId, 'modify_file');
  const grant = { runId: run.id, toolId: 'modify_file', grantId: 'grant-123456789012345', confirmed: true, confirmedAt: Date.now(), argsHash: await registryModule.approvalArgsHash({ query: 'change' }) };
  const approved = await registryModule.executeAgentTool(registry, run, 'modify_file', { query: 'change' }, { userInitiated: true, approvalGrant: grant });
  assert.equal(approved.ok, true);
  assert.equal(calls, 1);
  assert.equal(run.state, 'executing');
  assert.equal(run.pendingApprovalToolId, '');
  const replay = await registryModule.executeAgentTool(registry, run, 'modify_file', { query: 'change' }, { userInitiated: true, approvalGrant: grant });
  assert.equal(replay.code, 'APPROVAL_REQUIRED', 'a scoped approval grant cannot be replayed');
  assert.equal(calls, 1);
});

test('approval grants are scoped to one run and one tool and expire after five minutes', async () => {
  const registry = registryModule.createToolRegistry([
    validTool({ id: 'modify_file', risk: 'modify' }),
    validTool({ id: 'send_message', risk: 'external_send' })
  ]);
  const run = makeRun(); runtime.transitionAgentRun(run, 'understanding'); runtime.transitionAgentRun(run, 'planning');
  assert.equal((await registryModule.executeAgentTool(registry, run, 'modify_file', { query: 'x' }, { userInitiated: true })).code, 'APPROVAL_REQUIRED');
  const wrongTool = await registryModule.executeAgentTool(registry, run, 'send_message', { query: 'x' }, { userInitiated: true });
  assert.equal(wrongTool.code, 'PENDING_APPROVAL_MISMATCH');
  const expired = await registryModule.executeAgentTool(registry, run, 'modify_file', { query: 'x' }, { userInitiated: true, approvalGrant: { runId: run.id, toolId: 'modify_file', grantId: 'grant-123456789012346', confirmed: true, confirmedAt: Date.now() - 301_000, argsHash: await registryModule.approvalArgsHash({ query: 'x' }) } });
  assert.equal(expired.code, 'APPROVAL_REQUIRED');
  const wrongRun = await registryModule.executeAgentTool(registry, run, 'modify_file', { query: 'x' }, { userInitiated: true, approvalGrant: { runId: 'agent-run-9999', toolId: 'modify_file', grantId: 'grant-123456789012347', confirmed: true, confirmedAt: Date.now(), argsHash: await registryModule.approvalArgsHash({ query: 'x' }) } });
  assert.equal(wrongRun.code, 'APPROVAL_REQUIRED');
});

test('credentials, arbitrary code and unrestricted network tools are always denied', async () => {
  const registry = registryModule.createToolRegistry([
    validTool({ id: 'read_secret', risk: 'credentials' }),
    validTool({ id: 'run_code', risk: 'arbitrary_code' }),
    validTool({ id: 'fetch_anywhere', risk: 'unrestricted_network' })
  ]);
  for (const id of ['read_secret', 'run_code', 'fetch_anywhere']) {
    const run = makeRun(); runtime.transitionAgentRun(run, 'understanding'); runtime.transitionAgentRun(run, 'planning');
    const result = await registryModule.executeAgentTool(registry, run, id, { query: 'x' }, { userInitiated: true, approvedToolIds: [id] });
    assert.equal(result.code, 'TOOL_RISK_BLOCKED');
  }
});

test('tool execution rejects unknown tools, malformed arguments, oversized results and step exhaustion', async () => {
  const registry = registryModule.createToolRegistry([validTool(), validTool({ id: 'big_output', handler: async () => 'x'.repeat(contracts.MAX_AGENT_TOOL_RESULT_BYTES + 1) })]);
  const run = makeRun(); runtime.transitionAgentRun(run, 'understanding'); runtime.transitionAgentRun(run, 'planning');
  assert.equal((await registryModule.executeAgentTool(registry, run, 'not_registered', {}, { userInitiated: true })).code, 'TOOL_NOT_FOUND');
  assert.equal((await registryModule.executeAgentTool(registry, run, 'read_context', { wrong: true }, { userInitiated: true })).code, 'INVALID_TOOL_ARGUMENTS');
  assert.equal((await registryModule.executeAgentTool(registry, run, 'big_output', { query: 'x' }, { userInitiated: true })).code, 'TOOL_RESULT_TOO_LARGE');
  run.stepCount = contracts.MAX_AGENT_STEPS;
  assert.equal((await registryModule.executeAgentTool(registry, run, 'read_context', { query: 'x' }, { userInitiated: true })).code, 'STEP_LIMIT_REACHED');
});

test('tool execution enforces timeout, cancellation and run-state constraints', async () => {
  const registry = registryModule.createToolRegistry([
    validTool({ id: 'slow_tool', timeoutMs: 100, handler: async () => new Promise(resolve => setTimeout(() => resolve({ ok: true }), 300)) })
  ]);
  const timed = makeRun(); runtime.transitionAgentRun(timed, 'understanding'); runtime.transitionAgentRun(timed, 'planning');
  assert.equal((await registryModule.executeAgentTool(registry, timed, 'slow_tool', { query: 'x' }, { userInitiated: true })).code, 'TOOL_TIMEOUT');
  const cancelled = makeRun(); runtime.transitionAgentRun(cancelled, 'understanding'); runtime.transitionAgentRun(cancelled, 'planning');
  const controller = new AbortController(); controller.abort();
  assert.equal((await registryModule.executeAgentTool(registry, cancelled, 'slow_tool', { query: 'x' }, { userInitiated: true, signal: controller.signal })).code, 'EXECUTION_CANCELLED');
  const invalid = makeRun();
  assert.equal((await registryModule.executeAgentTool(registry, invalid, 'slow_tool', { query: 'x' }, { userInitiated: true })).code, 'INVALID_RUN_STATE');
});

test('permission policy separates safe reads, approval-required changes and denied capabilities', () => {
  assert.equal(policy.evaluateToolPermission({ risk: 'read' }, { userInitiated: true }).allowed, true);
  assert.equal(policy.evaluateToolPermission({ risk: 'delete' }, { userInitiated: true }).code, 'APPROVAL_REQUIRED');
  assert.equal(policy.evaluateToolPermission({ risk: 'delete' }, { userInitiated: true, approved: true }).allowed, true);
  assert.equal(policy.evaluateToolPermission({ risk: 'credentials' }, { userInitiated: true, approved: true }).code, 'TOOL_RISK_BLOCKED');
  assert.equal(policy.evaluateToolPermission({ risk: 'arbitrary_code' }, { userInitiated: true, approved: true }).code, 'TOOL_RISK_BLOCKED');
  assert.equal(policy.evaluateToolPermission({ risk: 'sandbox_execution', requiresApproval: true }, { userInitiated: true }).code, 'APPROVAL_REQUIRED');
  assert.equal(policy.evaluateToolPermission({ risk: 'sandbox_execution', requiresApproval: true }, { userInitiated: true, approved: true }).allowed, true);
  assert.equal(policy.evaluateToolPermission({ risk: 'modify' }, { userInitiated: false, approved: true }).code, 'USER_INITIATION_REQUIRED');
  assert.equal(policy.evaluateToolPermission({ risk: 'read' }, { userInitiated: false }).code, 'USER_INITIATION_REQUIRED');
});

test('Agent memory contract keeps temporary chats separate and delegates persistence to existing explicit memory service', () => {
  const normal = memoryPolicy.createAgentMemoryContext({ messages: [{ role: 'system', content: 'x<user_memory_json>y' }], saved: true });
  assert.equal(normal.contextualMemoryAvailable, true);
  assert.equal(normal.explicitSaveCompleted, true);
  assert.equal(normal.persistence, 'existing_explicit_memory_service');
  assert.equal(normal.automaticLearning, false);
  const temporary = memoryPolicy.createAgentMemoryContext({ messages: [{ role: 'system', content: '<user_memory_json>x' }], saved: true }, { temporary: true });
  assert.equal(temporary.contextualMemoryAvailable, false);
  assert.equal(temporary.explicitSaveCompleted, false);
  assert.equal(temporary.persistence, 'disabled');
  assert.match(memoryPolicy.buildAgentMemoryInstruction(temporary), /گفتگو موقت است/);
});

test('chat provider wires the Agent system policy and response metadata without exposing tool execution to clients', async () => {
  const chat = await read('../worker/providers/chat.js');
  assert.match(chat, /prepareAgentTurn\)\(normalizedMessages, data\.context, \{ runId: requestId, memoryContext: agentMemoryContext \}\)/);
  assert.match(chat, /messages\.splice\(firstNonSystemIndex/);
  assert.match(chat, /x-sayrox-agent-specialist/);
  assert.match(chat, /x-sayrox-agent-state/);
  assert.match(chat, /agentSummary = \{ runId: requestId, specialist: agentTurn\.plan\.specialist/);
  assert.doesNotMatch(chat, /data\.approvedToolIds|data\.toolCalls|data\.agentTools/, 'approval and executable tools must not be client-controlled');
});
