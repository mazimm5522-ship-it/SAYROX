import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const app = await readFile(new URL('../app/15-agent-history.js', import.meta.url), 'utf8');
const nav = await readFile(new URL('../site/index.html', import.meta.url), 'utf8');
const settings = await readFile(new URL('../app/08-modules-settings.js', import.meta.url), 'utf8');
const worker = await readFile(new URL('../worker/providers/chat.js', import.meta.url), 'utf8');
assert.match(nav, /data-nav="agent-history"/);
assert.match(settings, /renderAgentHistoryPage\(root\)/);
assert.match(app, /agentHistoryRequest\('POST',\{action:'delete'/);
assert.match(app, /agentHistoryMore/);
assert.match(app, /event\.status==='cancelled'\?'لغو شد'/, 'user-denied approval is shown as cancelled rather than failed');
assert.match(app, /window\.confirm\('این اجرای Agent از تاریخچهٔ حساب حذف شود؟'\)/);
assert.match(app, /\?limit=50&offset=/);
assert.match(app, /action:'clear'/);
assert.match(app, /متن پیام‌ها، پاسخ‌ها، محتوای فایل‌ها و آرگومان ابزارها ذخیره نمی‌شوند/);
for (const [tool, label] of [['web_research', 'جست‌وجوی وب'], ['read_url', 'خواندن پیوند'], ['calculate', 'ماشین‌حساب'], ['current_time', 'زمان و تاریخ']]) {
  assert.match(app, new RegExp(`${tool}:'${label}'`), `history shows a readable name for ${tool}`);
}
assert.match(app, /AGENT_HISTORY_TOOLS\[event\.tool\]\|\|event\.tool/, 'unknown tool ids still render safely as escaped text');
assert.match(worker, /persistAgentHistory\('running'\)/);
assert.match(worker, /trackAgentStream/);
assert.match(worker, /data\?\.temporary === true/);
console.log('agent history UI/wiring tests: navigation, live history API, deletion controls, privacy and temporary-chat exclusion passed');
