import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

let source = await readFile(new URL('../site/_worker.js', import.meta.url), 'utf8');
source = source.replace('export default __worker;', 'globalThis.__sayrox = { __worker, __load };');
const context = vm.createContext({ crypto: webcrypto, Request, Response, Headers, URL, URLSearchParams, AbortController, AbortSignal, ReadableStream, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, Blob, setTimeout, clearTimeout, console, atob, btoa, Date, Math, JSON, Number, String, Boolean, Object, Array, Map, Set, RegExp, Error, TypeError, Promise, Intl });
vm.runInContext(source, context, { filename: 'site/_worker.js' });
const history = context.__sayrox.__load('worker/features/agent-history.js');
const runId = '123e4567-e89b-42d3-a456-426614174000';

{
  let saved;
  const env = { USAGE_ACCOUNT: { idFromName: name => name, get: () => ({ recordAgentRun: async record => { saved = record; return { ok: true }; } }) } };
  const result = await history.persistAgentRun(env, 'account-key', {
    runId, specialist: 'research', state: 'completed', createdAt: 100, updatedAt: 200,
    toolEvents: [{ tool: 'web_research', status: 'success' }, { tool: 'unexpected tool', status: 'failed', code: 'tool_error' }],
    durationMs: 150, stepCount: 2, researchMode: 'deep', researchStatus: 'completed', sourceCount: 4,
    prompt: 'MUST NOT BE PERSISTED', answer: 'MUST NOT BE PERSISTED', toolArguments: { secret: 'MUST NOT BE PERSISTED' }
  });
  assert.equal(result.ok, true);
  assert.equal(saved.runId, runId);
  assert.equal(saved.toolEvents.length, 2);
  assert.equal(saved.toolEvents[0].tool, 'web_research');
  assert.equal(saved.toolEvents[1].tool, 'unexpected tool');
  assert.equal('prompt' in saved, false);
  assert.equal('answer' in saved, false);
  assert.equal('toolArguments' in saved, false);
}

{
  const calls = [];
  const stub = {
    listAgentRuns: async (limit, offset) => { calls.push(['list', limit, offset]); return { ok: true, hasMore: offset < 100, runs: [{ runId, state: 'completed' }] }; },
    getAgentRun: async id => ({ ok: true, run: { runId: id, state: 'completed' } }),
    deleteAgentRun: async id => { calls.push(['delete', id]); return { ok: true }; },
    clearAgentRuns: async () => { calls.push(['clear']); return { ok: true }; }
  };
  const env = { USAGE_ACCOUNT: { idFromName: name => name, get: () => stub } };
  const session = { accountKey: 'account-key' };
  let response = await history.agentHistoryApi(new Request('https://sayrox.test/api/agent/runs?limit=20&offset=40', { headers: { origin: 'https://sayrox.test' } }), env, session, '/api/agent/runs');
  let body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.runs.length, 1);
  assert.deepEqual(calls[0], ['list', 20, 40]);
  assert.equal(body.hasMore, true);
  assert.equal(body.nextOffset, 41);

  response = await history.agentHistoryApi(new Request('https://sayrox.test/api/agent/runs', { method: 'POST', headers: { origin: 'https://sayrox.test', 'content-type': 'application/json' }, body: JSON.stringify({ action: 'delete', runId }) }), env, session, '/api/agent/runs');
  assert.equal(response.status, 200);
  assert.deepEqual(calls[1], ['delete', runId]);

  response = await history.agentHistoryApi(new Request('https://sayrox.test/api/agent/runs', { method: 'POST', headers: { origin: 'https://sayrox.test', 'content-type': 'application/json' }, body: JSON.stringify({ action: 'clear' }) }), env, session, '/api/agent/runs');
  assert.equal(response.status, 200);
  assert.deepEqual(calls[2], ['clear']);

  response = await history.agentHistoryApi(new Request('https://sayrox.test/api/agent/runs?limit=999&offset=9999', { headers: { origin: 'https://sayrox.test' } }), env, session, '/api/agent/runs');
  assert.equal(response.status, 200);
  assert.deepEqual(calls[3], ['list', 50, 100]);
}

{
  const env = { USAGE_ACCOUNT: { idFromName: name => name, get: () => ({}) } };
  const cross = await history.agentHistoryApi(new Request('https://sayrox.test/api/agent/runs', { headers: { origin: 'https://evil.test' } }), env, { accountKey: 'account-key' }, '/api/agent/runs');
  assert.equal(cross.status, 403);
  const missing = await history.agentHistoryApi(new Request('https://sayrox.test/api/agent/runs'), env, null, '/api/agent/runs');
  assert.equal(missing.status, 401);
}

console.log('agent history API tests: privacy-minimal records, authenticated access, same-origin guard and deletion passed');
