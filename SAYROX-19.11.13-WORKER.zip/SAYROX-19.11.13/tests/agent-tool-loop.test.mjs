import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

let source = await readFile(new URL('../site/_worker.js', import.meta.url), 'utf8');
source = source.replace('export default __worker;', 'globalThis.__sayrox = { __worker, __load };');
const sandbox = vm.createContext({
  crypto: webcrypto, Request, Response, Headers, URL, URLSearchParams,
  AbortController, AbortSignal, ReadableStream, TextEncoder, TextDecoder,
  Uint8Array, ArrayBuffer, Blob, setTimeout, clearTimeout, console,
  atob, btoa, Date, Math, JSON, Number, String, Boolean, Object, Array,
  Map, Set, RegExp, Error, TypeError, Promise, Intl
});
vm.runInContext(source, sandbox, { filename: 'site/_worker.js' });
const load = sandbox.__sayrox.__load;
const runtime = load('worker/agent/runtime.js');
const registryModule = load('worker/agent/tool-registry.js');
const loopModule = load('worker/agent/tool-loop.js');

function makeRun(id = 'agent-loop-test-001') {
  const run = runtime.createAgentRun(id);
  runtime.transitionAgentRun(run, 'understanding');
  runtime.transitionAgentRun(run, 'planning');
  runtime.transitionAgentRun(run, 'responding');
  return run;
}

function toolDefinition(overrides = {}) {
  return {
    id: 'lookup_info',
    specialist: 'research',
    description: 'Read-only test lookup',
    risk: 'read',
    timeoutMs: 1000,
    providerSchema: {
      type: 'function',
      function: {
        name: 'lookup_info',
        description: 'Lookup trusted test data',
        parameters: {
          type: 'object', additionalProperties: false,
          properties: { query: { type: 'string', minLength: 1, maxLength: 80 } },
          required: ['query']
        }
      }
    },
    validateArgs: args => Object.keys(args).length === 1 && typeof args.query === 'string' && args.query.length > 0,
    handler: async args => ({ found: true, query: args.query }),
    ...overrides
  };
}

// The model may perform a true multi-round tool loop: request a function, receive the result, then request another.
{
  const run = makeRun();
  const registry = registryModule.createToolRegistry([toolDefinition()]);
  const modelCalls = [];
  const toolResults = [];
  const agentEvents = [];
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Compare two independent facts.' }],
    async callModel(messages, toolChoice, tools) {
      modelCalls.push({ messages, toolChoice, tools });
      const count = messages.filter(message => message.role === 'tool').length;
      if (count === 0) return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
        { id: 'call_lookup_0001', type: 'function', function: { name: 'lookup_info', arguments: JSON.stringify({ query: 'first' }) } }
      ] } }] } };
      if (count === 1) return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
        { id: 'call_lookup_0002', type: 'function', function: { name: 'lookup_info', arguments: JSON.stringify({ query: 'second' }) } }
      ] } }] } };
      return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'Both checks completed.' } }] } };
    },
    onToolResult: value => toolResults.push(value),
    onEvent: value => agentEvents.push(value)
  });
  assert.equal(result.ok, true);
  assert.equal(result.rounds, 2);
  assert.equal(result.calls, 2);
  assert.equal(run.stepCount, 2);
  assert.equal(run.state, 'responding');
  assert.equal(modelCalls.length, 3);
  assert.equal(modelCalls[0].tools[0].function.name, 'lookup_info');
  assert.equal(modelCalls[0].toolChoice, 'auto');
  assert.deepEqual(toolResults.map(item => item.outcome.result.query), ['first', 'second']);
  assert.equal(result.providerResult.data.choices[0].message.content, 'Both checks completed.');
  assert.deepEqual(agentEvents.map(item => item.type), [
    'thinking', 'tool_requested', 'tool_started', 'tool_completed', 'verifying',
    'thinking', 'tool_requested', 'tool_started', 'tool_completed', 'verifying',
    'thinking', 'responding'
  ], 'lifecycle notifications must reflect actual model/tool execution order');
  assert.equal(agentEvents.filter(item => item.type === 'tool_started').length, 2);
  assert.ok(agentEvents.filter(item => item.type === 'tool_started').every(item => item.tool === 'lookup_info'));
}

// Invalid function arguments are returned to the model as a tool error and never reach the handler.
{
  let handlerCalls = 0;
  const run = makeRun('agent-loop-test-002');
  const registry = registryModule.createToolRegistry([toolDefinition({ handler: async () => { handlerCalls++; return { ok: true }; } })]);
  let secondMessage;
  let modelCallCount = 0;
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Use a lookup tool.' }],
    async callModel(messages) {
      modelCallCount++;
      if (modelCallCount === 1) return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
        { id: 'call_bad_args_0001', type: 'function', function: { name: 'lookup_info', arguments: '{invalid-json' } }
      ] } }] } };
      secondMessage = messages.at(-1);
      return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'The tool arguments were invalid.' } }] } };
    }
  });
  assert.equal(result.ok, true);
  assert.equal(handlerCalls, 0);
  assert.match(secondMessage.content, /INVALID_TOOL_ARGUMENTS/);
  assert.equal(run.stepCount, 0);
}

// Required search fails closed when the model does not return a function call.
{
  const run = makeRun('agent-loop-test-003');
  const registry = registryModule.createToolRegistry([toolDefinition()]);
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Search this.' }], toolChoice: 'required',
    async callModel() { return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'Here is an unsupported answer.' } }] } }; }
  });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'REQUIRED_TOOL_NOT_CALLED');
}

// Provider tool schemas are exposed only for enabled tools with a declared schema.
{
  const disabled = toolDefinition({ id: 'disabled_tool', enabled: false });
  const plain = toolDefinition({ id: 'plain_tool', providerSchema: undefined });
  const registry = registryModule.createToolRegistry([toolDefinition(), disabled, plain]);
  const schemas = loopModule.providerTools(registry);
  assert.equal(schemas.length, 1);
  assert.equal(schemas[0].function.name, 'lookup_info');
  assert.equal(registry.list().length, 3);
}

// An unrelated tool can never satisfy a required tool: the choice stays "required" until the named tool really ran.
{
  const other = toolDefinition({ id: 'other_tool', providerSchema: { type: 'function', function: { name: 'other_tool', description: 'Other', parameters: { type: 'object', additionalProperties: false, properties: {} } } }, validateArgs: args => Object.keys(args).length === 0, handler: async () => ({ ok: true }) });
  const registry = registryModule.createToolRegistry([toolDefinition(), other]);
  const choices = [];
  const run = makeRun('agent-loop-test-004');
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Always look it up.' }], toolChoice: 'required', requiredToolId: 'lookup_info',
    async callModel(messages, toolChoice) {
      choices.push(toolChoice);
      const count = messages.filter(message => message.role === 'tool').length;
      if (count === 0) return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [{ id: 'call_other_0001', type: 'function', function: { name: 'other_tool', arguments: '{}' } }] } }] } };
      if (count === 1) return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [{ id: 'call_lookup_0003', type: 'function', function: { name: 'lookup_info', arguments: JSON.stringify({ query: 'required' }) } }] } }] } };
      return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'Done.' } }] } };
    }
  });
  assert.equal(result.ok, true);
  assert.deepEqual(choices, ['required', 'required', 'auto']);
  assert.equal(result.calls, 2);
}
{
  const other = toolDefinition({ id: 'other_tool', providerSchema: { type: 'function', function: { name: 'other_tool', description: 'Other', parameters: { type: 'object', additionalProperties: false, properties: {} } } }, validateArgs: args => Object.keys(args).length === 0, handler: async () => ({ ok: true }) });
  const registry = registryModule.createToolRegistry([toolDefinition(), other]);
  const run = makeRun('agent-loop-test-005');
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Always look it up.' }], toolChoice: 'required', requiredToolId: 'lookup_info',
    async callModel(messages) {
      const count = messages.filter(message => message.role === 'tool').length;
      if (count === 0) return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [{ id: 'call_other_0002', type: 'function', function: { name: 'other_tool', arguments: '{}' } }] } }] } };
      return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'Skipped the required tool.' } }] } };
    }
  });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'REQUIRED_TOOL_NOT_CALLED', 'fail closed instead of reporting an unrelated tool as the required one');
}
// An unknown requiredToolId is ignored (it cannot make a healthy loop fail).
{
  const registry = registryModule.createToolRegistry([toolDefinition()]);
  const run = makeRun('agent-loop-test-006');
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Hi' }], requiredToolId: 'not_registered',
    async callModel() { return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'Hello.' } }] } }; }
  });
  assert.equal(result.ok, true);
}

console.log('Agent tool-loop tests passed: true multi-round function calling, strict argument validation, required-tool enforcement (including unrelated-tool rejection) and allowlisted schemas');

// Sensitive tool calls stop the model loop and return a confirmation payload; handlers remain untouched.
{
  const run = makeRun('agent-loop-approval-001');
  let handlerCalls = 0;
  let modelCalls = 0;
  const registry = registryModule.createToolRegistry([toolDefinition({
    id: 'sensitive_action', risk: 'create', requiresApproval: true,
    description: 'Perform a sensitive user-visible action',
    handler: async () => { handlerCalls++; return { changed: true }; }
  })]);
  const events = [];
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Do the action.' }],
    async callModel() {
      modelCalls++;
      return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
        { id: 'call_sensitive_0001', type: 'function', function: { name: 'sensitive_action', arguments: JSON.stringify({ query: 'exact operation' }) } }
      ] } }] } };
    },
    onEvent: event => events.push(event)
  });
  assert.equal(result.ok, true);
  assert.equal(result.pendingApproval.toolId, 'sensitive_action');
  assert.equal(result.pendingApproval.args.query, 'exact operation');
  assert.equal(handlerCalls, 0, 'sensitive handler is never called before user approval');
  assert.equal(modelCalls, 1, 'model loop pauses rather than pretending the tool executed');
  assert.equal(run.state, 'awaiting_approval');
  assert.ok(events.some(event => event.type === 'approval_required'));
  assert.equal(events.some(event => event.type === 'tool_started'), false);
}
