import assert from 'node:assert/strict';
import { readFile, readdir } from 'node:fs/promises';
import { join } from 'node:path';

const root = new URL('..', import.meta.url).pathname;
async function walk(dir) {
  const out = [];
  for (const entry of await readdir(join(root, dir), { withFileTypes: true })) {
    const path = `${dir}/${entry.name}`;
    if (entry.isDirectory()) { if (entry.name !== 'vendor') out.push(...await walk(path)); }
    else if (/\.(js|mjs|html|css|json|md)$/.test(entry.name)) out.push(path);
  }
  return out;
}
// A bare "XYNORA" (brand text) must not reappear; identifiers such as XYNORA_* env vars or xynora_session are fine.
const BRAND = /(?<![A-Za-z0-9_.\-/:$@])XYNORA(?![A-Za-z0-9_\-/$@])(?!\.[A-Za-z0-9_])(?!:[A-Za-z0-9_])/;
const files = [...await walk('site'), ...await walk('app'), ...await walk('worker'), ...await walk('docs'), 'README.md'];
const offenders = [];
for (const file of files) if (file !== 'docs/CHANGELOG.md' /* history may name the old brand */ && BRAND.test(await readFile(join(root, file), 'utf8'))) offenders.push(file);
assert.deepEqual(offenders, [], `old brand name found in: ${offenders.join(', ')}`);

const manifest = JSON.parse(await readFile(join(root, 'site/manifest.json'), 'utf8'));
assert.equal(manifest.short_name, 'SAYROX');
assert.match(manifest.name, /^SAYROX/);
assert.match(await readFile(join(root, 'site/index.html'), 'utf8'), /<title>SAYROX<\/title>/);

// Internal identifiers must stay stable so sessions and stored data survive the rename.
const app = await readFile(join(root, 'site/src/app.js'), 'utf8');
const worker = await readFile(join(root, 'site/_worker.js'), 'utf8');
assert.ok(app.includes("'xynora-chats'") && app.includes('xynora-images'), 'storage keys must not change');
assert.ok(worker.includes('xynora_session') && worker.includes('xynora-account:'), 'cookie and Durable Object names must not change');
console.log('Brand test passed: SAYROX everywhere visible, internal identifiers unchanged');
