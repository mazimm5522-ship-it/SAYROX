import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { webcrypto } from 'node:crypto';

const root = new URL('../', import.meta.url);
const read = path => readFile(new URL(path, root), 'utf8');
const builtWorker = await read('site/_worker.js');
const context = vm.createContext({
  crypto: webcrypto, Request, Response, Headers, URL, URLSearchParams,
  AbortController, AbortSignal, ReadableStream, TextEncoder, TextDecoder,
  Uint8Array, ArrayBuffer, Blob, setTimeout, clearTimeout, console,
  atob, btoa, Date, Math, JSON, Number, String, Boolean, Object, Array,
  Map, Set, RegExp, Error, TypeError, Promise, Intl
});
vm.runInContext(builtWorker.replace('export default __worker;', 'globalThis.__sayrox = { __worker, __load };'), context, { filename: 'site/_worker.js' });
const load = context.__sayrox.__load;
const secret = 'sayrox-sandbox-internal-secret-test-value-0123456789';
const accountKey = 'acct_'.padEnd(43, 'a');

async function verifySignedRequest(request, expectedSecret = secret) {
  const timestamp = request.headers.get('x-sayrox-timestamp');
  const signature = request.headers.get('x-sayrox-signature');
  const body = await request.clone().text();
  const key = await webcrypto.subtle.importKey('raw', new TextEncoder().encode(expectedSecret), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
  const raw = Uint8Array.from(atob(signature.replace(/-/g, '+').replace(/_/g, '/') + '='), c => c.charCodeAt(0));
  return webcrypto.subtle.verify('HMAC', key, raw, new TextEncoder().encode(`${timestamp}.${body}`));
}

test('Sandbox capability intent is explicit and does not confuse code writing with execution', async () => {
  const capability = load('worker/agent/capability-intent.js');
  const detect = text => capability.detectCapabilityIntent([{ role: 'user', content: text }]);
  assert.equal(detect('این کد Python را اجرا کن').executeCode, true);
  assert.equal(detect('لطفاً کد را تست کن').executeCode, true);
  assert.equal(detect('Run this code').executeCode, true);
  assert.equal(detect('Write a Python script').executeCode, false);
  assert.equal(detect('این کد را توضیح بده').executeCode, false);
});

test('Python tool stays disabled unless both the private service binding and shared secret exist', async () => {
  const factory = load('worker/agent/code-execution-tools.js').createPythonExecutionTool;
  assert.equal(factory({ env: {}, accountKey }), null);
  assert.equal(factory({ env: { CODE_SANDBOX: { fetch() {} }, CODE_SANDBOX_INTERNAL_SECRET: 'short' }, accountKey }), null);
  assert.equal(factory({ env: { CODE_SANDBOX: { fetch() {} }, CODE_SANDBOX_INTERNAL_SECRET: secret } }), null);
});

test('execute_python validates a bounded Python-only contract and sends an authenticated minimal payload', async () => {
  const factory = load('worker/agent/code-execution-tools.js').createPythonExecutionTool;
  const requests = [];
  const service = {
    async fetch(request) {
      requests.push(request.clone());
      assert.equal(await verifySignedRequest(request.clone()), true, 'request HMAC must cover timestamp and exact raw body');
      return Response.json({ ok: true, result: { stdout: '2\\n', stderr: '', exitCode: 0, outputTruncated: false, timedOut: false } });
    }
  };
  const tool = factory({ env: { CODE_SANDBOX: service, CODE_SANDBOX_INTERNAL_SECRET: secret }, accountKey });
  assert.equal(tool.id, 'execute_python');
  assert.equal(tool.risk, 'sandbox_execution');
  assert.equal(tool.requiresApproval, true);
  assert.equal(tool.validateArgs({ language: 'python', code: 'print(1 + 1)' }), true);
  assert.equal(tool.validateArgs({ language: 'javascript', code: 'console.log(1)' }), false);
  assert.equal(tool.validateArgs({ language: 'python', code: 'print(1)', extra: true }), false);
  assert.equal(tool.validateArgs({ language: 'python', code: ' '.repeat(5) }), false);
  assert.equal(tool.validateArgs({ language: 'python', code: 'x'.repeat(8_001) }), false);
  const output = await tool.handler({ language: 'python', code: 'print(1 + 1)' }, { runId: 'sayrox-run-12345678' });
  assert.equal(output.ok, true);
  assert.equal(output.exitCode, 0);
  assert.equal(output.stdout, '2\\n');
  assert.equal(requests.length, 1);
  const payload = JSON.parse(await requests[0].text());
  assert.deepEqual(Object.keys(payload).sort(), ['code', 'jobId', 'language', 'version']);
  assert.match(payload.jobId, /^[a-f0-9]{64}$/);
  assert.equal(payload.language, 'python');
  assert.equal(payload.code, 'print(1 + 1)');
  const second = await tool.handler({ language: 'python', code: 'print(2 + 2)' }, { runId: 'sayrox-run-12345678' });
  assert.equal(second.ok, true);
  const secondPayload = JSON.parse(await requests[1].text());
  assert.notEqual(secondPayload.jobId, payload.jobId, 'separate executions in one Agent run need separate one-use sandboxes');
  assert.equal(requests.length, 2);
  assert.equal(JSON.stringify(payload).includes(accountKey), false, 'account identifiers never cross the service boundary');
});

test('Sandbox execution tool fails closed on missing run identity, bad service response, and service outage', async () => {
  const factory = load('worker/agent/code-execution-tools.js').createPythonExecutionTool;
  const args = { language: 'python', code: 'print(1)' };
  const base = { CODE_SANDBOX_INTERNAL_SECRET: secret };
  const missingId = factory({ env: { ...base, CODE_SANDBOX: { fetch: async () => Response.json({}) } }, accountKey });
  assert.equal((await missingId.handler(args, {})).code, 'INVALID_EXECUTION_CONTEXT');
  const badResult = factory({ env: { ...base, CODE_SANDBOX: { fetch: async () => new Response('not json') } }, accountKey });
  assert.equal((await badResult.handler(args, { runId: 'sayrox-run-12345678' })).code, 'CODE_SANDBOX_FAILED');
  const outage = factory({ env: { ...base, CODE_SANDBOX: { fetch: async () => { throw new Error('offline'); } } }, accountKey });
  assert.equal((await outage.handler(args, { runId: 'sayrox-run-12345678' })).code, 'CODE_SANDBOX_UNAVAILABLE');
});

test('the one-use approval route executes the same Python tool only after an authenticated approval', async () => {
  const tickets = load('worker/agent/approval-tickets.js');
  const approval = load('worker/features/agent-approval.js');
  const runId = webcrypto.randomUUID();
  const args = { language: 'python', code: 'print(6 * 7)' };
  const sealed = await tickets.sealAgentApprovalTicket({ AUTH_SESSION_SECRET: secret }, {
    accountKey, runId, toolId: 'execute_python', callId: 'call_python_0001', args,
    risk: 'sandbox_execution', description: 'Run Python in isolated sandbox', specialist: 'coding'
  });
  const consumed = new Set();
  let sandboxCalls = 0;
  const usageStub = {
    async consumeAgentApproval(id, account, expiresAt, decision) {
      if (account !== accountKey || expiresAt <= Date.now() || consumed.has(id)) return { ok: false, code: 'AGENT_APPROVAL_REPLAYED' };
      consumed.add(id); return { ok: true, decision };
    },
    async recordAgentRun(record) { this.lastRun = record; return { ok: true }; }
  };
  const service = {
    async fetch(request) {
      sandboxCalls++;
      assert.equal(await verifySignedRequest(request.clone()), true);
      const payload = JSON.parse(await request.text());
      assert.equal(payload.code, args.code);
      assert.equal(payload.jobId.length, 64);
      return Response.json({ ok: true, result: { stdout: '42\\n', stderr: '', exitCode: 0, outputTruncated: false, timedOut: false } });
    }
  };
  const env = {
    AUTH_SESSION_SECRET: secret,
    CODE_SANDBOX_INTERNAL_SECRET: secret,
    CODE_SANDBOX: service,
    USAGE_ACCOUNT: { idFromName: () => 'account', get: () => usageStub }
  };
  const makeRequest = () => new Request('https://sayrox.test/api/agent/approval', {
    method: 'POST', headers: { 'content-type': 'application/json', origin: 'https://sayrox.test', 'sec-fetch-site': 'same-origin' },
    body: JSON.stringify({ ticket: sealed.token, decision: 'approve' })
  });
  const response = await approval.agentApprovalApi(makeRequest(), env, { accountKey });
  const data = await response.json();
  assert.equal(response.status, 200);
  assert.equal(data.ok, true);
  assert.equal(data.approved, true);
  assert.equal(data.toolId, 'execute_python');
  assert.equal(data.result.exitCode, 0);
  assert.equal(data.result.stdout, '42\\n');
  assert.equal(sandboxCalls, 1);
  assert.equal(usageStub.lastRun.state, 'completed');
  const replay = await approval.agentApprovalApi(makeRequest(), env, { accountKey });
  assert.equal(replay.status, 409);
  assert.equal(sandboxCalls, 1, 'one-use ticket prevents repeated execution');
});
