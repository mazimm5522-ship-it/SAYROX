import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');

class FakeElement {
  constructor(tag){this.tagName=tag;this.children=[];this.attributes={};this.listeners={};this.dataset={};this.className='';this.textContent='';this.hidden=false;this.value='';}
  append(...items){for(const item of items)this.appendChild(item)}
  appendChild(item){this.children.push(item);item.parentNode=this;return item}
  replaceChildren(...items){this.children=[];this.append(...items)}
  setAttribute(name,value){this.attributes[name]=String(value)}
  getAttribute(name){return this.attributes[name]??null}
  addEventListener(name,callback){this.listeners[name]=callback}
  focus(){this.focused=true}
  click(){return this.listeners.click?.({preventDefault(){},stopPropagation(){}})}
}
class FakeDocument { createElement(tag){return new FakeElement(tag)} }
function loadBrowserModules(){
  const window={document:new FakeDocument(),navigator:{clipboard:{writeText:async()=>{}}}};
  return read('site/src/core/code-workspace.js').then(async codeSource=>{
    const previewSource=await read('site/src/core/secure-html-preview.js');
    const context={window};
    vm.runInNewContext(previewSource,context,{filename:'secure-html-preview.js'});
    vm.runInNewContext(codeSource,context,{filename:'code-workspace.js'});
    return window;
  });
}
function findByClass(node,className){
  if(String(node.className||'').split(/\s+/).includes(className))return node;
  for(const child of node.children||[]){const found=findByClass(child,className);if(found)return found}
  return null;
}
function findButton(node,label){
  if(node.tagName==='button'&&node.textContent===label)return node;
  for(const child of node.children||[]){const found=findButton(child,label);if(found)return found}
  return null;
}

test('language aliases and tokenization recognize common syntax without interpreting source as HTML', async()=>{
  const api=(await loadBrowserModules()).SayroxCodeWorkspace;
  assert.equal(api.normalizeLanguage('js'),'javascript');
  assert.equal(api.normalizeLanguage('language-py'),'python');
  assert.equal(api.normalizeLanguage('HTM'),'html');
  const js=api.tokenizeLine('const answer = `SAYROX`; // note','javascript');
  assert.ok(js.some(token=>token.type==='keyword'&&token.value==='const'));
  assert.ok(js.some(token=>token.type==='string'&&token.value==='`SAYROX`'));
  assert.ok(js.some(token=>token.type==='comment'&&token.value==='// note'));
  const html=api.tokenizeLine('<h1 class="title">Hi</h1>','html');
  assert.ok(html.some(token=>token.type==='tag'&&token.value==='<h1'));
  assert.ok(html.some(token=>token.type==='attribute'&&token.value==='class'));
  assert.ok(html.some(token=>token.type==='string'&&token.value==='"title"'));
});

test('editor applies changes through callback and refreshes line numbers', async()=>{
  const api=(await loadBrowserModules()).SayroxCodeWorkspace;
  let saved='';
  const block=api.createBlock({language:'javascript',source:'const a = 1;',onSave:value=>{saved=value;return true}});
  assert.equal(block.dataset.lineCount,'1');
  findButton(block,'ویرایش').click();
  const editor=findByClass(block,'cw-editor');
  editor.value='const a = 1;\nconsole.log(a);';
  findButton(block,'ذخیره در گفتگو').click();
  assert.equal(saved,'const a = 1;\nconsole.log(a);');
  assert.equal(block.dataset.lineCount,'2');
  assert.equal(findByClass(block,'cw-editor-panel').hidden,true);
});

test('HTML preview uses an opaque sandbox and restrictive CSP', async()=>{
  const window=await loadBrowserModules();
  const block=window.SayroxCodeWorkspace.createBlock({language:'html',source:'<!doctype html><html><head><title>Test</title></head><body><h1>Hi</h1></body></html>'});
  findButton(block,'پیش‌نمایش HTML').click();
  const frame=findByClass(block,'cw-preview-frame');
  assert.ok(frame,'HTML block must create a preview iframe');
  assert.equal(frame.getAttribute('sandbox'),'allow-scripts');
  assert.equal(frame.getAttribute('referrerpolicy'),'no-referrer');
  assert.doesNotMatch(frame.getAttribute('sandbox'),/allow-same-origin/);
  assert.match(frame.srcdoc,/default-src 'none'/);
  assert.match(frame.srcdoc,/connect-src 'none'/);
  assert.match(frame.srcdoc,/script-src 'unsafe-inline'/);
});

test('shared preview builder rejects oversized HTML and studio reuses it', async()=>{
  const window=await loadBrowserModules();
  assert.throws(()=>window.SayroxSecureHtmlPreview.createPreviewDocument('x'.repeat(window.SayroxSecureHtmlPreview.maxHtmlChars+1)),/پیش‌نمایش HTML/);
  const studio=await read('site/src/features/files/studio.js');
  assert.match(studio,/SayroxSecureHtmlPreview\?\.createFrame/);
  assert.doesNotMatch(studio,/setAttribute\('sandbox','allow-scripts'\)/);
});

test('assistant code edit updates only the selected fenced block and rejects fence injection', async()=>{
  const source=await read('app/02-chats-navigation.js');
  const start=source.indexOf('function replaceAssistantCodeBlock(');
  const end=source.indexOf('function appendSafeMessageContent(',start);
  assert.ok(start>=0&&end>start);
  const context={};
  vm.runInNewContext(`${source.slice(start,end)}\nglobalThis.replaceBlock=replaceAssistantCodeBlock;`,context);
  const original='before\n```js\nconst a=1;\n```\nmiddle\n```html\n<h1>x</h1>\n```\nafter';
  const revised=context.replaceBlock(original,1,'<h1>updated</h1>');
  assert.match(revised,/```js\nconst a=1;\n```/);
  assert.match(revised,/```html\n<h1>updated<\/h1>\n```/);
  assert.match(revised,/^before[\s\S]*after$/);
  assert.equal(context.replaceBlock(original,0,'x\n```\ny'),null);
});

test('chat response renderer reuses the shared code workspace and offline shell caches its dependencies', async()=>{
  const [app,renderer,html,sw,css]=await Promise.all([read('app/02-chats-navigation.js'),read('site/src/core/response-renderer.js'),read('site/index.html'),read('site/sw.js'),read('site/src/styles/code-workspace.css')]);
  assert.match(app,/const renderer=window\.SayroxResponseRenderer/);
  assert.match(app,/renderRecent\(\);toast\('ویرایش کد در گفتگو ذخیره شد\.'/);
  assert.match(renderer,/root\.SayroxCodeWorkspace\?\.createBlock/);
  assert.match(renderer,/onSave: nextCode/);
  assert.match(html,/src\/core\/secure-html-preview\.js/);
  assert.match(html,/src\/core\/code-workspace\.js/);
  assert.match(html,/src\/core\/response-renderer\.js/);
  assert.match(html,/src\/styles\/code-workspace\.css/);
  for(const asset of ['/src/core/secure-html-preview.js','/src/core/code-workspace.js','/src/core/response-renderer.js','/src/styles/code-workspace.css','/src/styles/response-rendering.css'])assert.ok(sw.includes(asset),`${asset} must be cached offline`);
  assert.match(css,/\.cw-gutter/);
  assert.match(css,/\.cw-editor/);
  assert.match(css,/\.cw-preview-frame/);
});

console.log('Code workspace tests passed: syntax highlighting, editing, persistent fences, isolated HTML preview and offline wiring');
