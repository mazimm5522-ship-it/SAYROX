import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const read = path => readFile(resolve(root, path), 'utf8');

test('composer keeps the existing control IDs in a separate toolbar', async () => {
  const html = await read('site/index.html');
  for (const id of ['composer', 'promptInput', 'attachBtn', 'micBtn', 'voiceBtn', 'stopBtn']) {
    assert.equal((html.match(new RegExp(`id="${id}"`, 'g')) || []).length, 1, `${id} must exist exactly once`);
  }
  assert.match(html, /class="composer-toolbar"/);
  assert.match(html, /id="composerInstructions"/);
  assert.match(html, /id="toolMenu"[^>]*role="menu"/);
});

test('composer input exposes the send contract and 24k limit', async () => {
  const html = await read('site/index.html');
  const input = html.match(/<textarea[^>]*id="promptInput"[^>]*>/)?.[0] || '';
  assert.match(input, /maxlength="24000"/);
  assert.match(input, /enterkeyhint="send"/);
  assert.match(input, /dir="auto"/);
  assert.match(input, /aria-describedby="composerInstructions"/);
});

test('Enter does not interrupt Persian IME composition; Shift+Enter remains available', async () => {
  const source = await read('app/09-composer-menus.js');
  assert.match(source, /event\.key!=='Enter'\|\|event\.shiftKey\|\|event\.isComposing\|\|event\.keyCode===229/);
  assert.match(source, /addEventListener\('keydown',handleComposerKeydown\)/);
});

test('tool menu exposes and restores its expanded state', async () => {
  const html = await read('site/index.html');
  const source = await read('app/09-composer-menus.js');
  assert.match(html, /id="attachBtn"[^>]*aria-haspopup="menu"[^>]*aria-expanded="false"/);
  assert.match(source, /setAttribute\('aria-expanded',String\(open\)\)/);
  assert.match(source, /setAttribute\('aria-hidden',String\(!open\)\)/);
  assert.match(source, /if\(event\.key!=='Escape'\)return;[\s\S]*?toggleToolMenu\(false\)/);
  assert.match(html, /id="conversationModeMenu"[^>]*role="menu"/);
});

test('composer state is reflected accessibly while processing', async () => {
  const html = await read('site/index.html');
  const source = await read('app/05-send-message.js');
  assert.match(html, /id="composer" aria-busy="false"/);
  assert.match(source, /composer\.setAttribute\('aria-busy',String\(state\.busy\)\)/);
  assert.match(source, /composer\.dataset\.mode=state\.busy\?'busy':has\?'send':'voice'/);
});
