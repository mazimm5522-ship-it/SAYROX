import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');

async function loadSpreadsheetStack() {
  const window = {};
  const context = vm.createContext({
    window, TextEncoder, TextDecoder, Uint8Array, Uint32Array, ArrayBuffer, Blob,
    DecompressionStream: globalThis.DecompressionStream, Date, Math, String, Number,
    Set, Map, Object, Array, RegExp, Error, TypeError, Promise, parseInt,
    crypto: { randomUUID: () => 'spreadsheet-test-id' }
  });
  vm.runInContext(await read('site/src/features/files/policy.js'), context);
  vm.runInContext(await read('site/src/features/files/zip.js'), context);
  vm.runInContext(await read('site/src/features/files/spreadsheet.js'), context);
  vm.runInContext(await read('site/src/features/chat/spreadsheet-input.js'), context);
  return { window, context };
}

function namedBlob(blob, name) {
  Object.defineProperty(blob, 'name', { value: name, configurable: true });
  return blob;
}

test('CSV parser preserves quoted commas, escaped quotes, Persian text and delimiter detection', async () => {
  const { window } = await loadSpreadsheetStack();
  assert.equal(window.SayroxFilePolicy.formatBytes(1024), '1 کیلوبایت');
  const rows = window.SayroxSpreadsheet.parseCSV('نام;مقدار;یادداشت\r\n"آذر؛ شرکت";12;"گفت: ""سلام"""\r\nسارا;18;تهران');
  assert.deepEqual(JSON.parse(JSON.stringify(rows)), [
    ['نام', 'مقدار', 'یادداشت'],
    ['آذر؛ شرکت', '12', 'گفت: "سلام"'],
    ['سارا', '18', 'تهران']
  ]);
  assert.throws(() => window.SayroxSpreadsheet.parseCSV('"باز نشده,12'), /بسته نشده/);
});

test('existing XLSX engine round-trips multiple sheets, formulas as data and chart workbook parts', async () => {
  const { window } = await loadSpreadsheetStack();
  const source = [
    { name: 'فروش', rows: [['ماه', 'مبلغ'], ['فروردین', 120], ['اردیبهشت', 180], ['جمع', { formula: '=SUM(B2:B3)', value: 300 }]], chart: { type: 'bar', title: 'فروش ماهانه', categoryColumn: 0, seriesColumns: [1], headerRow: 0, dataStartRow: 1, dataEndRow: 2 } },
    { name: 'مشتریان', rows: [['نام', 'شهر'], ['سارا', 'تهران'], ['علی', 'تبریز']] }
  ];
  const blob = await window.SayroxSpreadsheet.createXlsx(source);
  const parsed = await window.SayroxSpreadsheet.readXlsxWorkbook(blob);
  assert.equal(parsed.length, 2);
  assert.equal(parsed[0].name, 'فروش');
  assert.equal(parsed[0].rows[1][0], 'فروردین');
  assert.deepEqual(JSON.parse(JSON.stringify(parsed[0].rows[3][1])), { formula: 'SUM(B2:B3)', value: 300 });
  assert.equal(parsed[1].rows[1][0], 'سارا');
});

test('spreadsheet chat intake extracts CSV and XLSX locally, keeps only bounded text and never stores binaries', async () => {
  const { window } = await loadSpreadsheetStack();
  const csvText = 'نام,مبلغ\nسارا,120\nعلی,180';
  const csvFile = { name: 'فروش.csv', size: new TextEncoder().encode(csvText).length, text: async () => csvText };
  const csv = await window.SayroxChatSpreadsheetInput.prepareSpreadsheetFile(csvFile);
  assert.equal(csv.kind, 'spreadsheet');
  assert.equal(csv.extension, 'csv');
  assert.match(csv.text, /برگه: CSV/);
  assert.match(csv.text, /سارا \| 120/);
  assert.equal(Object.hasOwn(csv, 'file'), false);

  const workbook = await window.SayroxSpreadsheet.createXlsx([{ name: 'گزارش', rows: [['عنوان', 'مقدار'], ['درآمد', 500]] }]);
  const xlsx = await window.SayroxChatSpreadsheetInput.prepareSpreadsheetFile(namedBlob(workbook, 'گزارش.xlsx'));
  assert.equal(xlsx.extension, 'xlsx');
  assert.equal(xlsx.sheetCount, 1);
  assert.match(xlsx.text, /درآمد \| 500/);

  const macroNamed = await window.SayroxChatSpreadsheetInput.prepareSpreadsheetFile(namedBlob(workbook, 'قالب.xlsm'));
  assert.equal(macroNamed.macrosIgnored, true);
  assert.throws(() => window.SayroxChatSpreadsheetInput.validateSpreadsheetFile({ name: 'قدیمی.xls', size: 10 }), /پسوند \.xls پشتیبانی نمی‌شود/);
  assert.throws(() => window.SayroxChatSpreadsheetInput.validateSpreadsheetFile({ name: 'بزرگ.xlsx', size: 20 * 1024 * 1024 + 1 }), /۲۰ مگابایت/);
});

test('spreadsheet chat text is hard-capped at 60k characters and reports truncation', async () => {
  const { window } = await loadSpreadsheetStack();
  const rows = Array.from({ length: 300 }, (_, index) => [`ردیف-${index}`, 'X'.repeat(500)]);
  const result = window.SayroxChatSpreadsheetInput.workbookText([{ name: 'طولانی', rows }]);
  assert.equal(result.truncated, true);
  assert.ok(result.text.length <= 60000, `text exceeded cap: ${result.text.length}`);
  assert.ok(result.sourceChars > result.text.length);
  assert.match(result.text, /ادامه‌ی داده‌ها/);
});

test('XLSX parser accepts package-absolute worksheet relationships', async () => {
  const { window } = await loadSpreadsheetStack();
  const blob = await window.SayroxZip.createZip([
    { path: 'xl/workbook.xml', text: '<workbook xmlns:r="urn:test"><sheets><sheet name="Sheet1" sheetId="1" r:id="rId1"/></sheets></workbook>' },
    { path: 'xl/_rels/workbook.xml.rels', text: '<Relationships><Relationship Id="rId1" Target="/xl/worksheets/sheet1.xml"/></Relationships>' },
    { path: 'xl/worksheets/sheet1.xml', text: '<worksheet><sheetData><row r="1"><c r="A1" t="inlineStr"><is><t>سلام</t></is></c></row></sheetData></worksheet>' }
  ]);
  const parsed = await window.SayroxSpreadsheet.readXlsxWorkbook(blob);
  assert.equal(parsed[0].rows[0][0], 'سلام');
});

test('XLSX relationship traversal and unsafe formula creation are rejected', async () => {
  const { window } = await loadSpreadsheetStack();
  await assert.rejects(
    window.SayroxZip.createZip([{ path: 'xl/workbook.xml', text: '<workbook><sheets><sheet name="Bad" sheetId="1" r:id="rId1"/></sheets></workbook>' }, { path: 'xl/_rels/workbook.xml.rels', text: '<Relationships><Relationship Id="rId1" Target="../../outside.xml"/></Relationships>' }]).then(blob => window.SayroxSpreadsheet.readXlsxWorkbook(blob)),
    /از محدوده‌ی فایل خارج می‌شود/
  );
  await assert.rejects(window.SayroxSpreadsheet.createXlsx([['عنوان', { formula: '=HYPERLINK("https://bad.example")', value: 'باز' }]]), /فرمول Excel مجاز نیست/);
});

test('chat document context keeps newest documents, bounds aggregate text and reports missing session payloads', async () => {
  const window = {};
  const context = vm.createContext({ window, TextEncoder, Map, Set, String, Array, Object, Number });
  vm.runInContext(await read('site/src/features/chat/message-payload.js'), context);
  const messages = [
    { id: 'old', role: 'user', documents: [{ name: 'old.pdf' }] },
    { id: 'new', role: 'user', documents: [{ name: 'new.xlsx', kind: 'spreadsheet', extension: 'xlsx' }] },
    { id: 'missing', role: 'user', documents: [{ name: 'missing.csv', kind: 'spreadsheet', extension: 'csv' }] }
  ];
  const map = new Map([
    ['old', [{ kind: 'pdf', name: 'old.pdf', text: 'old text' }]],
    ['new', [{ kind: 'spreadsheet', extension: 'xlsx', name: 'new.xlsx', text: 'N'.repeat(70000) }]]
  ]);
  const result = window.SayroxChatPayload.buildDocumentContext(messages, map);
  assert.equal(result.documents.length, 2);
  assert.equal(result.documents[0].name, 'old.pdf');
  assert.equal(result.documents[1].name, 'new.xlsx');
  assert.equal(result.documents[1].text.length, 60000);
  assert.equal(result.unavailableCount, 1);
  const limited = window.SayroxChatPayload.buildDocumentContext(messages, map, 1, 5);
  assert.equal(limited.documents.length, 1);
  assert.equal(limited.documents[0].text.length, 5);
  assert.equal(limited.omittedCount, 2);
});

test('Excel chat wiring reuses the existing parser and sends extracted document text only', async () => {
  const html = await read('site/index.html');
  const sw = await read('site/sw.js');
  const menu = await read('app/09-composer-menus.js');
  const send = await read('app/05-send-message.js');
  const state = await read('app/01-core-state.js');
  const render = await read('app/04-message-rendering.js');
  const helper = await read('site/src/features/chat/spreadsheet-input.js');
  const worker = await read('worker/providers/chat.js');
  assert.match(html, /\.xlsx,.xlsm,.csv/);
  assert.match(html, /src="src\/features\/chat\/spreadsheet-input\.js"/);
  assert.match(sw, /\/src\/features\/chat\/spreadsheet-input\.js/);
  assert.match(helper, /window\.SayroxSpreadsheet\?\.readXlsxWorkbook/);
  assert.match(menu, /SayroxChatSpreadsheetInput\.prepareSpreadsheetFile/);
  assert.match(send, /buildDocumentContext\(chat\.messages,documentTextPayloadsByMessage\)/);
  assert.match(send, /documents:documentContext\.documents/);
  assert.match(state, /const documentTextPayloadsByMessage=new Map\(\)/);
  assert.match(render, /message-attachment-document/);
  assert.match(worker, /فرمول‌های صفحه‌گسترده در این مسیر اجرا یا محاسبه نمی‌شوند/);
  assert.match(worker, /داده‌ی بیرونی و غیرقابل‌اعتماد/);
  assert.equal((menu.match(/SayroxChatSpreadsheetInput\.prepareSpreadsheetFile\(file\)/g) || []).length, 1);
  assert.doesNotMatch(send, /text:document\.text/);
});
