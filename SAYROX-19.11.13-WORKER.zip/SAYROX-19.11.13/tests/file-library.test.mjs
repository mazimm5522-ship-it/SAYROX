import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';
import { readFile } from 'node:fs/promises';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');

class FakeFile extends Blob {
  constructor(parts, name, options = {}) { super(parts, options); this.name = name; this.lastModified = options.lastModified || 1_700_000_000_000; }
}
class FakeRequest {}
class FakeTransaction {
  constructor(database, mode) { this.database = database; this.mode = mode; this.pending = 0; this.finished = false; this.aborted = false; this.error = null; }
  objectStore() {
    const tx = this;
    const schedule = (operation) => {
      const request = new FakeRequest(); tx.pending++;
      queueMicrotask(() => {
        if (tx.aborted) return;
        try { request.result = operation(); request.onsuccess?.({ target: request }); }
        catch (error) { request.error = error; tx.error = error; request.onerror?.({ target: request }); tx.abort(); }
        finally { tx.pending--; tx.maybeComplete(); }
      });
      return request;
    };
    return {
      getAll: () => schedule(() => [...tx.database.records.values()]),
      get: id => schedule(() => tx.database.records.get(id)),
      add: record => schedule(() => { if (tx.database.records.has(record.id)) throw new Error('duplicate key'); tx.database.records.set(record.id, record); return record.id; }),
      put: record => schedule(() => { tx.database.records.set(record.id, record); return record.id; }),
      delete: id => schedule(() => tx.database.records.delete(id))
    };
  }
  maybeComplete() {
    if (this.pending || this.finished || this.aborted) return;
    setTimeout(() => { if (!this.pending && !this.finished && !this.aborted) { this.finished = true; this.oncomplete?.(); } }, 0);
  }
  abort() { if (this.aborted || this.finished) return; this.aborted = true; setTimeout(() => this.onabort?.(), 0); }
}
class FakeDatabase {
  constructor() { this.records = new Map(); this.objectStoreNames = { contains: name => name === 'files' }; }
  createObjectStore() { return { createIndex() {} }; }
  transaction(_store, mode) { return new FakeTransaction(this, mode); }
  close() {}
}
function fakeIndexedDB() {
  let database = null;
  return { open() {
    const request = new FakeRequest();
    setTimeout(() => {
      const isNew = !database;
      if (!database) database = new FakeDatabase();
      request.result = database;
      if (isNew) request.onupgradeneeded?.({ target: request });
      request.onsuccess?.({ target: request });
    }, 0);
    return request;
  }};
}
async function loadLibrary() {
  const events = [];
  class FakeCustomEvent extends Event { constructor(type, init = {}) { super(type); this.detail = init.detail; } }
  const window = new EventTarget();
  window.SayroxFilePolicy = {};
  const context = vm.createContext({
    window, indexedDB: fakeIndexedDB(), File: FakeFile, Blob, Event, CustomEvent: FakeCustomEvent,
    TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, Set, Map, Date, Math, Number, String,
    Array, Object, RegExp, Error, TypeError, Promise, JSON, crypto: webcrypto
  });
  vm.runInContext(await read('site/src/features/files/policy.js'), context);
  vm.runInContext(await read('site/src/features/files/library-store.js'), context);
  window.addEventListener('sayrox:file-library-change', event => events.push(event.detail.type));
  const file = (name, body = 'hello', type = '') => new FakeFile([body], name, { type, lastModified: 1_700_000_000_000 });
  return { api: window.SayroxFileLibrary, file, events };
}

test('file library persists real file blobs and returns metadata without exposing binary data in list()', async () => {
  const { api, file } = await loadLibrary();
  const original = file('report.pdf', '%PDF-test', 'application/pdf');
  const saved = await api.add(original, { source: 'chat' });
  assert.equal(saved.name, 'report.pdf');
  assert.equal(saved.category, 'pdf');
  assert.equal(saved.source, 'chat');
  const listed = await api.list();
  assert.equal(listed.length, 1);
  assert.equal(Object.hasOwn(listed[0], 'file'), false);
  const restored = await api.get(saved.id);
  assert.equal(restored.file.name, 'report.pdf');
  assert.equal(await restored.file.text(), '%PDF-test');
  assert.equal((await api.all()).length, 1);
});

test('file library deduplicates the same local file and tracks storage usage', async () => {
  const { api, file } = await loadLibrary();
  const original = file('notes.txt', 'same text', 'text/plain');
  const first = await api.add(original);
  const second = await api.add(original, { source: 'studio' });
  assert.equal(first.id, second.id);
  assert.equal(second.duplicate, true);
  const stats = await api.stats();
  assert.equal(stats.count, 1);
  assert.equal(stats.bytes, original.size);
});

test('file library does not collapse different content with identical name, size and timestamp', async () => {
  const { api, file } = await loadLibrary();
  const first = await api.add(file('report.txt', 'aaaa', 'text/plain'));
  const second = await api.add(file('report.txt', 'bbbb', 'text/plain'));
  assert.notEqual(first.id, second.id);
  assert.equal((await api.list()).length, 2);
  const third = await api.add(file('report.txt', 'aaaa', 'text/plain'));
  assert.equal(third.id, first.id);
  assert.equal(third.duplicate, true);
});

test('file library renames without changing extension and prevents path traversal', async () => {
  const { api, file } = await loadLibrary();
  const saved = await api.add(file('report.xlsx', 'binary', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'));
  const renamed = await api.rename(saved.id, 'گزارش نهایی.xlsx');
  assert.equal(renamed.name, 'گزارش نهایی.xlsx');
  await assert.rejects(api.rename(saved.id, 'malicious.zip'), /پسوند قابل تغییر نیست/);
  await assert.rejects(api.rename(saved.id, '../outside.xlsx'), /نام فایل معتبر نیست/);
  await assert.rejects(api.rename(saved.id, '   '), /نام فایل نمی‌تواند خالی باشد/);
  assert.equal((await api.get(saved.id)).file.name, 'گزارش نهایی.xlsx');
  const duplicateAfterRename = await api.add(file('گزارش نهایی.xlsx', 'binary', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'));
  assert.equal(duplicateAfterRename.id, saved.id);
  assert.equal(duplicateAfterRename.duplicate, true);
});

test('file library validates image types, file sizes, extension policy and total quota', async () => {
  const { api, file } = await loadLibrary();
  const image = await api.add(file('photo.png', 'image-bytes', 'image/png'));
  assert.equal(image.category, 'image');
  await assert.rejects(api.add(file('script.exe', 'bad', 'application/octet-stream')), /پشتیبانی نمی‌شود/);
  await assert.rejects(api.add(file('wrong.png', 'bad', 'image/svg+xml')), /نوع تصویر/);
  await assert.rejects(api.add({ name: 'huge.pdf', size: 20 * 1024 * 1024 + 1 }), /۲۰ مگابایت/);
});

test('file library enforces its item-count ceiling without partial records', async () => {
  const { api, file } = await loadLibrary();
  for (let index = 0; index < 100; index++) await api.add(file(`item-${index}.txt`, `content-${index}`, 'text/plain'));
  await assert.rejects(api.add(file('overflow.txt', 'overflow', 'text/plain')), /حداکثر ۱۰۰ فایل/);
  assert.equal((await api.stats()).count, 100);
});

test('file library remove is scoped to selected IDs and broadcasts changes', async () => {
  const { api, file, events } = await loadLibrary();
  const one = await api.add(file('one.txt', 'one', 'text/plain'));
  const two = await api.add(file('two.txt', 'two', 'text/plain'));
  const removed = await api.remove([one.id]);
  assert.equal(removed, 1);
  assert.equal(await api.get(one.id), null);
  assert.equal((await api.get(two.id)).name, 'two.txt');
  assert.deepEqual(events, ['added', 'added', 'removed']);
});

test('the Library page, Studio, chat picker and offline shell share the same local file store', async () => {
  const [html, sw, app, modules, studio, chat, css, docs] = await Promise.all([
    read('site/index.html'), read('site/sw.js'), read('app/09-composer-menus.js'), read('app/08-modules-settings.js'),
    read('site/src/features/files/studio.js'), read('app/09-composer-menus.js'), read('site/src/styles/file-studio.css'), read('docs/FILE-LIBRARY.md')
  ]);
  assert.match(html, /src="src\/features\/files\/library-store\.js"/);
  assert.match(html, /src="src\/features\/files\/library\.js"/);
  assert.match(sw, /\/src\/features\/files\/library-store\.js/);
  assert.match(sw, /\/src\/features\/files\/library\.js/);
  assert.match(modules, /SayroxFileLibraryUI\.render/);
  assert.match(modules, /SayroxFileLibraryUI\?\.destroy/);
  const libraryUi = await read('site/src/features/files/library.js');
  assert.match(libraryUi, /activeInstance\?\.destroy/);
  assert.match(modules, /SayroxFileStudioBridge\?\.openFile/);
  assert.match(modules, /SayroxChatFileBridge\?\.attachFromLibrary/);
  assert.match(studio, /library\.add\(file,\{source:'studio'\}\)/);
  assert.match(studio, /library\.all\(\)/);
  assert.match(chat, /rememberFileInLibrary\(file\)/);
  assert.match(chat, /attachFromLibrary/);
  assert.match(css, /\.sayrox-library/);
  assert.match(docs, /IndexedDB/);
  assert.doesNotMatch(docs, /Cloudflare D1/);
});
