import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

let source = await readFile(new URL('../site/_worker.js', import.meta.url), 'utf8');
source = source.replace('export default __worker;', 'globalThis.__xynoraBundle = { __worker, __load };');
const context = vm.createContext({
  crypto: webcrypto, fetch: globalThis.fetch, Request, Response, Headers, URL, URLSearchParams,
  AbortController, AbortSignal, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, Blob,
  setTimeout, clearTimeout, console, atob, btoa, WebSocketPair: undefined,
  Date, Math, JSON, Number, String, Boolean, Object, Array, Map, Set, RegExp, Error, TypeError, Promise, Intl
});
vm.runInContext(source, context, { filename: '_worker.js' });
const load = context.__xynoraBundle.__load;
const accountKey = 'a'.repeat(43);
const SECRET = 'k'.repeat(40);

function fakeQuota({ allow = true, current = null } = {}) {
  const calls = { reserve: [], commit: [], release: [] };
  const usage = {
    async reserveUsageBatch(requestId, items, subscription) { calls.reserve.push({ requestId, items, subscription }); return allow ? { ok: true } : { ok: false, code: 'QUOTA_EXCEEDED', feature: items[0].feature, used: 1, limit: 1, remaining: 0, resetAt: Date.now() + 3600000, tier: 'free' }; },
    async commitUsage(requestId) { calls.commit.push(requestId); return { ok: true }; },
    async releaseUsage(requestId) { calls.release.push(requestId); return { ok: true }; }
  };
  const billing = { async getSubscriptionSnapshot() { return { current }; } };
  return { USAGE_ACCOUNT: { idFromName: n => n, get: () => usage }, BILLING_ACCOUNT: { idFromName: n => n, get: () => billing }, calls };
}
const jsonRequest = (path, body, init = {}) => new Request(`https://xynora.test${path}`, { method: 'POST', headers: { 'content-type': 'application/json', ...(init.headers || {}) }, body: JSON.stringify(body) });
const PNG = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==';
const providerImage = (url = PNG, content = 'Here is your image') => new Response(JSON.stringify({ choices: [{ message: { content, images: [{ type: 'image_url', image_url: { url } }] } }] }), { status: 200, headers: { 'content-type': 'application/json' } });

// ───────── image generation ─────────
const { imageGenerate, imageConfig } = load('worker/features/images.js');
const imageEnv = (q, extra = {}) => ({ ...q, OPENROUTER_API_KEY: 'or-key', OPENROUTER_IMAGE_MODEL: 'google/gemini-2.5-flash-image', ...extra });
{
  const q = fakeQuota(); let sent;
  context.fetch = async (url, init) => { sent = { url, init, body: JSON.parse(init.body) }; return providerImage(); };
  const response = await imageGenerate(jsonRequest('/api/images/generate', { prompt: 'یک گربهٔ فضانورد', ratio: '16:9' }), imageEnv(q), { accountKey });
  const data = await response.json();
  assert.equal(response.status, 200);
  assert.equal(data.ok, true);
  assert.equal(data.image.mimeType, 'image/png');
  assert.equal(data.image.dataUrl, PNG);
  assert.equal(data.ratio, '16:9');
  assert.equal(data.model, 'google/gemini-2.5-flash-image');
  assert.equal(sent.url, 'https://openrouter.ai/api/v1/chat/completions');
  assert.deepEqual(Array.from(sent.body.modalities), ['image', 'text']);
  assert.match(sent.body.messages[0].content, /گربهٔ فضانورد[\s\S]*16:9/);
  assert.equal(sent.init.headers.authorization, 'Bearer or-key');
  assert.equal(JSON.stringify(q.calls.reserve.map(r => r.items)), JSON.stringify([[{ feature: 'image_generation', amount: 1 }]]));
  assert.equal(q.calls.commit.length, 1);
  assert.equal(q.calls.release.length, 0);
}
{ // unsupported ratio falls back to 1:1; provider error releases the reservation
  const q = fakeQuota(); let body;
  context.fetch = async (url, init) => { body = JSON.parse(init.body); return new Response('{}', { status: 500 }); };
  const response = await imageGenerate(jsonRequest('/api/images/generate', { prompt: 'a red car', ratio: '5:1' }), imageEnv(q), { accountKey });
  assert.equal(response.status, 502);
  assert.match(body.messages[0].content, /1:1/);
  assert.equal(q.calls.commit.length, 0);
  assert.equal(q.calls.release.length, 1, 'failed generation must not consume quota');
}
{ // no image / non-image data URL / svg are rejected and released
  for (const reply of [providerImage('https://evil.test/a.png'), providerImage('data:image/svg+xml;base64,PHN2Zz48L3N2Zz4='), new Response(JSON.stringify({ choices: [{ message: { content: 'sorry' } }] }), { status: 200 })]) {
    const q = fakeQuota(); context.fetch = async () => reply.clone();
    const response = await imageGenerate(jsonRequest('/api/images/generate', { prompt: 'a blue house' }), imageEnv(q), { accountKey });
    assert.equal(response.status, 422);
    assert.equal(q.calls.release.length, 1);
    assert.equal(q.calls.commit.length, 0);
  }
}
{ // not configured → 503 before any quota is touched; quota denied → 429 before any provider call
  const q = fakeQuota(); let called = false; context.fetch = async () => { called = true; return providerImage(); };
  let response = await imageGenerate(jsonRequest('/api/images/generate', { prompt: 'a tree' }), { ...q, OPENROUTER_API_KEY: 'k' }, { accountKey });
  assert.equal(response.status, 503); assert.equal((await response.json()).code, 'IMAGES_UNAVAILABLE'); assert.equal(q.calls.reserve.length, 0);
  const denied = fakeQuota({ allow: false });
  response = await imageGenerate(jsonRequest('/api/images/generate', { prompt: 'a tree' }), imageEnv(denied), { accountKey });
  assert.equal(response.status, 429); assert.equal(called, false);
  assert.equal((await imageGenerate(jsonRequest('/api/images/generate', { prompt: 'x' }), imageEnv(fakeQuota()), { accountKey })).status, 400);
  assert.equal((await imageGenerate(new Request('https://xynora.test/api/images/generate'), imageEnv(fakeQuota()), { accountKey })).status, 405);
  assert.equal(imageConfig({ OPENROUTER_API_KEY: 'k', OPENROUTER_IMAGE_MODEL: 'bad model!' }).ready, false);
}

// ───────── scheduled tasks: browser API ─────────
const { tasksApi, tasksReady } = load('worker/features/tasks.js');
function fakeTasks(overrides = {}) {
  const calls = [];
  const stub = new Proxy({}, { get: (_, method) => async (...args) => { calls.push({ method, args }); return overrides[method] ? overrides[method](...args) : { ok: true }; } });
  return { binding: { idFromName: n => n, get: () => stub }, calls };
}
{
  assert.equal(tasksReady({}), false);
  assert.equal(tasksReady({ TASKS_ACCOUNT: {}, TASKS_INTERNAL_SECRET: 'short' }), false);
  const t = fakeTasks({ listTasks: () => ({ ok: true, tasks: [], runs: [], unseen: 2 }), createTask: (input, limit) => limit < 3 ? { ok: false, code: 'TASK_LIMIT', limit } : { ok: true, task: { id: crypto.randomUUID() } } });
  const q = fakeQuota();
  const env = { ...q, TASKS_ACCOUNT: t.binding, TASKS_INTERNAL_SECRET: SECRET };
  const session = { accountKey };
  let response = await tasksApi(new Request('https://xynora.test/api/tasks'), env, session, '/api/tasks');
  let data = await response.json();
  assert.deepEqual([data.tier, data.limit, data.unseen], ['free', 1, 2]);
  const body = { title: 'خبر', prompt: 'اخبار را خلاصه کن', schedule: { type: 'daily', time: '09:00' }, useSearch: true };
  response = await tasksApi(jsonRequest('/api/tasks', body), env, session, '/api/tasks');
  assert.equal(response.status, 409, 'free plan allows one task');
  assert.equal(t.calls.find(c => c.method === 'createTask').args[1], 1);
  const pro = { ...env, ...fakeQuota({ current: { status: 'active', tier: 'pro' } }), TASKS_ACCOUNT: t.binding, TASKS_INTERNAL_SECRET: SECRET };
  response = await tasksApi(jsonRequest('/api/tasks', body), pro, session, '/api/tasks');
  assert.equal(response.status, 200);
  const create = t.calls.filter(c => c.method === 'createTask').pop();
  assert.equal(create.args[1], 30);
  assert.equal(create.args[2], accountKey, 'server passes the authenticated account, never a client value');
  assert.equal(create.args[0].useSearch, true);
  assert.equal((await tasksApi(jsonRequest('/api/tasks/delete', { id: 'nope' }), env, session, '/api/tasks/delete')).status, 400);
  assert.equal((await tasksApi(jsonRequest('/api/tasks/toggle', { id: crypto.randomUUID(), enabled: true }), env, session, '/api/tasks/toggle')).status, 200);
  assert.equal((await tasksApi(jsonRequest('/api/tasks/seen', {}), env, session, '/api/tasks/seen')).status, 200);
  assert.equal((await tasksApi(new Request('https://xynora.test/api/tasks/delete'), env, session, '/api/tasks/delete')).status, 405);
  assert.equal((await tasksApi(new Request('https://xynora.test/api/tasks'), { ...q }, session, '/api/tasks')).status, 503, 'fails closed without the Scheduler binding');
}

// ───────── scheduled tasks: signed internal run ─────────
const { taskRunInternal } = load('worker/features/tasks.js');
async function signed(body, { secret = SECRET, timestamp = String(Date.now()) } = {}) {
  const raw = JSON.stringify(body);
  const key = await webcrypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const mac = Buffer.from(await webcrypto.subtle.sign('HMAC', key, new TextEncoder().encode(`${timestamp}.${raw}`))).toString('hex');
  return new Request('https://xynora.test/api/internal/task-run', { method: 'POST', headers: { 'content-type': 'application/json', 'x-xy-timestamp': timestamp, 'x-xy-signature': mac }, body: raw });
}
const chatEnv = (q, t) => ({ ...q, TASKS_ACCOUNT: t.binding, TASKS_INTERNAL_SECRET: SECRET, GAPGPT_API_KEY: 'gap-key', GAPGPT_DEFAULT_MODEL: 'test-model', TAVILY_API_KEY: 'tv-key' });
const completion = text => new Response(JSON.stringify({ choices: [{ message: { content: text } }] }), { status: 200, headers: { 'content-type': 'application/json' } });
function scheduledAgentFetch({ searchStatus = 200, finalText = 'گزارش امروز' } = {}) {
  const calls = { chat: [], search: [], extract: [] };
  const fetchMock = async (url, init = {}) => {
    const target = String(url);
    const body = init.body ? JSON.parse(init.body) : {};
    if (target.endsWith('/chat/completions')) {
      calls.chat.push(body);
      const last = body.messages?.at(-1);
      if (Array.isArray(body.tools) && body.tools.length && last?.role !== 'tool') {
        return new Response(JSON.stringify({ choices: [{ finish_reason: 'tool_calls', message: {
          role: 'assistant', content: null,
          tool_calls: [{ id: `scheduled-research-${calls.chat.length}`, type: 'function', function: {
            name: 'web_research', arguments: JSON.stringify({ query: 'اخبار مهم فناوری', mode: 'quick', topic: 'news' })
          } }]
        } }] }), { status: 200, headers: { 'content-type': 'application/json' } });
      }
      return completion(finalText);
    }
    if (target.endsWith('/search')) {
      calls.search.push(body);
      return new Response(JSON.stringify({ answer: 'خلاصه خبرها', results: [{ title: 'منبع خبری', url: 'https://example.com/news', content: 'چکیده خبر' }] }), { status: searchStatus, headers: { 'content-type': 'application/json' } });
    }
    if (target.endsWith('/extract')) {
      calls.extract.push(body);
      return new Response(JSON.stringify({ results: body.urls.map(url => ({ url, raw_content: 'متن استخراج‌شده از منبع خبری' })) }), { status: 200, headers: { 'content-type': 'application/json' } });
    }
    throw new Error(`Unexpected scheduled task URL: ${target}`);
  };
  return { fetchMock, calls };
}
const runId = () => crypto.randomUUID();
{ // happy path with web search: chat + search quota reserved, prompt comes from the claimed task
  const t = fakeTasks({ claimRun: () => ({ ok: true, task: { title: 'خبر', prompt: 'اخبار مهم فناوری را خلاصه کن', useSearch: true, timezone: 'Asia/Tehran' } }) });
  const q = fakeQuota(); const mock = scheduledAgentFetch(); context.fetch = mock.fetchMock;
  const response = await taskRunInternal(await signed({ accountKey, runId: runId() }), chatEnv(q, t));
  const data = await response.json();
  assert.equal(response.status, 200);
  assert.deepEqual([data.ok, data.content, data.searchUsed], [true, 'گزارش امروز', true]);
  assert.equal(mock.calls.chat.length, 2, 'the Main Agent must call the tool and then continue with its result');
  assert.equal(mock.calls.chat[0].tool_choice, 'required');
  assert.deepEqual([mock.calls.search.length, mock.calls.extract.length], [1, 1]);
  assert.deepEqual(q.calls.reserve.map(r => r.items[0].feature), ['chat', 'search', 'search'], 'chat and each Agent search/page extraction reserve their own quota');
  assert.deepEqual(q.calls.reserve.slice(0, 2).map(r => r.items[0].amount), [1, 1]);
  assert.equal(q.calls.commit.length, 3);
}
{ // search failure degrades gracefully with an explicit note; no search quota is charged for the failure
  const t = fakeTasks({ claimRun: () => ({ ok: true, task: { title: 't', prompt: 'اخبار امروز', useSearch: true, timezone: 'Asia/Tehran' } }) });
  const q = fakeQuota(); const mock = scheduledAgentFetch({ searchStatus: 500, finalText: 'پاسخ بدون جست‌وجو' }); context.fetch = mock.fetchMock;
  const data = await (await taskRunInternal(await signed({ accountKey, runId: runId() }), chatEnv(q, t))).json();
  assert.equal(data.ok, true); assert.equal(data.searchUsed, false); assert.match(data.content, /جست‌وجوی وب برای این اجرا انجام نشد/);
  assert.equal(mock.calls.chat.length, 2, 'the model receives the failed tool result before answering');
  assert.equal(q.calls.release.length, 1);
}
{ // authentication: bad signature, wrong secret, stale timestamp, malformed body, replayed run
  const t = fakeTasks({ claimRun: () => ({ ok: true, task: { title: 't', prompt: 'prompt text', useSearch: false, timezone: 'Asia/Tehran' } }) });
  const q = fakeQuota(); const env = chatEnv(q, t); context.fetch = async () => completion('x');
  const tamper = await signed({ accountKey, runId: runId() }); const forged = new Request(tamper.url, { method: 'POST', headers: tamper.headers, body: JSON.stringify({ accountKey, runId: runId() }) });
  assert.equal((await taskRunInternal(forged, env)).status, 401);
  assert.equal((await taskRunInternal(await signed({ accountKey, runId: runId() }, { secret: 'z'.repeat(40) }), env)).status, 401);
  assert.equal((await taskRunInternal(await signed({ accountKey, runId: runId() }, { timestamp: String(Date.now() - 10 * 60_000) }), env)).status, 401);
  assert.equal((await taskRunInternal(await signed({ accountKey: 'short', runId: runId() }), env)).status, 400);
  assert.equal((await taskRunInternal(new Request('https://xynora.test/api/internal/task-run'), env)).status, 405);
  assert.equal((await taskRunInternal(await signed({ accountKey, runId: runId() }), { ...env, TASKS_INTERNAL_SECRET: 'tiny' })).status, 503);
  assert.equal(t.calls.length, 0, 'nothing is claimed for rejected requests');
  assert.equal(q.calls.reserve.length, 0);
  const replay = fakeTasks({ claimRun: () => ({ ok: false, code: 'RUN_NOT_CLAIMABLE' }) });
  assert.equal((await taskRunInternal(await signed({ accountKey, runId: runId() }), chatEnv(fakeQuota(), replay))).status, 409);
}
{ // chat quota exhausted surfaces as QUOTA_EXCEEDED (the Scheduler will not retry it)
  const t = fakeTasks({ claimRun: () => ({ ok: true, task: { title: 't', prompt: 'prompt text', useSearch: false, timezone: 'Asia/Tehran' } }) });
  const response = await taskRunInternal(await signed({ accountKey, runId: runId() }), chatEnv(fakeQuota({ allow: false }), t));
  assert.equal(response.status, 429); assert.equal((await response.json()).code, 'QUOTA_EXCEEDED');
}

// ───────── router wiring ─────────
{
  const api = load('worker/routes/api.js').api;
  const q = fakeQuota();
  const health = await (await api(new Request('https://xynora.test/api/health'), {})).json();
  assert.equal(health.providers.images, false); assert.equal(health.providers.tasks, false);
  const ready = await (await api(new Request('https://xynora.test/api/health'), { ...q, OPENROUTER_API_KEY: 'k', OPENROUTER_IMAGE_MODEL: 'google/gemini-2.5-flash-image', TASKS_ACCOUNT: {}, TASKS_INTERNAL_SECRET: SECRET })).json();
  assert.equal(ready.providers.images, true); assert.equal(ready.providers.tasks, true);
  // without a configured auth backend the billable and task routes fail closed
  for (const path of ['/api/images/generate', '/api/tasks']) {
    const method = path === '/api/tasks' ? 'GET' : 'POST';
    const response = await api(new Request(`https://xynora.test${path}`, { method, headers: { 'content-type': 'application/json' }, body: method === 'POST' ? '{"prompt":"hello"}' : undefined }), { ...q });
    assert.equal(response.status, 503, path);
  }
  const cross = await api(new Request('https://xynora.test/api/images/generate', { method: 'POST', headers: { origin: 'https://evil.test', 'content-type': 'application/json' }, body: '{}' }), {});
  assert.equal(cross.status, 403);
  assert.equal((await api(new Request('https://xynora.test/api/internal/task-run', { method: 'GET' }), {})).status, 405);
}
console.log('Images & tasks tests passed: provider handling, quota reserve/commit/release, auth, signed internal run, router wiring');
