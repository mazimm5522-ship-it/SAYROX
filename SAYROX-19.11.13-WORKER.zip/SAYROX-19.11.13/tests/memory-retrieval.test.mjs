import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

const sourcePath = new URL('../site/_worker.js', import.meta.url);
let source = await readFile(sourcePath, 'utf8');
source = source.replace('export default __worker;', 'globalThis.__xynoraBundle = { __worker, __load };');
const context = vm.createContext({
  crypto: webcrypto, fetch: globalThis.fetch, Request, Response, Headers, URL, URLSearchParams,
  AbortController, AbortSignal, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, Blob,
  setTimeout, clearTimeout, console, atob, btoa, Date, Math, JSON, Number, String,
  Boolean, Object, Array, Map, Set, RegExp, Error, TypeError, Promise, Intl
});
vm.runInContext(source, context, { filename: '_worker.js' });
const memory = context.__xynoraBundle.__load('worker/features/memory.js');

const memories = [
  { id: 'p1', category: 'preference', content: 'پاسخ‌ها را فارسی و مرحله‌به‌مرحله ارائه کن.', updated_at: 10 },
  { id: 'x1', category: 'project', content: 'پروژه SAYROX یک رابط هوش مصنوعی فارسی و چندزبانه است.', updated_at: 20 },
  { id: 'x2', category: 'project', content: 'در SAYROX از Cloudflare Workers و Durable Objects استفاده می‌کنیم.', updated_at: 30 },
  { id: 'w1', category: 'work', content: 'در حال یادگیری طراحی رابط کاربری و CSS هستم.', updated_at: 40 },
  { id: 'o1', category: 'other', content: 'کتابخانه مورد علاقه‌ام درباره نجوم است.', updated_at: 50 }
];

// Persian/Arabic character variants and ZWNJ should match consistently.
{
  const selected = memory.selectRelevantMemories(memories, [{ role: 'user', content: 'درباره پروژه زينورا و Cloudflare بیشتر توضیح بده.' }]);
  const contents = selected.map(item => item.content);
  assert.ok(contents.some(value => value.includes('رابط هوش مصنوعی')));
  assert.ok(contents.some(value => value.includes('Durable Objects')));
  assert.ok(contents.some(value => value.includes('فارسی')));
  assert.ok(!contents.some(value => value.includes('نجوم')));
}

// Stable preference is retained, but unrelated memories are not used as filler.
{
  const selected = memory.selectRelevantMemories(memories, [{ role: 'user', content: 'سلام، امروز حالت چطوره؟' }]);
  assert.ok(selected.some(item => item.category === 'ترجیحات'));
  assert.ok(!selected.some(item => item.content.includes('نجوم')));
  assert.ok(!selected.some(item => item.content.includes('Cloudflare')));
}

// The latest user turn has greater weight than old turns in the same request.
{
  const selected = memory.selectRelevantMemories(memories, [
    { role: 'user', content: 'راهنمای CSS و طراحی رابط کاربری' },
    { role: 'assistant', content: 'متوجه شدم.' },
    { role: 'user', content: 'برای پروژه SAYROX معماری حافظه را توضیح بده.' }
  ]);
  const contents = selected.map(item => item.content);
  assert.ok(contents.some(value => value.includes('پروژه SAYROX')));
  assert.ok(contents.indexOf('پروژه SAYROX یک رابط هوش مصنوعی فارسی و چندزبانه است.') < contents.indexOf('در حال یادگیری طراحی رابط کاربری و CSS هستم.')); 
}

// Duplicate entries are removed before scoring, and selection stays bounded.
{
  const duplicated = [...memories, { ...memories[1], id: 'duplicate' }];
  const selected = memory.selectRelevantMemories(duplicated, [{ role: 'user', content: 'پروژه SAYROX' }]);
  assert.equal(selected.filter(item => item.content === memories[1].content).length, 1);
  assert.ok(selected.length <= 10);
  assert.ok(selected.every(item => typeof item.content === 'string' && item.content.length <= 500));
}

// Explicit save phrases remain recognized, while ordinary messages are not auto-saved.
{
  assert.equal(memory.extractExplicitMemory('یادت باشه پاسخ‌ها را کوتاه و روشن بنویسی.'), 'پاسخ‌ها را کوتاه و روشن بنویسی.');
  assert.equal(memory.extractExplicitMemory('لطفاً در این مورد کمکم کن.'), '');
}

console.log('memory retrieval tests: 5 scenarios passed');
