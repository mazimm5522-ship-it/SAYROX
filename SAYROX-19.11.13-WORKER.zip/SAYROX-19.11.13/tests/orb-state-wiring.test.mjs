import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const read = path => readFile(new URL(path, import.meta.url), 'utf8');
const send = await read('../app/05-send-message.js');
const orb = await read('../site/src/core/orb.js');
const css = await read('../site/src/styles/voice.css');

// Exercise the real code-intent recognizer instead of duplicating its pattern in a test.
const detector = send.match(/function looksLikeCodeRequest\(text\)\{[\s\S]*?\n\}/)?.[0];
assert.ok(detector, 'code-intent detector must exist');
const sandbox = {};
vm.runInNewContext(`${detector}\nglobalThis.detectCode = looksLikeCodeRequest;`, sandbox);
for (const prompt of ['لطفاً کد پایتون بنویس', 'این JavaScript را debug کن', 'یک صفحه HTML بساز'])
  assert.equal(sandbox.detectCode(prompt), true, `must recognize coding prompt: ${prompt}`);
for (const prompt of ['سلام، حالت چطوره؟', 'برای فردا یک متن تبریک بنویس'])
  assert.equal(sandbox.detectCode(prompt), false, `must not classify ordinary prompt as coding: ${prompt}`);

assert.match(send, /const initialOrbState=hasFileContext\?'processing':coding\?'coding':'thinking'/,
  'image-context analysis (including retry), code and ordinary reasoning must map to distinct initial states; web search is now executed by Main Agent in the Worker');
assert.match(send, /const preparationOrbState=coding\?'coding':hasFileContext\?'processing':'thinking'/,
  'after request analysis, the Orb must return to the relevant task state');
assert.match(send, /webSearchPreference:state\.searchMode\|\|'auto'/, 'the selected search preference must reach the server-side Agent');
assert.match(send, /x-sayrox-agent-research/, 'the UI must receive the actual Agent research result from the Worker');
assert.doesNotMatch(send, /searchForContext|fetch\('\/api\/search'/, 'the browser must not pre-search ahead of Main Agent');
assert.match(send, /x-sayrox-agent-specialist/, 'chat status must consume the Main Agent routing metadata');
assert.match(send, /agentRoleLabels/, 'the UI must accurately identify the selected specialist');
assert.match(send, /coding\?'coding':'speaking'/,
  'code generation must keep the coding indicator instead of switching to speaking');
for (const state of ['searching', 'coding', 'processing']) {
  assert.match(orb, new RegExp(`${state}:\\s*\\{`), `${state} must be a supported Orb state`);
  assert.ok(css.includes(`.xorb[data-state="${state}"]::after`), `${state} must have a visible status glyph`);
}
console.log('orb state wiring tests: coding intent, real search, image processing and code-generation transitions passed');
