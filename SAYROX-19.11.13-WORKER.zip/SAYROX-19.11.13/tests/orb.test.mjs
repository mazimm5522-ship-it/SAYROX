// Orb guard: the Orb must stay calm, concentric and symmetric (docs/ORB.md). These checks fail if someone
// brings back noise, wobble, tilted rings, drag-tilt or offset shadows — the things that made the old Orb lopsided.
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const read = path => readFile(new URL(path, import.meta.url), 'utf8');
const orb = await read('../site/src/core/orb.js');
const voiceCss = await read('../site/src/styles/voice.css');
const contentCss = await read('../site/src/styles/content.css');
const sw = await read('../site/sw.js');
const html = await read('../site/index.html');

// ---- public API (the app wiring in app/*.js and settings/controller.js depends on it) -----------------
const sandbox = { console, matchMedia: () => ({ matches: false }) };
sandbox.globalThis = sandbox;
vm.runInNewContext(orb, sandbox);
const api = sandbox.SayroxOrb;
assert.ok(api, 'SayroxOrb global must exist');
for (const name of ['mount', 'get', 'mountAll', 'unmountIn']) assert.equal(typeof api[name], 'function', `SayroxOrb.${name}`);
assert.deepEqual([...api.states].sort(), ['coding', 'idle', 'listening', 'loading', 'processing', 'searching', 'speaking', 'thinking']);
assert.ok(Object.isFrozen(api), 'SayroxOrb must stay frozen');
for (const method of ['setColors', 'setState', 'setEnergy', 'setSeed', 'destroy']) assert.match(orb, new RegExp(`\\b${method}\\(`), `controller.${method}`);
for (const state of ['searching', 'coding', 'processing']) assert.match(orb, new RegExp(`${state}:\\s*\\{`), `${state} must have dedicated motion targets`);

// ---- symmetry guard: the fragment shader must be noise-free and deformation-free ------------------------
const frag = orb.slice(orb.indexOf('const FRAG'), orb.indexOf('// Per-state targets'));
assert.ok(frag.length > 1000, 'fragment shader not found');
for (const banned of ['vnoise', 'fbm', 'wob', 'uTilt', 'rotX', 'rotY', 'domain']) assert.ok(!frag.includes(banned), `shader must not contain "${banned}"`);
assert.match(frag, /float Re = R \* \(/, 'silhouette radius must be a single scalar (a true circle)');
assert.match(frag, /vec2 q = p \/ Re;/, 'sphere must be shaded in a uniformly scaled space');
assert.ok(!/hash\(/.test(frag), 'no random hash patterns in the shader (dithering is static)');

// ---- no drag-to-tilt, no per-frame tilt state -------------------------------------------------------------
for (const banned of ['pointerdown', 'pointermove', 'tiltTarget', 'setPointerCapture']) assert.ok(!orb.includes(banned), `orb.js must not contain "${banned}"`);

// ---- CSS: concentric only ---------------------------------------------------------------------------------
assert.ok(!/\.orb-scene::after/.test(voiceCss), 'no extra tilted ring around the live-voice orb');
assert.ok(!/perspective\s*:/.test(voiceCss), 'no perspective on orb scenes');
assert.ok(!/drop-shadow\(0 \d+px/.test(voiceCss), 'no downward-offset shadow under the orb');
assert.ok(!/rotateX\(/.test(voiceCss), 'no tilted 3D transforms in voice.css');
for (const dead of ['fbRing', 'fbSpark', 'fbFloat', 'fbSpin', 'xorb-fb-spark', 'xorb-fb-ring-two']) assert.ok(!voiceCss.includes(dead), `dead fallback CSS "${dead}" must stay deleted`);
assert.ok(!/orbBreath/.test(contentCss), 'orbBreath was never defined; the legacy flat disc behind the mini orb must stay deleted');
assert.ok(!/\.deep-status-orb\{[^}]*background/.test(contentCss), 'mini orb must not get a second painted disc');
for (const [state, glyph] of [['searching', '⌕'], ['coding', '</>'], ['processing', '▤']]) {
  assert.ok(voiceCss.includes(`.xorb[data-state=\"${state}\"]::after`), `${state} activity glyph selector must exist`);
  assert.ok(voiceCss.includes(`content: \"${glyph}\"`), `${state} glyph must be recognizable`);
}
assert.match(voiceCss, /prefers-reduced-motion:[^{]+\{[^}]*\.xorb::after/s, 'activity glyph animations must respect reduced motion');

// ---- fallback markup emitted by orb.js has a style for every element it creates ---------------------------
const emitted = [...orb.matchAll(/class="(xorb-fb[^"]*)"/g)].flatMap(m => m[1].split(/\s+/)).filter(c => c.startsWith('xorb-fb-'));
assert.ok(emitted.length >= 3, 'fallback markup missing');
for (const cls of new Set(emitted)) assert.ok(voiceCss.includes(`.${cls}`), `voice.css has no rule for .${cls}`);

// ---- shipped & cached -----------------------------------------------------------------------------------
assert.ok(html.includes('src/core/orb.js'), 'index.html must load orb.js');
assert.ok(sw.includes('/src/core/orb.js'), 'sw.js must precache orb.js');
console.log('orb tests: API, symmetric shader (no noise/wobble/tilt), concentric CSS, fallback markup passed');
