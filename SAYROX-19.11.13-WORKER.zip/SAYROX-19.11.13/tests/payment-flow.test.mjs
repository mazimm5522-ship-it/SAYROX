import assert from 'node:assert/strict';
import { readFile, writeFile, unlink } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { webcrypto } from 'node:crypto';

if (!globalThis.crypto) globalThis.crypto = webcrypto;
const workerSource = await readFile(new URL('../site/_worker.js', import.meta.url), 'utf8');
const temporaryModule = join(tmpdir(), `xynora-worker-test-${process.pid}.mjs`);
await writeFile(temporaryModule, workerSource, 'utf8');
const { default: worker } = await import(`${pathToFileURL(temporaryModule).href}?test=${Date.now()}`);

const AUTH_SECRET = 'test-auth-secret-'.repeat(3);
const CALLBACK_SECRET = 'test-payment-callback-secret-'.repeat(2);
const accountKey = 'A'.repeat(43);
const sessionId = 'B'.repeat(43);
const expiresAt = Math.floor(Date.now() / 1000) + 3600;
const base64url = value => Buffer.from(value).toString('base64url');
async function hmac(secret, value) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return base64url(new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(value))));
}
const encodedSession = base64url(`v1.${accountKey}.${sessionId}.${expiresAt}`);
const sessionToken = `${encodedSession}.${await hmac(AUTH_SECRET, encodedSession)}`;
const cookie = `xynora_session=${sessionToken}`;
let order = null;
let providerCalls = [];
let settleCalls = 0;
let verifyCalls = 0;

const AUTH_ACCOUNTS = {
  idFromName: name => name,
  get: () => ({ fetch: async request => {
    const path = new URL(request.url).pathname;
    if (path === '/internal/validate-session') {
      return Response.json({ ok: true, user: { id: 'test-user', email: 'test@example.invalid', display_name: 'Test User', created_at: 1 } });
    }
    return Response.json({ ok: true });
  } })
};
const AUTH_RATE_LIMITER = {
  idFromName: name => name,
  get: () => ({ fetch: async () => Response.json({ ok: true, allowed: true, attempts: 1 }) })
};
const BILLING_ACCOUNT = {
  idFromName: name => name,
  get: () => ({
    async createOrder(input) {
      order = {
        orderId: input.orderId, planId: input.planId, months: 1,
        amountToman: 1371000, amountRial: 13710000, status: 'creating',
        authority: null, expiresAt: Date.now() + 86400000
      };
      return { ok: true, order };
    },
    async attachAuthority(orderId, authority) {
      assert.equal(order.orderId, orderId);
      order.status = 'pending'; order.authority = authority;
      return { ok: true, order };
    },
    async failOrder() { if (order) order.status = 'failed'; return { ok: true }; },
    async getOrder(orderId) { return order?.orderId === orderId ? { ...order } : null; },
    async cancelOrder(orderId, authority) {
      if (order?.orderId === orderId && order.authority === authority) order.status = 'cancelled';
      return { ok: true, order };
    },
    async settleVerified(orderId, authority, refId) {
      settleCalls++;
      assert.equal(order.orderId, orderId);
      assert.equal(order.authority, authority);
      order.status = 'paid'; order.refId = refId; order.verifiedAt = Date.now();
      return { ok: true, order, subscription: { subscriptionId: 'test-subscription' } };
    },
    async getSubscriptionSnapshot() { return { ok: true, current: null, upcoming: [], payments: [] }; }
  })
};
const env = {
  AUTH_ACCOUNTS, AUTH_RATE_LIMITER, BILLING_ACCOUNT,
  AUTH_SESSION_SECRET: AUTH_SECRET, PAYMENT_CALLBACK_SECRET: CALLBACK_SECRET,
  ZARINPAL_MODE: 'sandbox', ZARINPAL_MERCHANT_ID: 'test-merchant-id',
  PAYMENTS_ENABLED: 'true', SUBSCRIPTION_ACTIVATION_READY: 'true'
};

const results = [];
let providerMockCalls = 0;
globalThis.fetch = async (url, options = {}) => {
  providerMockCalls++;
  const target = String(url);
  const body = JSON.parse(options.body || '{}');
  providerCalls.push({ url: target, body });
  if (target.endsWith('/request.json')) {
    return Response.json({ data: { code: 100, authority: '12345678901234567890123456789012' } });
  }
  if (target.endsWith('/verify.json')) {
    verifyCalls++;
    return Response.json({ data: { code: 100, ref_id: 987654321 } });
  }
  throw new Error(`Unexpected provider call: ${target}`);
};

async function call(name, request, expectedStatus, runtimeEnv = env) {
  const response = await worker.fetch(request, runtimeEnv, {});
  const body = await response.json().catch(() => ({}));
  assert.equal(response.status, expectedStatus, `${name}: unexpected HTTP status`);
  results.push({ name, status: response.status, code: body.code || null });
  return { response, body };
}

try {
  await call('guest checkout blocked', new Request('https://preview.example/api/payment/request', {
    method: 'POST', headers: { origin: 'https://preview.example', 'content-type': 'application/json', 'Idempotency-Key': crypto.randomUUID() },
    body: JSON.stringify({ planId: 'plus-1m' })
  }), 401);

  await call('guest subscription lookup blocked', new Request('https://preview.example/api/subscription/me', {
    headers: { origin: 'https://preview.example' }
  }), 401);

  await call('cross-origin checkout blocked', new Request('https://preview.example/api/payment/request', {
    method: 'POST', headers: { origin: 'https://attacker.example', 'content-type': 'application/json', 'Idempotency-Key': crypto.randomUUID() },
    body: JSON.stringify({ planId: 'plus-1m' })
  }), 403);

  await call('checkout remains closed when feature flags are off', new Request('https://preview.example/api/payment/request', {
    method: 'POST', headers: { origin: 'https://preview.example', cookie, 'content-type': 'application/json', 'Idempotency-Key': crypto.randomUUID() },
    body: JSON.stringify({ planId: 'plus-1m' })
  }), 503, { ...env, PAYMENTS_ENABLED: 'false' });

  const hugeBody = JSON.stringify({ planId: 'plus-1m', extra: 'x'.repeat(4096) });
  await call('oversized checkout body rejected', new Request('https://preview.example/api/payment/request', {
    method: 'POST', headers: { origin: 'https://preview.example', cookie, 'content-type': 'application/json', 'Idempotency-Key': crypto.randomUUID() }, body: hugeBody
  }), 400);
  assert.equal(providerMockCalls, 0, 'Provider must not be called for rejected requests');

  const checkout = await call('authenticated checkout uses server price', new Request('https://preview.example/api/payment/request', {
    method: 'POST', headers: { origin: 'https://preview.example', cookie, 'content-type': 'application/json', 'Idempotency-Key': crypto.randomUUID() },
    body: JSON.stringify({ planId: 'plus-1m', amountToman: 1, amountRial: 1, months: 99, plan: 'plus-12m' })
  }), 200);
  assert.equal(checkout.body.amountToman, 1371000);
  const requestCall = providerCalls.find(item => item.url.endsWith('/request.json'));
  assert.ok(requestCall, 'Zarinpal request mock was not called');
  assert.equal(requestCall.body.amount, 13710000, 'Amount must be server-calculated in IRR');
  assert.equal(requestCall.body.currency, 'IRR');

  const callbackState = new URL(requestCall.body.callback_url).searchParams.get('state');
  assert.ok(callbackState, 'Signed callback state is missing');
  const callbackUrl = `https://preview.example/api/payment/callback?Authority=12345678901234567890123456789012&Status=OK&state=${encodeURIComponent(callbackState)}`;
  const callback = await worker.fetch(new Request(callbackUrl), env, {});
  assert.equal(callback.status, 303);
  assert.match(callback.headers.get('location') || '', /payment=success/);
  assert.equal(verifyCalls, 1);
  assert.equal(settleCalls, 1);
  results.push({ name: 'verified callback settles order and creates subscription once', status: callback.status, verifyCalls, settleCalls });

  const duplicate = await worker.fetch(new Request(callbackUrl), env, {});
  assert.equal(duplicate.status, 303);
  assert.equal(verifyCalls, 1, 'Duplicate callback must not re-verify');
  assert.equal(settleCalls, 1, 'Duplicate callback must not create another subscription');
  results.push({ name: 'duplicate callback is idempotent', status: duplicate.status, verifyCalls, settleCalls });

  const statePayload = JSON.parse(Buffer.from(callbackState.split('.')[0], 'base64url').toString('utf8'));
  const altered = { ...statePayload, orderId: crypto.randomUUID(), origin: 'https://preview.example' };
  const encoded = base64url(JSON.stringify(altered));
  const alteredToken = `${encoded}.${await hmac(CALLBACK_SECRET, `xynora/payment-callback/v1.${encoded}`)}`;
  await call('callback token cannot be replayed on another origin', new Request(
    `https://attacker.example/api/payment/callback?Authority=12345678901234567890123456789012&Status=OK&state=${encodeURIComponent(alteredToken)}`
  ), 400);

  await call('invalid callback signature rejected', new Request(
    'https://preview.example/api/payment/callback?Authority=12345678901234567890123456789012&Status=OK&state=invalid.token'
  ), 400);

  console.log(JSON.stringify({ pass: true, tests: results, mockedProviderCalls: providerMockCalls }, null, 2));
} finally {
  await unlink(temporaryModule).catch(() => {});
}
