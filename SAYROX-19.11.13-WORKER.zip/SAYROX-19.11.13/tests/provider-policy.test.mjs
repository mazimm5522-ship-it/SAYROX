import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

const bundleUrl = new URL('../site/_worker.js', import.meta.url);
let source = await readFile(bundleUrl, 'utf8');
source = source.replace('export default __worker;', 'globalThis.__sayroxBundle = { __worker, __load };');
const context = vm.createContext({
  crypto: webcrypto, fetch: globalThis.fetch, Request, Response, Headers, URL, URLSearchParams,
  AbortController, AbortSignal, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, Blob,
  setTimeout, clearTimeout, console, atob, btoa, Date, Math, JSON, Number, String, Boolean,
  Object, Array, Map, Set, RegExp, Error, TypeError, Promise, Intl
});
vm.runInContext(source, context, { filename: '_worker.js' });
const registry = context.__sayroxBundle.__load('worker/providers/registry.js');

const bothConfigured = {
  AI_PROVIDER: 'openrouter',
  GAPGPT_API_KEY: 'gap-test-key', GAPGPT_DEFAULT_MODEL: 'gap-model', GAPGPT_BASE_URL: 'https://gap.example/v1',
  OPENROUTER_API_KEY: 'router-test-key', OPENROUTER_DEFAULT_MODEL: 'router-model', OPENROUTER_BASE_URL: 'https://openrouter.ai/api/v1'
};
assert.deepEqual(Array.from(registry.providerOrder(bothConfigured)), ['gapgpt']);
assert.deepEqual(Array.from(registry.modelCatalog(bothConfigured), item => item.provider), ['auto', 'gapgpt']);
const diagnostics = registry.providerDiagnostics(bothConfigured);
assert.equal(diagnostics.primary, 'gapgpt');
assert.equal(diagnostics.fallback, null);
assert.equal(diagnostics.chatReady, true);
assert.equal(diagnostics.fallbackReady, false);
const automatic = registry.resolveModelSelection(bothConfigured, 'auto');
assert.equal(automatic.ok, true);
assert.equal(automatic.provider, 'gapgpt');
assert.deepEqual(Array.from(automatic.fallbackProviders), []);
assert.equal(registry.resolveModelSelection(bothConfigured, 'router-model').reason, 'model-not-configured');

const noGap = { OPENROUTER_API_KEY: 'router-test-key', OPENROUTER_DEFAULT_MODEL: 'router-model' };
assert.deepEqual(Array.from(registry.providerOrder(noGap)), [], 'OpenRouter credentials must never activate chat');
assert.equal(registry.resolveModelSelection(noGap, 'auto').reason, 'no-provider');
assert.equal(registry.providerConfig('openrouter', noGap).key, 'router-test-key', 'OpenRouter image provider config remains available separately');

console.log('Provider policy passed: GapGPT-only chat, no OpenRouter fallback, optional image-provider config retained');
