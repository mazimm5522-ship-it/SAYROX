import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

const bundlePath = new URL('../site/_worker.js', import.meta.url);
let source = await readFile(bundlePath, 'utf8');
source = source.replace('export default __worker;', 'globalThis.__xynoraBundle = { __worker, __load };');
const context = vm.createContext({
  crypto: webcrypto, fetch: globalThis.fetch, Request, Response, Headers, URL, URLSearchParams,
  AbortController, AbortSignal, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, Blob,
  setTimeout, clearTimeout, console, atob, btoa, WebSocketPair: undefined,
  Date, Math, JSON, Number, String, Boolean, Object, Array, Map, Set, RegExp, Error,
  TypeError, Promise, Intl
});
vm.runInContext(source, context, { filename: '_worker.js' });
const load = context.__xynoraBundle.__load;
const accountKey = 'a'.repeat(43);

function fakeBinding({ allow = true, current = null } = {}) {
  const calls = { reserve: [], commit: [], release: [] };
  const usageStub = {
    async reserveUsageBatch(requestId, items, subscription) {
      calls.reserve.push({ requestId, items, subscription });
      return allow ? { ok: true } : { ok: false, code: 'QUOTA_EXCEEDED', feature: items[0]?.feature, used: 30, limit: 30, remaining: 0, resetAt: Date.now() + 3600000, tier: 'free' };
    },
    async commitUsage(requestId) { calls.commit.push(requestId); return { ok: true }; },
    async releaseUsage(requestId) { calls.release.push(requestId); return { ok: true }; },
    async getUsageSnapshot(subscription) { return { tier: subscription?.tier || 'free', isPlus: Boolean(subscription), resetAt: Date.now() + 3600000, features: {} }; }
  };
  const billingStub = { async getSubscriptionSnapshot() { return { current }; } };
  const binding = { idFromName: name => name, get: () => usageStub };
  const billingBinding = { idFromName: name => name, get: () => billingStub };
  return { binding, billingBinding, calls };
}

// Search reserves then commits only after Tavily succeeds.
{
  const search = load('worker/features/search.js').search;
  const mock = fakeBinding();
  context.fetch = async () => new Response(JSON.stringify({ answer: 'ok', results: [{ title: 'Example', url: 'https://example.com', content: 'text' }] }), { status: 200, headers: { 'content-type': 'application/json' } });
  const env = { BILLING_ACCOUNT: mock.billingBinding, USAGE_ACCOUNT: mock.binding, TAVILY_API_KEY: 'test-key', TAVILY_SEARCH_DEPTH: 'advanced' };
  const request = new Request('https://xynora.test/api/search', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ query: 'xynora test' }) });
  const response = await search(request, env, { accountKey });
  assert.equal(response.status, 200);
  assert.equal(mock.calls.reserve.length, 1);
  assert.equal(mock.calls.reserve[0].items[0].feature, 'search');
  assert.equal(mock.calls.commit.length, 1);
  assert.equal(mock.calls.release.length, 0);
}

// A provider failure releases the reservation instead of charging the account.
{
  const search = load('worker/features/search.js').search;
  const mock = fakeBinding();
  context.fetch = async () => new Response(JSON.stringify({ message: 'provider down' }), { status: 503 });
  const env = { BILLING_ACCOUNT: mock.billingBinding, USAGE_ACCOUNT: mock.binding, TAVILY_API_KEY: 'test-key' };
  const request = new Request('https://xynora.test/api/search', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ query: 'xynora test' }) });
  const response = await search(request, env, { accountKey });
  assert.equal(response.status, 502);
  assert.equal(mock.calls.commit.length, 0);
  assert.equal(mock.calls.release.length, 1);
}

// TTS also commits only after a successful upstream response.
{
  const tts = load('worker/features/tts.js').tts;
  const mock = fakeBinding();
  context.fetch = async () => new Response(new Uint8Array([1, 2, 3]), { status: 200, headers: { 'content-type': 'audio/mpeg' } });
  const env = { BILLING_ACCOUNT: mock.billingBinding, USAGE_ACCOUNT: mock.binding, ELEVENLABS_API_KEY: 'test-key', ELEVENLABS_ARIA_VOICE_ID: 'voice-id' };
  const request = new Request('https://xynora.test/api/tts', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ text: 'hello', voice: 'aria' }) });
  const response = await tts(request, env, { accountKey });
  assert.equal(response.status, 200);
  assert.equal(mock.calls.reserve[0].items[0].feature, 'tts');
  assert.equal(mock.calls.commit.length, 1);
}

// Chat reserves chat + image units before any provider call, and stops on quota denial.
{
  const chat = load('worker/providers/chat.js').chat;
  const mock = fakeBinding({ allow: false });
  let providerCalls = 0;
  context.fetch = async () => { providerCalls++; throw new Error('provider must not be called'); };
  const env = {
    BILLING_ACCOUNT: mock.billingBinding, USAGE_ACCOUNT: mock.binding,
    GAPGPT_API_KEY: 'test-key', GAPGPT_DEFAULT_MODEL: 'test-model', GAPGPT_BASE_URL: 'https://provider.example/v1',
    AI_PROVIDER: 'gapgpt'
  };
  const request = new Request('https://xynora.test/api/chat', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({
    model: 'auto', messages: [{ role: 'user', content: 'hello' }], stream: false
  }) });
  const response = await chat(request, env, { accountKey });
  const data = await response.json();
  assert.equal(response.status, 429);
  assert.equal(data.code, 'QUOTA_EXCEEDED');
  assert.equal(mock.calls.reserve[0].items[0].feature, 'chat');
  assert.equal(providerCalls, 0);
}


// The Main Agent plans a real turn, injects trusted specialist policy, and reports its result metadata.
{
  const chat = load('worker/providers/chat.js').chat;
  const mock = fakeBinding();
  let upstreamPayload = null;
  context.fetch = async (url, init) => {
    assert.match(String(url), /chat\/completions$/);
    upstreamPayload = JSON.parse(init.body);
    return new Response(JSON.stringify({ choices: [{ message: { role: 'assistant', content: 'کد بررسی شد.' } }] }), { status: 200, headers: { 'content-type': 'application/json' } });
  };
  const env = {
    BILLING_ACCOUNT: mock.billingBinding, USAGE_ACCOUNT: mock.binding,
    GAPGPT_API_KEY: 'test-key', GAPGPT_DEFAULT_MODEL: 'test-model', GAPGPT_BASE_URL: 'https://provider.example/v1',
    AI_PROVIDER: 'gapgpt'
  };
  const request = new Request('https://xynora.test/api/chat', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({
    model: 'auto', messages: [{ role: 'user', content: 'این کد JavaScript را بررسی و باگش را پیدا کن.' }], stream: false
  }) });
  const response = await chat(request, env, { accountKey });
  const data = await response.json();
  assert.equal(response.status, 200);
  assert.equal(data.agent.specialist, 'coding');
  assert.equal(data.agent.state, 'completed');
  assert.ok(data.agent.plannedSteps <= 6);
  assert.ok(upstreamPayload.messages.some(item => item.role === 'system' && item.content.includes('برنامه‌نویس')));
  assert.equal(response.headers.get('x-sayrox-agent-specialist'), 'coding');
  assert.equal(response.headers.get('x-sayrox-agent-state'), 'completed');
  assert.equal(mock.calls.commit.length, 1);
}

// The active subscription is fetched from the billing DO and passed to the quota DO by the Worker, not by the browser.
{
  const search = load('worker/features/search.js').search;
  const now = Date.now();
  const current = { subscriptionId: crypto.randomUUID(), planId: 'plus-9m', tier: 'pro', months: 9,
    startsAt: now - 1000, expiresAt: now + 250 * 86400000, status: 'active' };
  const mock = fakeBinding({ current });
  context.fetch = async () => new Response(JSON.stringify({ answer: 'ok', results: [] }), { status: 200, headers: { 'content-type': 'application/json' } });
  const env = { BILLING_ACCOUNT: mock.billingBinding, USAGE_ACCOUNT: mock.binding, TAVILY_API_KEY: 'test-key' };
  const request = new Request('https://xynora.test/api/search', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ query: 'paid quota test' }) });
  const response = await search(request, env, { accountKey });
  assert.equal(response.status, 200);
  assert.equal(mock.calls.reserve[0].subscription.tier, 'pro');
  assert.equal(mock.calls.reserve[0].subscription.planId, 'plus-9m');
}

console.log('quota API integration tests: 6 scenarios passed');
