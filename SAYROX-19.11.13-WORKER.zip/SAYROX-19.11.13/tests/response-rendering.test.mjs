import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');

class FakeElement {
  constructor(tag, namespace = null) {
    this.tagName = tag; this.localName = tag; this.namespaceURI = namespace;
    this.children = []; this.attributes = {}; this.listeners = {}; this.parentNode = null;
    this.className = ''; this.hidden = false; this.href = ''; this.target = ''; this.rel = '';
    this._text = '';
    this.classList = { add: (...names) => { const all = new Set(String(this.className).split(/\s+/).filter(Boolean)); names.forEach(name => all.add(name)); this.className = [...all].join(' '); } };
  }
  appendChild(child) { this.children.push(child); child.parentNode = this; return child; }
  append(...children) { children.forEach(child => this.appendChild(child)); }
  replaceChildren(...children) { this.children = []; this._text = ''; this.append(...children); }
  setAttribute(name, value) { this.attributes[name] = String(value); }
  getAttribute(name) { return this.attributes[name] ?? null; }
  addEventListener(name, callback) { this.listeners[name] = callback; }
  set textContent(value) { this._text = String(value ?? ''); this.children = []; }
  get textContent() { return this._text + this.children.map(child => child.textContent ?? '').join(''); }
  click() { return this.listeners.click?.({ preventDefault() {} }); }
}
class FakeDocument {
  createElement(tag) { return new FakeElement(tag); }
  createElementNS(namespace, tag) { return new FakeElement(tag, namespace); }
  createTextNode(value) { const node = new FakeElement('#text'); node.textContent = String(value); return node; }
}

async function loadRenderer({ workspace = null } = {}) {
  const document = new FakeDocument();
  const sandbox = { document, URL, URLSearchParams, console, navigator: { clipboard: { writeText: async () => {} } }, location: { href: 'https://sayrox.test/' } };
  sandbox.window = sandbox;
  sandbox.SayroxCodeWorkspace = workspace;
  const context = vm.createContext(sandbox);
  vm.runInContext(await read('site/src/features/files/markdown.js'), context, { filename: 'markdown.js' });
  vm.runInContext(await read('site/src/core/response-renderer.js'), context, { filename: 'response-renderer.js' });
  return { api: sandbox.SayroxResponseRenderer, document };
}
function walk(node, predicate, found = []) {
  if (predicate(node)) found.push(node);
  for (const child of node.children || []) walk(child, predicate, found);
  return found;
}

 test('renders headings, inline formatting, lists, quotes, separators and responsive tables as real nodes', async () => {
  const { api, document } = await loadRenderer();
  const host = document.createElement('div');
  const source = [
    '## عنوان اصلی',
    'متن **مهم** و *تأکیدی* و ~~حذف‌شده~~ و `inline()`.',
    '',
    '- گزینه اول',
    '- گزینه دوم',
    '',
    '> یک نقل‌قول',
    '',
    '| نام | وضعیت |',
    '| --- | --- |',
    '| SAYROX | آماده |',
    '',
    '---'
  ].join('\n');
  assert.equal(api.render(host, source), true);
  assert.equal(walk(host, node => node.tagName === 'h2').length, 1);
  assert.equal(walk(host, node => node.tagName === 'strong').length, 1);
  assert.equal(walk(host, node => node.tagName === 'em').length, 1);
  assert.equal(walk(host, node => node.tagName === 'del').length, 1);
  assert.equal(walk(host, node => node.tagName === 'code').length, 1);
  assert.equal(walk(host, node => node.tagName === 'ul').length, 1);
  assert.equal(walk(host, node => node.tagName === 'li').length, 2);
  assert.equal(walk(host, node => node.tagName === 'blockquote').length, 1);
  assert.equal(walk(host, node => node.tagName === 'table').length, 1);
  assert.equal(walk(host, node => node.tagName === 'th').length, 2);
  assert.equal(walk(host, node => node.tagName === 'td').length, 2);
  assert.equal(walk(host, node => node.tagName === 'hr').length, 1);
  assert.equal(host.getAttribute('data-render-mode'), 'complete');
});

test('untrusted message HTML remains literal text and unsafe URL schemes are not linked', async () => {
  const { api, document } = await loadRenderer();
  const host = document.createElement('div');
  api.render(host, '<img src=x onerror=alert(1)> [خطر](javascript:alert(1)) [منبع](https://example.com/report)');
  assert.equal(walk(host, node => node.tagName === 'img').length, 0);
  assert.equal(walk(host, node => node.tagName === 'a').length, 1);
  const link = walk(host, node => node.tagName === 'a')[0];
  assert.equal(link.href, 'https://example.com/report');
  assert.ok(host.textContent.includes('<img src=x onerror=alert(1)>'));
  assert.ok(host.textContent.includes('javascript:alert(1)'));
  assert.equal(api.safeUrl('data:text/html,boom'), null);
  assert.equal(api.safeUrl('https://user:pass@example.com'), null);
});

test('renders common LaTeX with MathML fractions, roots, superscripts, subscripts and Greek symbols', async () => {
  const { api, document } = await loadRenderer();
  const host = document.createElement('div');
  api.render(host, 'فرمول inline: \\(x_1^2 + \\frac{\\alpha}{\\sqrt{y}}\\)\n\n$$E = mc^2$$');
  const math = walk(host, node => node.localName === 'math');
  assert.equal(math.length, 2);
  assert.equal(walk(host, node => node.localName === 'mfrac').length, 1);
  assert.equal(walk(host, node => node.localName === 'msqrt').length, 1);
  assert.equal(walk(host, node => node.localName === 'msubsup').length, 1);
  assert.ok(host.textContent.includes('α'));
  assert.equal(math[0].getAttribute('display'), 'inline');
  assert.equal(math[1].getAttribute('display'), 'block');
});

test('reuses the existing code workspace for completed fenced blocks and preserves the save callback', async () => {
  let captured = null;
  const workspace = { createBlock(options) { captured = options; const node = new FakeElement('section'); node.className = 'cw-block'; return node; } };
  const { api, document } = await loadRenderer({ workspace });
  const host = document.createElement('div');
  let saved = null;
  api.render(host, 'نمونه:\n```js\nconst x = 1;\n```', { onCodeSave: (index, value) => { saved = { index, value }; return true; } });
  assert.equal(walk(host, node => node.className === 'cw-block').length, 1);
  assert.equal(captured.language, 'js');
  assert.equal(captured.source, 'const x = 1;');
  assert.equal(captured.onSave('const x = 2;'), true);
  assert.deepEqual(saved, { index: 0, value: 'const x = 2;' });
});

test('streaming mode renders unfinished code fences without creating editable workspace widgets', async () => {
  let workspaceCalls = 0;
  const { api, document } = await loadRenderer({ workspace: { createBlock() { workspaceCalls++; return new FakeElement('section'); } } });
  const host = document.createElement('div');
  api.render(host, 'در حال نوشتن\n```python\nprint("hello")', { streaming: true });
  assert.equal(workspaceCalls, 0);
  assert.equal(walk(host, node => node.tagName === 'details').length, 1);
  assert.equal(walk(host, node => node.tagName === 'code')[0].textContent, 'print("hello")');
  assert.equal(host.getAttribute('data-render-mode'), 'streaming');
});

console.log('Response rendering tests passed: Markdown structure, safe URLs, MathML, code workspace and streamed rendering');
