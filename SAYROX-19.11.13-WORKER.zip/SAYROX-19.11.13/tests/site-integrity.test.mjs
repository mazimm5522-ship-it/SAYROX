import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';

// Development gate: syntax, referenced assets, single version, no stray files in site/.
const run = spawnSync(process.execPath, [new URL('../scripts/verify-site.mjs', import.meta.url).pathname, '--allow-missing-sdk'], { encoding: 'utf8' });
assert.equal(run.status, 0, `site verification failed:\n${run.stdout}${run.stderr}`);
assert.match(run.stdout, /verify OK/);
console.log('Site integrity test passed:', run.stdout.trim());
