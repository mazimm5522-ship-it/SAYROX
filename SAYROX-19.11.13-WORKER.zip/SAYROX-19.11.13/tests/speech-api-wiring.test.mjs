import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const worker = await readFile(new URL('../site/_worker.js', import.meta.url), 'utf8');
// The page logic lives in app/*.js and is built into site/src/app.js; test markup + built app together.
const page = (await readFile(new URL('../site/index.html', import.meta.url), 'utf8')) + (await readFile(new URL('../site/src/app.js', import.meta.url), 'utf8'));
const speech = await readFile(new URL('../site/src/core/speech-input.js', import.meta.url), 'utf8');
assert.match(worker, /pathname === '\/api\/voice\/transcription-token'/);
assert.match(worker, /sameOriginRequest\(request\)/);
assert.match(worker, /authenticatedSession\(request, env\)/);
assert.match(worker, /feature: 'voice_input'/);
assert.match(worker, /single-use-token\/realtime_scribe/);
assert.match(worker, /voice-input-token/);
assert.match(worker, /'cache-control': 'no-store'/);
assert.match(page, /SayroxSpeechInput\.start/);
assert.match(page, /getUserMedia/);
assert.doesNotMatch(page, /ELEVENLABS_API_KEY/);
assert.match(speech, /wss:\/\/api\.elevenlabs\.io\/v1\/speech-to-text\/realtime/);
assert.doesNotMatch(speech, /esm\.sh|jsdelivr/);
console.log('speech wiring tests: auth, quota, one-use token, no browser API key/CDN SDK passed');
