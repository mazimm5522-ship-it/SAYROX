import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const source = await readFile(new URL('../site/src/core/speech-input.js', import.meta.url), 'utf8');

class FakeTarget {
  constructor() { this.listeners = new Map(); }
  addEventListener(type, fn) { const list = this.listeners.get(type) || []; list.push(fn); this.listeners.set(type, list); }
  removeEventListener(type, fn) { this.listeners.set(type, (this.listeners.get(type) || []).filter(item => item !== fn)); }
  dispatch(type, event = {}) { for (const fn of [...(this.listeners.get(type) || [])]) fn(event); }
}
class FakeSocket extends FakeTarget {
  static OPEN = 1; static CLOSING = 2;
  constructor(url) {
    super(); this.url = url; this.readyState = 0; this.bufferedAmount = 0; this.sent = []; FakeSocket.lastInstance = this;
    queueMicrotask(() => { this.readyState = 1; this.dispatch('open');
      setTimeout(() => this.dispatch('message', { data: JSON.stringify({ message_type: 'session_started' }) }), 0);
    });
  }
  send(value) { this.sent.push(value); }
  close() { this.readyState = 3; this.dispatch('close'); }
}
class FakeNode {
  constructor() { this.port = { onmessage: null, postMessage() {} }; this.connected = false; }
  connect() { this.connected = true; }
  disconnect() { this.connected = false; }
}
let workletUrl = '';
let lastProcessor = null;
class FakeAudioContext {
  constructor() {
    this.sampleRate = 48000; this.state = 'running'; this.destination = {};
    this.audioWorklet = { addModule: async url => { workletUrl = url; } };
  }
  createMediaStreamSource() { return new FakeNode(); }
  createGain() { const node = new FakeNode(); node.gain = { value: 1 }; return node; }
  async resume() {}
  async close() { this.state = 'closed'; }
}
class FakeAudioWorkletNode extends FakeNode {
  constructor() { super(); lastProcessor = this; }
}
const tracks = [{ stopped: false, stop() { this.stopped = true; } }];
const stream = { getTracks: () => tracks };
const context = {
  window: null,
  navigator: { mediaDevices: { getUserMedia: async () => stream } },
  WebSocket: FakeSocket,
  AudioContext: FakeAudioContext,
  AudioWorkletNode: FakeAudioWorkletNode,
  URL,
  location: { origin: 'https://xynora.test' },
  setTimeout, clearTimeout,
  btoa: value => Buffer.from(value, 'binary').toString('base64'),
  Float32Array, Int16Array, Uint8Array, DataView, ArrayBuffer, Math, Number, TypeError, RangeError, Promise,
};
context.window = context;
vm.runInNewContext(source, context);
const session = await context.SayroxSpeechInput.start({ token: 'single-use-test-token', stream, maxDurationMs: 30000 });
assert.equal(session.processorMode, 'audio-worklet');
assert.equal(workletUrl, 'https://xynora.test/src/core/speech-pcm-worklet.js');
assert.ok(lastProcessor?.port?.onmessage);
const samples = new Float32Array(2048).fill(0.25);
lastProcessor.port.onmessage({ data: samples.buffer });
// Inspect the live socket captured by the test constructor.
assert.equal(FakeSocket.lastInstance?.sent?.length > 0, true);
const audioMessage = JSON.parse(FakeSocket.lastInstance.sent.at(-1));
assert.equal(audioMessage.message_type, 'input_audio_chunk');
assert.ok(typeof audioMessage.audio_base_64 === 'string' && audioMessage.audio_base_64.length > 0);
session.stop();
assert.equal(session.active, false);
assert.equal(tracks[0].stopped, true);
console.log('Scribe AudioWorklet integration test: same-origin worklet, PCM send and stream teardown passed');
