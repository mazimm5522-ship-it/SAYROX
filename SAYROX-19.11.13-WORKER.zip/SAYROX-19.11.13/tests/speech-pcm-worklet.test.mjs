import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
const source = await readFile(new URL('../site/src/core/speech-pcm-worklet.js', import.meta.url), 'utf8');
let Processor = null;
class AudioWorkletProcessor { constructor(){ this.port={onmessage:null, sent:[], postMessage(data){this.sent.push(data)}}; } }
vm.runInNewContext(source, { AudioWorkletProcessor, registerProcessor(name, ctor){ assert.equal(name,'xynora-pcm-capture'); Processor=ctor; }, Float32Array, Math });
assert.ok(Processor);
const processor = new Processor({processorOptions:{chunkSize:512}});
const input = new Float32Array(640).fill(0.25);
const output = new Float32Array(128).fill(1);
processor.process([[input]], [[output]]);
assert.deepEqual([...output], Array(128).fill(0));
assert.equal(processor.port.sent.length, 1);
assert.equal(processor.port.sent[0].byteLength, 512*4);
processor.port.onmessage({data:{type:'stop'}});
assert.equal(processor.process([[input]], [[output]]), false);
console.log('AudioWorklet tests: chunk transfer, silence output and stop handling passed');
