import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');
const [app, html, sw, integrations] = await Promise.all([read('site/src/app.js'), read('site/index.html'), read('site/sw.js'), read('site/src/features/settings/pages/integrations.js')]);

// Modules open the real pages; the old "not connected" placeholders are gone.
assert.match(app, /if\(key==='images'\)\{renderImagesStudio\(root\);return\}/);
assert.match(app, /if\(key==='tasks'\)\{renderTasksPage\(root\);return\}/);
assert.ok(!app.includes('موتور تولید تصویر هنوز به این نسخه متصل نشده'));
assert.ok(!app.includes('اجرای خودکار و اعلان سروری تا اتصال Scheduler فعال نیست'));
// Image studio talks to the server API and never exposes keys or stores images remotely.
assert.match(app, /fetch\('\/api\/images\/generate'/);
assert.match(app, /indexedDB\.open\(IMAGE_DB_NAME/);
assert.ok(!/localStorage[^;]*dataUrl/.test(app), 'image data must not be written to localStorage');
// Task inbox never opens the sign-in screen by itself and runs after login.
const inbox = app.slice(app.indexOf('async function checkTaskInbox'), app.indexOf('async function checkTaskInbox') + 900);
assert.ok(!inbox.includes('authScreen') && !inbox.includes('protectedApiAuthError'));
assert.match(app, /toast\('ورود موفق بود'\);\s*checkTaskInbox\(true\)/);
// Styles are linked and precached; health rows exist.
assert.ok(html.includes('src/styles/studio.css') && sw.includes('/src/styles/studio.css'));
assert.ok(integrations.includes('ctx.providers.images') && integrations.includes('ctx.providers.tasks'));
console.log('Studio wiring tests passed');
