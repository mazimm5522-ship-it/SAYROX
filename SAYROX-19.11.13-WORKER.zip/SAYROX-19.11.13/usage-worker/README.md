# SAYROX Usage Storage Worker

`UsageAccountObject` stores per-account monthly feature counters and request reservations in SQLite Durable Objects. The Pages Worker reads the active subscription from `BILLING_ACCOUNT` and passes only that server-derived snapshot to `USAGE_ACCOUNT`; clients cannot submit their tier, period, or limit.

Reservation flow: reserve atomically -> call provider -> commit on success or release on failure. Reservation IDs are idempotent, expired reservations are reclaimed, and storage failures fail closed.

Initial monthly caps are defined in `src/index.js` and documented in `../docs/quota-policy.json`. These are staging values and require provider-cost validation before production.

The `voice_input` feature meters Scribe real-time dictation separately from `live_voice`. The client currently applies a 3-minute session stop; this is not a tamper-proof duration limit and must be enforced server-side before Production.
