import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { DatabaseSync } from 'node:sqlite';

let source = await readFile(new URL('../src/index.js', import.meta.url), 'utf8');
source = source.replace("import { DurableObject } from 'cloudflare:workers';", 'class DurableObject { constructor(ctx, env) { this.ctx = ctx; this.env = env; } }');
const sourceUrl = `data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;
const { UsageAccountObject } = await import(sourceUrl);

function createObject() {
  const db = new DatabaseSync(':memory:');
  const sql = {
    exec(query, ...args) {
      if (!args.length && /;\s*(CREATE|INSERT|UPDATE|DELETE|ALTER)/i.test(query)) {
        db.exec(query);
        return { toArray: () => [], one: () => null };
      }
      const statement = db.prepare(query);
      if (/^\s*(SELECT|WITH)\b/i.test(query)) {
        const rows = statement.all(...args);
        return { toArray: () => rows, one: () => rows[0] ?? null };
      }
      statement.run(...args);
      return { toArray: () => [], one: () => null };
    }
  };
  const storage = { sql, transactionSync(callback) { db.exec('BEGIN IMMEDIATE'); try { const value = callback(); db.exec('COMMIT'); return value; } catch (error) { db.exec('ROLLBACK'); throw error; } } };
  const ctx = { storage, blockConcurrencyWhile(callback) { this.initialization = Promise.resolve().then(callback); return this.initialization; } };
  const instance = new UsageAccountObject(ctx, {});
  return { instance, db, ready: ctx.initialization };
}
const uuid = () => crypto.randomUUID();

{
  const { instance, db, ready } = createObject();
  await ready;
  const id = uuid(), now = Date.now();
  const record = {
    runId: id, specialist: 'research', state: 'running', createdAt: now, updatedAt: now,
    durationMs: 12, stepCount: 1,
    toolEvents: [{ tool: 'web_research', status: 'success' }, { tool: 'dangerous_tool!', status: 'failed', code: 'TOOL_NOT_FOUND' }, { tool: 'create_scheduled_task', status: 'cancelled' }],
    researchStatus: 'completed', researchMode: 'deep', sourceCount: 4, provider: 'gapgpt', model: 'test-model'
  };
  assert.equal((await instance.recordAgentRun(record)).ok, true);
  const listed = await instance.listAgentRuns(10);
  assert.equal(listed.runs.length, 1);
  assert.equal(listed.runs[0].runId, id);
  assert.equal(listed.runs[0].toolEvents[0].tool, 'web_research');
  assert.equal(listed.runs[0].toolEvents[1].tool, 'unknown_tool');
  assert.equal(listed.runs[0].toolEvents[2].status, 'cancelled');
  assert.equal(listed.runs[0].researchMode, 'deep');

  assert.equal((await instance.recordAgentRun({ ...record, state: 'completed', updatedAt: now + 50, durationMs: 50, stepCount: 2 })).ok, true);
  const detail = await instance.getAgentRun(id);
  assert.equal(detail.run.state, 'completed');
  assert.equal(detail.run.durationMs, 50);
  assert.equal((await instance.deleteAgentRun(id)).ok, true);
  assert.equal((await instance.getAgentRun(id)).code, 'AGENT_RUN_NOT_FOUND');
  db.close();
}

{
  const { instance, db, ready } = createObject();
  await ready;
  assert.equal((await instance.recordAgentRun({ runId: 'bad', state: 'completed', specialist: 'main' })).code, 'INVALID_AGENT_RUN');
  assert.equal((await instance.recordAgentRun({ runId: uuid(), state: 'unknown', specialist: 'main' })).code, 'INVALID_AGENT_RUN');
  for (let i = 0; i < 105; i++) {
    const id = uuid();
    await instance.recordAgentRun({ runId: id, state: 'completed', specialist: 'main', createdAt: Date.now() + i, updatedAt: Date.now() + i });
  }
  const firstPage = await instance.listAgentRuns(50, 0);
  const secondPage = await instance.listAgentRuns(50, 50);
  assert.equal(firstPage.runs.length, 50);
  assert.equal(firstPage.hasMore, true);
  assert.equal(secondPage.runs.length, 50);
  assert.equal(secondPage.hasMore, false);
  assert.equal(new Set([...firstPage.runs, ...secondPage.runs].map(run => run.runId)).size, 100);
  assert.equal(db.prepare('SELECT COUNT(*) AS total FROM agent_run_history').get().total, 100);
  assert.equal((await instance.clearAgentRuns()).ok, true);
  assert.equal((await instance.listAgentRuns()).runs.length, 0);

  const staleId = uuid();
  const staleAt = Date.now() - 91 * 86400_000;
  assert.equal((await instance.recordAgentRun({ runId: staleId, state: 'completed', specialist: 'main', createdAt: staleAt, updatedAt: staleAt })).ok, true);
  assert.equal((await instance.getAgentRun(staleId)).code, 'AGENT_RUN_NOT_FOUND');
  db.close();
}

console.log('agent history storage tests: persistence, upsert, validation, 100-run/90-day retention and deletion passed');

{
  const { instance, db, ready } = createObject();
  await ready;
  const ticketId = uuid(), accountKey = 'x'.repeat(43), now = Date.now();
  const accepted = await instance.consumeAgentApproval(ticketId, accountKey, now + 300_000, 'approved', now);
  assert.equal(accepted.ok, true);
  assert.equal((await instance.consumeAgentApproval(ticketId, accountKey, now + 300_000, 'approved', now + 1)).code, 'AGENT_APPROVAL_REPLAYED');
  const deniedId = uuid();
  assert.equal((await instance.consumeAgentApproval(deniedId, accountKey, now + 300_000, 'denied', now)).decision, 'denied');
  assert.equal((await instance.consumeAgentApproval(uuid(), accountKey, now - 1, 'approved', now)).code, 'INVALID_AGENT_APPROVAL');
  assert.equal((await instance.consumeAgentApproval(uuid(), 'bad', now + 300_000, 'approved', now)).code, 'INVALID_AGENT_APPROVAL');
  assert.equal(db.prepare('SELECT COUNT(*) AS total FROM agent_approval_tickets').get().total, 2);
  db.close();
}
