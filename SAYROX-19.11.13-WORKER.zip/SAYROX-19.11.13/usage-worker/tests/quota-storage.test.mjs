import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { DatabaseSync } from 'node:sqlite';
import { pathToFileURL } from 'node:url';

const sourcePath = new URL('../../usage-worker/src/index.js', import.meta.url);
let source = await readFile(sourcePath, 'utf8');
source = source.replace("import { DurableObject } from 'cloudflare:workers';", 'class DurableObject { constructor(ctx, env) { this.ctx = ctx; this.env = env; } }');

const sourceUrl = `data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;
const { UsageAccountObject } = await import(sourceUrl);

function createObject() {
  const db = new DatabaseSync(':memory:');
  const sql = {
    exec(query, ...args) {
      if (!args.length && /;\s*(CREATE|INSERT|UPDATE|DELETE|ALTER)/i.test(query)) {
        db.exec(query);
        return { toArray: () => [], one: () => null };
      }
      const statement = db.prepare(query);
      if (/^\s*(SELECT|WITH)\b/i.test(query)) {
        const rows = statement.all(...args);
        return { toArray: () => rows, one: () => rows[0] ?? null };
      }
      statement.run(...args);
      return { toArray: () => [], one: () => null };
    }
  };
  const storage = {
    sql,
    transactionSync(callback) {
      db.exec('BEGIN IMMEDIATE');
      try { const result = callback(); db.exec('COMMIT'); return result; }
      catch (error) { db.exec('ROLLBACK'); throw error; }
    }
  };
  const ctx = { storage, blockConcurrencyWhile(callback) { this.initialization = Promise.resolve().then(callback); return this.initialization; } };
  const instance = new UsageAccountObject(ctx, {});
  return { instance, db, ready: ctx.initialization };
}
const uid = () => crypto.randomUUID();

// Free account: atomic reservations, release, commit and exhaustion.
{
  const { instance, db, ready } = createObject();
  await ready;
  const first = uid();
  assert.equal((await instance.reserveUsageBatch(first, [{ feature: 'chat', amount: 1 }])).ok, true);
  assert.equal((await instance.releaseUsage(first)).released, 1);
  let snapshot = await instance.getUsageSnapshot();
  assert.equal(snapshot.tier, 'free');
  assert.equal(snapshot.features.chat.used, 0);
  assert.equal(snapshot.features.chat.reserved, 0);

  for (let index = 0; index < 30; index++) {
    const requestId = uid();
    assert.equal((await instance.reserveUsageBatch(requestId, [{ feature: 'chat' }])).ok, true);
    assert.equal((await instance.commitUsage(requestId)).ok, true);
    assert.equal((await instance.commitUsage(requestId)).duplicate, true);
  }
  const denied = await instance.reserveUsageBatch(uid(), [{ feature: 'chat' }]);
  assert.equal(denied.ok, false);
  assert.equal(denied.code, 'QUOTA_EXCEEDED');
  assert.equal(denied.used, 30);
  snapshot = await instance.getUsageSnapshot();
  assert.equal(snapshot.features.chat.remaining, 0);
  db.close();
}

// Concurrent final slot: only one reservation can take it.
{
  const { instance, db, ready } = createObject();
  await ready;
  for (let index = 0; index < 29; index++) {
    const requestId = uid();
    await instance.reserveUsageBatch(requestId, [{ feature: 'chat' }]);
    await instance.commitUsage(requestId);
  }
  const results = await Promise.all([
    instance.reserveUsageBatch(uid(), [{ feature: 'chat' }]),
    instance.reserveUsageBatch(uid(), [{ feature: 'chat' }])
  ]);
  assert.equal(results.filter(result => result.ok).length, 1);
  assert.equal(results.filter(result => result.code === 'QUOTA_EXCEEDED').length, 1);
  db.close();
}

// A server-derived active subscription overrides Free quotas and uses its paid monthly cycle.
{
  const { instance, db, ready } = createObject();
  await ready;
  const now = Date.now();
  const subscription = { subscriptionId: uid(), planId: 'plus-3m', tier: 'advanced', months: 3,
    startsAt: now - 1000, expiresAt: now + 90 * 86400000, status: 'active' };
  const requestId = uid();
  const reservation = await instance.reserveUsageBatch(requestId, [{ feature: 'chat' }, { feature: 'images', amount: 2 }], subscription);
  assert.equal(reservation.ok, true);
  await instance.commitUsage(requestId);
  const snapshot = await instance.getUsageSnapshot(subscription);
  assert.equal(snapshot.tier, 'advanced');
  assert.equal(snapshot.isPlus, true);
  assert.equal(snapshot.features.chat.used, 1);
  assert.equal(snapshot.features.images.used, 2);
  assert.equal(snapshot.features.chat.limit, 450);
  db.close();
}

// Invalid features and idempotency-key reuse with a changed payload are rejected.
{
  const { instance, db, ready } = createObject();
  await ready;
  assert.equal((await instance.reserveUsageBatch(uid(), [{ feature: 'not-a-feature' }])).code, 'INVALID_USAGE_ITEM');
  const requestId = uid();
  assert.equal((await instance.reserveUsageBatch(requestId, [{ feature: 'chat' }])).ok, true);
  assert.equal((await instance.reserveUsageBatch(requestId, [{ feature: 'search' }])).code, 'USAGE_IDEMPOTENCY_CONFLICT');
  db.close();
}


// Scribe voice input is tracked independently from live conversation voice.
{
  const { instance, db, ready } = createObject();
  await ready;
  for (let index = 0; index < 10; index++) {
    const requestId = uid();
    const reserved = await instance.reserveUsageBatch(requestId, [{ feature: 'voice_input' }]);
    assert.equal(reserved.ok, true);
    assert.equal((await instance.commitUsage(requestId)).ok, true);
  }
  const denied = await instance.reserveUsageBatch(uid(), [{ feature: 'voice_input' }]);
  assert.equal(denied.ok, false);
  assert.equal(denied.code, 'QUOTA_EXCEEDED');
  const snapshot = await instance.getUsageSnapshot();
  assert.equal(snapshot.features.voice_input.used, 10);
  assert.equal(snapshot.features.voice_input.remaining, 0);
  db.close();
}

console.log('quota storage tests: 5 groups passed');
