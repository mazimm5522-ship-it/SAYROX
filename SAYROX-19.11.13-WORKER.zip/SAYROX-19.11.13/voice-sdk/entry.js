// First-party build entry for the official ElevenLabs browser SDK.
// `npm run build:voice-sdk` bundles it into site/vendor/elevenlabs-client.mjs (same-origin, no CDN).
import { Conversation } from '@elevenlabs/client';
export { Conversation };
