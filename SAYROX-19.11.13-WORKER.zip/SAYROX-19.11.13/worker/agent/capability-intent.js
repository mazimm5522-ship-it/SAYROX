"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.detectCapabilityIntent = detectCapabilityIntent;
function latestUserText(messages) {
    if (!Array.isArray(messages)) return "";
    for (let index = messages.length - 1; index >= 0; index--) {
        const message = messages[index];
        if (message?.role !== "user") continue;
        if (typeof message.content === "string") return message.content.slice(0, 12_000);
        if (Array.isArray(message.content)) return message.content.filter(part => part?.type === "text" && typeof part.text === "string").map(part => part.text).join(" ").slice(0, 12_000);
    }
    return "";
}
function normalize(value) {
    return String(value || "").toLocaleLowerCase("fa").replace(/[يى]/g, "ی").replace(/ك/g, "ک").replace(/[\u064b-\u065f\u0670\u0640]/g, "").replace(/\s+/g, " ").trim();
}
function detectCapabilityIntent(messages) {
    const text = normalize(latestUserText(messages));
    const imageRequest = /\b(generate|create|make|draw)\s+(?:me\s+)?(?:an?\s+)?(?:image|picture|illustration)\b|تصویر\s*(?:بساز|ایجاد\s*کن|تولید\s*کن)|عکس\s*(?:بساز|ایجاد\s*کن)|تولید\s*تصویر/.test(text);
    const fileType = /\b(word|docx|pdf|excel|xlsx|spreadsheet)\b|ورد|پی.?دی.?اف|اکسل|صفحه.?گسترده|فایل\s*(?:word|pdf|excel)?/.test(text);
    const createVerb = /\b(create|make|generate|export|download|build)\b|بساز|ساخت|ایجاد\s*کن|تولید\s*کن|خروجی\s*بگیر|تبدیل\s*کن/.test(text);
    const createFile = fileType && createVerb && !/\b(read|open|analy[sz]e|summari[sz]e|review)\b|بخوان|باز\s*کن|تحلیل\s*کن|خلاصه\s*کن/.test(text);
    const scheduledTask = /\b(remind\s+me|set\s+(?:a\s+)?reminder|schedule\s+(?:this|a\s+task)|every\s+(?:day|week)|daily|weekly)\b|یادآوری\s*کن|برام\s*یادآور|زمان.?بندی\s*کن|هر\s*روز|هر\s*هفته|روزانه|هفتگی/.test(text);
    const memorySearch = /\b(what\s+do\s+you\s+remember|search\s+my\s+memory|what\s+is\s+saved\s+about\s+me)\b|چی\s*(?:از من|درباره.?ی من)\s*(?:یادت|می.?دونی)|چه\s*چیزی\s*(?:از من|درباره.?ی من)\s*(?:یادت|ذخیره)|حافظه.?ات\s*(?:چی|چه)/.test(text);
    const executeCode = /\b(?:run|execute|test)\b.{0,50}\b(?:code|script|python)\b|\b(?:code|script|python)\b.{0,50}\b(?:run|execute|test)\b|کد.{0,45}(?:اجرا|ران|تست)|(?:اجرا|ران|تست).{0,45}کد|پایتون.{0,45}(?:اجرا|تست)|(?:اجرا|تست).{0,45}پایتون/.test(text);
    return Object.freeze({ generateImage: imageRequest, createFile, scheduleTask: scheduledTask, searchMemory: memorySearch, executeCode });
}
