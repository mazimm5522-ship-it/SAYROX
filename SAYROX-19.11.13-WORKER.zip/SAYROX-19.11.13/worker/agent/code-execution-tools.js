"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPythonExecutionTool = createPythonExecutionTool;

const MAX_CODE_CHARS = 8_000;
const MAX_RESPONSE_BYTES = 36_000;

function toBase64Url(bytes) {
    let binary = "";
    for (const byte of new Uint8Array(bytes)) binary += String.fromCharCode(byte);
    return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

async function signRequest(secret, timestamp, body) {
    const key = await crypto.subtle.importKey(
        "raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
    );
    const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`${timestamp}.${body}`));
    return toBase64Url(signature);
}

async function deriveJobId(accountKey, runId, invocationId) {
    const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`sayrox-code-job-v1\n${accountKey}\n${runId}\n${invocationId}`));
    return Array.from(new Uint8Array(bytes), byte => byte.toString(16).padStart(2, "0")).join("");
}

function createPythonExecutionTool({ env, accountKey } = {}) {
    const service = env?.CODE_SANDBOX;
    const secret = typeof env?.CODE_SANDBOX_INTERNAL_SECRET === "string" ? env.CODE_SANDBOX_INTERNAL_SECRET : "";
    if (!accountKey || !service || typeof service.fetch !== "function" || secret.length < 32) return null;
    return {
        id: "execute_python",
        specialist: "coding",
        description: "Run user-requested Python code inside a dedicated isolated Linux microVM with outbound Internet disabled. Requires explicit user approval.",
        risk: "sandbox_execution",
        requiresApproval: true,
        timeoutMs: 24_000,
        providerSchema: {
            type: "function",
            function: {
                name: "execute_python",
                description: "Execute Python 3.13 code only when the user explicitly asks to run, execute, test, or calculate by executing code. Do not call this when the user only asks to write or explain code. The isolated environment has Python standard library only, no Internet, no API credentials, and a temporary one-job workspace. The user must approve before execution.",
                parameters: {
                    type: "object", additionalProperties: false,
                    properties: {
                        language: { type: "string", enum: ["python"] },
                        code: { type: "string", minLength: 1, maxLength: MAX_CODE_CHARS }
                    }, required: ["language", "code"]
                }
            }
        },
        validateArgs(args) {
            return Boolean(args && typeof args === "object" && !Array.isArray(args)
                && Object.keys(args).every(key => ["language", "code"].includes(key))
                && args.language === "python"
                && typeof args.code === "string" && args.code.trim().length > 0
                && args.code.length <= MAX_CODE_CHARS
                && new TextEncoder().encode(args.code).byteLength <= 12_000);
        },
        async handler(args, context = {}) {
            if (context.signal?.aborted) return { ok: false, code: "EXECUTION_CANCELLED", message: "اجرای کد لغو شد." };
            if (!/^[A-Za-z0-9_-]{8,80}$/.test(context.runId || "")) return { ok: false, code: "INVALID_EXECUTION_CONTEXT", message: "شناسهٔ اجرای امن موجود نیست." };
            // A fresh invocation id permits multiple approved code calls in one Agent run
            // while keeping each signed request one-use and replay-isolated.
            const invocationId = crypto.randomUUID();
            const jobId = await deriveJobId(accountKey, context.runId, invocationId);
            const payload = { version: 1, jobId, language: "python", code: args.code };
            const body = JSON.stringify(payload);
            const timestamp = String(Date.now());
            let response;
            try {
                const signature = await signRequest(secret, timestamp, body);
                response = await service.fetch(new Request("https://sayrox-code-sandbox.internal/internal/execute", {
                    method: "POST",
                    headers: {
                        "content-type": "application/json",
                        "x-sayrox-timestamp": timestamp,
                        "x-sayrox-signature": signature
                    },
                    body,
                    ...(context.signal ? { signal: context.signal } : {})
                }));
            } catch {
                return { ok: false, code: "CODE_SANDBOX_UNAVAILABLE", message: "ارتباط امن با محیط اجرای کد برقرار نشد؛ کدی اجرا نشده است." };
            }
            let responseText = "";
            try { responseText = await response.text(); } catch { }
            if (new TextEncoder().encode(responseText).byteLength > MAX_RESPONSE_BYTES) {
                return { ok: false, code: "CODE_SANDBOX_RESPONSE_TOO_LARGE", message: "پاسخ محیط اجرا از سقف مجاز بزرگ‌تر بود." };
            }
            let data;
            try { data = JSON.parse(responseText); } catch { data = null; }
            if (!response.ok || !data?.ok || !data.result || !Number.isInteger(data.result.exitCode)) {
                return {
                    ok: false,
                    code: typeof data?.code === "string" ? data.code.slice(0, 64) : "CODE_SANDBOX_FAILED",
                    message: typeof data?.message === "string" ? data.message.slice(0, 240) : "اجرای ایزولهٔ Python ناموفق بود."
                };
            }
            return {
                ok: true,
                language: "python",
                stdout: String(data.result.stdout || "").slice(0, 18_000),
                stderr: String(data.result.stderr || "").slice(0, 18_000),
                exitCode: data.result.exitCode,
                outputTruncated: data.result.outputTruncated === true,
                timedOut: data.result.timedOut === true,
                isolation: "cloudflare_container_no_internet"
            };
        }
    };
}
