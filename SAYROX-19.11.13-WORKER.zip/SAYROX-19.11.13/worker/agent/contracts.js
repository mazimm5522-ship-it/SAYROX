"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AGENT_SPECIALISTS = exports.AGENT_RUN_STATES = exports.MAX_AGENT_STEPS = exports.MAX_AGENT_TOOL_ARGUMENT_BYTES = exports.MAX_AGENT_TOOL_RESULT_BYTES = exports.MAX_AGENT_TOOL_TIMEOUT_MS = void 0;
exports.AGENT_RUN_STATES = Object.freeze([
    'created', 'understanding', 'planning', 'awaiting_approval', 'executing',
    'verifying', 'responding', 'completed', 'failed', 'cancelled'
]);
exports.MAX_AGENT_STEPS = 6;
exports.MAX_AGENT_TOOL_ARGUMENT_BYTES = 16_384;
exports.MAX_AGENT_TOOL_RESULT_BYTES = 131_072;
exports.MAX_AGENT_TOOL_TIMEOUT_MS = 95_000;
exports.AGENT_SPECIALISTS = Object.freeze({
    main: Object.freeze({ id: 'main', label: 'دستیار اصلی', purpose: 'مدیریت گفتگو، استدلال عمومی و هماهنگی' }),
    research: Object.freeze({ id: 'research', label: 'پژوهشگر', purpose: 'تحقیق، بررسی شواهد و منابع' }),
    coding: Object.freeze({ id: 'coding', label: 'برنامه‌نویس', purpose: 'تحلیل کد، طراحی راه‌حل و رفع اشکال' }),
    documents: Object.freeze({ id: 'documents', label: 'متخصص اسناد', purpose: 'خواندن و توضیح اسناد و فایل‌های پیوست‌شده' }),
    data: Object.freeze({ id: 'data', label: 'تحلیلگر داده', purpose: 'تحلیل جدول‌ها، داده‌ها و نمودارها' }),
    creative: Object.freeze({ id: 'creative', label: 'متخصص خلاق', purpose: 'ایده‌پردازی و نگارش خلاقانه' })
});
