"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createImageGenerationTool = createImageGenerationTool;
const images_js_1 = __load("worker/features/images.js");

function createImageGenerationTool({ env, accountKey, origin, onGenerated } = {}) {
    if (!accountKey || !(0, images_js_1.imageConfig)(env).ready) return null;
    return {
        id: "generate_image",
        specialist: "creative",
        description: "Generate one user-requested image using the configured image provider and account quota. Returns image through a separate UI event, not through the model token context.",
        risk: "create",
        requiresApproval: true,
        timeoutMs: 90_000,
        providerSchema: {
            type: "function",
            function: {
                name: "generate_image",
                description: "Generate a real image only when the user explicitly requested image creation. Produce one image per chat turn. Describe the visual result in the final response only after the tool succeeds.",
                parameters: {
                    type: "object", additionalProperties: false,
                    properties: {
                        prompt: { type: "string", minLength: 3, maxLength: 1200 },
                        ratio: { type: "string", enum: ["1:1", "3:4", "4:3", "9:16", "16:9"] }
                    }, required: ["prompt"]
                }
            }
        },
        validateArgs(args) {
            return Boolean(args && typeof args === "object" && !Array.isArray(args) &&
                Object.keys(args).every(key => ["prompt", "ratio"].includes(key)) &&
                typeof args.prompt === "string" && args.prompt.trim().length >= 3 && args.prompt.length <= 1200 &&
                (args.ratio === undefined || ["1:1", "3:4", "4:3", "9:16", "16:9"].includes(args.ratio)));
        },
        async handler(args, context = {}) {
            const generated = await (0, images_js_1.generateImageData)(env, accountKey, args.prompt, args.ratio, { origin, signal: context.signal });
            if (!generated.ok) return { ok: false, code: generated.code || "IMAGE_GENERATION_FAILED", message: generated.message || "ساخت تصویر انجام نشد." };
            try { onGenerated?.(generated); } catch { return { ok: false, code: "IMAGE_DELIVERY_FAILED", message: "تصویر ساخته شد اما تحویل آن به رابط گفتگو انجام نشد." }; }
            return { generated: true, prompt: generated.prompt, ratio: generated.ratio, model: generated.model, bytes: generated.image.bytes, delivery: "chat_image_event" };
        }
    };
}
