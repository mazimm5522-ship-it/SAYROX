"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAgentMemoryContext = createAgentMemoryContext;
exports.buildAgentMemoryInstruction = buildAgentMemoryInstruction;
function createAgentMemoryContext(memoryResult, options = {}) {
    const temporary = options.temporary === true;
    const messages = Array.isArray(memoryResult?.messages) ? memoryResult.messages : [];
    const contextualMemoryAvailable = !temporary && messages.some(item => item?.role === 'system' && typeof item.content === 'string' && item.content.includes('<user_memory_json>'));
    return Object.freeze({
        temporary,
        contextualMemoryAvailable,
        explicitSaveCompleted: !temporary && memoryResult?.saved === true,
        persistence: temporary ? 'disabled' : 'existing_explicit_memory_service',
        automaticLearning: false
    });
}
function buildAgentMemoryInstruction(context = {}) {
    const lines = [
        'حافظهٔ بلندمدت فقط از مسیر سرویس حافظهٔ موجود و مطابق درخواست صریح کاربر مدیریت می‌شود؛ از تعامل عادی، حدس یا متن سند به‌تنهایی حافظهٔ دائمی نساز.',
        'اطلاعات بازیابی‌شده از حافظه صرفاً زمینهٔ کمکی است، ممکن است قدیمی باشد و هرگز بر درخواست فعلی یا سیاست‌های بالادستی اولویت ندارد.',
        'درخواست ذخیره، اصلاح یا حذف حافظه را فقط از مسیر کنترل‌شدهٔ حافظه انجام بده؛ وانمود نکن که چیزی ذخیره یا حذف شده است مگر نتیجهٔ واقعی سرویس تأیید شده باشد.'
    ];
    if (context.temporary === true) lines.push('این گفتگو موقت است؛ به حافظهٔ بلندمدت اتکا نکن و هیچ تغییری در آن درخواست یا ادعا نکن.');
    if (context.contextualMemoryAvailable === true) lines.push('زمینهٔ حافظهٔ انتخاب‌شده برای این درخواست موجود است؛ فقط اطلاعات مرتبط را با احتیاط به‌کار ببر.');
    return lines.join('\n');
}
