"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TOOL_RISKS = void 0;
exports.evaluateToolPermission = evaluateToolPermission;
exports.TOOL_RISKS = Object.freeze(['read', 'create', 'modify', 'delete', 'external_send', 'financial', 'deployment', 'credentials', 'arbitrary_code', 'unrestricted_network', 'sandbox_execution']);
const DENIED_RISKS = new Set(['credentials', 'arbitrary_code', 'unrestricted_network']);
const APPROVAL_RISKS = new Set(['modify', 'delete', 'external_send', 'financial', 'deployment', 'sandbox_execution']);
function evaluateToolPermission(tool, context = {}) {
    const risk = typeof tool?.risk === 'string' ? tool.risk : 'unclassified';
    if (!exports.TOOL_RISKS.includes(risk)) return { allowed: false, code: 'UNCLASSIFIED_TOOL_RISK', requiresApproval: false };
    if (tool.enabled === false) return { allowed: false, code: 'TOOL_DISABLED', requiresApproval: false };
    if (DENIED_RISKS.has(risk)) return { allowed: false, code: 'TOOL_RISK_BLOCKED', requiresApproval: false };
    const requiresApproval = APPROVAL_RISKS.has(risk) || tool.requiresApproval === true;
    if (requiresApproval && context.approved !== true) return { allowed: false, code: 'APPROVAL_REQUIRED', requiresApproval: true };
    if (context.userInitiated !== true) return { allowed: false, code: 'USER_INITIATION_REQUIRED', requiresApproval };
    return { allowed: true, code: 'ALLOWED', requiresApproval };
}
