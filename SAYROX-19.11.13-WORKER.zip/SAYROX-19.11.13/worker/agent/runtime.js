"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAgentRun = createAgentRun;
exports.transitionAgentRun = transitionAgentRun;
exports.prepareAgentTurn = prepareAgentTurn;
exports.finishAgentRun = finishAgentRun;
const contracts_js_1 = __load("worker/agent/contracts.js");
const planner_js_1 = __load("worker/agent/planner.js");
const ALLOWED_TRANSITIONS = Object.freeze({
    created: ['understanding', 'cancelled', 'failed'],
    understanding: ['planning', 'cancelled', 'failed'],
    planning: ['awaiting_approval', 'executing', 'responding', 'cancelled', 'failed'],
    awaiting_approval: ['executing', 'cancelled', 'failed'],
    executing: ['awaiting_approval', 'verifying', 'cancelled', 'failed'],
    verifying: ['executing', 'responding', 'completed', 'cancelled', 'failed'],
    responding: ['awaiting_approval', 'executing', 'completed', 'cancelled', 'failed'],
    completed: [], failed: [], cancelled: []
});
function createAgentRun(id, now = Date.now()) {
    const runId = typeof id === 'string' && /^[A-Za-z0-9_-]{8,80}$/.test(id) ? id : '';
    if (!runId) throw new Error('invalid_agent_run_id');
    return { id: runId, state: 'created', stepCount: 0, createdAt: Number.isFinite(now) ? now : Date.now(), updatedAt: Number.isFinite(now) ? now : Date.now(), specialist: 'main', failureCode: '', pendingApprovalToolId: '', approvalGrantsUsed: [] };
}
function transitionAgentRun(run, nextState, now = Date.now()) {
    if (!run || !Array.isArray(ALLOWED_TRANSITIONS[run.state]) || !ALLOWED_TRANSITIONS[run.state].includes(nextState)) throw new Error('invalid_agent_state_transition');
    run.state = nextState;
    run.updatedAt = Number.isFinite(now) ? now : Date.now();
    return run;
}
function prepareAgentTurn(messages, context, options = {}) {
    const run = createAgentRun(options.runId || (typeof crypto !== 'undefined' && crypto.randomUUID ? crypto.randomUUID() : 'agent-run-00000000'));
    transitionAgentRun(run, 'understanding');
    transitionAgentRun(run, 'planning');
    const plan = (0, planner_js_1.buildAgentPlan)(messages, context, { runId: run.id });
    run.specialist = plan.specialist;
    transitionAgentRun(run, 'responding');
    const memoryContext = options.memoryContext && typeof options.memoryContext === 'object' ? options.memoryContext : {};
    return Object.freeze({ run, plan, systemMessage: (0, planner_js_1.buildAgentSystemMessage)(plan, memoryContext) });
}
function finishAgentRun(run, outcome = 'completed') {
    if (!['completed', 'failed', 'cancelled'].includes(outcome)) throw new Error('invalid_agent_terminal_state');
    if (run.state === outcome) return run;
    transitionAgentRun(run, outcome);
    return run;
}
