"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createScheduledTaskTool = createScheduledTaskTool;
const constants_js_1 = __load("worker/shared/constants.js");
const http_js_1 = __load("worker/shared/http.js");
const quotas_js_1 = __load("worker/features/quotas.js");
const TIMEZONE_PATTERN = /^[A-Za-z][A-Za-z0-9_+\-]*(?:\/[A-Za-z0-9_+\-]+){0,2}$/;
function validSchedule(schedule) {
    if (!schedule || typeof schedule !== "object" || Array.isArray(schedule)) return false;
    if (Object.keys(schedule).some(key => !['type', 'date', 'weekday', 'time', 'timezone'].includes(key))) return false;
    if (!['once', 'daily', 'weekly'].includes(schedule.type) || typeof schedule.time !== 'string' || !/^([01]\d|2[0-3]):([0-5]\d)$/.test(schedule.time)) return false;
    if (typeof schedule.timezone !== 'string' || schedule.timezone.length > 64 || !TIMEZONE_PATTERN.test(schedule.timezone)) return false;
    try { new Intl.DateTimeFormat('en-US', { timeZone: schedule.timezone }); } catch { return false; }
    if (schedule.type === 'once') {
        const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(schedule.date || ''));
        if (!match || schedule.weekday !== undefined) return false;
        const date = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
        return date.getUTCFullYear() === Number(match[1]) && date.getUTCMonth() === Number(match[2]) - 1 && date.getUTCDate() === Number(match[3]);
    }
    if (schedule.type === 'weekly') return schedule.date === undefined && Number.isInteger(schedule.weekday) && schedule.weekday >= 0 && schedule.weekday <= 6;
    return schedule.date === undefined && schedule.weekday === undefined;
}
function taskStub(env, accountKey) {
    if (!env?.TASKS_ACCOUNT || typeof env.TASKS_ACCOUNT.get !== 'function' || typeof env.TASKS_ACCOUNT.idFromName !== 'function') throw new Error('TASKS_UNAVAILABLE');
    return env.TASKS_ACCOUNT.get(env.TASKS_ACCOUNT.idFromName(`xynora-account:${accountKey}`));
}
function createScheduledTaskTool({ env, accountKey, timezone = 'Asia/Tehran' } = {}) {
    if (!env?.TASKS_ACCOUNT || typeof env.TASKS_INTERNAL_SECRET !== 'string' || env.TASKS_INTERNAL_SECRET.length < 32 || !accountKey) return null;
    return {
        id: 'create_scheduled_task',
        specialist: 'main',
        description: 'Create a user-requested scheduled Agent task. Only register for clear, explicit scheduling requests and require a complete local date/time/timezone.',
        risk: 'create',
        requiresApproval: true,
        timeoutMs: 12000,
        providerSchema: {
            type: 'function',
            function: {
                name: 'create_scheduled_task',
                description: 'Create a scheduled SAYROX task only when the user explicitly asked to schedule or be reminded. Ask for missing date, time, recurrence or timezone instead of guessing. Types: once (date YYYY-MM-DD), daily, weekly (weekday 0=Sunday through 6=Saturday). Time is 24-hour local time.',
                parameters: {
                    type: 'object', additionalProperties: false,
                    properties: {
                        title: { type: 'string', minLength: 2, maxLength: 80 },
                        prompt: { type: 'string', minLength: 5, maxLength: 2000 },
                        schedule: {
                            type: 'object', additionalProperties: false,
                            properties: {
                                type: { type: 'string', enum: ['once', 'daily', 'weekly'] },
                                date: { type: 'string', pattern: '^\\d{4}-\\d{2}-\\d{2}$' },
                                weekday: { type: 'integer', minimum: 0, maximum: 6 },
                                time: { type: 'string', pattern: '^([01]\\d|2[0-3]):([0-5]\\d)$' },
                                timezone: { type: 'string', minLength: 1, maxLength: 64 }
                            }, required: ['type', 'time', 'timezone']
                        },
                        useSearch: { type: 'boolean' }
                    }, required: ['title', 'prompt', 'schedule']
                }
            }
        },
        validateArgs(args) {
            return Boolean(args && typeof args === 'object' && !Array.isArray(args) &&
                Object.keys(args).every(key => ['title', 'prompt', 'schedule', 'useSearch'].includes(key)) &&
                typeof args.title === 'string' && args.title.trim().length >= 2 && args.title.length <= 80 &&
                typeof args.prompt === 'string' && args.prompt.trim().length >= 5 && args.prompt.length <= 2000 &&
                (args.useSearch === undefined || typeof args.useSearch === 'boolean') && validSchedule(args.schedule));
        },
        async handler(args) {
            const tier = await (0, quotas_js_1.currentTier)(env, accountKey);
            if (!tier) return { ok: false, code: 'TASKS_UNAVAILABLE', message: 'سرویس سهمیهٔ کارهای زمان‌بندی‌شده در دسترس نیست.' };
            let result;
            try {
                result = await taskStub(env, accountKey).createTask({
                    title: (0, http_js_1.text)(args.title, 80), prompt: (0, http_js_1.text)(args.prompt, 2000),
                    schedule: args.schedule, useSearch: args.useSearch === true
                }, constants_js_1.TASK_LIMITS[tier], accountKey);
            } catch {
                return { ok: false, code: 'TASKS_UNAVAILABLE', message: 'سرویس زمان‌بندی موقتاً در دسترس نیست.' };
            }
            if (!result?.ok) return { ok: false, code: result?.code || 'TASK_CREATE_FAILED', message: result?.message || 'ساخت کار زمان‌بندی‌شده انجام نشد.' };
            return { ok: true, task: { id: result.task.id, title: result.task.title, schedule: result.task.schedule, nextRun: result.task.nextRun, enabled: result.task.enabled }, timezone: args.schedule.timezone || timezone };
        }
    };
}
