"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runAgentToolLoop = runAgentToolLoop;
exports.providerTools = providerTools;
const contracts_js_1 = __load("worker/agent/contracts.js");
const runtime_js_1 = __load("worker/agent/runtime.js");

const MAX_TOOL_ROUNDS = 4;
const MAX_TOOL_CALLS_PER_ROUND = 3;
const MAX_TOOL_ARGUMENT_TEXT = contracts_js_1.MAX_AGENT_TOOL_ARGUMENT_BYTES;
const MAX_AGENT_LOOP_MS = 120_000;

function providerTools(registry) {
    if (!registry || typeof registry.list !== "function") return [];
    return registry.list()
        .filter(tool => tool.enabled && tool.providerSchema)
        .map(tool => tool.providerSchema)
        .slice(0, 16);
}

function readToolCalls(data) {
    const message = data?.choices?.[0]?.message;
    const calls = Array.isArray(message?.tool_calls) ? message.tool_calls : [];
    if (calls.length) return calls.slice(0, MAX_TOOL_CALLS_PER_ROUND);
    const legacy = message?.function_call;
    if (legacy && typeof legacy === "object") {
        return [{ id: "legacy_function_call_0001", type: "function", function: legacy }];
    }
    return [];
}

function normalizeToolCall(call, fallbackIndex, run) {
    const fn = call?.function && typeof call.function === "object" ? call.function : {};
    const name = typeof fn.name === "string" ? fn.name : "";
    const raw = typeof fn.arguments === "string" ? fn.arguments : "";
    const id = typeof call?.id === "string" && /^[A-Za-z0-9_-]{1,128}$/.test(call.id)
        ? call.id
        : `sayrox-${run.id.slice(0, 24)}-${run.stepCount}-${fallbackIndex}`;
    if (!name || name.length > 64 || raw.length > MAX_TOOL_ARGUMENT_TEXT) {
        return { id, name, args: null, error: "INVALID_TOOL_CALL" };
    }
    try {
        const args = JSON.parse(raw);
        if (!args || typeof args !== "object" || Array.isArray(args)) {
            return { id, name, args: null, error: "INVALID_TOOL_ARGUMENTS" };
        }
        return { id, name, args };
    } catch {
        return { id, name, args: null, error: "INVALID_TOOL_ARGUMENTS" };
    }
}

function resultMessage(code) {
    const messages = {
        INVALID_TOOL_CALL: "درخواست ابزار از نظر ساختار معتبر نیست.",
        INVALID_TOOL_ARGUMENTS: "پارامترهای ابزار JSON معتبر یا مطابق قرارداد نیستند.",
        TOOL_NOT_FOUND: "این ابزار در فهرست مجاز Worker وجود ندارد.",
        TOOL_DISABLED: "این ابزار در محیط فعلی غیرفعال است.",
        STEP_LIMIT_REACHED: "سقف تعداد مراحل این اجرا رسیده است.",
        EXECUTION_CANCELLED: "اجرای ابزار لغو شد.",
        TOOL_TIMEOUT: "زمان اجرای ابزار به پایان رسید.",
        TOOL_EXECUTION_FAILED: "اجرای ابزار ناموفق بود.",
        TOOL_RISK_BLOCKED: "سیاست امنیتی اجرای این ابزار را مجاز نمی‌داند.",
        APPROVAL_REQUIRED: "برای این عملیات تأیید صریح کاربر لازم است."
    };
    return messages[code] || "اجرای ابزار موفق نبود؛ نتیجه را به‌عنوان موفقیت گزارش نکن.";
}

function safeToolOutput(value) {
    try {
        const text = JSON.stringify(value);
        if (typeof text !== "string") return "{}";
        return new TextEncoder().encode(text).byteLength <= contracts_js_1.MAX_AGENT_TOOL_RESULT_BYTES
            ? text
            : JSON.stringify({ ok: false, code: "TOOL_RESULT_TOO_LARGE", message: "خروجی ابزار برای ارسال به مدل بیش از حد بزرگ است." });
    } catch {
        return JSON.stringify({ ok: false, code: "INVALID_TOOL_RESULT", message: "خروجی ابزار قابل سریال‌سازی نبود." });
    }
}

async function runAgentToolLoop({ registry, run, messages, callModel, toolChoice = "auto", requiredToolId = "", signal, onToolResult, onEvent }) {
    if (!registry || !run || !Array.isArray(messages) || typeof callModel !== "function") {
        return { ok: false, code: "INVALID_TOOL_LOOP_CONTEXT" };
    }
    const tools = providerTools(registry);
    if (!tools.length) return { ok: false, code: "NO_TOOLS_AVAILABLE" };
    const conversation = messages.slice();
    const loopController = new AbortController();
    const parentSignal = signal;
    const abortFromParent = () => loopController.abort(parentSignal?.reason || "cancelled");
    if (parentSignal?.aborted) abortFromParent();
    else parentSignal?.addEventListener?.("abort", abortFromParent, { once: true });
    const loopTimer = setTimeout(() => loopController.abort("agent_tool_loop_timeout"), MAX_AGENT_LOOP_MS);
    const loopSignal = loopController.signal;
    let choice = toolChoice === "required" ? "required" : "auto";
    const mustUse = typeof requiredToolId === "string" && requiredToolId && typeof registry.has === "function" && registry.has(requiredToolId) ? requiredToolId : "";
    const requiredMissing = () => Boolean(mustUse) && !results.some(item => item.tool === mustUse);
    let rounds = 0;
    let calls = 0;
    let finalResult = null;
    const results = [];
    const notify = (type, tool = "") => {
        try { onEvent?.({ type, ...(typeof tool === "string" && tool ? { tool: tool.slice(0, 64) } : {}) }); } catch { }
    };

    try {
    while (rounds < MAX_TOOL_ROUNDS) {
        if (loopSignal.aborted) return { ok: false, code: loopSignal.reason === "agent_tool_loop_timeout" ? "AGENT_LOOP_TIMEOUT" : "EXECUTION_CANCELLED", rounds, calls, results };
        notify("thinking");
        const response = await callModel(conversation, choice, tools, loopSignal);
        if (!response?.ok) return { ok: false, code: "PROVIDER_FAILED", providerResult: response, rounds, calls, results };
        finalResult = response;
        const modelMessage = response.data?.choices?.[0]?.message;
        const toolCalls = readToolCalls(response.data);
        if (!toolCalls.length) {
            notify("responding");
            if (choice === "required" && calls === 0) {
                return { ok: false, code: "REQUIRED_TOOL_NOT_CALLED", providerResult: response, rounds, calls, results };
            }
            if (requiredMissing()) return { ok: false, code: "REQUIRED_TOOL_NOT_CALLED", providerResult: response, rounds, calls, results };
            return { ok: true, providerResult: response, messages: conversation, rounds, calls, results };
        }
        rounds++;
        if (modelMessage && typeof modelMessage === "object") {
            conversation.push({
                role: "assistant",
                ...(typeof modelMessage.content === "string" ? { content: modelMessage.content } : { content: null }),
                tool_calls: toolCalls.map((call, index) => {
                    const normalized = normalizeToolCall(call, index, run);
                    return {
                        id: normalized.id,
                        type: "function",
                        function: {
                            name: normalized.name || "unknown_tool",
                            arguments: typeof call?.function?.arguments === "string" ? call.function.arguments : "{}"
                        }
                    };
                })
            });
        }

        for (let index = 0; index < toolCalls.length; index++) {
            const call = normalizeToolCall(toolCalls[index], index, run);
            notify("tool_requested", call.name);
            let outcome;
            if (call.error) {
                outcome = { ok: false, code: call.error, message: resultMessage(call.error) };
            } else {
                outcome = await (async () => {
                    const tool = registry.get(call.name);
                    if (!tool) return { ok: false, code: "TOOL_NOT_FOUND", message: resultMessage("TOOL_NOT_FOUND") };
                    const executed = await __load("worker/agent/tool-registry.js").executeAgentTool(
                        registry, run, call.name, call.args,
                        { userInitiated: true, signal: loopSignal, onEvent: event => { if (event?.type === "started") notify("tool_started", call.name); } }
                    );
                    if (!executed.ok) return { ok: false, code: executed.code, message: executed.message || resultMessage(executed.code) };
                    return { ok: true, result: executed.result };
                })();
            }
            calls++;
            const entry = { tool: call.name || "unknown_tool", callId: call.id, outcome };
            results.push(entry);
            if (outcome.code === "APPROVAL_REQUIRED") {
                const pendingTool = registry.get(call.name);
                notify("approval_required", call.name);
                try { onToolResult?.(entry); } catch { }
                return {
                    ok: true, pendingApproval: {
                        toolId: call.name, callId: call.id, args: call.args,
                        risk: pendingTool?.risk || "unclassified",
                        description: pendingTool?.description || "برای این عملیات تأیید صریح لازم است.",
                        specialist: pendingTool?.specialist || "main"
                    },
                    rounds, calls, results
                };
            }
            notify(outcome.ok ? "tool_completed" : "tool_failed", call.name);
            try { onToolResult?.(entry); } catch { }
            conversation.push({
                role: "tool",
                tool_call_id: call.id,
                content: safeToolOutput(outcome)
            });
        }

        notify("verifying");
        if (run.state === "executing") {
            runtime_js_1.transitionAgentRun(run, "verifying");
            runtime_js_1.transitionAgentRun(run, "responding");
        }
        choice = requiredMissing() ? "required" : "auto";
        if (run.stepCount >= contracts_js_1.MAX_AGENT_STEPS) {
            conversation.push({ role: "system", content: "سقف امن مراحل ابزار برای این اجرا تکمیل شده است. ابزار دیگری فراخوانی نکن؛ فقط بر اساس نتایج واقعی موجود پاسخ بده و محدودیت را در صورت اثرگذاری اعلام کن." });
            notify("thinking");
            const final = await callModel(conversation, "none", [], loopSignal);
            if (!final?.ok) return { ok: false, code: "PROVIDER_FAILED", providerResult: final, rounds, calls, results };
            notify("responding");
            if (requiredMissing()) return { ok: false, code: "REQUIRED_TOOL_NOT_CALLED", providerResult: final, rounds, calls, results };
            return { ok: true, providerResult: final, messages: conversation, rounds, calls, results, limitReached: true };
        }
    }

    conversation.push({ role: "system", content: "حداکثر دورهای مجاز فراخوانی ابزار تمام شده است. ابزار دیگری در دسترس نیست؛ با شواهد فعلی پاسخ بده و اگر کار کامل نیست صریح بگو." });
    notify("thinking");
    const final = await callModel(conversation, "none", [], loopSignal);
    if (!final?.ok) return { ok: false, code: "PROVIDER_FAILED", providerResult: final, rounds, calls, results };
    notify("responding");
    if (requiredMissing()) return { ok: false, code: "REQUIRED_TOOL_NOT_CALLED", providerResult: final, rounds, calls, results };
    return { ok: true, providerResult: final, messages: conversation, rounds, calls, results, roundLimitReached: true };
    } finally {
        clearTimeout(loopTimer);
        parentSignal?.removeEventListener?.("abort", abortFromParent);
    }
}
