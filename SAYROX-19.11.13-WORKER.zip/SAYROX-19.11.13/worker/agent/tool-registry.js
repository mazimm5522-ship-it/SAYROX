"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createToolRegistry = createToolRegistry;
exports.executeAgentTool = executeAgentTool;
exports.approvalArgsHash = approvalArgsHash;
const contracts_js_1 = __load("worker/agent/contracts.js");
const policy_js_1 = __load("worker/agent/policy.js");
const runtime_js_1 = __load("worker/agent/runtime.js");
const TOOL_ID = /^[a-z][a-z0-9_.-]{1,63}$/;
function isPlainObject(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
    const prototype = Object.getPrototypeOf(value);
    return prototype === Object.prototype || prototype === null;
}
function safeJsonSize(value) {
    try {
        const serialized = JSON.stringify(value);
        return typeof serialized === 'string' ? new TextEncoder().encode(serialized).byteLength : Infinity;
    } catch { return Infinity; }
}
function canonicalValue(value) {
    if (Array.isArray(value)) return value.map(canonicalValue);
    if (value && typeof value === 'object') {
        const output = {};
        for (const key of Object.keys(value).sort()) output[key] = canonicalValue(value[key]);
        return output;
    }
    return value;
}
async function approvalArgsHash(value) {
    const serialized = JSON.stringify(canonicalValue(value));
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(serialized));
    return Array.from(new Uint8Array(digest), byte => byte.toString(16).padStart(2, '0')).join('');
}
function createToolRegistry(definitions = []) {
    if (!Array.isArray(definitions) || definitions.length > 32) throw new Error('invalid_tool_registry');
    const tools = new Map();
    for (const item of definitions) {
        if (!item || !TOOL_ID.test(item.id || '') || tools.has(item.id) || typeof item.handler !== 'function' || typeof item.validateArgs !== 'function') throw new Error('invalid_tool_definition');
        const risk = (0, policy_js_1.evaluateToolPermission)({ risk: item.risk, enabled: item.enabled !== false, requiresApproval: item.requiresApproval });
        if (risk.code === 'UNCLASSIFIED_TOOL_RISK') throw new Error('unclassified_tool_risk');
        const descriptor = Object.freeze({
            id: item.id,
            specialist: typeof item.specialist === 'string' ? item.specialist.slice(0, 32) : 'main',
            description: typeof item.description === 'string' ? item.description.slice(0, 240) : '',
            risk: item.risk,
            enabled: item.enabled !== false,
            requiresApproval: item.requiresApproval === true,
            providerSchema: item.providerSchema && typeof item.providerSchema === 'object' ? JSON.parse(JSON.stringify(item.providerSchema)) : null,
            timeoutMs: Number.isFinite(item.timeoutMs) ? Math.max(100, Math.min(contracts_js_1.MAX_AGENT_TOOL_TIMEOUT_MS, Math.trunc(item.timeoutMs))) : 8000,
            validateArgs: item.validateArgs,
            handler: item.handler
        });
        tools.set(item.id, descriptor);
    }
    return Object.freeze({
        list() { return Array.from(tools.values(), tool => ({ id: tool.id, specialist: tool.specialist, description: tool.description, risk: tool.risk, enabled: tool.enabled, requiresApproval: tool.requiresApproval, providerSchema: tool.providerSchema })); },
        get(id) { return tools.get(id) || null; },
        has(id) { return tools.has(id); }
    });
}
async function executeAgentTool(registry, run, toolId, args, options = {}) {
    const fail = (code, message) => ({ ok: false, code, message });
    if (!registry || typeof registry.get !== 'function' || !run || typeof run !== 'object' || !/^[A-Za-z0-9_-]{8,80}$/.test(run.id || '') || !Number.isInteger(run.stepCount) || run.stepCount < 0) return fail('INVALID_EXECUTION_CONTEXT', 'زمینهٔ اجرای ابزار معتبر نیست.');
    const tool = registry.get(toolId);
    if (!tool) return fail('TOOL_NOT_FOUND', 'ابزار در فهرست مجاز ثبت نشده است.');
    if (!isPlainObject(args) || safeJsonSize(args) > contracts_js_1.MAX_AGENT_TOOL_ARGUMENT_BYTES) return fail('INVALID_TOOL_ARGUMENTS', 'ورودی ابزار معتبر یا در محدودهٔ مجاز نیست.');
    try { if (tool.validateArgs(args) !== true) return fail('INVALID_TOOL_ARGUMENTS', 'ساختار ورودی با قرارداد ابزار مطابقت ندارد.'); }
    catch { return fail('INVALID_TOOL_ARGUMENTS', 'اعتبارسنجی ورودی ابزار ناموفق بود.'); }
    if (run.stepCount >= contracts_js_1.MAX_AGENT_STEPS) return fail('STEP_LIMIT_REACHED', 'سقف مراحل اجرای Agent پر شده است.');
    const allowedStates = ['planning', 'responding', 'executing', 'awaiting_approval'];
    if (!allowedStates.includes(run.state)) return fail('INVALID_RUN_STATE', 'وضعیت فعلی Agent اجازهٔ اجرای ابزار را نمی‌دهد.');
    if (run.state === 'awaiting_approval' && run.pendingApprovalToolId !== tool.id) return fail('PENDING_APPROVAL_MISMATCH', 'ابتدا باید تأیید ابزار در انتظار تعیین تکلیف شود.');
    const signal = options.signal;
    if (signal?.aborted || run.state === 'cancelled') return fail('EXECUTION_CANCELLED', 'اجرای ابزار لغو شده است.');
    const grant = options.approvalGrant && typeof options.approvalGrant === 'object' ? options.approvalGrant : {};
    const now = Date.now();
    const hasScopedApproval = run.state === 'awaiting_approval' && run.pendingApprovalToolId === tool.id
        && grant.runId === run.id && grant.toolId === tool.id && grant.confirmed === true
        && typeof grant.grantId === 'string' && /^[A-Za-z0-9_-]{16,80}$/.test(grant.grantId)
        && typeof grant.argsHash === 'string' && grant.argsHash === await approvalArgsHash(args)
        && Number.isFinite(grant.confirmedAt) && grant.confirmedAt <= now && now - grant.confirmedAt <= 300_000
        && !run.approvalGrantsUsed.includes(grant.grantId);
    const permission = (0, policy_js_1.evaluateToolPermission)(tool, {
        approved: hasScopedApproval,
        userInitiated: options.userInitiated === true
    });
    if (!permission.allowed) {
        if (permission.code === 'APPROVAL_REQUIRED' && (run.state === 'planning' || run.state === 'responding' || run.state === 'executing')) {
            run.pendingApprovalToolId = tool.id;
            (0, runtime_js_1.transitionAgentRun)(run, 'awaiting_approval');
        }
        return fail(permission.code, permission.requiresApproval ? 'برای اجرای این عملیات تأیید صریح کاربر لازم است.' : 'سیاست امنیتی اجرای این ابزار را مجاز نمی‌داند.');
    }
    if (hasScopedApproval) {
        run.approvalGrantsUsed.push(grant.grantId);
        run.pendingApprovalToolId = '';
    }
    if (run.state !== 'executing') (0, runtime_js_1.transitionAgentRun)(run, 'executing');
    run.stepCount++;
    try { options.onEvent?.({ type: 'started', toolId: tool.id, stepCount: run.stepCount }); } catch { }
    const timeoutMs = Math.min(tool.timeoutMs, Number.isFinite(options.timeoutMs) ? Math.max(100, Math.min(contracts_js_1.MAX_AGENT_TOOL_TIMEOUT_MS, Math.trunc(options.timeoutMs))) : tool.timeoutMs);
    let timer;
    let abortHandler;
    const controller = new AbortController();
    try {
        const timeout = new Promise((_, reject) => {
            timer = setTimeout(() => { controller.abort('timeout'); reject(new Error('agent_tool_timeout')); }, timeoutMs);
        });
        const aborted = new Promise((_, reject) => {
            abortHandler = () => { controller.abort(signal?.reason); reject(new Error('agent_tool_aborted')); };
            if (signal?.aborted) abortHandler();
            else if (signal && typeof signal.addEventListener === 'function') signal.addEventListener('abort', abortHandler, { once: true });
        });
        const output = await Promise.race([Promise.resolve().then(() => tool.handler(args, { runId: run.id, signal: controller.signal })), timeout, aborted]);
        const serialized = JSON.stringify(output);
        if (serialized === undefined) return fail('INVALID_TOOL_RESULT', 'خروجی ابزار قابل تبدیل به دادهٔ امن نیست.');
        if (new TextEncoder().encode(serialized).byteLength > contracts_js_1.MAX_AGENT_TOOL_RESULT_BYTES) return fail('TOOL_RESULT_TOO_LARGE', 'خروجی ابزار از سقف مجاز بزرگ‌تر است.');
        return { ok: true, toolId: tool.id, result: JSON.parse(serialized) };
    } catch (error) {
        const message = String(error?.message || '');
        if (message === 'agent_tool_timeout') return fail('TOOL_TIMEOUT', 'زمان مجاز اجرای ابزار تمام شد.');
        if (message === 'agent_tool_aborted') return fail('EXECUTION_CANCELLED', 'اجرای ابزار لغو شد.');
        return fail('TOOL_EXECUTION_FAILED', 'اجرای ابزار ناموفق بود.');
    } finally {
        clearTimeout(timer);
        if (signal && abortHandler && typeof signal.removeEventListener === 'function') signal.removeEventListener('abort', abortHandler);
    }
}
