"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createWebResearchTool = createWebResearchTool;
exports.runWebResearch = runWebResearch;
exports.extractWebPages = tavilyExtract;
const http_js_1 = __load("worker/shared/http.js");
const quotas_js_1 = __load("worker/features/quotas.js");
const SEARCH_TOPICS = new Set(["general", "news", "finance"]);
const TIME_RANGES = new Set(["day", "week", "month", "year"]);
const MAX_QUERY_LENGTH = 400;
const MAX_QUERIES = 3;
const MAX_PAGES = 4;
const MAX_SOURCE_TEXT = 10000;

function normalizedQuery(value) {
    return (0, http_js_1.text)(value, MAX_QUERY_LENGTH).replace(/\s+/g, " ").trim();
}
function normalizeTopic(value, query) {
    const requested = (0, http_js_1.text)(value, 20).trim().toLowerCase();
    if (SEARCH_TOPICS.has(requested)) return requested;
    if (/(?:خبر|اخبار|رویداد|تحولات|انتخابات|جنگ|زلزله|breaking news|latest news)/i.test(query)) return "news";
    if (/(?:قیمت|نرخ|دلار|یورو|طلا|بورس|سهام|بیت.?کوین|ارز|price|exchange rate|stock|bitcoin|crypto)/i.test(query)) return "finance";
    return "general";
}
function isTimeRange(value, topic, query) {
    const normalized = (0, http_js_1.text)(value, 20).trim().toLowerCase();
    if (TIME_RANGES.has(normalized)) return normalized;
    if (/(?:امروز|همین\s+الان|فوری|today|right\s+now|breaking)/i.test(query)) return 'day';
    if (/(?:این\s+هفته|هفته[‌ -]?ی\s+اخیر|هفت\s+روز|this\s+week|past\s+week)/i.test(query)) return 'week';
    if (/(?:این\s+ماه|ماه[‌ -]?ی\s+اخیر|this\s+month|past\s+month)/i.test(query)) return 'month';
    if (/(?:سال\s+جاری|امسال|this\s+year|past\s+year)/i.test(query)) return 'year';
    return topic === 'news' ? 'week' : undefined;
}
function buildQueries(query, mode, topic) {
    if (mode !== "deep") return [query];
    const second = topic === "news"
        ? `${query} منابع رسمی و گزارش‌های مستقل`
        : topic === "finance"
            ? `${query} داده‌های رسمی و منابع اولیه`
            : `${query} منابع رسمی، مستندات اولیه و اطلاعات به‌روز`;
    const third = topic === "news"
        ? `${query} تحلیل‌های تخصصی و تأیید مستقل`
        : topic === "finance"
            ? `${query} روندها و مقایسه داده‌های معتبر`
            : `${query} مقایسه منابع معتبر و دیدگاه‌های مستقل`;
    return [query, second.slice(0, MAX_QUERY_LENGTH), third.slice(0, MAX_QUERY_LENGTH)];
}
function resultScore(item) {
    const value = Number(item?.score);
    return Number.isFinite(value) ? Math.max(0, Math.min(1, value)) : 0;
}
function normalizeSearchResult(item, query) {
    const url = (0, http_js_1.safeUrl)(item?.url);
    if (!url) return null;
    let domain = "";
    try { domain = new URL(url).hostname.replace(/^www\./i, ""); } catch { }
    return {
        title: (0, http_js_1.text)(item?.title, 250).trim() || domain,
        url,
        domain,
        publishedDate: (0, http_js_1.text)(item?.published_date ?? item?.publishedDate, 60).trim(),
        score: resultScore(item),
        content: (0, http_js_1.text)(item?.content, 1500).trim(),
        extractedContent: "",
        extracted: false,
        query
    };
}
function withTimeout(parentSignal, timeoutMs) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort("timeout"), timeoutMs);
    const abort = () => controller.abort(parentSignal?.reason || "cancelled");
    if (parentSignal?.aborted) abort();
    else parentSignal?.addEventListener?.("abort", abort, { once: true });
    return {
        signal: controller.signal,
        dispose() {
            clearTimeout(timer);
            parentSignal?.removeEventListener?.("abort", abort);
        }
    };
}
async function reserve(env, accountKey, amount, requestId) {
    const reservation = await quotas_js_1.reserveQuota(env, accountKey, requestId, [{ feature: "search", amount }]);
    return reservation?.ok ? { ok: true } : { ok: false, code: reservation?.code || "USAGE_UNAVAILABLE" };
}
async function tavilySearch(query, { env, accountKey, key, topic, timeRange, depth, signal }) {
    const requestId = `agent-search-${crypto.randomUUID()}`;
    const quota = await reserve(env, accountKey, 1, requestId);
    if (!quota.ok) return { ok: false, code: quota.code };
    const timeout = withTimeout(signal, 6000);
    try {
        const response = await fetch("https://api.tavily.com/search", {
            method: "POST",
            headers: { authorization: `Bearer ${key}`, "content-type": "application/json", accept: "application/json" },
            body: JSON.stringify({
                query,
                topic,
                search_depth: depth,
                max_results: 5,
                include_answer: true,
                include_raw_content: false,
                ...(timeRange ? { time_range: timeRange } : {})
            }),
            signal: timeout.signal
        });
        const payload = await response.json().catch(() => null);
        if (!response.ok || !payload || !Array.isArray(payload.results)) {
            await quotas_js_1.releaseQuota(env, accountKey, requestId);
            return { ok: false, code: response.status === 429 ? "SEARCH_RATE_LIMITED" : "SEARCH_PROVIDER_FAILED" };
        }
        const committed = await quotas_js_1.commitQuota(env, accountKey, requestId);
        if (!committed?.ok) { await quotas_js_1.releaseQuota(env, accountKey, requestId); return { ok: false, code: "USAGE_COMMIT_UNAVAILABLE" }; }
        return {
            ok: true,
            query,
            answer: (0, http_js_1.text)(payload.answer, 2500).trim(),
            results: payload.results.slice(0, 5).map(item => normalizeSearchResult(item, query)).filter(Boolean)
        };
    }
    catch (error) {
        await quotas_js_1.releaseQuota(env, accountKey, requestId);
        return { ok: false, code: signal?.aborted ? "SEARCH_CANCELLED" : error?.name === "AbortError" ? "SEARCH_TIMEOUT" : "SEARCH_NETWORK_ERROR" };
    }
    finally { timeout.dispose(); }
}
async function tavilyExtract(urls, { env, accountKey, key, depth, signal }) {
    const selected = Array.from(new Set((Array.isArray(urls) ? urls : []).map(http_js_1.safeUrl).filter(Boolean))).slice(0, MAX_PAGES);
    if (!selected.length) return { ok: true, results: [] };
    const requestId = `agent-extract-${crypto.randomUUID()}`;
    const quota = await reserve(env, accountKey, selected.length, requestId);
    if (!quota.ok) return { ok: false, code: quota.code, results: [] };
    const timeout = withTimeout(signal, 6000);
    try {
        const response = await fetch("https://api.tavily.com/extract", {
            method: "POST",
            headers: { authorization: `Bearer ${key}`, "content-type": "application/json", accept: "application/json" },
            body: JSON.stringify({ urls: selected, extract_depth: depth, format: "markdown", timeout: 8 }),
            signal: timeout.signal
        });
        const payload = await response.json().catch(() => null);
        if (!response.ok || !payload || !Array.isArray(payload.results)) {
            await quotas_js_1.releaseQuota(env, accountKey, requestId);
            return { ok: false, code: response.status === 429 ? "EXTRACT_RATE_LIMITED" : "EXTRACT_PROVIDER_FAILED", results: [] };
        }
        const successful = payload.results.filter(item => (0, http_js_1.safeUrl)(item?.url));
        if (successful.length) {
            const committed = await quotas_js_1.commitQuota(env, accountKey, requestId);
            if (!committed?.ok) { await quotas_js_1.releaseQuota(env, accountKey, requestId); return { ok: false, code: "USAGE_COMMIT_UNAVAILABLE", results: [] }; }
        }
        else {
            await quotas_js_1.releaseQuota(env, accountKey, requestId);
        }
        return {
            ok: true,
            results: successful.map(item => ({
                url: (0, http_js_1.safeUrl)(item.url),
                content: (0, http_js_1.text)(item.raw_content ?? item.content, MAX_SOURCE_TEXT).trim()
            })).filter(item => item.content)
        };
    }
    catch (error) {
        await quotas_js_1.releaseQuota(env, accountKey, requestId);
        return { ok: false, code: signal?.aborted ? "EXTRACT_CANCELLED" : error?.name === "AbortError" ? "EXTRACT_TIMEOUT" : "EXTRACT_NETWORK_ERROR", results: [] };
    }
    finally { timeout.dispose(); }
}
async function runWebResearch(queryValue, env, trustedOptions = {}, options = {}) {
    const query = normalizedQuery(queryValue);
    if (query.length < 3) return { ok: false, code: "INVALID_QUERY", message: "عبارت تحقیق باید دست‌کم ۳ نویسه باشد." };
    const key = (0, http_js_1.text)(env?.TAVILY_API_KEY, 1000).trim();
    if (!key) return { ok: false, code: "SEARCH_NOT_CONFIGURED", message: "سرویس جست‌وجوی وب در Worker تنظیم نشده است." };
    if (!trustedOptions.accountKey) return { ok: false, code: "ACCOUNT_REQUIRED", message: "برای ثبت امن سهمیهٔ تحقیق، حساب معتبر لازم است." };
    if (options.signal?.aborted) return { ok: false, code: "SEARCH_CANCELLED", message: "درخواست تحقیق لغو شد." };
    const mode = options.mode === "deep" ? "deep" : "quick";
    const topic = normalizeTopic(options.topic, query);
    const timeRange = isTimeRange(options.timeRange, topic, query);
    const queries = buildQueries(query, mode, topic);
    const depth = mode === "deep" ? "advanced" : "fast";
    const searches = await Promise.all(queries.map(item => tavilySearch(item, {
        env, accountKey: trustedOptions.accountKey, key, topic, timeRange, depth, signal: options.signal
    })));
    const successfulSearches = searches.filter(item => item.ok);
    if (!successfulSearches.length) {
        const failure = searches.find(item => !item.ok)?.code || "SEARCH_PROVIDER_FAILED";
        return { ok: false, code: failure, message: failure === "QUOTA_EXCEEDED" ? "سهمیهٔ جست‌وجوی وب برای این تحقیق کافی نیست." : "جست‌وجوی وب برای این اجرا کامل نشد." };
    }
    const byUrl = new Map();
    for (const search of successfulSearches) {
        for (const item of search.results) {
            const current = byUrl.get(item.url);
            if (!current || item.score > current.score) byUrl.set(item.url, item);
        }
    }
    const results = Array.from(byUrl.values()).sort((a, b) => b.score - a.score).slice(0, mode === "deep" ? 10 : 5);
    const pagesToRead = results.slice(0, mode === "deep" ? 4 : 1).map(item => item.url);
    const extraction = await tavilyExtract(pagesToRead, {
        env, accountKey: trustedOptions.accountKey, key,
        depth: mode === "deep" ? "advanced" : "basic", signal: options.signal
    });
    if (extraction.ok && extraction.results.length) {
        const extracted = new Map(extraction.results.map(item => [item.url, item.content]));
        for (const item of results) {
            const content = extracted.get(item.url);
            if (content) { item.extractedContent = content; item.extracted = true; }
        }
    }
    const answer = successfulSearches.map(item => item.answer).filter(Boolean).slice(0, 2).join("\n\n");
    const errors = searches.filter(item => !item.ok).map(item => item.code);
    if (!extraction.ok && extraction.code) errors.push(extraction.code);
    return {
        ok: true,
        mode,
        topic,
        timeRange: timeRange || null,
        query,
        queries: successfulSearches.map(item => item.query),
        answer,
        results,
        searchCount: successfulSearches.length,
        extractionCount: extraction.ok ? extraction.results.length : 0,
        partial: errors.length > 0,
        errors: errors.slice(0, 3),
        completedAt: new Date().toISOString()
    };
}
function createWebResearchTool({ env, accountKey, defaultMode, mode, topic, timeRange, signal }) {
    const fallbackMode = (defaultMode || mode) === "deep" ? "deep" : "quick";
    return {
        id: "web_research",
        specialist: "research",
        description: "جست‌وجوی واقعی وب، جمع‌آوری منابع و خواندن متن صفحات منتخب؛ فقط برای اطلاعات بیرونی یا به‌روز.",
        risk: "read",
        enabled: true,
        requiresApproval: false,
        timeoutMs: 15000,
        providerSchema: {
            type: "function",
            function: {
                name: "web_research",
                description: "جست‌وجوی واقعی وب، مقایسه چند منبع و خواندن صفحات منتخب. فقط وقتی لازم است از اطلاعات بیرونی، تازه یا قابل راستی‌آزمایی استفاده کنی فراخوانی کن. برای تحقیق جامع mode=deep انتخاب کن.",
                parameters: {
                    type: "object",
                    additionalProperties: false,
                    properties: {
                        query: { type: "string", minLength: 3, maxLength: MAX_QUERY_LENGTH, description: "پرس‌وجوی دقیق و مستقل برای وب، به زبان مناسب منابع" },
                        mode: { type: "string", enum: ["quick", "deep"], description: "quick برای بررسی محدود؛ deep برای بررسی چندزاویه‌ای و خواندن چند صفحه" },
                        topic: { type: "string", enum: ["general", "news", "finance"], description: "دسته موضوع برای بهبود جست‌وجو" },
                        time_range: { type: "string", enum: ["day", "week", "month", "year"], description: "محدوده زمانی اختیاری برای اطلاعات زمان‌مند" }
                    },
                    required: ["query"]
                }
            }
        },
        validateArgs(args) {
            const keys = Object.keys(args);
            return keys.every(key => ["query", "mode", "topic", "time_range"].includes(key))
                && typeof args.query === "string" && args.query.trim().length >= 3 && args.query.length <= MAX_QUERY_LENGTH
                && (args.mode === undefined || ["quick", "deep"].includes(args.mode))
                && (args.topic === undefined || SEARCH_TOPICS.has(args.topic))
                && (args.time_range === undefined || TIME_RANGES.has(args.time_range));
        },
        handler(args, executionContext = {}) {
            return runWebResearch(args.query, env, { accountKey }, {
                mode: args.mode || fallbackMode,
                topic: args.topic || topic,
                timeRange: args.time_range || timeRange,
                signal: executionContext.signal || signal
            });
        }
    };
}
