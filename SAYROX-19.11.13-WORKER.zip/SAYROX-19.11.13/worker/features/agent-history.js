"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.agentHistoryApi = agentHistoryApi;
exports.persistAgentRun = persistAgentRun;
const http_js_1 = __load("worker/shared/http.js");
const sessions_js_1 = __load("worker/security/sessions.js");

function accountStub(env, accountKey) {
    if (!env?.USAGE_ACCOUNT || !accountKey) throw new Error("AGENT_HISTORY_UNAVAILABLE");
    return env.USAGE_ACCOUNT.get(env.USAGE_ACCOUNT.idFromName(`xynora-account:${accountKey}`));
}

function normalizeRunRecord(input = {}) {
    const events = Array.isArray(input.toolEvents) ? input.toolEvents.slice(0, 20).map(event => ({
        tool: (0, http_js_1.text)(event?.tool, 64).toLowerCase(),
        status: event?.status === "success" ? "success" : event?.status === "pending" ? "pending" : event?.status === "cancelled" ? "cancelled" : "failed",
        code: (0, http_js_1.text)(event?.code, 64).toUpperCase()
    })) : [];
    return {
        runId: (0, http_js_1.text)(input.runId, 36),
        specialist: (0, http_js_1.text)(input.specialist, 24),
        state: (0, http_js_1.text)(input.state, 16),
        createdAt: Number(input.createdAt) || Date.now(),
        updatedAt: Number(input.updatedAt) || Date.now(),
        durationMs: Math.max(0, Math.min(600000, Math.trunc(Number(input.durationMs) || 0))),
        stepCount: Math.max(0, Math.min(20, Math.trunc(Number(input.stepCount) || 0))),
        toolEvents: events,
        researchStatus: (0, http_js_1.text)(input.researchStatus, 16),
        researchMode: (0, http_js_1.text)(input.researchMode, 8),
        sourceCount: Math.max(0, Math.min(20, Math.trunc(Number(input.sourceCount) || 0))),
        provider: (0, http_js_1.text)(input.provider, 16),
        model: (0, http_js_1.text)(input.model, 120),
        failureCode: (0, http_js_1.text)(input.failureCode, 64).toUpperCase()
    };
}

async function persistAgentRun(env, accountKey, record) {
    if (!accountKey) return { ok: false, code: "ACCOUNT_REQUIRED" };
    try {
        return await accountStub(env, accountKey).recordAgentRun(normalizeRunRecord(record));
    } catch {
        return { ok: false, code: "AGENT_HISTORY_UNAVAILABLE" };
    }
}

async function agentHistoryApi(request, env, session, pathname) {
    if (!session?.accountKey) return (0, http_js_1.json)({ ok: false, code: "AUTH_REQUIRED", message: "برای مشاهدهٔ تاریخچهٔ Agent ابتدا وارد حساب شو." }, 401);
    if (!(0, sessions_js_1.sameOriginRequest)(request)) return (0, http_js_1.json)({ ok: false, code: "CROSS_ORIGIN", message: "مبدأ درخواست معتبر نیست." }, 403);
    let stub;
    try { stub = accountStub(env, session.accountKey); }
    catch { return (0, http_js_1.json)({ ok: false, code: "AGENT_HISTORY_UNAVAILABLE", message: "ذخیره‌ساز تاریخچهٔ Agent در دسترس نیست." }, 503); }

    if (pathname === "/api/agent/runs" && request.method === "GET") {
        const params = new URL(request.url).searchParams;
        const requestedLimit = Number(params.get("limit"));
        const requestedOffset = Number(params.get("offset"));
        const limit = Number.isSafeInteger(requestedLimit) ? Math.max(1, Math.min(50, requestedLimit)) : 30;
        const offset = Number.isSafeInteger(requestedOffset) ? Math.max(0, Math.min(100, requestedOffset)) : 0;
        try {
            const result = await stub.listAgentRuns(limit, offset);
            if (!result?.ok) throw new Error("list_failed");
            const runs = Array.isArray(result.runs) ? result.runs.slice(0, limit) : [];
            return (0, http_js_1.json)({ ok: true, runs, hasMore: result.hasMore === true, offset, nextOffset: offset + runs.length, retentionDays: 90, maxRuns: 100 });
        } catch {
            return (0, http_js_1.json)({ ok: false, code: "AGENT_HISTORY_UNAVAILABLE", message: "دریافت تاریخچهٔ Agent موقتاً ممکن نیست." }, 503);
        }
    }

    if (pathname === "/api/agent/runs" && request.method === "POST") {
        let data;
        try { data = await (0, http_js_1.readJson)(request, 2000); }
        catch (error) { return (0, http_js_1.json)({ ok: false, code: "INVALID_REQUEST", message: error?.message || "درخواست معتبر نیست." }, 400); }
        const action = (0, http_js_1.text)(data.action, 16);
        try {
            if (action === "delete") {
                const id = (0, http_js_1.text)(data.runId, 36);
                const result = await stub.deleteAgentRun(id);
                return result?.ok ? (0, http_js_1.json)({ ok: true }) : (0, http_js_1.json)({ ok: false, code: result?.code || "DELETE_FAILED", message: "اجرای موردنظر پیدا نشد یا شناسه معتبر نیست." }, 400);
            }
            if (action === "clear") {
                const result = await stub.clearAgentRuns();
                return result?.ok ? (0, http_js_1.json)({ ok: true }) : (0, http_js_1.json)({ ok: false, code: "CLEAR_FAILED", message: "پاک‌کردن تاریخچه انجام نشد." }, 503);
            }
            return (0, http_js_1.json)({ ok: false, code: "INVALID_ACTION", message: "عملیات تاریخچه شناخته نشد." }, 400);
        } catch {
            return (0, http_js_1.json)({ ok: false, code: "AGENT_HISTORY_UNAVAILABLE", message: "عملیات تاریخچه موقتاً ممکن نیست." }, 503);
        }
    }

    const match = /^\/api\/agent\/runs\/([0-9a-f-]{36})$/i.exec(pathname);
    if (match && request.method === "GET") {
        try {
            const result = await stub.getAgentRun(match[1]);
            return result?.ok ? (0, http_js_1.json)({ ok: true, run: result.run }) : (0, http_js_1.json)({ ok: false, code: "AGENT_RUN_NOT_FOUND", message: "اجرای موردنظر پیدا نشد." }, 404);
        } catch {
            return (0, http_js_1.json)({ ok: false, code: "AGENT_HISTORY_UNAVAILABLE", message: "دریافت جزئیات اجرا موقتاً ممکن نیست." }, 503);
        }
    }
    return (0, http_js_1.json)({ ok: false, code: "NOT_FOUND", message: "مسیر تاریخچه پیدا نشد." }, 404);
}
