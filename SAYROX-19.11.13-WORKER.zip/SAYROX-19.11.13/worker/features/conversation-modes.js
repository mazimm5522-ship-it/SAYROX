"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CONVERSATION_MODE_IDS = void 0;
exports.normalizeConversationMode = normalizeConversationMode;
exports.conversationModeInstruction = conversationModeInstruction;
const MODE_INSTRUCTIONS = Object.freeze({
  auto: '',
  fast: 'در این درخواست، پاسخ را مستقیم و کم‌حجم ارائه کن و ابتدا نتیجهٔ اصلی را بگو. از توضیحات حاشیه‌ای بپرهیز، اما صحت، ایمنی و بیان عدم‌قطعیت را فدای کوتاهی نکن و برای سرعت حدس نزن.',
  precise: 'در این درخواست، دقت و صحت را بر اختصار مقدم بدان. فرض‌ها و محدودیت‌های مهم را روشن کن، مراحل یا معیارهای لازم را منظم توضیح بده و هرجا مطمئن نیستی صریح بگو. داده، منبع، نقل‌قول یا نتیجهٔ آزمایش اختراع نکن.',
  creative: 'در این درخواست، رویکردی خلاقانه و غیرکلیشه‌ای داشته باش. وقتی مفید است چند ایده یا مسیر متمایز پیشنهاد بده و از مثال‌های روشن استفاده کن. واقعیت را از فرض و تخیل جدا نگه دار و دقت و ایمنی را حفظ کن.',
  deep: 'در این درخواست، پاسخ را با بررسی جامع‌تر و توجه به جزئیات مهم آماده کن. مسئله را ساختارمند تحلیل کن و در خروجی نتیجه، دلایل قابل‌ارائه، محدودیت‌ها و گام‌های عملی را خلاصه کن. زنجیرهٔ استدلال خصوصی یا محتوای پنهان را افشا نکن؛ فقط توضیح قابل‌ارائه بده.',
  coding: 'در این درخواست، مانند یک مهندس نرم‌افزار دقیق عمل کن. ابتدا نیاز و محدودیت‌ها را بفهم، سپس راه‌حل قابل‌اجرا و قابل‌نگهداری ارائه بده؛ کد را با نام‌گذاری روشن، مدیریت خطا و ملاحظات امنیتی بنویس. در صورت تناسب تست یا نمونهٔ اجرا اضافه کن و هرگز ادعا نکن کدی را اجرا یا آزمایش کرده‌ای مگر واقعاً اجرا شده باشد. توضیحات را به زبان کاربر بنویس.'
});
exports.CONVERSATION_MODE_IDS = Object.freeze(Object.keys(MODE_INSTRUCTIONS));
function normalizeConversationMode(value) {
  return typeof value === 'string' && Object.prototype.hasOwnProperty.call(MODE_INSTRUCTIONS, value) ? value : 'auto';
}
function conversationModeInstruction(value) {
  return MODE_INSTRUCTIONS[normalizeConversationMode(value)];
}
