"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.imageConfig = imageConfig;
exports.imageGenerate = imageGenerate;
exports.generateImageData = generateImageData;
const http_js_1 = __load("worker/shared/http.js");
const registry_js_1 = __load("worker/providers/registry.js");
const quotas_js_1 = __load("worker/features/quotas.js");
const RATIOS = ['1:1', '3:4', '4:3', '9:16', '16:9'];
const MAX_PROMPT = 1200;
const MAX_BASE64_CHARS = 7_500_000;           // Fits the chat's bounded volatile-image cache
const DATA_URL = /^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/]+={0,2})$/;
/**
 * Image generation goes through OpenRouter only, with an explicitly configured image model
 * (OPENROUTER_IMAGE_MODEL). Nothing is enabled implicitly, so an unconfigured deployment fails closed.
 */
function imageConfig(env) {
    const provider = (0, registry_js_1.providerConfig)('openrouter', env);
    const model = (0, http_js_1.text)(env.OPENROUTER_IMAGE_MODEL, 160).trim();
    let httpsBase = false;
    try {
        httpsBase = new URL(provider.base).protocol === 'https:';
    }
    catch { }
    return { ready: Boolean(provider.key && httpsBase && (0, registry_js_1.validModel)(model)), key: provider.key, base: provider.base, model };
}
async function generateImageData(env, accountKey, promptValue, ratioValue, options = {}) {
    const prompt = (0, http_js_1.text)(promptValue, MAX_PROMPT).trim();
    const ratio = RATIOS.includes(ratioValue) ? ratioValue : '1:1';
    if (prompt.length < 3) return { ok: false, status: 400, code: 'INVALID_PROMPT', message: 'توضیح تصویر حداقل سه نویسه باشد.' };
    if (!accountKey) return { ok: false, status: 401, code: 'AUTH_REQUIRED', message: 'برای تولید تصویر ابتدا وارد حساب کاربری شو.' };
    const config = imageConfig(env);
    if (!config.ready) return { ok: false, status: 503, code: 'IMAGES_UNAVAILABLE', message: 'تولید تصویر هنوز پیکربندی نشده است؛ کلید Provider تصویر و مدل تصویری را در Secrets/Variables تنظیم کن.' };

    const quotaRequestId = crypto.randomUUID();
    const quota = await quotas_js_1.reserveQuota(env, accountKey, quotaRequestId, [{ feature: 'image_generation', amount: 1 }]);
    if (!quota?.ok) {
        const denied = quotas_js_1.quotaDenied(quota);
        const body = await denied.json().catch(() => ({}));
        return { ok: false, status: denied.status || 503, ...body };
    }

    const abort = new AbortController();
    const parentSignal = options.signal;
    const abortFromParent = () => abort.abort(parentSignal?.reason || 'cancelled');
    if (parentSignal?.aborted) abortFromParent();
    else parentSignal?.addEventListener?.('abort', abortFromParent, { once: true });
    const timer = setTimeout(() => abort.abort('image_timeout'), 90_000);
    let committed = false;
    const release = async () => { if (!committed) { committed = true; await quotas_js_1.releaseQuota(env, accountKey, quotaRequestId); } };
    const origin = typeof options.origin === 'string' && /^https:\/\//i.test(options.origin) ? options.origin : 'https://sayrox.invalid';
    try {
        if (abort.signal.aborted) throw new Error('image_cancelled');
        const response = await fetch(`${config.base}/chat/completions`, {
            method: 'POST', signal: abort.signal,
            headers: {
                authorization: `Bearer ${config.key}`, 'content-type': 'application/json', accept: 'application/json',
                'http-referer': (0, http_js_1.text)(env.OPENROUTER_SITE_URL, 500) || origin, 'x-title': 'SAYROX'
            },
            body: JSON.stringify({ model: config.model, modalities: ['image', 'text'], stream: false, messages: [{ role: 'user', content: `${prompt}\n\nAspect ratio: ${ratio}.` }] })
        });
        if (!response.ok) {
            await release();
            return { ok: false, status: response.status === 429 ? 429 : 502, code: 'IMAGES_PROVIDER_ERROR', message: response.status === 429 ? 'سرویس تصویر موقتاً شلوغ است؛ کمی بعد دوباره تلاش کن.' : `سرویس تصویر خطای ${response.status} برگرداند.` };
        }
        const payload = await response.json().catch(() => null);
        const message = payload?.choices?.[0]?.message;
        const entry = Array.isArray(message?.images) ? message.images.find(item => (item?.image_url?.url || item?.imageUrl?.url)) : null;
        const url = (0, http_js_1.text)(entry?.image_url?.url || entry?.imageUrl?.url, MAX_BASE64_CHARS + 100);
        const match = DATA_URL.exec(url);
        if (!match || match[2].length > MAX_BASE64_CHARS) {
            await release();
            return { ok: false, status: 422, code: 'IMAGE_NOT_RETURNED', message: 'مدل تصویری برای این توضیح خروجی تصویر برنگرداند؛ توضیح را تغییر بده و دوباره تلاش کن.' };
        }
        const usageCommit = await quotas_js_1.commitQuota(env, accountKey, quotaRequestId);
        if (!usageCommit?.ok) {
            await release();
            return { ok: false, status: 503, code: 'USAGE_COMMIT_UNAVAILABLE', message: 'ثبت سهمیه تولید تصویر کامل نشد؛ دوباره تلاش کن.' };
        }
        committed = true;
        return {
            ok: true,
            prompt, ratio, model: config.model,
            image: { mimeType: `image/${match[1]}`, dataUrl: url, bytes: Math.floor(match[2].length * 3 / 4) },
            caption: (0, http_js_1.text)(typeof message?.content === 'string' ? message.content : '', 500).trim()
        };
    }
    catch (error) {
        await release();
        const cancelled = error?.name === 'AbortError' || abort.signal.aborted;
        return { ok: false, status: cancelled ? 504 : 502, code: cancelled ? 'IMAGE_GENERATION_TIMEOUT_OR_CANCELLED' : 'IMAGES_PROVIDER_ERROR', message: cancelled ? 'تولید تصویر متوقف شد یا زمان مجاز آن پایان یافت.' : 'ارتباط با سرویس تصویر برقرار نشد.' };
    }
    finally {
        clearTimeout(timer);
        parentSignal?.removeEventListener?.('abort', abortFromParent);
    }
}

async function imageGenerate(request, env, trustedOptions = {}) {
    if (request.method !== 'POST') return (0, http_js_1.json)({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
    let data;
    try { data = await (0, http_js_1.readJson)(request, 8000); }
    catch (error) { return (0, http_js_1.json)({ ok: false, code: 'INVALID_REQUEST', message: error?.message || 'درخواست معتبر نیست.' }, 400); }
    const result = await generateImageData(env, trustedOptions.accountKey, data.prompt, data.ratio, { origin: new URL(request.url).origin, signal: request.signal });
    if (!result.ok) {
        const { status = 502, ...body } = result;
        return (0, http_js_1.json)(body, status);
    }
    return (0, http_js_1.json)(result);
}
