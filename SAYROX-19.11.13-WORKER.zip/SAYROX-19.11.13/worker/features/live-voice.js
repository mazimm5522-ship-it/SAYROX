"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.liveVoiceTestHelpers = void 0;
exports.liveVoiceApi = liveVoiceApi;
const http_js_1 = __load("worker/shared/http.js");
const sessions_js_1 = __load("worker/security/sessions.js");
const quotas_js_1 = __load("worker/features/quotas.js");
const chat_js_1 = __load("worker/providers/chat.js");
const ENGINE_ISSUER = 'https://api.elevenlabs.io/convai/speech-engine';
const ENGINE_SUBJECT = 'convai_speech_engine_upstream';
const MAX_TRANSCRIPT_MESSAGES = 23; // Keep one slot for the server-owned voice system message.
const MAX_TRANSCRIPT_CHARS = 24_000;
const MAX_RESPONSE_CHARS = 9_000;
const MAX_LIVE_SESSION_MS = 180_000; // Server-enforced cap; client timers are UX only.
const RESIDENCY_KEY_SUFFIX = /_residency_[a-z0-9]+$/;
// ElevenLabs signs Speech Engine JWTs with the SHA-256 of the base key.
// Data-residency keys append `_residency_<region>`; mirror the official SDK.
function normalizeApiKeyForSigning(apiKey) {
    return String(apiKey || '').trim().replace(RESIDENCY_KEY_SUFFIX, '');
}
function decodeBase64Url(value) {
    if (typeof value !== 'string' || !/^[A-Za-z0-9_-]+$/.test(value))
        throw new Error('invalid base64url');
    const padded = value.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - value.length % 4) % 4);
    const binary = atob(padded);
    return Uint8Array.from(binary, char => char.charCodeAt(0));
}
async function verifySpeechEngineJwt(token, apiKey) {
    if (!token || token.length > 4096 || !apiKey)
        return false;
    const parts = token.split('.');
    if (parts.length !== 3)
        return false;
    let header, payload, signature;
    try {
        header = JSON.parse(new TextDecoder().decode(decodeBase64Url(parts[0])));
        payload = JSON.parse(new TextDecoder().decode(decodeBase64Url(parts[1])));
        signature = decodeBase64Url(parts[2]);
    }
    catch {
        return false;
    }
    if (header?.alg !== 'HS256' || payload?.iss !== ENGINE_ISSUER || payload?.sub !== ENGINE_SUBJECT)
        return false;
    const now = Math.floor(Date.now() / 1000);
    if (!Number.isFinite(payload.exp) || payload.exp < now - 60)
        return false;
    if (Number.isFinite(payload.iat) && payload.iat > now + 60)
        return false;
    try {
        const signingKey = normalizeApiKeyForSigning(apiKey);
        if (!signingKey)
            return false;
        const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(signingKey));
        const key = await crypto.subtle.importKey('raw', digest, { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
        return await crypto.subtle.verify('HMAC', key, signature, new TextEncoder().encode(`${parts[0]}.${parts[1]}`));
    }
    catch {
        return false;
    }
}
function cleanTranscript(records) {
    if (!Array.isArray(records) || records.length > 200)
        return null;
    const cleaned = [];
    let total = 0;
    for (const item of records.slice(-MAX_TRANSCRIPT_MESSAGES)) {
        if (!item || typeof item !== 'object')
            continue;
        const role = item.role === 'agent' || item.role === 'assistant' ? 'assistant' : item.role === 'user' ? 'user' : null;
        const content = typeof item.content === 'string' ? item.content.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F]/g, '').trim().slice(0, 4000) : '';
        if (!role || !content)
            continue;
        total += content.length;
        if (total > MAX_TRANSCRIPT_CHARS)
            return null;
        cleaned.push({ role, content });
    }
    if (!cleaned.length || !cleaned.some(item => item.role === 'user'))
        return null;
    return cleaned;
}
function sendSocket(socket, payload) {
    if (socket.readyState === WebSocket.OPEN) {
        try {
            socket.send(JSON.stringify(payload));
            return true;
        }
        catch {
            return false;
        }
    }
    return false;
}
function makeVoiceSystemPrompt() {
    return [
        'تو SAYROX هستی؛ یک دستیار هوش مصنوعی فارسی‌زبان، گرم، طبیعی، دقیق و خوش‌برخورد.',
        'در مکالمه صوتی مثل یک گفتگوی زنده و طبیعی حرف بزن: مستقیم وارد پاسخ شو، جمله‌ها کوتاه و روان باشند، لحن دوستانه و انسانی‌نما اما صادقانه باشد.',
        'برای شروع پاسخ مقدمه‌های تکراری مثل «حتماً، با کمال میل» نگو. پاسخ را سریع و بدون توضیح روند تفکر ارائه کن.',
        'وقتی کاربر وسط پاسخ صحبت می‌کند، حرف تازه‌اش را اولویت بده و پاسخ قبلی را ادامه نده مگر خودش بخواهد.',
        'به زبان کاربر پاسخ بده؛ پیش‌فرض فارسی محاوره‌ای معیار است. از Markdown، جدول، لینک‌نویسی و فهرست‌های طولانی در پاسخ صوتی پرهیز کن.',
        'عددها و واژه‌های انگلیسی را تا حد امکان به شکلی بنویس که طبیعی تلفظ شوند. برای درخواست پیچیده، ابتدا پاسخ کوتاه و کاربردی بده و سپس جزئیات را فقط در صورت نیاز اضافه کن.',
        'هرگز ادعا نکن انسان یا دارای احساس/آگاهی انسانی هستی؛ در صورت پرسش، شفاف بگو دستیار هوش مصنوعی SAYROX هستی.'
    ].join('\n');
}
async function streamChatToSpeech(socket, env, transcript, eventId, controller, getCurrentEventId) {
    const request = new Request('https://xynora.internal/api/chat', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ messages: transcript, model: 'auto', stream: true, temporary: true, max_tokens: 420, temperature: 0.72 }),
        signal: controller.signal
    });
    const response = await (0, chat_js_1.chat)(request, env, { systemPrompt: makeVoiceSystemPrompt() });
    if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.message || 'Voice model request failed');
    }
    if (!response.body)
        throw new Error('Voice model returned an empty stream');
    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let pending = '';
    let output = '';
    let sentChars = 0;
    let frameBuffer = '';
    let finished = false;
    const isCurrent = () => !controller.signal.aborted && getCurrentEventId() === eventId;
    const flushChunk = (force = false) => {
        while (pending && isCurrent()) {
            const punctuation = pending.search(/[.!?؟،؛:\n]/u);
            let cut = punctuation >= 0 && punctuation < 90 ? punctuation + 1 : 0;
            if (!cut && pending.length >= 30) {
                const boundary = pending.lastIndexOf(' ', 48);
                cut = boundary >= 18 ? boundary : (pending.length >= 54 ? 48 : 0);
            }
            if (!cut && force)
                cut = pending.length;
            if (!cut)
                break;
            const chunk = pending.slice(0, cut).trim();
            pending = pending.slice(cut).replace(/^\s+/, '');
            if (chunk)
                sendSocket(socket, { type: 'agent_response', event_id: eventId, content: chunk, is_final: false });
        }
    };
    const consumeSse = (line) => {
        if (!line.startsWith('data:'))
            return;
        const raw = line.slice(5).trim();
        // SSE uses a blank line between events. Only the explicit [DONE] sentinel
        // or a provider finish_reason ends the stream; an empty data line is not EOF.
        if (!raw)
            return;
        if (raw === '[DONE]') {
            finished = true;
            return;
        }
        let data;
        try {
            data = JSON.parse(raw);
        }
        catch {
            return;
        }
        const delta = data?.choices?.[0]?.delta?.content;
        if (typeof delta === 'string' && delta) {
            const remaining = MAX_RESPONSE_CHARS - output.length;
            const safeDelta = delta.slice(0, Math.max(0, remaining));
            if (!safeDelta) {
                finished = true;
                return;
            }
            output += safeDelta;
            pending += safeDelta;
            flushChunk(false);
            if (output.length >= MAX_RESPONSE_CHARS)
                finished = true;
        }
        if (data?.choices?.[0]?.finish_reason)
            finished = true;
        if (data?.error)
            throw new Error('Voice model stream failed');
    };
    try {
        while (!finished && isCurrent()) {
            const { done, value } = await reader.read();
            if (done)
                break;
            frameBuffer += decoder.decode(value, { stream: true });
            let newline;
            while ((newline = frameBuffer.indexOf('\n')) >= 0) {
                const line = frameBuffer.slice(0, newline).replace(/\r$/, '');
                frameBuffer = frameBuffer.slice(newline + 1);
                consumeSse(line);
            }
        }
        if (frameBuffer.trim())
            consumeSse(frameBuffer.trim());
        if (isCurrent()) {
            flushChunk(true);
            sendSocket(socket, { type: 'agent_response', event_id: eventId, content: '', is_final: true });
        }
    }
    finally {
        try {
            await reader.cancel();
        }
        catch { }
        try {
            reader.releaseLock();
        }
        catch { }
    }
}
async function liveVoiceApi(request, env, pathname) {
    if (pathname === '/api/voice/transcription-token') {
        if (request.method !== 'GET')
            return (0, http_js_1.json)({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
        if (!(0, sessions_js_1.sameOriginRequest)(request))
            return (0, http_js_1.json)({ ok: false, message: 'مبدأ درخواست معتبر نیست.' }, 403);
        const session = await (0, sessions_js_1.authenticatedSession)(request, env);
        if (!session)
            return (0, http_js_1.json)({ ok: false, code: 'AUTH_REQUIRED', message: 'برای تشخیص گفتار ابتدا وارد حساب SAYROX شو.' }, 401);
        const key = (0, http_js_1.text)(env.ELEVENLABS_API_KEY, 1000).trim();
        if (!key)
            return (0, http_js_1.json)({ ok: false, code: 'VOICE_INPUT_NOT_CONFIGURED', message: 'ورودی گفتار هوشمند هنوز روی Worker پیکربندی نشده است.' }, 503);
        const quotaRequestId = crypto.randomUUID();
        const quota = await quotas_js_1.reserveQuota(env, session.accountKey, quotaRequestId, [{ feature: 'voice_input', amount: 1 }]);
        if (!quota?.ok) return quotas_js_1.quotaDenied(quota);
        let upstream;
        try {
            upstream = await fetch('https://api.elevenlabs.io/v1/single-use-token/realtime_scribe', {
                method: 'POST',
                headers: { 'xi-api-key': key, accept: 'application/json' },
                signal: AbortSignal.timeout(12000)
            });
        }
        catch {
            await quotas_js_1.releaseQuota(env, session.accountKey, quotaRequestId);
            return (0, http_js_1.json)({ ok: false, message: 'ارتباط با موتور تشخیص گفتار برقرار نشد.' }, 502);
        }
        const data = await upstream.json().catch(() => ({}));
        if (!upstream.ok || typeof data.token !== 'string' || !data.token) {
            await quotas_js_1.releaseQuota(env, session.accountKey, quotaRequestId);
            console.warn('SAYROX Scribe token failed', JSON.stringify({ status: upstream.status }));
            return (0, http_js_1.json)({ ok: false, message: upstream.status === 401 || upstream.status === 403 ? 'کلید ElevenLabs برای Scribe معتبر یا مجاز نیست.' : 'ساخت نشست تشخیص گفتار ناموفق بود.' }, upstream.status === 429 ? 429 : 502);
        }
        const committed = await quotas_js_1.commitQuota(env, session.accountKey, quotaRequestId);
        if (!committed?.ok) return (0, http_js_1.json)({ ok: false, code: 'USAGE_COMMIT_UNAVAILABLE', message: 'ثبت سهمیه ورودی گفتار کامل نشد؛ دوباره تلاش کن.' }, 503);
        return (0, http_js_1.json)({ ok: true, token: data.token, model: 'scribe_v2_realtime', language: 'fa' }, 200, { 'cache-control': 'no-store' });
    }
    if (pathname === '/api/voice/token') {
        if (request.method !== 'GET')
            return (0, http_js_1.json)({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
        if (!(0, sessions_js_1.sameOriginRequest)(request))
            return (0, http_js_1.json)({ ok: false, message: 'مبدأ درخواست معتبر نیست.' }, 403);
        const session = await (0, sessions_js_1.authenticatedSession)(request, env);
        if (!session)
            return (0, http_js_1.json)({ ok: false, message: 'برای استفاده از مکالمه زنده ابتدا وارد حساب SAYROX شو.' }, 401);
        const key = (0, http_js_1.text)(env.ELEVENLABS_API_KEY, 1000).trim();
        const engineId = (0, http_js_1.text)(env.ELEVENLABS_SPEECH_ENGINE_ID, 120).trim();
        if (!key || !/^seng_[A-Za-z0-9]+$/.test(engineId)) {
            return (0, http_js_1.json)({ ok: false, message: 'موتور مکالمه زنده هنوز روی Worker پیکربندی نشده است.' }, 503);
        }
        const quotaRequestId = crypto.randomUUID();
        const quota = await quotas_js_1.reserveQuota(env, session.accountKey, quotaRequestId, [{ feature: 'live_voice', amount: 1 }]);
        if (!quota?.ok) return quotas_js_1.quotaDenied(quota);
        const endpoint = new URL('https://api.elevenlabs.io/v1/convai/conversation/token');
        endpoint.searchParams.set('agent_id', engineId);
        const abort = AbortSignal.timeout(12000);
        let upstream;
        try {
            upstream = await fetch(endpoint, { headers: { 'xi-api-key': key, accept: 'application/json' }, signal: abort });
        }
        catch {
            await quotas_js_1.releaseQuota(env, session.accountKey, quotaRequestId);
            return (0, http_js_1.json)({ ok: false, message: 'ارتباط با سرویس مکالمه زنده برقرار نشد.' }, 502);
        }
        const data = await upstream.json().catch(() => ({}));
        if (!upstream.ok || typeof data.token !== 'string' || !data.token) {
            await quotas_js_1.releaseQuota(env, session.accountKey, quotaRequestId);
            console.warn('SAYROX live voice token failed', JSON.stringify({ status: upstream.status }));
            return (0, http_js_1.json)({ ok: false, message: upstream.status === 401 || upstream.status === 403 ? 'کلید یا دسترسی ElevenLabs معتبر نیست.' : 'ساخت نشست مکالمه زنده ناموفق بود.' }, upstream.status === 429 ? 429 : 502);
        }
        const committed = await quotas_js_1.commitQuota(env, session.accountKey, quotaRequestId);
        if (!committed?.ok) return (0, http_js_1.json)({ ok: false, code: 'USAGE_COMMIT_UNAVAILABLE', message: 'ثبت سهمیه مکالمه زنده کامل نشد؛ دوباره تلاش کن.' }, 503);
        return (0, http_js_1.json)({ ok: true, token: data.token, conversationId: (0, http_js_1.text)(data.conversation_id, 120) }, 200, { 'cache-control': 'no-store' });
    }
    if (pathname === '/api/voice/upstream') {
        if (request.method !== 'GET' || request.headers.get('upgrade')?.toLowerCase() !== 'websocket') {
            return (0, http_js_1.json)({ ok: false, message: 'ارتقای WebSocket لازم است.' }, 426);
        }
        const apiKey = (0, http_js_1.text)(env.ELEVENLABS_API_KEY, 1000).trim();
        const auth = request.headers.get('x-elevenlabs-speech-engine-authorization') || '';
        if (!apiKey || !(await verifySpeechEngineJwt(auth, apiKey)))
            return (0, http_js_1.json)({ ok: false, message: 'اعتبار اتصال موتور صوتی تأیید نشد.' }, 401);
        if (typeof WebSocketPair === 'undefined')
            return (0, http_js_1.json)({ ok: false, message: 'WebSocket در این محیط پشتیبانی نمی‌شود.' }, 501);
        const pair = new WebSocketPair();
        const client = pair[0], server = pair[1];
        server.accept();
        let latestEventId = -1;
        let activeController = null;
        let eventCount = 0;
        let closed = false;
        let initialized = false;
        let conversationId = '';
        const sessionStartedAt = Date.now();
        let sessionTimer = 0;
        const closeActive = () => { if (activeController) {
            activeController.abort();
            activeController = null;
        } };
        const closeSession = (code = 1000, reason = 'Conversation closed') => {
            if (closed) return;
            closed = true;
            if (sessionTimer) clearTimeout(sessionTimer);
            closeActive();
            try { server.close(code, reason); } catch { }
        };
        sessionTimer = setTimeout(() => closeSession(1008, 'Maximum live session duration reached'), MAX_LIVE_SESSION_MS);
        server.addEventListener('message', async event => {
                if (closed) return;
                if (Date.now() - sessionStartedAt >= MAX_LIVE_SESSION_MS) {
                    closeSession(1008, 'Maximum live session duration reached');
                    return;
                }
                if (typeof event.data !== 'string' || event.data.length > 100_000) {
                    closeSession(1009, 'Message too large');
                    return;
                }
                let message;
                try {
                    message = JSON.parse(event.data);
                }
                catch {
                    return;
                }
                if (message?.type === 'ping') {
                    sendSocket(server, { type: 'pong' });
                    return;
                }
                if (message?.type === 'init') {
                    const incomingConversationId = (0, http_js_1.text)(message.conversation_id, 120);
                    if (!incomingConversationId || !/^conv_[A-Za-z0-9_-]+$/.test(incomingConversationId)) {
                        closeSession(1008, 'Invalid conversation initialization');
                        return;
                    }
                    initialized = true;
                    conversationId = incomingConversationId;
                    return;
                }
                if (message?.type === 'close') {
                    closeSession(1000, 'Conversation closed');
                    return;
                }
                if (message?.type === 'error') {
                    // Speech Engine upstream does not accept a client-style `error` event.
                    // Close this failed upstream session and let the SDK surface disconnect.
                    console.warn('SAYROX Speech Engine upstream reported an error');
                    closeSession(1011, 'ElevenLabs upstream error');
                    return;
                }
                if (message?.type !== 'user_transcript')
                    return;
                if (!initialized || !conversationId) {
                    closeSession(1008, 'Conversation was not initialized');
                    return;
                }
                const eventId = Number(message.event_id);
                if (!Number.isSafeInteger(eventId) || eventId <= latestEventId)
                    return;
                const transcript = cleanTranscript(message.user_transcript);
                if (!transcript) {
                    // Ignore malformed transcript events; `error` is not an upstream
                    // Speech Engine client message type.
                    return;
                }
                eventCount += 1;
                if (eventCount > 120) {
                    closeSession(1008, 'Conversation event limit reached');
                    return;
                }
                latestEventId = eventId;
                closeActive();
                const controller = new AbortController();
                activeController = controller;
                try {
                    await streamChatToSpeech(server, env, transcript, eventId, controller, () => latestEventId);
                }
                catch (error) {
                    if (!controller.signal.aborted && latestEventId === eventId) {
                        console.warn('SAYROX live voice response failed', JSON.stringify({ eventId, name: error?.name || 'Error' }));
                        sendSocket(server, { type: 'agent_response', event_id: eventId, content: 'الان نتونستم پاسخ بدم؛ لطفاً دوباره بگو.', is_final: true });
                    }
                }
                finally {
                    if (activeController === controller)
                        activeController = null;
                }
        });
        server.addEventListener('close', () => { closed = true; if (sessionTimer) clearTimeout(sessionTimer); closeActive(); });
        server.addEventListener('error', () => { closed = true; if (sessionTimer) clearTimeout(sessionTimer); closeActive(); });
        return new Response(null, { status: 101, webSocket: client });
    }
    return null;
}
exports.liveVoiceTestHelpers = { decodeBase64Url, normalizeApiKeyForSigning, verifySpeechEngineJwt, cleanTranscript, makeVoiceSystemPrompt };
