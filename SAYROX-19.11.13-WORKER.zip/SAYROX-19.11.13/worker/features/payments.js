"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.paymentRequest = paymentRequest;
exports.paymentCallback = paymentCallback;
exports.subscriptionMe = subscriptionMe;
const http_js_1 = __load("worker/shared/http.js");
const quotas_js_1 = __load("worker/features/quotas.js");

const PLANS = Object.freeze({
  'plus-1m': { months: 1, amountToman: 1371000, name: 'Plus Start' },
  'plus-3m': { months: 3, amountToman: 4113000, name: 'Plus Advanced' },
  'plus-9m': { months: 9, amountToman: 13710000, name: 'Plus Pro' },
  'plus-12m': { months: 12, amountToman: 21936000, name: 'Plus Ultra' }
});
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const authorityPattern = /^[A-Za-z0-9_-]{20,64}$/;
function json(data, status = 200) { return (0, http_js_1.json)(data, status); }
function text(value, max = 256) { return (0, http_js_1.text)(value, max).trim(); }
function billingStub(env, accountKey) {
  if (!env.BILLING_ACCOUNT || !accountKey) throw new Error('BILLING_BINDING_UNAVAILABLE');
  const id = env.BILLING_ACCOUNT.idFromName(`xynora-account:${accountKey}`);
  return env.BILLING_ACCOUNT.get(id);
}
function paymentMode(env) { const mode = text(env.ZARINPAL_MODE, 16).toLowerCase(); return mode === 'sandbox' || mode === 'production' ? mode : null; }
function zarinpalBase(mode) { return mode === 'sandbox' ? 'https://sandbox.zarinpal.com' : 'https://payment.zarinpal.com'; }
function paymentPageBase(mode) { return mode === 'sandbox' ? 'https://sandbox.zarinpal.com' : 'https://www.zarinpal.com'; }
function callbackSecret(env) {
  const dedicated = text(env.PAYMENT_CALLBACK_SECRET, 500);
  if (dedicated) return dedicated;
  // Staging-only fallback: domain-separated HMAC using the existing auth secret.
  // Production requires a dedicated PAYMENT_CALLBACK_SECRET.
  return paymentMode(env) === 'sandbox' ? text(env.AUTH_SESSION_SECRET, 500) : '';
}
function b64url(bytes) {
  let binary = '';
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}
function fromB64url(value) {
  if (!/^[A-Za-z0-9_-]+$/.test(value)) throw new Error('INVALID_STATE');
  const padded = value.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - value.length % 4) % 4);
  const binary = atob(padded);
  return Uint8Array.from(binary, ch => ch.charCodeAt(0));
}
async function stateToken(payload, secret) {
  const encoded = b64url(new TextEncoder().encode(JSON.stringify(payload)));
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const signature = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(`xynora/payment-callback/v1.${encoded}`));
  return `${encoded}.${b64url(new Uint8Array(signature))}`;
}
async function verifyStateToken(token, secret) {
  if (!secret || typeof token !== 'string' || token.length > 2048) return null;
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  try {
    const payload = JSON.parse(new TextDecoder().decode(fromB64url(parts[0])));
    if (!payload || payload.v !== 1 || !uuidPattern.test(String(payload.orderId || '')) ||
        !/^[A-Za-z0-9_-]{32,64}$/.test(String(payload.accountKey || '')) ||
        !Number.isSafeInteger(payload.exp) || payload.exp < Math.floor(Date.now() / 1000) ||
        typeof payload.origin !== 'string' || !payload.origin.startsWith('https://')) return null;
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
    const valid = await crypto.subtle.verify('HMAC', key, fromB64url(parts[1]), new TextEncoder().encode(`xynora/payment-callback/v1.${parts[0]}`));
    return valid ? payload : null;
  } catch { return null; }
}
function callbackRedirect(request, status, orderId) {
  const target = new URL('/', new URL(request.url).origin);
  target.searchParams.set('payment', status);
  if (orderId && uuidPattern.test(String(orderId))) target.searchParams.set('order', orderId);
  return new Response(null, { status: 303, headers: { location: target.toString(), 'cache-control': 'no-store' } });
}
async function readPlanRequest(request) {
  const contentType = text(request.headers.get('content-type'), 100).toLowerCase();
  if (!contentType.startsWith('application/json')) return null;
  const length = Number(request.headers.get('content-length') || 0);
  if (Number.isFinite(length) && length > 2048) return null;
  if (!request.body) return null;
  const reader = request.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > 2048) {
        await reader.cancel();
        return null;
      }
      chunks.push(value);
    }
    const bytes = new Uint8Array(total);
    let offset = 0;
    for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
    const value = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
    return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
  } catch { return null; }
  finally { try { reader.releaseLock(); } catch {} }
}
async function paymentRequest(request, env, session) {
  if (request.method !== 'POST') return json({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
  if (env.PAYMENTS_ENABLED !== 'true' || env.SUBSCRIPTION_ACTIVATION_READY !== 'true')
    return json({ ok: false, code: 'SUBSCRIPTIONS_NOT_READY', message: 'سامانه پرداخت هنوز در محیط آزمایشی آماده‌سازی می‌شود.' }, 503);
  const merchant = text(env.ZARINPAL_MERCHANT_ID, 100);
  const secret = callbackSecret(env);
  const mode = paymentMode(env);
  if (!merchant || !secret || !mode || !env.BILLING_ACCOUNT || !session?.accountKey)
    return json({ ok: false, code: 'PAYMENT_CONFIG_INCOMPLETE', message: 'تنظیمات امن پرداخت یا اتصال ذخیره‌سازی اشتراک کامل نیست.' }, 503);
  const data = await readPlanRequest(request);
  const planId = String(data?.planId || '').toLowerCase();
  const plan = PLANS[planId];
  const idempotencyKey = text(request.headers.get('idempotency-key'), 64);
  if (!plan || !uuidPattern.test(idempotencyKey))
    return json({ ok: false, message: 'بسته یا شناسه درخواست معتبر نیست.' }, 400);
  let stub;
  try { stub = billingStub(env, session.accountKey); }
  catch { return json({ ok: false, code: 'BILLING_UNAVAILABLE', message: 'ذخیره‌سازی امن اشتراک در دسترس نیست.' }, 503); }
  const orderId = crypto.randomUUID();
  let created;
  try { created = await stub.createOrder({ orderId, idempotencyKey, planId }); }
  catch { return json({ ok: false, code: 'ORDER_STORAGE_ERROR', message: 'ثبت امن سفارش ناموفق بود.' }, 503); }
  if (!created?.ok) {
    const status = created?.code === 'REQUEST_IN_PROGRESS' ? 409 : 400;
    return json({ ok: false, code: created?.code || 'ORDER_REJECTED', message: created?.code === 'REQUEST_IN_PROGRESS' ? 'درخواست پرداخت قبلی هنوز در حال پردازش است.' : 'ثبت سفارش انجام نشد.' }, status);
  }
  if (created.alreadyPaid) return json({ ok: true, alreadyPaid: true, orderId: created.order.orderId });
  if (created.reused && created.order?.authority) {
    const mode = paymentMode(env);
    if (!mode) return json({ ok: false, code: 'PAYMENT_MODE_INVALID', message: 'حالت درگاه پرداخت مشخص نشده است.' }, 503);
    return json({ ok: true, reused: true, orderId: created.order.orderId, amountToman: created.order.amountToman,
      paymentUrl: `${paymentPageBase(mode)}/pg/StartPay/${encodeURIComponent(created.order.authority)}` });
  }
  const callbackOrigin = new URL(request.url).origin;
  const callbackState = await stateToken({ v: 1, orderId, accountKey: session.accountKey, origin: callbackOrigin, exp: Math.floor((Date.now() + 24 * 60 * 60 * 1000) / 1000) }, secret);
  const callback = new URL('/api/payment/callback', callbackOrigin);
  callback.searchParams.set('state', callbackState);
  const email = text(session.user?.email, 160);
  try {
    const upstream = await fetch(`${zarinpalBase(mode)}/pg/v4/payment/request.json`, {
      method: 'POST', headers: { 'content-type': 'application/json', accept: 'application/json' },
      body: JSON.stringify({ merchant_id: merchant, amount: plan.amountToman * 10, currency: 'IRR',
        description: `اشتراک ${plan.name} در SAYROX`, callback_url: callback.toString(),
        metadata: email ? { email } : {} })
    });
    const result = await upstream.json().catch(() => ({}));
    const authority = text(result?.data?.authority, 100);
    if (!upstream.ok || Number(result?.data?.code) !== 100 || !authorityPattern.test(authority)) {
      await stub.failOrder(orderId).catch(() => {});
      return json({ ok: false, code: 'ZARINPAL_REQUEST_FAILED', message: 'زرین‌پال درخواست پرداخت را نپذیرفت.' }, 502);
    }
    const attached = await stub.attachAuthority(orderId, authority);
    if (!attached?.ok) {
      await stub.failOrder(orderId).catch(() => {});
      return json({ ok: false, code: 'ORDER_AUTHORITY_CONFLICT', message: 'ثبت امن شناسه پرداخت انجام نشد.' }, 503);
    }
    return json({ ok: true, orderId, planId, amountToman: plan.amountToman,
      paymentUrl: `${paymentPageBase(mode)}/pg/StartPay/${encodeURIComponent(authority)}` });
  } catch {
    await stub.failOrder(orderId).catch(() => {});
    return json({ ok: false, code: 'ZARINPAL_UNAVAILABLE', message: 'ارتباط با درگاه پرداخت برقرار نشد.' }, 502);
  }
}
async function paymentCallback(request, env) {
  if (request.method !== 'GET') return json({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
  const url = new URL(request.url);
  const authority = text(url.searchParams.get('Authority'), 100);
  const status = text(url.searchParams.get('Status'), 20).toUpperCase();
  const state = await verifyStateToken(url.searchParams.get('state') || '', callbackSecret(env));
  if (!state || !authorityPattern.test(authority) || state.origin !== url.origin) return json({ ok: false, code: 'INVALID_CALLBACK', message: 'بازگشت درگاه معتبر نیست.' }, 400);
  let stub;
  try { stub = billingStub(env, state.accountKey); }
  catch { return json({ ok: false, code: 'BILLING_UNAVAILABLE', message: 'ثبت اشتراک در دسترس نیست.' }, 503); }
  const order = await stub.getOrder(state.orderId).catch(() => null);
  if (!order || order.authority !== authority) return json({ ok: false, code: 'ORDER_MISMATCH', message: 'سفارش با شناسه پرداخت مطابقت ندارد.' }, 404);
  if (order.status === 'paid') return callbackRedirect(request, 'success', order.orderId);
  if (status !== 'OK') {
    await stub.cancelOrder(order.orderId, authority).catch(() => {});
    return callbackRedirect(request, 'cancelled', order.orderId);
  }
  if (order.status !== 'pending' || order.expiresAt < Date.now()) return callbackRedirect(request, 'failed', order.orderId);
  const merchant = text(env.ZARINPAL_MERCHANT_ID, 100);
  const mode = paymentMode(env);
  if (!merchant || !mode) return json({ ok: false, code: 'PAYMENT_CONFIG_INCOMPLETE', message: 'تنظیمات پذیرنده کامل نیست.' }, 503);
  try {
    const upstream = await fetch(`${zarinpalBase(mode)}/pg/v4/payment/verify.json`, {
      method: 'POST', headers: { 'content-type': 'application/json', accept: 'application/json' },
      body: JSON.stringify({ merchant_id: merchant, amount: order.amountRial, authority })
    });
    const verified = await upstream.json().catch(() => ({}));
    const code = Number(verified?.data?.code);
    const refId = String(verified?.data?.ref_id ?? '');
    if (!upstream.ok || ![100, 101].includes(code) || !/^\d{1,32}$/.test(refId))
      return callbackRedirect(request, 'failed', order.orderId);
    const settled = await stub.settleVerified(order.orderId, authority, refId);
    if (!settled?.ok) return json({ ok: false, code: 'SETTLEMENT_FAILED', message: 'تراکنش تأیید شد اما ثبت اشتراک کامل نشد؛ پشتیبانی باید سفارش را بررسی کند.' }, 503);
    return callbackRedirect(request, 'success', order.orderId);
  } catch {
    return json({ ok: false, code: 'VERIFICATION_UNAVAILABLE', message: 'تأیید تراکنش موقتاً در دسترس نیست؛ وضعیت سفارش امن نگه داشته شد.' }, 503);
  }
}
async function subscriptionMe(request, env, session) {
  if (request.method !== 'GET') return json({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
  if (!session?.accountKey) return json({ ok: false, code: 'AUTH_REQUIRED', message: 'برای مشاهده اشتراک وارد حساب شو.' }, 401);
  try {
    const stub = billingStub(env, session.accountKey);
    const snapshot = await stub.getSubscriptionSnapshot();
    const usage = await quotas_js_1.usageSnapshot(env, session.accountKey, snapshot?.current || null);
    if (!usage) return json({ ok: false, code: 'USAGE_UNAVAILABLE', message: 'اطلاعات سهمیه فعلاً در دسترس نیست.' }, 503);
    return json({ ...snapshot, usage });
  } catch {
    return json({ ok: false, code: 'BILLING_UNAVAILABLE', message: 'اطلاعات اشتراک فعلاً در دسترس نیست.' }, 503);
  }
}