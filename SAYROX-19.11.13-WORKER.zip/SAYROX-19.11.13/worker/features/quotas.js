"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.reserveQuota = reserveQuota;
exports.commitQuota = commitQuota;
exports.releaseQuota = releaseQuota;
exports.quotaDenied = quotaDenied;
exports.usageSnapshot = usageSnapshot;
exports.currentTier = currentTier;
const http_js_1 = __load("worker/shared/http.js");
const constants_js_1 = __load("worker/shared/constants.js");
function accountStub(binding, accountKey) {
  if (!binding || !accountKey) throw new Error('ACCOUNT_BINDING_UNAVAILABLE');
  return binding.get(binding.idFromName(`xynora-account:${accountKey}`));
}
async function activeSubscription(env, accountKey) {
  const snapshot = await accountStub(env.BILLING_ACCOUNT, accountKey).getSubscriptionSnapshot();
  const current = snapshot?.current;
  return current && current.status === 'active' ? current : null;
}
function usageStub(env, accountKey) { return accountStub(env.USAGE_ACCOUNT, accountKey); }
async function reserveQuota(env, accountKey, requestId, items) {
  try {
    const subscription = await activeSubscription(env, accountKey);
    return await usageStub(env, accountKey).reserveUsageBatch(requestId, items, subscription);
  } catch { return { ok: false, code: 'USAGE_STORAGE_UNAVAILABLE' }; }
}
async function commitQuota(env, accountKey, requestId) {
  try { return await usageStub(env, accountKey).commitUsage(requestId); }
  catch { return { ok: false, code: 'USAGE_COMMIT_UNAVAILABLE' }; }
}
async function releaseQuota(env, accountKey, requestId) {
  try { return await usageStub(env, accountKey).releaseUsage(requestId); }
  catch { return { ok: false, code: 'USAGE_RELEASE_UNAVAILABLE' }; }
}
function quotaDenied(result) {
  if (result?.code === 'QUOTA_EXCEEDED') {
    const names = { chat: 'گفتگو', search: 'جست‌وجوی وب', tts: 'تبدیل متن به صدا', live_voice: 'مکالمه زنده', voice_input: 'ورودی گفتار', images: 'تصویر', image_generation: 'تولید تصویر' };
    const name = names[result.feature] || 'این قابلیت';
    return (0, http_js_1.json)({ ok: false, code: 'QUOTA_EXCEEDED', feature: result.feature,
      used: result.used, limit: result.limit, remaining: result.remaining, resetAt: result.resetAt, tier: result.tier,
      message: `${name} این دوره به سقف سهمیه رسیده است. سهمیه در تاریخ بعدی بازنشانی می‌شود.` }, 429,
      { 'retry-after': String(Math.max(1, Math.ceil((Number(result.resetAt || Date.now() + 60000) - Date.now()) / 1000))) });
  }
  return (0, http_js_1.json)({ ok: false, code: 'USAGE_UNAVAILABLE', message: 'کنترل سهمیه فعلاً در دسترس نیست؛ درخواست برای جلوگیری از مصرف کنترل‌نشده متوقف شد.' }, 503);
}
/** Plan tier from the server-side subscription ledger; null when billing storage is unreachable (callers fail closed). */
async function currentTier(env, accountKey) {
  try {
    const subscription = await activeSubscription(env, accountKey);
    return subscription && Object.hasOwn(constants_js_1.TASK_LIMITS, subscription.tier) ? subscription.tier : 'free';
  } catch { return null; }
}
async function usageSnapshot(env, accountKey, currentSubscription) {
  try {
    const subscription = currentSubscription === undefined ? await activeSubscription(env, accountKey) : currentSubscription;
    return await usageStub(env, accountKey).getUsageSnapshot(subscription?.status === 'active' ? subscription : null);
  } catch { return null; }
}

