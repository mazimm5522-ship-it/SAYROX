"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.search = search;
const http_js_1 = __load("worker/shared/http.js");
const quotas_js_1 = __load("worker/features/quotas.js");
const agent_web_research_js_1 = __load("worker/agent/web-research.js");
const SEARCH_TOPICS = new Set(['general', 'news', 'finance']);
const SEARCH_DEPTHS = new Set(['ultra-fast', 'fast', 'basic', 'advanced']);
const TIME_RANGES = new Set(['day', 'week', 'month', 'year']);
function normalizeResult(item) {
    const url = (0, http_js_1.safeUrl)(item?.url);
    if (!url)
        return null;
    let domain = '';
    try {
        domain = new URL(url).hostname.replace(/^www\./i, '');
    }
    catch { }
    const score = Number(item?.score);
    return {
        title: (0, http_js_1.text)(item?.title, 250).trim() || domain,
        url,
        domain,
        content: (0, http_js_1.text)(item?.content, 1600).trim(),
        publishedDate: (0, http_js_1.text)(item?.published_date, 60).trim(),
        ...(Number.isFinite(score) ? { score: Math.max(0, Math.min(1, score)) } : {})
    };
}
async function search(request, env, trustedOptions = {}) {
    if (request.method !== 'POST')
        return (0, http_js_1.json)({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
    const data = await (0, http_js_1.readJson)(request, 10000);
    const query = (0, http_js_1.text)(data.query, 400).replace(/\s+/g, ' ').trim();
    const mode = data.mode === 'deep' ? 'deep' : 'quick';
    if (mode === 'deep') {
        const research = await (0, agent_web_research_js_1.runWebResearch)(query, env, trustedOptions, {
            mode: 'deep', topic: data.topic, timeRange: data.timeRange, signal: request.signal
        });
        if (!research.ok) {
            const status = research.code === 'QUOTA_EXCEEDED' ? 429
                : research.code === 'SEARCH_NOT_CONFIGURED' || research.code === 'ACCOUNT_REQUIRED' ? 503
                    : research.code === 'SEARCH_CANCELLED' ? 499 : 502;
            return (0, http_js_1.json)(research, status);
        }
        return (0, http_js_1.json)(research);
    }
    const key = (0, http_js_1.text)(env.TAVILY_API_KEY, 1000).trim();
    if (query.length < 3)
        return (0, http_js_1.json)({ ok: false, message: 'عبارت جست‌وجو باید دست‌کم ۳ نویسه باشد.' }, 400);
    if (!key)
        return (0, http_js_1.json)({ ok: false, message: 'TAVILY_API_KEY در Secrets محیط Preview تنظیم نشده است.' }, 503);
    const quotaRequestId = crypto.randomUUID();
    const quota = await quotas_js_1.reserveQuota(env, trustedOptions.accountKey, quotaRequestId, [{ feature: 'search', amount: 1 }]);
    if (!quota?.ok) return quotas_js_1.quotaDenied(quota);
    const requestedTopic = (0, http_js_1.text)(data.topic, 20).trim().toLowerCase();
    const topic = SEARCH_TOPICS.has(requestedTopic) ? requestedTopic : 'general';
    const requestedDepth = (0, http_js_1.text)(data.depth, 20).trim().toLowerCase();
    const configuredDepth = (0, http_js_1.text)(env.TAVILY_SEARCH_DEPTH, 20).trim().toLowerCase();
    const depth = SEARCH_DEPTHS.has(requestedDepth) ? requestedDepth : (SEARCH_DEPTHS.has(configuredDepth) ? configuredDepth : 'advanced');
    const requestedRange = (0, http_js_1.text)(data.timeRange, 20).trim().toLowerCase();
    const timeRange = TIME_RANGES.has(requestedRange) ? requestedRange : undefined;
    const configuredTimeout = Number(env.TAVILY_TIMEOUT_MS || 18000);
    const timeoutMs = Number.isFinite(configuredTimeout) ? Math.max(5000, Math.min(30000, configuredTimeout)) : 18000;
    const startedAt = Date.now();
    const aborter = new AbortController();
    const onAbort = () => aborter.abort();
    if (request.signal?.aborted)
        aborter.abort();
    else
        request.signal?.addEventListener('abort', onAbort, { once: true });
    const timer = setTimeout(() => aborter.abort(), timeoutMs);
    try {
        const upstream = await fetch('https://api.tavily.com/search', {
            method: 'POST',
            headers: { 'content-type': 'application/json', accept: 'application/json' },
            body: JSON.stringify({
                api_key: key,
                query,
                topic,
                search_depth: depth,
                max_results: 6,
                include_answer: true,
                include_raw_content: false,
                ...(timeRange ? { time_range: timeRange } : {})
            }),
            signal: aborter.signal
        });
        const payload = await upstream.json().catch(() => null);
        if (!upstream.ok) {
            await quotas_js_1.releaseQuota(env, trustedOptions.accountKey, quotaRequestId);
            const status = upstream.status === 429 ? 429 : upstream.status >= 500 ? 502 : 502;
            return (0, http_js_1.json)({ ok: false, message: upstream.status === 429
                    ? 'سرویس جست‌وجوی وب موقتاً محدود شده است؛ کمی بعد دوباره تلاش کن.'
                    : 'سرویس جست‌وجوی وب درخواست را نپذیرفت؛ کلید و تنظیمات Tavily را بررسی کن.' }, status);
        }
        if (!payload || typeof payload !== 'object' || !Array.isArray(payload.results)) {
            await quotas_js_1.releaseQuota(env, trustedOptions.accountKey, quotaRequestId);
            return (0, http_js_1.json)({ ok: false, message: 'پاسخ سرویس جست‌وجوی وب معتبر نبود.' }, 502);
        }
        const committed = await quotas_js_1.commitQuota(env, trustedOptions.accountKey, quotaRequestId);
        if (!committed?.ok) return (0, http_js_1.json)({ ok: false, code: 'USAGE_COMMIT_UNAVAILABLE', message: 'ثبت سهمیه جست‌وجو کامل نشد؛ دوباره تلاش کن.' }, 503);
        const results = payload.results.slice(0, 6).map(normalizeResult).filter(Boolean);
        return (0, http_js_1.json)({
            ok: true,
            query,
            topic,
            timeRange: timeRange || null,
            answer: (0, http_js_1.text)(payload.answer, 3000).trim(),
            results,
            responseTimeMs: Math.max(0, Date.now() - startedAt)
        });
    }
    catch (error) {
        await quotas_js_1.releaseQuota(env, trustedOptions.accountKey, quotaRequestId);
        if (request.signal?.aborted)
            return (0, http_js_1.json)({ ok: false, message: 'درخواست جست‌وجو توسط کاربر متوقف شد.' }, 499);
        if (error?.name === 'AbortError')
            return (0, http_js_1.json)({ ok: false, message: 'زمان پاسخ سرویس جست‌وجوی وب تمام شد؛ دوباره تلاش کن.' }, 504);
        return (0, http_js_1.json)({ ok: false, message: 'ارتباط امن با سرویس جست‌وجوی وب برقرار نشد.' }, 502);
    }
    finally {
        clearTimeout(timer);
        request.signal?.removeEventListener('abort', onAbort);
    }
}
