"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tasksReady = tasksReady;
exports.tasksApi = tasksApi;
exports.taskRunInternal = taskRunInternal;
const constants_js_1 = __load("worker/shared/constants.js");
const http_js_1 = __load("worker/shared/http.js");
const chat_js_1 = __load("worker/providers/chat.js");
const quotas_js_1 = __load("worker/features/quotas.js");
const MAX_SKEW_MS = 5 * 60_000;
const ACCOUNT_KEY = /^[A-Za-z0-9_-]{43}$/;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const TASK_SYSTEM_PROMPT = 'تو در حال اجرای یک کار زمان‌بندی‌شده برای کاربر هستی. کاربر همین الان با تو گفتگو نمی‌کند، پس سؤال برنگردان و منتظر پاسخ نمان؛ بر اساس دستور کار، یک پاسخ نهایی، کامل و مستقل بنویس و زبان آن را با زبان دستور یکی کن. اگر برای پاسخ به داده‌ی زنده یا زمینه‌ی جست‌وجو نیاز بود و در اختیار نداری، صریح بگو و حدس نزن.';
const SERVICE_UNAVAILABLE = () => (0, http_js_1.json)({ ok: false, code: 'TASKS_UNAVAILABLE', message: 'سرویس کارهای زمان‌بندی‌شده هنوز پیکربندی نشده یا موقتاً در دسترس نیست.' }, 503);
/** The Scheduler is available only when its Durable Object binding and the shared signing secret are configured. */
function tasksReady(env) {
    return Boolean(env.TASKS_ACCOUNT && (0, http_js_1.text)(env.TASKS_INTERNAL_SECRET, 500).length >= 32);
}
function taskStub(env, accountKey) {
    return env.TASKS_ACCOUNT.get(env.TASKS_ACCOUNT.idFromName(`xynora-account:${accountKey}`));
}
function respond(result) {
    if (result?.ok)
        return (0, http_js_1.json)(result);
    const code = String(result?.code || 'TASKS_ERROR');
    const status = code === 'TASK_LIMIT' ? 409 : code === 'NOT_FOUND' ? 404 : /^INVALID_/.test(code) ? 400 : 500;
    return (0, http_js_1.json)({ ok: false, code, message: result?.message || 'درخواست انجام نشد.', ...(result?.limit ? { limit: result.limit } : {}) }, status);
}
/** Authenticated, same-origin API used by the browser. `session` has already been validated by the router. */
async function tasksApi(request, env, session, pathname) {
    if (!tasksReady(env))
        return SERVICE_UNAVAILABLE();
    const stub = taskStub(env, session.accountKey);
    try {
        if (pathname === '/api/tasks' && request.method === 'GET') {
            const [state, tier] = await Promise.all([stub.listTasks(), quotas_js_1.currentTier(env, session.accountKey)]);
            if (!tier)
                return SERVICE_UNAVAILABLE();
            return (0, http_js_1.json)({ ...state, tier, limit: constants_js_1.TASK_LIMITS[tier] });
        }
        if (request.method !== 'POST')
            return (0, http_js_1.json)({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
        let data;
        try {
            data = await (0, http_js_1.readJson)(request, 6000);
        }
        catch (error) {
            return (0, http_js_1.json)({ ok: false, code: 'INVALID_REQUEST', message: error?.message || 'درخواست معتبر نیست.' }, 400);
        }
        if (pathname === '/api/tasks') {
            const tier = await quotas_js_1.currentTier(env, session.accountKey);
            if (!tier)
                return SERVICE_UNAVAILABLE();
            return respond(await stub.createTask({ title: (0, http_js_1.text)(data.title, 200), prompt: (0, http_js_1.text)(data.prompt, 4000), schedule: data.schedule, useSearch: data.useSearch === true }, constants_js_1.TASK_LIMITS[tier], session.accountKey));
        }
        if (pathname === '/api/tasks/seen')
            return respond(await stub.markSeen());
        const id = (0, http_js_1.text)(data.id, 60);
        if (!UUID.test(id))
            return (0, http_js_1.json)({ ok: false, code: 'INVALID_TASK', message: 'شناسه‌ی کار معتبر نیست.' }, 400);
        if (pathname === '/api/tasks/delete')
            return respond(await stub.deleteTask(id));
        if (pathname === '/api/tasks/toggle')
            return respond(await stub.setEnabled(id, data.enabled === true));
        if (pathname === '/api/tasks/run-now')
            return respond(await stub.runNow(id));
        return (0, http_js_1.json)({ ok: false, message: 'مسیر یافت نشد.' }, 404);
    }
    catch {
        return SERVICE_UNAVAILABLE();
    }
}
function hexToBytes(hex) {
    const bytes = new Uint8Array(hex.length / 2);
    for (let index = 0; index < bytes.length; index++)
        bytes[index] = parseInt(hex.slice(index * 2, index * 2 + 2), 16);
    return bytes;
}
/**
 * Server-to-server endpoint called by the Scheduler Durable Object when a task is due.
 * Authenticated by an HMAC over `${timestamp}.${body}`; the prompt itself never travels in the request:
 * the run id is claimed exactly once from the account's Durable Object, which hands back the task.
 */
async function taskRunInternal(request, env) {
    if (request.method !== 'POST')
        return (0, http_js_1.json)({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
    if (!tasksReady(env))
        return (0, http_js_1.json)({ ok: false, code: 'TASKS_MISCONFIGURED', message: 'Scheduler پیکربندی نشده است.' }, 503);
    const raw = await request.text();
    const timestamp = request.headers.get('x-xy-timestamp') || '';
    const signature = request.headers.get('x-xy-signature') || '';
    const denied = () => (0, http_js_1.json)({ ok: false, code: 'BAD_SIGNATURE', message: 'امضای درخواست معتبر نیست.' }, 401);
    if (raw.length > 2000 || !/^\d{13}$/.test(timestamp) || Math.abs(Date.now() - Number(timestamp)) > MAX_SKEW_MS || !/^[0-9a-f]{64}$/.test(signature))
        return denied();
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode((0, http_js_1.text)(env.TASKS_INTERNAL_SECRET, 500)), { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
    if (!await crypto.subtle.verify('HMAC', key, hexToBytes(signature), new TextEncoder().encode(`${timestamp}.${raw}`)))
        return denied();
    let body;
    try {
        body = JSON.parse(raw);
    }
    catch {
        return denied();
    }
    if (!ACCOUNT_KEY.test(String(body?.accountKey)) || !UUID.test(String(body?.runId)))
        return (0, http_js_1.json)({ ok: false, code: 'INVALID_REQUEST', message: 'درخواست معتبر نیست.' }, 400);
    const accountKey = body.accountKey;
    let claim;
    try {
        claim = await taskStub(env, accountKey).claimRun(body.runId);
    }
    catch {
        return SERVICE_UNAVAILABLE();
    }
    if (!claim?.ok)
        return (0, http_js_1.json)({ ok: false, code: 'RUN_NOT_CLAIMABLE', message: 'این اجرا قابل دریافت نیست.' }, 409);
    const origin = new URL(request.url).origin;
    const post = (path, payload) => new Request(`${origin}${path}`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload) });
    // Scheduled tasks use the same Main Agent research decision and tool path as interactive chat.
    // The task's explicit useSearch flag is a server-trusted preference, not a browser-controlled value.
    const chatResponse = await chat_js_1.chat(post('/api/chat', {
        messages: [{ role: 'user', content: claim.task.prompt }], stream: false, temporary: true,
        context: { webSearchPreference: claim.task.useSearch === true ? 'always' : 'off', researchMode: 'quick' }
    }), env, { accountKey, systemPrompt: `${TASK_SYSTEM_PROMPT}\nزمان اجرا: ${new Date().toISOString()} (منطقه‌ی زمانی کاربر: ${(0, http_js_1.text)(claim.task.timezone, 64)}).` });
    const result = await chatResponse.json().catch(() => null);
    if (!chatResponse.ok || !result?.ok) {
        const code = String(result?.code || 'CHAT_FAILED');
        return (0, http_js_1.json)({ ok: false, code, message: (0, http_js_1.text)(result?.message, 300) || 'اجرای کار ناموفق بود.' }, code === 'QUOTA_EXCEEDED' ? 429 : chatResponse.status >= 500 ? 502 : 400);
    }
    const reply = result.choices?.[0]?.message?.content;
    const content = (0, http_js_1.text)(typeof reply === 'string' ? reply : Array.isArray(reply) ? reply.map(part => typeof part === 'string' ? part : part?.text || '').join('') : '', 8000).trim();
    if (!content)
        return (0, http_js_1.json)({ ok: false, code: 'EMPTY_RESULT', message: 'مدل پاسخ خالی برگرداند.' }, 502);
    const searchStatus = chatResponse.headers.get('x-sayrox-agent-research') || 'not_used';
    const searchUsed = searchStatus === 'completed';
    const note = claim.task.useSearch && !searchUsed ? '\n\n(یادداشت: جست‌وجوی وب برای این اجرا انجام نشد.)' : '';
    return (0, http_js_1.json)({ ok: true, content: `${content}${note}`.slice(0, 8000), searchUsed,
        research: searchUsed ? { mode: chatResponse.headers.get('x-sayrox-agent-research-mode') || 'quick', partial: chatResponse.headers.get('x-sayrox-agent-research-partial') === 'true', sourceCount: Number(chatResponse.headers.get('x-sayrox-agent-source-count')) || 0 } : null });
}
