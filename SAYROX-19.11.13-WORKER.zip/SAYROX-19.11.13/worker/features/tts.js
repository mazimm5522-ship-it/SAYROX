"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.tts = tts;
const constants_js_1 = __load("worker/shared/constants.js");
const http_js_1 = __load("worker/shared/http.js");
const quotas_js_1 = __load("worker/features/quotas.js");
async function tts(request, env, trustedOptions = {}) {
    if (request.method !== 'POST')
        return (0, http_js_1.json)({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
    const data = await (0, http_js_1.readJson)(request, 12000);
    const content = (0, http_js_1.text)(data.text, 5000).trim();
    const voiceRate = Number.isFinite(Number(data.rate)) ? Math.min(1.2, Math.max(0.7, Number(data.rate))) : 1;
    const voiceName = constants_js_1.VOICES.includes(data.voice) ? data.voice : 'aria';
    const voiceId = (0, http_js_1.text)(env[`ELEVENLABS_${voiceName.toUpperCase()}_VOICE_ID`], 200).trim();
    const key = (0, http_js_1.text)(env.ELEVENLABS_API_KEY, 1000).trim();
    if (!content)
        return (0, http_js_1.json)({ ok: false, message: 'متن برای تبدیل به صدا خالی است.' }, 400);
    if (!key || !voiceId)
        return (0, http_js_1.json)({ ok: false, message: 'کلید ElevenLabs و Voice ID انتخاب‌شده در Secrets تنظیم نشده است.' }, 503);
    const quotaRequestId = crypto.randomUUID();
    const quota = await quotas_js_1.reserveQuota(env, trustedOptions.accountKey, quotaRequestId, [{ feature: 'tts', amount: 1 }]);
    if (!quota?.ok) return quotas_js_1.quotaDenied(quota);
    try {
        const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voiceId)}`, {
            method: 'POST', headers: { 'xi-api-key': key, 'content-type': 'application/json', accept: 'audio/mpeg' },
            body: JSON.stringify({ text: content, model_id: (0, http_js_1.text)(env.ELEVENLABS_MODEL_ID, 100) || 'eleven_multilingual_v2', voice_settings: { stability: 0.48, similarity_boost: 0.78, speed: voiceRate } })
        });
        if (!response.ok) {
            await quotas_js_1.releaseQuota(env, trustedOptions.accountKey, quotaRequestId);
            return (0, http_js_1.json)({ ok: false, message: `ElevenLabs خطای ${response.status} برگرداند.` }, response.status === 429 ? 429 : 502);
        }
        const committed = await quotas_js_1.commitQuota(env, trustedOptions.accountKey, quotaRequestId);
        if (!committed?.ok) return (0, http_js_1.json)({ ok: false, code: 'USAGE_COMMIT_UNAVAILABLE', message: 'ثبت سهمیه تبدیل صدا کامل نشد؛ دوباره تلاش کن.' }, 503);
        return new Response(response.body, { status: 200, headers: { 'content-type': 'audio/mpeg', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' } });
    }
    catch {
        await quotas_js_1.releaseQuota(env, trustedOptions.accountKey, quotaRequestId);
        return (0, http_js_1.json)({ ok: false, message: 'ارتباط با ElevenLabs برقرار نشد.' }, 502);
    }
}
