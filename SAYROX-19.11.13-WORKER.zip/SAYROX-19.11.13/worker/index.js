"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const api_js_1 = __load("worker/routes/api.js");
const http_js_1 = __load("worker/shared/http.js");
exports.default = {
    async fetch(request, env) {
        let response;
        try {
            const url = new URL(request.url);
            if (request.method === 'OPTIONS')
                response = new Response(null, { status: 204, headers: { 'access-control-allow-methods': 'GET, POST, OPTIONS', 'access-control-allow-headers': 'Content-Type', 'access-control-max-age': '86400' } });
            else if (url.pathname.startsWith('/api/')) {
                response = await (0, api_js_1.api)(request, env);
                if (!response)
                    response = (0, http_js_1.json)({ ok: false, message: 'مسیر API پیدا نشد.' }, 404);
            }
            if (!response && env.ASSETS)
                response = await env.ASSETS.fetch(request);
            if (!response)
                response = (0, http_js_1.json)({ ok: false, message: 'مسیر پیدا نشد.' }, 404);
        }
        catch (error) {
            const detail = (0, http_js_1.text)(error?.message, 300);
            const isClientError = /بدنه‌ی JSON معتبر نیست|درخواست بزرگ‌تر از حد مجاز|تعداد پیام‌ها معتبر نیست|نقش یا متن یکی از پیام‌ها معتبر نیست|طول متن یکی از پیام‌ها معتبر نیست|نوع محتوای درخواست باید JSON باشد/.test(detail);
            if (!isClientError)
                console.error('SAYROX Worker request failed:', detail || 'unknown error');
            response = (0, http_js_1.json)({ ok: false, message: isClientError ? detail : 'خطای داخلی سرویس رخ داد. تنظیمات Worker و گزارش خطا را بررسی کن.' }, isClientError ? 400 : 500);
        }
        // WebSocket 101 responses carry a runtime WebSocket object and must not be reconstructed.
        return response?.status === 101 ? response : (0, http_js_1.securityHeaders)(response, request);
    }
};
