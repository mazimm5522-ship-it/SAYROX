"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.providerOrder = providerOrder;
exports.providerConfig = providerConfig;
exports.validModel = validModel;
exports.visionModelForProvider = visionModelForProvider;
exports.modelCatalog = modelCatalog;
exports.providerDiagnostics = providerDiagnostics;
exports.resolveModelSelection = resolveModelSelection;
const http_js_1 = __load("worker/shared/http.js");
/**
 * SAYROX chat is GapGPT-only by product policy. OpenRouter is intentionally
 * kept in providerConfig solely for the separate optional image-generation path.
 */
function providerOrder(env) {
    const hasGap = Boolean((0, http_js_1.text)(env.GAPGPT_API_KEY, 500).trim());
    return hasGap ? ['gapgpt'] : [];
}
function providerConfig(name, env) {
    if (name === 'gapgpt')
        return {
            key: (0, http_js_1.text)(env.GAPGPT_API_KEY, 1000).trim(),
            base: ((0, http_js_1.text)(env.GAPGPT_BASE_URL, 1000).trim() || 'https://api.gapgpt.app/v1').replace(/\/+$/, ''),
            model: (0, http_js_1.text)(env.GAPGPT_DEFAULT_MODEL, 160).trim()
        };
    if (name === 'openrouter')
        return {
            key: (0, http_js_1.text)(env.OPENROUTER_API_KEY, 1000).trim(),
            base: ((0, http_js_1.text)(env.OPENROUTER_BASE_URL, 1000).trim() || 'https://openrouter.ai/api/v1').replace(/\/+$/, ''),
            model: (0, http_js_1.text)(env.OPENROUTER_DEFAULT_MODEL, 160).trim()
        };
    return { key: '', base: '', model: '' };
}
function validModel(model) {
    return typeof model === 'string' && model.length <= 160 && /^[A-Za-z0-9._:/-]+$/.test(model);
}
const MODEL_ID = /^[A-Za-z0-9._:/-]{1,160}$/;
function extraModelConfig(env) {
    const raw = (0, http_js_1.text)(env.XYNORA_MODEL_CATALOG, 12000).trim();
    if (!raw)
        return [];
    try {
        const value = JSON.parse(raw);
        return Array.isArray(value) ? value.slice(0, 40).filter(item => item && typeof item === 'object') : [];
    }
    catch {
        return [];
    }
}
function visionModelForProvider(provider, env) {
    const directKey = provider === 'gapgpt' ? 'GAPGPT_VISION_MODEL' : provider === 'openrouter' ? 'OPENROUTER_VISION_MODEL' : '';
    const direct = directKey ? (0, http_js_1.text)(env[directKey], 160).trim() : '';
    if (validModel(direct))
        return direct;
    const configured = extraModelConfig(env).find(item => item.provider === provider && (item.vision === true || item.supportsVision === true) && typeof item.id === 'string' && validModel(item.id.trim()));
    return configured?.id?.trim() || '';
}
/**
 * Public, non-secret model catalogue. Only models explicitly configured by the
 * operator are exposed to the UI; provider credentials are never returned.
 * Vision capability is opt-in and never inferred from model-name heuristics.
 */
function modelCatalog(env) {
    const configuredProviders = new Set(providerOrder(env));
    const hasVisionModel = configuredProviders.has('gapgpt') && Boolean(visionModelForProvider('gapgpt', env));
    const models = [{ id: 'auto', label: 'مدل خودکار · GapGPT اصلی', provider: 'auto', supportsVision: hasVisionModel }];
    const add = (id, label, provider, supportsVision = false) => {
        if (!configuredProviders.has(provider) || !MODEL_ID.test(id))
            return;
        const existing = models.find(item => item.id === id);
        if (existing) {
            existing.supportsVision ||= supportsVision;
            return;
        }
        models.push({ id, label: (0, http_js_1.text)(label, 100).trim() || id, provider, supportsVision: Boolean(supportsVision) });
    };
    add((0, http_js_1.text)(env.GAPGPT_DEFAULT_MODEL, 160).trim(), (0, http_js_1.text)(env.GAPGPT_MODEL_LABEL, 100).trim(), 'gapgpt', (0, http_js_1.text)(env.GAPGPT_DEFAULT_MODEL, 160).trim() === visionModelForProvider('gapgpt', env));
    const gapVision = visionModelForProvider('gapgpt', env);
    if (gapVision)
        add(gapVision, (0, http_js_1.text)(env.GAPGPT_VISION_MODEL_LABEL, 100).trim() || 'مدل بینایی GapGPT', 'gapgpt', true);
    for (const item of extraModelConfig(env)) {
        if (typeof item.id !== 'string' || typeof item.provider !== 'string' || item.provider !== 'gapgpt')
            continue;
        add(item.id.trim(), item.label, item.provider, item.vision === true || item.supportsVision === true);
    }
    return models;
}
/**
 * Read-only provider diagnostics for the settings screen and health endpoint.
 * Only booleans and provider names are exposed; credentials and endpoint URLs
 * are never returned to the client.
 */
function providerDiagnostics(env) {
    const inspectGap = () => {
        const cfg = providerConfig('gapgpt', env);
        let validBase = false;
        try { validBase = new URL(cfg.base).protocol === 'https:'; } catch { }
        const keyConfigured = Boolean(cfg.key);
        const modelConfigured = Boolean(cfg.model && validModel(cfg.model));
        return { keyConfigured, baseUrlValid: validBase, defaultModelConfigured: modelConfigured, ready: keyConfigured && validBase && modelConfigured };
    };
    const gapgpt = inspectGap();
    return { primary: 'gapgpt', fallback: null, gapgpt, openrouter: { keyConfigured: false, baseUrlValid: false, defaultModelConfigured: false, ready: false }, chatReady: gapgpt.ready, primaryReady: gapgpt.ready, fallbackReady: false };
}
/**
 * Resolve an explicit model only through the server-side allow-list. Provider
 * routing must never be guessed from a model ID prefix or slash character.
 * Automatic chat requests use GapGPT only; OpenRouter is not eligible for chat.
 * Explicitly selected models stay pinned to their declared provider.
 */
function resolveModelSelection(env, requestedModel, { requiresVision = false } = {}) {
    const order = providerOrder(env);
    if (!order.length)
        return { ok: false, reason: 'no-provider' };
    if (requestedModel === undefined || requestedModel === null || requestedModel === '' || requestedModel === 'auto') {
        if (requiresVision) {
            const visionProviders = order.map(provider => ({ provider, model: visionModelForProvider(provider, env) })).filter(item => item.model);
            if (!visionProviders.length)
                return { ok: false, reason: 'no-vision-model' };
            return { ok: true, automatic: true, provider: visionProviders[0].provider, model: visionProviders[0].model, fallbackProviders: visionProviders.slice(1).map(item => item.provider), requiresVision: true };
        }
        return { ok: true, automatic: true, provider: order[0], model: undefined, fallbackProviders: order.slice(1), requiresVision: false };
    }
    if (!validModel(requestedModel))
        return { ok: false, reason: 'invalid-model' };
    const selected = modelCatalog(env).find(item => item.id === requestedModel && item.provider !== 'auto');
    if (!selected)
        return { ok: false, reason: 'model-not-configured' };
    if (requiresVision && !selected.supportsVision)
        return { ok: false, reason: 'vision-model-required' };
    return { ok: true, automatic: false, provider: selected.provider, model: selected.id, fallbackProviders: [], requiresVision: Boolean(requiresVision) };
}