"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.base64url = base64url;
exports.fromBase64url = fromBase64url;
exports.sha256 = sha256;
exports.derivePassword = derivePassword;
exports.createPasswordHash = createPasswordHash;
exports.constantTimeEqual = constantTimeEqual;
const constants_js_1 = __load("worker/shared/constants.js");
function base64url(bytes) {
    let binary = '';
    for (const byte of bytes)
        binary += String.fromCharCode(byte);
    return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}
function fromBase64url(value) {
    const normalized = String(value).replace(/-/g, '+').replace(/_/g, '/');
    const binary = atob(normalized + '='.repeat((4 - normalized.length % 4) % 4));
    return Uint8Array.from(binary, c => c.charCodeAt(0));
}
async function sha256(value) {
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
    return base64url(new Uint8Array(digest));
}
async function derivePassword(password, salt, iterations = constants_js_1.PASSWORD_ITERATIONS) {
    if (!Number.isInteger(iterations) || iterations < 100_000 || iterations > constants_js_1.PASSWORD_ITERATIONS) {
        throw new Error('پارامتر هش رمز عبور معتبر نیست.');
    }
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits']);
    const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, 256);
    return base64url(new Uint8Array(bits));
}
async function createPasswordHash(password) {
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const saltText = base64url(salt);
    const digest = await derivePassword(password, salt, constants_js_1.PASSWORD_ITERATIONS);
    return `pbkdf2$${constants_js_1.PASSWORD_ITERATIONS}$${saltText}$${digest}`;
}
function constantTimeEqual(a, b) {
    const left = new TextEncoder().encode(String(a));
    const right = new TextEncoder().encode(String(b));
    if (left.length !== right.length)
        return false;
    let diff = 0;
    for (let i = 0; i < left.length; i++)
        diff |= left[i] ^ right[i];
    return diff === 0;
}
