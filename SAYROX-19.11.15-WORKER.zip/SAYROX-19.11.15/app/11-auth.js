// Sign-in / sign-up UI, protected-API gate, logout
// Part of the SAYROX app closure: parts are concatenated in file order by scripts/build-app.mjs.
// Do not edit site/src/app.js directly.
// Local-only mode remains available; provider APIs require a validated account session.
let authMode='login',authProviders=false,authAvailability='checking',authDiagnostics=null,authInitPromise=null,authCheckComplete=false;
function showAuthForm(mode='login'){
  $('#authLanding').classList.add('hidden');
  $('#authFormPanel').classList.remove('hidden');
  $('#authScreen').classList.add('is-form');
  setAuthMode(mode);
  if(mode==='login')$('#authEmail').focus({preventScroll:true});
}
function showAuthLanding(){
  $('#authFormPanel').classList.add('hidden');
  $('#authLanding').classList.remove('hidden');
  $('#authScreen').classList.remove('is-form');
  setAuthStatus('');
}
function setAuthMode(mode){
  authMode=mode;
  const signup=mode==='signup';
  $('#authSignInTab').classList.toggle('active',!signup);
  $('#authSignUpTab').classList.toggle('active',signup);
  $('#authSignInTab').setAttribute('aria-selected',String(!signup));
  $('#authSignUpTab').setAttribute('aria-selected',String(signup));
  $('#authNameWrap').classList.toggle('hidden',!signup);
  $('#authName').required=signup;
  $('#authPassword').autocomplete=signup?'new-password':'current-password';
  $('#authTitle').textContent=signup?'ساخت حساب SAYROX':'ورود به SAYROX';
  $('#authSubtitle').textContent=signup?'با ایمیل خودت یک فضای شخصی امن بساز.':'برای ادامه وارد حساب خودت شو.';
  $('#authSubmit').textContent=signup?'ساخت حساب':'ورود به حساب';
  $('#authStatus').textContent='';
  $('#authStatus').className='auth-status'
}
$('#authSignInTab').onclick=()=>setAuthMode('login');
$('#authSignUpTab').onclick=()=>setAuthMode('signup');
$('#authContinueEmail').onclick=()=>showAuthForm('login');
$('#authCreateAccount').onclick=()=>showAuthForm('signup');
$('#authFormBack').onclick=showAuthLanding;
function setAuthStatus(text,kind=''){
  const el=$('#authStatus');
  el.textContent=text;
  el.className='auth-status '+kind
}
function userLabel(){
  const override=String(state.settings?.displayNameOverride||'').trim();
  return state.user?(override||state.user.displayName||state.user.email||'حساب کاربری'):(state.guest?'مهمان':'مهمان')
}
function userInitials(){
  const name=(state.settings?.displayNameOverride||state.user?.displayName||state.user?.email||'').trim();
  if(!name)return 'X';
  const parts=name.replace(/@.*$/,'').split(/[\s._-]+/).filter(Boolean);
  return ((parts[0]?.[0]||'')+(parts[1]?.[0]||parts[0]?.[1]||'')).toUpperCase()||'X'
}
function refreshAccountUI(){
  const av=$('#drawerAvatar');
  if(av)av.textContent=userInitials();
  $('#openSettings').title=userLabel();
  settingsFeature?.refreshMemoryForAccount?.();
  if(state.view==='settings')settingsFeature?.renderList($('#settingsSearch').value||'')
}
function enterGuest(){
  state.guest=true;
  state.user=null;
  $('#authScreen').classList.add('hidden');
  refreshAccountUI();
  toast('حالت محلی فعال شد؛ برای چت، جست‌وجوی وب و صدای اختصاصی باید وارد حساب شوی')
}
function enterAccount(user){
  state.user=user;
  state.guest=false;
  $('#authScreen').classList.add('hidden');
  refreshAccountUI();
  toast('ورود موفق بود');
  checkTaskInbox(true)
}
function authUnavailableMessage(){
  if(authAvailability==='checking')return 'در حال بررسی اتصال امن SAYROX به Worker هستیم؛ یک لحظه دیگر دوباره تلاش کن.';
  if(authAvailability==='offline')return 'پاسخ معتبر از API سلامت Worker دریافت نشد. اتصال یا نشانی همین Worker را بررسی کن و دوباره وضعیت را بسنج.';
  const missing=[];
  if(authDiagnostics?.accountNamespace===false)missing.push('Binding حساب AUTH_ACCOUNTS');
  if(authDiagnostics?.rateLimitNamespace===false)missing.push('Binding امنیتی AUTH_RATE_LIMITER');
  if(authDiagnostics?.sessionSecret===false)missing.push('Secret با نام AUTH_SESSION_SECRET (حداقل ۳۲ نویسه)');
  if(missing.length)return `زیرساخت حساب روی همین Worker کامل نیست: ${missing.join('، ')}.`;
  return 'Worker وضعیت احراز هویت را آماده اعلام نکرد. نشانی Worker و نسخهٔ منتشرشده را بررسی کن؛ این پیام به معنی خطای GapGPT نیست.'
}
function updateAuthFootnote(message,retry=false){
  const note=$('#authFootnote');
  if(!note)return;
  note.textContent=message;
  if(!retry)return;
  const button=document.createElement('button');
  button.type='button';
  button.className='auth-health-retry';
  button.textContent='بررسی دوباره';
  button.addEventListener('click',()=>{
    button.disabled=true;
    authInitPromise=null;
    authCheckComplete=false;
    state.authReady=false;
    void initAuth(true).then(()=>{
      if(!state.user)setAuthStatus(authProviders?'برای ادامه وارد حساب SAYROX شو.':authUnavailableMessage(),authProviders?'':'error')
    });
  });
  note.append(document.createTextNode(' '),button)
}
function requireAccountForProtectedApis(){
  if(state.user)return true;
  $('#authScreen').classList.remove('hidden');
  showAuthForm('login');
  if(!authCheckComplete){
    setAuthStatus('در حال بررسی اتصال امن SAYROX به Worker…');
    void initAuth().then(()=>{
      if(!state.user)setAuthStatus(authProviders?'برای استفاده از چت هوشمند، جست‌وجوی وب و صدای اختصاصی ابتدا وارد حساب SAYROX شو.':authUnavailableMessage(),'error');
    });
    return false
  }
  setAuthStatus(authProviders?'برای استفاده از چت هوشمند، جست‌وجوی وب و صدای اختصاصی ابتدا وارد حساب SAYROX شو.':authUnavailableMessage(),authProviders?'':'error');
  return false
}
function protectedApiAuthError(response,data){
  if(response.status===401&&data.code==='AUTH_REQUIRED'){
    state.user=null;
    state.guest=true;
    refreshAccountUI();
    $('#authScreen').classList.remove('hidden');
    showAuthForm('login');
    setAuthStatus(data.message||'نشست حساب معتبر نیست؛ دوباره وارد شو.','error');
    return Object.assign(new Error(data.message||'ورود به حساب لازم است.'),{authGate:true})
  }
  if(response.status===503&&data.code==='AUTH_UNAVAILABLE'){
    if(!state.user)state.guest=true;
    $('#authScreen').classList.remove('hidden');
    showAuthForm('login');
    setAuthStatus(data.message||'سرویس ورود در دسترس نیست.','error');
    $('#authFootnote').textContent='زیرساخت احراز هویت در Worker آماده نیست؛ درخواست‌های هزینه‌دار تا زمان رفع مشکل مسدود می‌مانند.';
    return Object.assign(new Error(data.message||'سرویس ورود در دسترس نیست.'),{authGate:true})
  }
  return null
}
function initAuth(force=false){
  if(authInitPromise&&!force)return authInitPromise;
  authAvailability='checking';
  authDiagnostics=null;
  authProviders=false;
  authCheckComplete=false;
  authInitPromise=(async()=>{
    try{
      if(!['https:','http:'].includes(location.protocol)){
        authAvailability='offline';
        updateAuthFootnote('این فایل به‌صورت محلی باز شده است. برای ورود واقعی، نشانی Worker اصلی SAYROX را باز کن.',true);
        return
      }
      const healthResponse=await fetch('/api/health',{credentials:'same-origin',cache:'no-store',headers:{accept:'application/json'},signal:AbortSignal.timeout(10000)});
      const health=await healthResponse.json().catch(()=>null);
      if(!healthResponse.ok||health?.ok!==true||!health.providers){
        throw new Error(`health endpoint status ${healthResponse.status}`)
      }
      authDiagnostics=health.authDiagnostics&&typeof health.authDiagnostics==='object'?health.authDiagnostics:null;
      authProviders=health.providers.auth===true;
      authAvailability=authProviders?'ready':'misconfigured';
      if(authProviders){
        updateAuthFootnote('اتصال Worker و زیرساخت حساب آماده است. برای استفاده از چت هوشمند و سرویس‌های ابری وارد حساب SAYROX شو.')
      }else{
        updateAuthFootnote(authUnavailableMessage(),true)
      }
      const meResponse=await fetch('/api/auth/me',{credentials:'same-origin',cache:'no-store',headers:{accept:'application/json'},signal:AbortSignal.timeout(10000)});
      const me=await meResponse.json().catch(()=>null);
      if(meResponse.status===503){
        authProviders=false;
        authAvailability='misconfigured';
        updateAuthFootnote(authUnavailableMessage(),true)
      }
      if(me?.authenticated&&me.user){enterAccount(me.user);return}
    }catch{
      authProviders=false;
      authAvailability='offline';
      updateAuthFootnote(authUnavailableMessage(),true)
    }finally{
      authCheckComplete=true;
      state.authReady=authProviders
    }
  })();
  return authInitPromise
}
$('#authForm').addEventListener('submit',async e=>{
  e.preventDefault();
  if(!authProviders){
    if(!authCheckComplete){
      setAuthStatus('در حال بررسی اتصال امن SAYROX به Worker…');
      void initAuth().then(()=>{
        if(!state.user)setAuthStatus(authProviders?'برای ادامه وارد حساب SAYROX شو.':authUnavailableMessage(),authProviders?'':'error');
      });
    }else setAuthStatus(authUnavailableMessage(),'error');
    return
  }
  const button=$('#authSubmit');
  button.disabled=true;
  button.textContent='در حال بررسی…';
  try{
    const payload={email:$('#authEmail').value.trim(),password:$('#authPassword').value};
    if(authMode==='signup')payload.displayName=$('#authName').value.trim();
    const response=await fetch(`/api/auth/${authMode}`,{
      method:'POST',
      credentials:'same-origin',
      headers:{'content-type':'application/json'},
      body:JSON.stringify(payload)
    });
    const data=await response.json().catch(()=>({}));
    if(!response.ok||!data.ok)throw new Error(data.message||'ورود انجام نشد.');
    enterAccount(data.user)
  }catch(err){setAuthStatus(err.message||'خطای ورود.','error')}finally{
    button.disabled=false;
    button.textContent=authMode==='signup'?'ساخت حساب':'ورود به حساب'
  }
});
$('#authForgot').onclick=()=>setAuthStatus('بازیابی رمز از طریق ایمیل هنوز به سرویس ارسال ایمیل متصل نشده است. برای امنیت، رمز را از این فرم دریافت یا بازیابی نمی‌کنیم.','error');
$('#authGuest').onclick=enterGuest;
async function logoutAccount(){
  showModal('خروج از حساب','<p>از حساب SAYROX خارج شوی؟ گفتگوهای محلی این دستگاه حذف نمی‌شوند.</p>','خروج',async()=>{
    try{
      if(state.user&&['http:','https:'].includes(location.protocol))await fetch('/api/auth/logout',{method:'POST',credentials:'same-origin'}).catch(()=>{})
    }finally{
      state.user=null;
      state.guest=false;
      refreshAccountUI();
      $('#authScreen').classList.remove('hidden');
      showAuthLanding();
      toast('از حساب خارج شدی')
    }
  })
}
