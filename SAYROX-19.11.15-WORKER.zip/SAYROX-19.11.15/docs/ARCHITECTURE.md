# معماری و نقشهٔ فایل‌ها

## مرورگر (`app/` → `site/src/app.js`)

همهٔ بخش‌ها داخل یک closure مشترک اجرا می‌شوند (همان state و helperها)، پس ترتیب فایل‌ها مهم است و با پیشوند شماره مشخص شده:

| فایل | مسئولیت |
|---|---|
| `prelude.js` | پل Studio فایل (بیرون از closure) |
| `01-core-state` | helperهای ذخیره‌سازی امن، state، persist، toast، تم |
| `02-chats-navigation` | مدل چت، viewها و تب‌ها، رندر امن محتوای پیام |
| `03-user-message-menu` | منوی لمس طولانی روی پیام کاربر |
| `04-message-rendering` | پیوست‌ها، فهرست پیام‌ها، کشوی تاریخچه |
| `05-send-message` | ارسال پیام، دریافت metadata تحقیقِ Agent، انتخاب مدل، پخش پاسخ |
| `06-dictation` | دیکتهٔ فارسی (Scribe و fallback مرورگر) |
| `07-live-voice` | مکالمهٔ زنده: SDK، نشست، اتصال دوباره، قطع صدا |
| `08-modules-settings` | تنظیمات، صفحه‌های ماژول، خروجی و پاک‌سازی داده |
| `09-composer-menus` | اتصال رویدادها: کشو، composer، منوی هدر و ابزار |
| `10-pull-to-new-chat` | حرکت کشیدن برای چت جدید |
| `11-auth` | ورود و ثبت‌نام، دروازهٔ APIهای محافظت‌شده |
| `12-images-studio` | استودیوی تصویر و گالری محلی (IndexedDB) |
| `13-scheduled-tasks` | صفحهٔ کارهای زمان‌بندی‌شده و صندوق نتایج |
| `14-boot` | کنترل‌های صوت، راه‌اندازی، رندر اول، Service Worker |

ماژول‌های مستقل (`site/src/core`, `site/src/features`, `site/src/styles`) مستقیم ویرایش می‌شوند و فایل ساخته‌شده نیستند.

در 19.10.6، `site/src/core/code-workspace.js` محیط بلوک‌های کد گفتگو (شماره خطوط، رنگ‌بندی سبک، ویرایش و کنترل پیش‌نمایش) را ارائه می‌کند و `site/src/core/secure-html-preview.js` تنها مالک ساخت iframe ایزولهٔ HTML است؛ استودیو فایل و بلوک‌های کد چت هر دو از همین سازنده استفاده می‌کنند.

در 19.10.8، `site/src/features/chat/spreadsheet-input.js` ورودی XLSX/XLSM/CSV گفتگو را به موتور مشترک `site/src/features/files/spreadsheet.js` وصل می‌کند؛ PDF و صفحه‌گسترده‌ها از یک Map حافظه‌ای و `buildDocumentContext` استفاده می‌کنند. متن استخراج‌شده در localStorage ذخیره نمی‌شود و فقط زمینهٔ محدودشده به Worker می‌رسد.

در 19.10.9، `site/src/features/chat/zip-input.js` موتور ZIP مشترک را در مسیر محلی به composer وصل می‌کند. `site/src/features/files/zip.js` مالک parsing، استخراج انتخابی، CRC و بررسی ساختار آرشیو است؛ استودیو فایل نیز از همان API استفاده می‌کند. Worker فقط متن استخراج‌شده با نوع `archive` را می‌گیرد و هیچ فایل باینری یا لینک عمومی ایجاد نمی‌کند.


در 19.11.0، `site/src/features/files/library-store.js` تنها مالک ذخیره‌سازی باینری فایل‌ها در IndexedDB مرورگر است و `site/src/features/files/library.js` رابط کتابخانهٔ مرکزی را می‌سازد. استودیو فایل، پیوست‌های تأییدشدهٔ چت و خروجی‌های تولیدی از همان مخزن استفاده می‌کنند؛ لیست و جستجو فقط فراداده را می‌خوانند و دریافت Blob فقط هنگام بازبینی یا دانلود انجام می‌شود. `site/src/features/files/studio.js` همچنان مالک پیش‌نمایش/تبدیل است و منطق parser موازی ساخته نشده است. هیچ فایل باینری در localStorage، Worker، Cloudflare D1 یا فضای ذخیره‌سازی سرور ثبت نمی‌شود.


در 19.11.1، `site/src/features/files/markdown.js` تنها مالک parser بلوکی Markdown و renderer امن HTML است. `documents.js` از همان AST برای ساخت DOCX (از جمله جدول‌های OOXML واقعی) استفاده می‌کند و `studio.js` فقط تبدیل‌ها را هماهنگ می‌کند؛ هیچ parser موازی Markdown در Studio/Word باقی نمانده است. این ماژول باید پیش از `documents.js` و `studio.js` در `site/index.html` بارگذاری و در precache سرویس‌ورکر ثبت شود. تبدیل‌های Office استخراج محتوای قابل‌خواندن را انجام می‌دهند، نه بازسازی یک‌به‌یک قالب اصلی.

## Worker (`worker/` → `site/_worker.js`)

هر فایل یک ماژول بارگذاری‌شده با `__load` است و شناسه‌اش مسیر خودش است. نکته: این سورس‌ها همان JavaScript کامپایل‌شدهٔ قبلی‌اند (سورس TypeScript اصلی در بسته نبود) و از این پس مرجع اصلی هستند.

- `index.js` ورودی، `routes/` مسیرهای API و احراز هویت، `providers/` چت و ثبت مدل‌ها
- `features/` حافظه، پرداخت، جست‌وجو، TTS، سهمیه، صوت زنده، `images.js` (تولید تصویر)، `tasks.js` (API کارها و مسیر داخلی امضاشده)
- `security/` رمز عبور و نشست، `shared/` ثابت‌ها و ابزار HTTP

## گردش کار

```bash
# ویرایش app/ یا worker/
npm run build:code     # بازسازی فایل‌های ساخته‌شده
npm test               # شامل تست یکپارچگی و هم‌خوانی ساخته‌شده‌ها
```


## مرزهای مالکیت و وابستگی‌های خارجی

- خروجی‌های `site/src/app.js` و `site/_worker.js` ساخته‌شده‌اند؛ سورس مرجع به‌ترتیب `app/` و `worker/` است. هر دو باید با اسکریپت‌های Build بازتولید شوند و دستی ویرایش نشوند.
- فایل‌های مستقل زیر `site/src/core/` و `site/src/features/` در این نسخه سورس مستقیم مرورگرند؛ برای آن‌ها کپی موازی در `app/` نساز.
- پیاده‌سازی Durable Objectهای `AUTH_ACCOUNTS` و `AUTH_RATE_LIMITER` در `auth-worker/` نگهداری می‌شود و Worker اصلی `sayrox` از Bindingهای cross-script به Worker مالک `sayrox-auth-storage` متصل می‌شود. نام و Namespaceهای واقعی در Cloudflare باید با `docs/INFRASTRUCTURE.md` تطبیق داده شوند.
- `usage-worker/`، `billing-worker/` و `tasks-worker/` مالک‌های جداگانهٔ داده و Durable Objectهای خود هستند. تعریف lifecycle موجود آن‌ها بدون بررسی Namespace و دادهٔ زنده یکسان‌سازی یا بازنویسی نمی‌شود.
- فهرست کامل Bindingها، متغیرها، Secrets و مراحل انتشار در `docs/INFRASTRUCTURE.md` مرجع عملیاتی است.

## هستهٔ Agent و Function Calling (19.11.4)

`worker/agent/` مالک قراردادهای نقش و حالت، Planner/Router، سیاست حافظه، سیاست مجوز، Tool Registry و اجرای محدود ابزار است. `worker/providers/chat.js` نقطهٔ ورود Main Agent است و System Policy را پیش از پیام‌های کاربر/تاریخچه قرار می‌دهد.

در 19.11.4 ابزار `web_research` به‌صورت schema استاندارد به Provider ارائه می‌شود؛ مدل در حالت `auto` خودش انتخاب می‌کند که تابع را فراخوانی کند یا نه. `worker/agent/tool-loop.js` چرخهٔ درخواست تابع → اعتبارسنجی/مجوز → اجرای Worker → بازگشت پیام tool → ادامه استدلال مدل را با سقف دور/مراحل اجرا می‌کند. حالت‌های `always/off` در سمت Worker enforce می‌شوند. Tavily Search/Extract در Worker و با quota استفاده می‌شود؛ Deep تا سه پرس‌وجو و چهار صفحه با ۱۰٬۰۰۰ نویسه برای هر صفحه دارد. محتوای وب دادهٔ غیرقابل‌اعتماد است. درخواست‌های stream پاسخ نهایی را با SSE دریافت می‌کنند. پشتیبانی زندهٔ Function Calling GapGPT و Secret Tavily هنوز به Preview واقعی نیاز دارد. نقش‌ها همچنان Agentهای تخصصی منطقی زیر Main Agent هستند، نه سرویس‌های موازی. سیاست حافظه از سرویس موجود استفاده می‌کند. جزئیات در `docs/AGENT-CORE.md` و `docs/AGENT-WEB-RESEARCH.md` آمده است.


## ابزارهای کاربردی Agent و قابلیت‌های متصل (19.11.8)

`worker/agent/utility-tools.js` سه ابزار `calculate`، `current_time` و `read_url` را تعریف می‌کند و `worker/providers/chat.js` آن‌ها را به Tool Registry همان درخواست می‌دهد: `web_research` (اگر جست‌وجو فعال باشد)، `read_url` (فقط با پیوند کاربر و وب فعال)، `calculate` و `current_time` (فقط با نیت مناسب). فهرست مجاز پیوند از پیام‌های کاربر ساخته می‌شود و خود ابزار نیز آن را دوباره بررسی می‌کند؛ `read_url` از آداپتور Tavily Extract و سهمیهٔ `search` موجود استفاده می‌کند. `tool-loop.js` پارامتر `requiredToolId` را برای قرارداد `always` می‌گیرد. جزئیات و محدودیت‌ها: `docs/AGENT-UTILITY-TOOLS.md`.

## یکپارچه‌سازی قابلیت‌های Main Agent (19.11.8)

`worker/agent/file-tools.js` ابزارهای `inspect_attached_files` و `create_file` را فراهم می‌کند؛ متن سند با allowlist فایل فعلی و سقف اندازه فقط از مسیر tool قابل خواندن است و خروجی DOCX/PDF/XLSX به موتورهای محلی `SayroxFileStudio` در مرورگر تحویل می‌شود. `memory-tools.js` خواندن محدود حافظهٔ کاربر را از سرویس موجود انجام می‌دهد؛ `scheduled-task-tools.js` فقط ساخت کار را از طریق `TASKS_ACCOUNT` موجود انجام می‌دهد؛ `image-tools.js` تولید تصویر را به API موجود تصویر متصل می‌کند؛ `capability-intent.js` ابزارهای هزینه‌دار/تغییردهنده را فقط بعد از درخواست صریح ثبت می‌کند. خروجی تصویر و فایل با رویدادهای اختصاصی SSE به UI می‌رسند. جزئیات، حدود و پیکربندی در `docs/AGENT-CAPABILITIES.md` است.

این بخش D1، Binding جدید یا فضای ذخیره‌سازی موازی اضافه نمی‌کند. ابزار حافظه فقط‌خواندنی است؛ ابزار زمان‌بندی فقط create است؛ ساخت فایل در مرورگر انجام می‌شود؛ تصویر از مسیر تصویری موجود و با سهمیهٔ فعلی استفاده می‌کند. تنظیم Provider تصویر و bindingهای قبلی Tasks پیش‌نیازهای مستقل‌اند.


## نمایش زندهٔ مراحل Agent (19.11.9)

`worker/agent/tool-loop.js` رویدادهای lifecycle را در لحظهٔ رخداد تولید می‌کند؛ `worker/agent/tool-registry.js` رویداد شروع را تنها پس از بررسی schema، allowlist، ریسک و مجوز می‌فرستد. `worker/providers/chat.js` این رویدادها را در یک `ReadableStream` از نوع SSE به مرورگر ارسال می‌کند؛ مسیرهای non-stream همان پاسخ JSON قبلی را حفظ می‌کنند. `site/src/core/stream.js` رویدادهای سفارشی را از deltaهای متن جدا نگه می‌دارد و `app/05-send-message.js` وضعیت را از روی رویداد دریافت‌شده به‌روزرسانی می‌کند.

قرارداد رویداد با `runId`، شمارهٔ ترتیبی و نوع وضعیت محدود است؛ `summary` پیش از متن نهایی فقط state برابر `responding` دارد و `completed` پس از ارسال آخرین delta صادر می‌شود. شکست و لغو نیز رویداد پایانی مستقل دارند. دادهٔ پیشرفت شامل آرگومان ابزار، متن سند، خروجی ابزار یا استدلال داخلی مدل نیست. منابع تحقیق فقط در رویداد summary و پس از پاک‌سازی URL وارد UI می‌شوند. `tool_started` معادل «درخواست مدل برای ابزار» نیست؛ فقط بعد از عبور از اعتبارسنجی و سیاست مجوز Worker صادر می‌شود. متن پاسخ نهایی پس از تمام‌شدن Tool Loop ارسال می‌شود و به قطعه‌های سازگار با delta تقسیم می‌شود؛ بنابراین 19.11.9 پیشرفت ابزار را زنده می‌کند، اما هنوز stream توکن خام Provider در طول دورهای Function Calling را پیاده نمی‌کند.

## موتور نمایش پاسخ (19.11.5)

`site/src/core/response-renderer.js` مسئول تبدیل متن پاسخ مدل به ساختار قابل‌خواندن چت است. این ماژول از `site/src/features/files/markdown.js` و `SayroxMarkdown.parseBlocks` برای تشخیص بلوک‌ها استفاده می‌کند، اما خروجی را با API ساخت DOM می‌سازد و محتوای مدل را در `innerHTML` قرار نمی‌دهد. لینک‌ها با allowlist پروتکل اعتبارسنجی می‌شوند. بلوک‌های کد نهایی از `SayroxCodeWorkspace` مشترک استفاده می‌کنند؛ پاسخ stream با حالت streaming و بدون ایجاد ابزار ویرایش بازترسیم می‌شود. فرمول‌های متداول از MathML بومی استفاده می‌کنند و پشتیبانی آن‌ها زیرمجموعهٔ رایج LaTeX است، نه TeX کامل. اسکریپت و CSS جدید در Service Worker نیز precache می‌شوند. همچنین `worker/providers/chat.js` یک راهنمای نگارش مشترک را در System Context همهٔ درخواست‌ها قرار می‌دهد تا مدل پاسخ طبیعی و متناسب با طول درخواست تولید کند و از Markdown، جدول و فرمول فقط در جای لازم بهره ببرد؛ این دستور سبک نگارش است و سیاست امنیت/مجوز را تغییر نمی‌دهد.

## تأیید امن ابزارهای اثرگذار (19.11.10)

`worker/agent/tool-loop.js` توقف قبل از handler را مدیریت می‌کند؛ `worker/agent/approval-tickets.js` Ticket AES-GCM حساب‌محور و hash-bound می‌سازد؛ `worker/features/agent-approval.js` ابزار را فقط از allowlist سمت سرور بازسازی می‌کند و `worker/routes/api.js` احراز هویت، same-origin و rate limit را اعمال می‌کند. کارت UI در `app/05-send-message.js` هیچ آرگومان ابزاری را نشان نمی‌دهد یا از کاربر نمی‌گیرد.

Ticket فقط پنج دقیقه معتبر و یک‌بارمصرف است. مصرف آن در جدول `agent_approval_tickets` در SQLite داخلی Durable Object فعلی `USAGE_ACCOUNT` و با transaction اتمیک انجام می‌شود. این Cloudflare D1 نیست و Binding/DO class جدیدی ندارد. چون `usage-worker` مالک متد مصرف اتمیک است، در rollout ابتدا همان Worker به‌روز و سپس Worker اصلی `sayrox` و رابط Static Assets منتشر می‌شود. ابزارهای credentials، کد دلخواه و شبکهٔ نامحدود همچنان مسدودند.


## اجرای کد ایزوله (19.11.11)

اجرای Python کاربر/مدل در Worker اصلی `sayrox` انجام نمی‌شود. Worker اصلی فقط یک درخواست HMAC امضاشده را از طریق Service Binding به Worker مستقل `sayrox-code-sandbox-preview` می‌فرستد؛ آن Worker از یک Durable Object/Container اختصاصی برای هر فراخوانی ابزار استفاده می‌کند. اینترنت خاموش است، Secret و Binding به Container پاس داده نمی‌شود، کد از stdin اجرا می‌شود و خروجی محدود می‌ماند. جزئیات و پیش‌نیازها در `docs/AGENT-SANDBOX.md` است.
