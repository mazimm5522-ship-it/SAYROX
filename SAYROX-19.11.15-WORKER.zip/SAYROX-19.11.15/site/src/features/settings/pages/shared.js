(function (global) {
  'use strict';
  const escape = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
  const icon = name => (global.SayroxIcons ? global.SayroxIcons.svg(name) : '');
  const head = (iconName, title, description, tone) => `<div class="sx-page-head" style="--tone:${escape(tone || '#4065e7')}"><span class="sx-hero-icon">${icon(iconName)}</span><h2>${escape(title)}</h2>${description ? `<p>${escape(description)}</p>` : ''}</div>`;
  const section = (title, body, note = '') => `<section class="sx-section">${title ? `<h2>${escape(title)}</h2>` : ''}<div class="sx-card">${body}</div>${note ? `<p class="sx-note">${escape(note)}</p>` : ''}</section>`;
  const row = (title, description, control, options = {}) => `<div class="sx-row ${options.danger ? 'is-danger' : ''} ${options.block ? 'is-block' : ''}"><div class="sx-copy"><strong>${escape(title)}</strong>${description ? `<small>${escape(description)}</small>` : ''}</div><div class="sx-control">${control || ''}</div></div>`;
  const toggle = (key, title, description, checked = false, disabled = false) => row(title, description, `<button type="button" class="sx-switch ${checked ? 'is-on' : ''}" role="switch" aria-checked="${checked}" aria-label="${escape(title)}" data-setting-toggle="${escape(key)}" ${disabled ? 'disabled' : ''}><span></span></button>`);
  const badge = (text, type = 'neutral') => `<span class="sx-badge sx-badge-${type}">${escape(text)}</span>`;
  const button = (action, label, type = 'secondary', extra = '') => `<button type="button" class="sx-button sx-button-${type}" data-setting-action="${escape(action)}" ${extra}>${escape(label)}</button>`;
  const status = (title, description, value, type = 'neutral') => row(title, description, badge(value, type));
  global.SayroxSettingsPages = global.SayroxSettingsPages || { renderers: {}, register(key, render) { this.renderers[key] = render; } };
  Object.assign(global.SayroxSettingsPages, { escape, icon, head, section, row, toggle, badge, button, status });
})(globalThis);
