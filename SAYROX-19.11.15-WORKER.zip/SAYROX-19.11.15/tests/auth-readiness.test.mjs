import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

const bundle = await readFile(new URL('../site/_worker.js', import.meta.url), 'utf8');
const source = bundle.replace('export default __worker;', 'globalThis.__sayroxBundle = { __worker, __load };');
const context = vm.createContext({
  crypto: webcrypto, fetch: globalThis.fetch, Request, Response, Headers, URL, URLSearchParams,
  AbortController, AbortSignal, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, Blob,
  setTimeout, clearTimeout, console, atob, btoa, Date, Math, JSON, Number, String, Boolean,
  Object, Array, Map, Set, RegExp, Error, TypeError, Promise, Intl
});
vm.runInContext(source, context, { filename: 'site/_worker.js' });
const { __worker, __load } = context.__sayroxBundle;
const sessions = __load('worker/security/sessions.js');
const namespace = { idFromName: name => name, get: () => ({ fetch: async () => new Response('{}') }) };
const secret = 'SAYROX-test-secret-that-is-long-enough-64-characters';

function readiness(env) {
  return JSON.parse(JSON.stringify(sessions.authReadiness(env)));
}

assert.deepEqual(readiness({ AUTH_ACCOUNTS: namespace, AUTH_RATE_LIMITER: namespace, AUTH_SESSION_SECRET: secret }), {
  accountNamespace: true, rateLimitNamespace: true, sessionSecret: true
});
assert.equal(sessions.authReady({ AUTH_ACCOUNTS: namespace, AUTH_RATE_LIMITER: namespace, AUTH_SESSION_SECRET: secret }), true);

for (const [env, missing] of [
  [{ AUTH_RATE_LIMITER: namespace, AUTH_SESSION_SECRET: secret }, 'accountNamespace'],
  [{ AUTH_ACCOUNTS: namespace, AUTH_SESSION_SECRET: secret }, 'rateLimitNamespace'],
  [{ AUTH_ACCOUNTS: namespace, AUTH_RATE_LIMITER: namespace, AUTH_SESSION_SECRET: 'short' }, 'sessionSecret'],
  [{ AUTH_ACCOUNTS: {}, AUTH_RATE_LIMITER: namespace, AUTH_SESSION_SECRET: secret }, 'accountNamespace'],
]) {
  const result = readiness(env);
  assert.equal(result[missing], false, `${missing} must be reported as unavailable`);
  assert.equal(sessions.authReady(env), false, 'auth must remain fail-closed when any dependency is missing');
}

const healthResponse = await __worker.fetch(new Request('https://sayrox.test/api/health'), {
  AUTH_ACCOUNTS: namespace,
  AUTH_RATE_LIMITER: namespace,
  AUTH_SESSION_SECRET: secret,
  AI_PROVIDER: 'gapgpt'
});
assert.equal(healthResponse.status, 200);
const health = await healthResponse.json();
assert.equal(health.providers.auth, true);
assert.deepEqual(health.authDiagnostics, {
  accountNamespace: true, rateLimitNamespace: true, sessionSecret: true
});
assert.doesNotMatch(JSON.stringify(health), new RegExp(secret), 'health must never echo a secret value');

const missingHealthResponse = await __worker.fetch(new Request('https://sayrox.test/api/health'), {
  AUTH_ACCOUNTS: namespace,
  AUTH_RATE_LIMITER: namespace,
  AUTH_SESSION_SECRET: 'short',
  AI_PROVIDER: 'gapgpt'
});
const missingHealth = await missingHealthResponse.json();
assert.equal(missingHealth.providers.auth, false);
assert.equal(missingHealth.authDiagnostics.sessionSecret, false);

const authUi = await readFile(new URL('../app/11-auth.js', import.meta.url), 'utf8');
assert.match(authUi, /authAvailability='checking'/, 'auth UI must model the initial readiness check');
assert.match(authUi, /authCheckComplete/, 'auth UI must not confuse an unfinished health check with a missing service');
assert.match(authUi, /authDiagnostics\?\.accountNamespace/, 'auth UI must report the missing account binding precisely');
assert.match(authUi, /بررسی دوباره/, 'auth UI must provide a retry after health/connectivity failures');
assert.match(authUi, /healthResponse\.ok/, 'auth UI must reject non-OK health responses instead of treating them as readiness data');
assert.match(authUi, /cache:'no-store'/, 'auth health checks must not reuse a cached response');
assert.doesNotMatch(authUi, /سرویس حساب روی Worker هنوز پیکربندی نشده است/, 'obsolete generic auth error must not be shown');

console.log('Auth readiness tests passed: prerequisites, safe health diagnostics, fail-closed behavior, and UI initialization race handling.');
