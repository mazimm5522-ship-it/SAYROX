"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.api = api;
const constants_js_1 = __load("worker/shared/constants.js");
const http_js_1 = __load("worker/shared/http.js");
const registry_js_1 = __load("worker/providers/registry.js");
const chat_js_1 = __load("worker/providers/chat.js");
const search_js_1 = __load("worker/features/search.js");
const tts_js_1 = __load("worker/features/tts.js");
const payments_js_1 = __load("worker/features/payments.js");
const memory_js_1 = __load("worker/features/memory.js");
const auth_js_1 = __load("worker/routes/auth.js");
const sessions_js_1 = __load("worker/security/sessions.js");
const live_voice_js_1 = __load("worker/features/live-voice.js");
const quotas_js_1 = __load("worker/features/quotas.js");
const images_js_1 = __load("worker/features/images.js");
const tasks_js_1 = __load("worker/features/tasks.js");
const agent_history_js_1 = __load("worker/features/agent-history.js");
const agent_approval_js_1 = __load("worker/features/agent-approval.js");
async function api(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/api/models') {
        if (request.method !== 'GET')
            return (0, http_js_1.json)({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
        return (0, http_js_1.json)({ ok: true, models: (0, registry_js_1.modelCatalog)(env) });
    }
    if (url.pathname === '/api/health') {
        if (request.method !== 'GET')
            return (0, http_js_1.json)({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
        const chatProviders = (0, registry_js_1.providerOrder)(env);
        const chatDiagnostics = (0, registry_js_1.providerDiagnostics)(env);
        return (0, http_js_1.json)({ ok: true, providers: {
                chat: chatDiagnostics.chatReady,
                chatPrimary: chatProviders[0] || chatDiagnostics.primary,
                chatFallback: chatProviders[1] || null,
                chatPrimaryReady: chatDiagnostics.primaryReady,
                chatFallbackReady: chatDiagnostics.fallbackReady,
                gapgpt: chatDiagnostics.gapgpt,
                openrouter: chatDiagnostics.openrouter,
                search: Boolean((0, http_js_1.text)(env.TAVILY_API_KEY, 1000).trim()),
                tts: Boolean((0, http_js_1.text)(env.ELEVENLABS_API_KEY, 1000).trim() && constants_js_1.VOICES.some(v => (0, http_js_1.text)(env[`ELEVENLABS_${v.toUpperCase()}_VOICE_ID`], 200).trim())),
                voiceLive: Boolean((0, http_js_1.text)(env.ELEVENLABS_API_KEY, 1000).trim() && /^seng_[A-Za-z0-9]+$/.test((0, http_js_1.text)(env.ELEVENLABS_SPEECH_ENGINE_ID, 120).trim())),
                voiceInput: Boolean((0, http_js_1.text)(env.ELEVENLABS_API_KEY, 1000).trim()),
                payments: Boolean((0, http_js_1.text)(env.ZARINPAL_MERCHANT_ID, 100).trim() && env.BILLING_ACCOUNT && ['sandbox','production'].includes((0, http_js_1.text)(env.ZARINPAL_MODE, 16).toLowerCase()) && ((0, http_js_1.text)(env.PAYMENT_CALLBACK_SECRET, 500).trim() || ((0, http_js_1.text)(env.ZARINPAL_MODE, 16).toLowerCase() === 'sandbox' && (0, http_js_1.text)(env.AUTH_SESSION_SECRET, 500).length >= 32)) && env.PAYMENTS_ENABLED === 'true' && env.SUBSCRIPTION_ACTIVATION_READY === 'true'),
                images: (0, images_js_1.imageConfig)(env).ready,
                codeSandbox: Boolean(env.CODE_SANDBOX && typeof env.CODE_SANDBOX.fetch === "function" && (0, http_js_1.text)(env.CODE_SANDBOX_INTERNAL_SECRET, 500).length >= 32),
                tasks: (0, tasks_js_1.tasksReady)(env),
                auth: (0, sessions_js_1.authReady)(env),
                rateLimit: (0, sessions_js_1.rateLimitReady)(env)
            }, authDiagnostics: (0, sessions_js_1.authReadiness)(env) });
    }
    // Server-to-server (Scheduler Durable Object): signed, no cookies, no browser origin.
    if (url.pathname === '/api/internal/task-run')
        return (0, tasks_js_1.taskRunInternal)(request, env);
    if (url.pathname.startsWith('/api/auth/'))
        return (0, auth_js_1.authApi)(request, env, url.pathname);
    if (url.pathname.startsWith('/api/voice/')) {
        if ((url.pathname === '/api/voice/token' || url.pathname === '/api/voice/transcription-token') && request.method === 'GET') {
            const limited = await (0, sessions_js_1.enforceApiRateLimit)(request, env, url.pathname === '/api/voice/token' ? 'voice-token' : 'voice-input-token');
            if (limited)
                return limited;
        }
        return (0, live_voice_js_1.liveVoiceApi)(request, env, url.pathname);
    }
    if (url.pathname === '/api/memory' && request.method === 'GET') {
        const limited = await (0, sessions_js_1.enforceApiRateLimit)(request, env, 'memory-read');
        if (limited)
            return limited;
    }
    if (url.pathname === '/api/agent/runs' || url.pathname.startsWith('/api/agent/runs/')) {
        const limited = await (0, sessions_js_1.enforceApiRateLimit)(request, env, 'agent-history');
        if (limited) return limited;
        if (!(0, sessions_js_1.authReady)(env))
            return (0, http_js_1.json)({ ok: false, code: 'AUTH_UNAVAILABLE', message: 'ورود امن در دسترس نیست.' }, 503);
        const session = await (0, sessions_js_1.authenticatedSession)(request, env);
        if (!session)
            return (0, http_js_1.json)({ ok: false, code: 'AUTH_REQUIRED', message: 'برای مشاهدهٔ تاریخچهٔ Agent ابتدا وارد حساب شو.' }, 401);
        return (0, agent_history_js_1.agentHistoryApi)(request, env, session, url.pathname);
    }
    if (url.pathname === '/api/tasks' && request.method === 'GET') {
        const limited = await (0, sessions_js_1.enforceApiRateLimit)(request, env, 'tasks-read');
        if (limited)
            return limited;
    }
    const protectedProviderRoute = url.pathname === '/api/chat' || url.pathname === '/api/agent/approval' || url.pathname === '/api/search' || url.pathname === '/api/tts' || url.pathname === '/api/images/generate';
    if (protectedProviderRoute && !(0, sessions_js_1.sameOriginRequest)(request))
        return (0, http_js_1.json)({ ok: false, code: 'CROSS_ORIGIN', message: 'مبدأ درخواست معتبر نیست.' }, 403);
    if (request.method === 'POST') {
        const limitedRoute = url.pathname === '/api/chat' ? 'chat'
            : url.pathname === '/api/agent/approval' ? 'agent-approval'
                : url.pathname === '/api/search' ? 'search'
                : url.pathname === '/api/tts' ? 'tts'
                    : url.pathname === '/api/images/generate' ? 'images'
                        : url.pathname.startsWith('/api/tasks') ? 'tasks'
                    : url.pathname === '/api/payment/request' ? 'payment'
                        : url.pathname === '/api/memory' ? 'memory' : null;
        if (limitedRoute) {
            const limited = await (0, sessions_js_1.enforceApiRateLimit)(request, env, limitedRoute);
            if (limited)
                return limited;
        }
    }
    // Billable provider routes are account-only. Fail closed when auth is not
    // configured, and validate the server-side session before any provider call.
    let providerSession = null;
    if (protectedProviderRoute) {
        if (!(0, sessions_js_1.authReady)(env))
            return (0, http_js_1.json)({ ok: false, code: 'AUTH_UNAVAILABLE', message: 'ورود امن در حال حاضر در دسترس نیست؛ زیرساخت حساب را بررسی کن.' }, 503);
        providerSession = await (0, sessions_js_1.authenticatedSession)(request, env);
        if (!providerSession)
            return (0, http_js_1.json)({ ok: false, code: 'AUTH_REQUIRED', message: 'برای استفاده از چت هوشمند، جست‌وجوی وب و تبدیل متن به صدا ابتدا وارد حساب SAYROX شو.' }, 401);
    }
    if (url.pathname === '/api/payment/request' || url.pathname === '/api/subscription/me') {
        const requiredMethod = url.pathname === '/api/payment/request' ? 'POST' : 'GET';
        if (request.method !== requiredMethod)
            return (0, http_js_1.json)({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
        if (!(0, sessions_js_1.sameOriginRequest)(request))
            return (0, http_js_1.json)({ ok: false, code: 'CROSS_ORIGIN', message: 'مبدأ درخواست معتبر نیست.' }, 403);
        if (!(0, sessions_js_1.authReady)(env))
            return (0, http_js_1.json)({ ok: false, code: 'AUTH_UNAVAILABLE', message: 'ورود امن در دسترس نیست.' }, 503);
        const session = await (0, sessions_js_1.authenticatedSession)(request, env);
        if (!session)
            return (0, http_js_1.json)({ ok: false, code: 'AUTH_REQUIRED', message: 'برای پرداخت و مشاهده اشتراک ابتدا وارد حساب شو.' }, 401);
        if (url.pathname === '/api/payment/request')
            return (0, payments_js_1.paymentRequest)(request, env, session);
        return (0, payments_js_1.subscriptionMe)(request, env, session);
    }
    if (url.pathname === '/api/payment/callback')
        return (0, payments_js_1.paymentCallback)(request, env);
    if (url.pathname === '/api/memory')
        return (0, memory_js_1.memoryApi)(request, env);
    if (url.pathname === '/api/chat')
        return (0, chat_js_1.chat)(request, env, { accountKey: providerSession?.accountKey });
    if (url.pathname === '/api/agent/approval')
        return (0, agent_approval_js_1.agentApprovalApi)(request, env, { accountKey: providerSession?.accountKey });
    if (url.pathname === '/api/search')
        return (0, search_js_1.search)(request, env, { accountKey: providerSession?.accountKey });
    if (url.pathname === '/api/tts')
        return (0, tts_js_1.tts)(request, env, { accountKey: providerSession?.accountKey });
    if (url.pathname === '/api/images/generate')
        return (0, images_js_1.imageGenerate)(request, env, { accountKey: providerSession?.accountKey });
    if (url.pathname === '/api/tasks' || url.pathname.startsWith('/api/tasks/')) {
        if (!(0, sessions_js_1.sameOriginRequest)(request))
            return (0, http_js_1.json)({ ok: false, code: 'CROSS_ORIGIN', message: 'مبدأ درخواست معتبر نیست.' }, 403);
        if (!(0, sessions_js_1.authReady)(env))
            return (0, http_js_1.json)({ ok: false, code: 'AUTH_UNAVAILABLE', message: 'ورود امن در دسترس نیست.' }, 503);
        const session = await (0, sessions_js_1.authenticatedSession)(request, env);
        if (!session)
            return (0, http_js_1.json)({ ok: false, code: 'AUTH_REQUIRED', message: 'برای مدیریت کارهای زمان‌بندی‌شده ابتدا وارد حساب شو.' }, 401);
        return (0, tasks_js_1.tasksApi)(request, env, session, url.pathname);
    }
    return null;
}
