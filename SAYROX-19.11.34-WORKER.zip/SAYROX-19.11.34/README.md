# SAYROX 19.11.34

## Pre-Deploy Stabilization — Update 15 (19.11.34)

این نسخه مرحلهٔ تثبیت پیش از Deploy است و قابلیت محصولی تازه‌ای اضافه نمی‌کند. ممیزی پایه سه نقص اجرایی را پیدا کرد و برطرف ساخت: Service Worker دیگر پاسخ 404/500 یا محتوای غیر HTML را روی App Shell آفلاین نمی‌نویسد و عملیات Cache را در عمر Fetch Event نگه می‌دارد؛ اعتبارسنج Asset دیگر کل پوشهٔ `vendor/` را معاف نمی‌کند و فقط SDK صوتی اختیاری را در حالت توسعه می‌پذیرد؛ بررسی `APP_ORIGIN` اکنون ورودی تکراری، whitespace و origin غیر canonical را مسدود می‌کند.

ممیزی وابستگی‌ها نیز دو pin آسیب‌پذیر را یافت: `fflate` در Deploy Kit از 0.8.2 به 0.8.3 برای رفع CVE-2026-45820 ارتقا یافت و `esbuild` از 0.24.2 به 0.28.2 ارتقا یافت تا اصلاحات امنیتی نسخه‌های 0.25.0 و 0.28.1+ را در بر بگیرد. نسخهٔ دقیق Wrangler فعلی حفظ شد. این بررسی هدفمند است و جایگزین اسکن کامل وابستگی‌های انتقالی با lockfile نیست.

جزئیات، محدودیت‌ها و شواهد: [`docs/RELEASE-19.11.34.md`](docs/RELEASE-19.11.34.md) و [`docs/DEPENDENCY-SECURITY.md`](docs/DEPENDENCY-SECURITY.md).

## معماری و انتشار

- هیچ Renderer، parser، Provider، Agent، Worker، Tool Loop، Durable Object، Binding، Secret، Namespace، schema، migration یا D1 جدیدی ایجاد نشده است.
- خروجی‌های `site/src/app.js` و `site/_worker.js` باید با `npm run build:code` از سورس مرجع تولید شوند؛ ویرایش دستی ممنوع است.
- Deploy واقعی Cloudflare، SDK محلی ElevenLabs و Smoke Test با Secrets واقعی در این محیط تأیید نشده‌اند.
- رجیستری npm از محیط ساخت پاسخ نداد؛ بنابراین lockfile تازه تولید یا ادعا نشده است. وابستگی‌های مستقیم در manifestها دقیق pin شده‌اند.

برای Rollback، کد و Static Assets نسخهٔ قبل را یکپارچه بازگردان؛ اصلاحات امنیتی `fflate` و `esbuild` را در ابزار ساخت حفظ کن و به نسخه‌های آسیب‌پذیر برنگرد.
