# بازگشت از 19.11.34

این نسخه فقط Service Worker Cache، کنترل Assetها، اعتبارسنج Origin، تست‌ها، مستندات و نسخه‌های ابزار ساخت را تغییر می‌دهد؛ schema و دادهٔ Durable Object تغییر نکرده‌اند. برای بازگشت کد محصول، بستهٔ هماهنگ `SAYROX-19.11.33-WORKER.zip` را برگردان و فایل‌های تولیدی را از همان بسته نگه دار. با این حال، نسخه‌های امن `fflate@0.8.3` و `esbuild@0.28.2` را در Deploy Kit نگه دار؛ بازگرداندن manifest قدیمی Deploy Kit، CVE-2026-45820 و advisoryهای esbuild را دوباره وارد می‌کند. هیچ Durable Object، SQLite، Namespace یا داده‌ای را حذف نکن. Deploy واقعی این نسخه در محیط ساخت انجام نشده است.

---

# بازگشت نسخه — 19.11.33

## بازگشت از 19.11.33

این نسخه فقط parser مشترک `site/src/features/files/markdown.js`، renderer موجود `site/src/core/response-renderer.js`، CSS پاسخ، راهنمای نگارش موجود، تست‌ها، مستندات و cache نسخه‌دار Service Worker را تغییر می‌دهد. هیچ schema، جدول، دادهٔ پایدار، Worker، API، Binding، Secret، Durable Object، Namespace، migration یا D1 جدیدی اضافه نشده است. برای Rollback کامل، بستهٔ هماهنگ `SAYROX-19.11.32-WORKER.zip` را یکجا برگردان و فایل‌های تولیدی `site/_worker.js`، `site/src/app.js` و `site/sw.js` را از همان بسته نگه دار؛ خروجی‌های دو نسخه را ترکیب نکن. پیام‌ها و داده‌های ذخیره‌شده تغییر نکرده‌اند. Deploy واقعی و آزمون دیداری روی دستگاه واقعی در این محیط انجام نشده است.

---

# بازگشت نسخه — 19.11.32

## بازگشت از 19.11.32

این نسخه فقط راهنمای نگارش Provider موجود، parser مشترک `site/src/features/files/markdown.js`، `site/src/core/response-renderer.js`، CSS نمایش پاسخ، نسخهٔ Service Worker، تست‌ها و مستندات را تغییر می‌دهد. هیچ schema، جدول، دادهٔ پایدار، Worker، API، Binding، Secret، Durable Object class، Namespace، migration یا D1 جدیدی اضافه نشده است. برای Rollback کامل، بستهٔ هماهنگ `SAYROX-19.11.31-WORKER.zip` را برگردان و تمام فایل‌های `site/`، به‌ویژه `site/src/features/files/markdown.js`، `site/src/core/response-renderer.js`، `site/src/styles/response-rendering.css`، `site/_worker.js` و `site/sw.js` را از همان نسخه استفاده کن؛ فایل‌های تولیدی را بین نسخه‌ها ترکیب نکن. Service Worker با نسخهٔ قبلی cache خودش را بازسازی می‌کند. پیام‌ها و داده‌های ذخیره‌شده تغییر نکرده‌اند. هیچ Durable Object، SQLite یا داده‌ای را حذف نکن. Deploy واقعی و آزمون دیداری دستگاه واقعی در این محیط انجام نشده است.

---

# بازگشت نسخه — 19.11.31

## بازگشت از 19.11.31

این نسخه فقط Reader SSE سمت مرورگر و مستندات/تست‌های همراه را تغییر می‌دهد؛ هیچ تغییر schema، migration، Worker، Binding یا دادهٔ پایدار ندارد. برای Rollback کامل، بستهٔ هماهنگ `SAYROX-19.11.30-WORKER.zip` را به‌صورت یک مجموعه بازگردان و `site/_worker.js`، `site/src/app.js`، `site/src/core/stream.js` و `site/sw.js` را از نسخه‌های مختلف ترکیب نکن. Service Worker نسخهٔ قبلی cache خودش را دوباره می‌سازد. هیچ Durable Object، Namespace، SQLite یا داده‌ای را حذف نکن. اگر Providerی علامت پایان SSE را نمی‌فرستد، به‌جای Rollback بهتر است قرارداد streaming همان Provider را بررسی کنی؛ این نسخه عمداً چنین streamی را کامل تلقی نمی‌کند. Deploy زنده در این محیط انجام نشده است.

---

# بازگشت نسخه — 19.11.30

## بازگشت از 19.11.30

این نسخه فقط خواندن ورودی RPC داخلی Auth را محدود و Workerهای ذخیره‌سازی را با `workers_dev: false` از URL عمومی خارج می‌کند. هیچ migration، جدول، Binding، Durable Object class، Namespace یا D1 جدیدی ندارد. برای Rollback کد، Worker اصلی و `site/` را با بستهٔ کامل `SAYROX-19.11.29-WORKER.zip` جایگزین کن؛ فایل‌های تولیدی را از نسخه‌های مختلف ترکیب نکن. اگر Workerهای داخلی 19.11.30 باقی می‌مانند، URL عمومی خاموش می‌ماند و Main Worker از همان bindingهای موجود استفاده می‌کند. هیچ DO، SQLite، داده، Namespace یا Binding را حذف نکن. Deploy زنده در این محیط انجام نشده است.

---

# بازگشت نسخه — 19.11.29

## بازگشت از 19.11.29

این انتشار AvalAI و Hooshgar را به Provider Registry موجود اضافه می‌کند و هیچ migration، جدول، Binding، Worker، Durable Object class، Namespace یا D1 جدیدی ندارد. برای Rollback، Worker اصلی و پوشهٔ `site/` را به‌صورت یک مجموعه از بستهٔ کامل `SAYROX-19.11.28-WORKER.zip` بازگردان؛ `site/_worker.js`، `site/src/app.js` و `site/sw.js` نباید از نسخه‌های متفاوت باشند. Secretهای اختیاری `AVALAI_API_KEY` و `HOOSHGAR_API_KEY` را می‌توان نگه داشت؛ نسخهٔ قبلی آن‌ها را نادیده می‌گیرد. هیچ DO، داده، namespace یا binding را حذف نکن. Deploy واقعی این بسته از محیط ساخت انجام نشده است.

---

# بازگشت نسخه — 19.11.28

## بازگشت از 19.11.28

این نسخه فقط راهنمای نگارش Provider موجود، Markdown parser/renderer مشترک، CSS رابط، خروجی HTML/DOCX، تست‌ها و مستندات را تغییر می‌دهد. هیچ schema، جدول، دادهٔ پایدار، Binding، Secret، Worker، Durable Object class، Namespace، migration یا D1 اضافه/تغییر نکرده است. برای بازگشت، Worker اصلی و تمام Static Assets را به‌صورت هماهنگ با بستهٔ 19.11.26 جایگزین کن؛ به‌ویژه `site/_worker.js`، `site/src/features/files/markdown.js`، `site/src/core/response-renderer.js`، CSS و `site/sw.js`. cache Service Worker با فعال‌شدن نسخهٔ قبلی بازسازی می‌شود. پیام‌های ذخیره‌شده تغییر نکرده‌اند. هیچ Durable Object، SQLite یا دادهٔ حساب را حذف نکن. انتشار واقعی با این بسته انجام نشده است.

# بازگشت نسخه — 19.11.26

## بازگشت از 19.11.26

این نسخه Planner، Tool Loop، مسیر Chat، نمایش تاریخچه و نرمال‌سازی رویداد در `usage-worker` موجود را تغییر می‌دهد. هیچ جدول، ستون، migration، Binding، Secret، Worker، Durable Object class، Namespace یا D1 جدیدی ایجاد نشده است. برای بازگشت، Worker اصلی، `usage-worker` و Static Assets را با نسخهٔ کامل 19.11.25 جایگزین کن. فیلد JSON اختیاری `specialist` در `tool_events_json` توسط نسخهٔ قبلی نادیده گرفته می‌شود؛ پاک‌سازی دستی SQLite/DO لازم نیست و نباید Durable Object یا Namespace حذف شود. انتشار واقعی با این بسته انجام نشده است.

# بازگشت نسخه — 19.11.25

## بازگشت از 19.11.25

این نسخه Browser Engine فعلی، مسیر chat/approval و `usage-worker` موجود را تغییر می‌دهد. فقط جدول افزایشی `agent_browser_sessions` در SQLite داخلی `UsageAccountObject` موجود اضافه شده است؛ هیچ D1، migration بیرونی، Binding، Namespace یا Durable Object class جدیدی ایجاد نشده است. برای rollback، Worker اصلی، `usage-worker` و Static Assets را با بستهٔ کامل 19.11.24 جایگزین کن. جدول و داده‌های رمزگذاری‌شده در SQLite باقی می‌مانند و حذف دستی لازم نیست؛ نسخهٔ قبلی آن‌ها را نمی‌خواند. نشست‌های Browser Run باز با حداکثر ۲۰ دقیقه idle keepAlive به‌طور طبیعی منقضی می‌شوند. Durable Object یا Namespace را حذف نکن. اگر فقط Worker اصلی rollback شود، `usage-worker` جدید می‌تواند متدهای ذخیره را نگه دارد؛ هماهنگی کامل نسخه‌ها توصیه می‌شود. انتشار واقعی با این ZIP انجام نشده است.

# بازگشت نسخه — 19.11.24

## بازگشت از 19.11.24

این نسخه مسیر رابط چت، Worker اصلی/Agent و کد Worker Sandbox موجود را تغییر می‌دهد؛ در Sandbox تنها schema ورودی اجرای Python توسعه یافته است و هیچ جدول، migration یا کلاس/Namespace جدید Durable Object ایجاد نشده است. برای rollback، ابتدا Worker اصلی و Static Assets را به بستهٔ کامل 19.11.23 بازگردان. سپس اگر Worker Sandbox نسخهٔ 19.11.24 منتشر شده، کد موجود `sayrox-code-sandbox-preview` را نیز به نسخهٔ 19.11.23 برگردان تا قرارداد payload دوباره code-only شود. Service Binding و Secretهای قبلی را حذف نکن؛ هیچ D1 یا دادهٔ پایدار تازه‌ای نیازمند حذف نیست. اگر Rollout کامل نشده، فقط سرویس‌هایی را برگردان که واقعاً به 19.11.24 ارتقا یافته‌اند. Production با ساخت بسته محلی تغییر نکرده است.

# بازگشت نسخه — 19.11.23

## بازگشت از 19.11.23

این نسخه Tool Loop و `worker/providers/chat.js` موجود را برای Checkpoint/Resume تقویت می‌کند و `usage-worker` موجود را با جدول افزایشی `agent_run_checkpoints` در SQLite داخلی `UsageAccountObject` به‌روزرسانی می‌کند. این **Cloudflare D1 نیست**. هیچ Binding، Worker مستقل، Namespace، Durable Object class یا migration کلاس DO جدیدی اضافه نشده است.

### ترتیب استقرار

1. ابتدا `usage-worker` نسخهٔ 19.11.23 را منتشر کن تا متدهای checkpoint در همان `UsageAccountObject` موجود در دسترس باشند. جدول با `CREATE TABLE IF NOT EXISTS` در storage داخلی همان DO ساخته می‌شود.
2. سپس Worker اصلی SAYROX و Static Assets نسخهٔ 19.11.23 را منتشر کن. GitHub Kit هر پنج Worker موجود را به ترتیب فعلی بررسی/منتشر می‌کند؛ Worker یا Binding تازه‌ای اضافه نشده است.
3. پیش از انتشار، `AUTH_SESSION_SECRET` فعلی باید در usage/main Worker یکسان و پایدار باقی بماند. کلید رمز checkpoint از همین Secret مشتق می‌شود؛ Secret را در میانهٔ rollout عوض نکن.
4. پس از انتشار، در Preview یک اجرای متنی غیرموقت را با خطای کنترل‌شده Provider آزمایش کن؛ دکمهٔ Resume باید فقط پس از ثبت checkpoint امن ظاهر شود. حین آزمون از ابزار دارای اثر جانبی استفاده نکن.

### بازگشت

- برای Rollback رابط/Worker اصلی، ZIP کامل `SAYROX-19.11.22-WORKER.zip` را بازگردان و پوشهٔ `site/` تولیدشدهٔ همان نسخه را منتشر کن. نسخهٔ قبلی endpoint Resume را فراخوانی نمی‌کند؛ بنابراین checkpointها بلااستفاده می‌مانند و پس از ۳۰ دقیقه منقضی می‌شوند.
- `usage-worker` نسخهٔ 19.11.23 را می‌توان نگه داشت؛ جدول افزایشی با نسخهٔ قبلی سازگار است و مسیرهای سهمیه/تاریخچهٔ قبلی را تغییر نمی‌دهد. برای Rollback لازم نیست جدول یا SQLite Durable Object را حذف کنی. حذف جدول یا namespace ممنوع است.
- برای بازگشت کامل کد backend، `usage-worker` را به نسخهٔ 19.11.22 برگردان؛ جدول باقی می‌ماند ولی متدهای checkpoint دیگر در دسترس نیستند. checkpointها را دستی حذف یا تبدیل نکن.
- Deployment واقعی این ZIP در زمان ساخت بسته انجام نشده است. هیچ Production، Secret، Binding یا Namespace در این محیط تغییر نکرده است.

---

# بازگشت نسخه — 19.11.22

## بازگشت از 19.11.22

این نسخه منطق API و TaskAccountObject موجود را برای مدیریت وظایف گسترش می‌دهد: متد `updateTask`، guard اجرای هم‌زمان، و آداپتورهای Agent/Approval. هیچ جدول، ستون، migration، Binding، Namespace، Durable Object class یا Worker ذخیره‌سازی جدیدی اضافه نشده است؛ تغییر در SQLite همان DO موجود schema change ندارد. برای rollback کد Worker اصلی و `tasks-worker` را هر دو به بستهٔ 19.11.21 برگردان و تمام فایل‌های `site/` همان نسخه، شامل `_worker.js` و `sw.js` را با هم منتشر کن. داده‌ها و DOهای موجود را حذف یا reset نکن. API جدید update پس از rollback دیگر در دسترس نیست، اما رکوردهای قبلی دست‌نخورده می‌مانند. استقرار واقعی با این بسته انجام نشده است.

# بازگشت نسخه — 19.11.21

## بازگشت از 19.11.21

این به‌روزرسانی فقط Tool Registry موجود را برای اعتبارسنجی/immutable کردن Provider Schema و تفسیر صحیح شکست Handler تقویت می‌کند؛ موتور Agent، Tool Loop، API، Binding، Secret، Durable Object class، schema ذخیره‌سازی و زمان‌بندی تغییر نکرده‌اند. Migration یا اقدام داده‌ای لازم نیست. برای بازگشت، ZIP کامل 19.11.20 را بازیابی و Worker bundle یعنی `site/_worker.js` را از همان نسخه منتشر کن؛ برای بازگشت دقیق رابط نیز فایل‌های `site/` را به‌صورت یک مجموعه از همان نسخه برگردان تا cache نسخه‌دار Service Worker دوباره ساخته شود. هیچ Durable Object، SQLite داخلی یا دادهٔ حساب را حذف نکن. هیچ Deploy واقعی از این محیط انجام نشده است.

# بازگشت نسخه — 19.11.20

## بازگشت از 19.11.20

این نسخه موتور مرورگر Agent را به سورس Worker، کارت تأیید فعلی و رابط چت اضافه می‌کند و Binding محلی `BROWSER` را در `wrangler.jsonc` اعلام می‌کند. در این به‌روزرسانی هیچ تنظیم حساب Cloudflare، Binding زنده، Secret، Namespace، Durable Object یا Deploy تغییر نکرده است؛ نشست مرورگر نیز ذخیرهٔ پایدار یا migration ندارد. برای بازگشت، ZIP کامل نسخهٔ 19.11.19 را جایگزین کن و خروجی‌های `site/` همان نسخه را با هم بازگردان؛ cache Service Worker نسخهٔ قبلی پس از فعال‌سازی دوباره ساخته می‌شود. هیچ Durable Object یا دادهٔ حساب را حذف نکن. اگر نسخهٔ 19.11.20 در آینده مستقر شد، برای استفاده از آن باید Browser Run و Binding `BROWSER` را جداگانه در Cloudflare فعال کنی؛ rollback کد به 19.11.19 دیگر به این Binding نیاز ندارد.

# بازگشت نسخه — 19.11.19

## بازگشت از 19.11.19

این نسخه فقط رابط مرورگر، ماژول‌های تنظیمات سمت کاربر، فایل‌های تست و فرادادهٔ انتشار را تغییر می‌دهد. منطق Worker سمت سرور، تنظیمات Wrangler، Bindingها، Secretها و Durable Objectها تغییر نکرده‌اند و migration لازم نیست. برای بازگشت رابط، ZIP کامل نسخهٔ قبلی را بازیابی و فایل‌های `site/` همان نسخه را منتشر کن؛ داده‌های IndexedDB و Local Storage را صرفاً برای rollback حذف نکن. Service Worker پس از فعال‌شدن نسخهٔ قبلی cache رابط را دوباره می‌سازد.

# بازگشت نسخه — 19.11.18

برای بازگشت Worker اصلی `sayrox`، آخرین نسخه سالم Worker را از بخش Deployments در Cloudflare انتخاب و Rollback کن. تنظیمات Worker و Secretها را مستقل از کد نگه دار؛ هیچ Worker قدیمی یا Namespace Durable Object را صرفاً برای Rollback حذف نکن. اگر Worker Tasks جدید مستقر شده باشد، تا وقتی درخواست فعالی ندارد می‌توان آن را جداگانه غیرفعال/حذف کرد؛ داده‌های آن مستقل از D1 است. Worker Sandbox را فقط بعد از حذف Service Binding و Secret مشترک جداگانه خاموش کن.

## بازگشت از 19.11.11

این نسخه Worker اصلی Pages، Tool Registry/Policy، ماژول کارت تأیید، رابط نمایش خروجی، و Worker مستقل `sandbox-worker/` را اضافه می‌کند. Container Sandbox از طریق Service Binding `CODE_SANDBOX` و Secretهای مشترک فعال می‌شود؛ اگر نیاز به بازگشت داری ابتدا در Pages Service Binding را حذف/غیرفعال کن و Secret `CODE_SANDBOX_INTERNAL_SECRET` را از Pages بردار، سپس ZIP 19.11.10 را بازگردان و فقط `site/` همان نسخه را منتشر کن. Worker مستقل Sandbox پس از قطع Binding دیگر از Pages قابل‌دسترسی نیست؛ برای حذف کامل آن می‌توانی Worker `sayrox-code-sandbox-preview` را پس از توقف درخواست‌ها جداگانه حذف کنی. DO SQLite داخلی Sandbox، D1 نیست و schema/دادهٔ برنامهٔ قبلی را تغییر نمی‌دهد. هیچ Production در این مرحله تغییر نکرده است.

## بازگشت از 19.11.10

این نسخه مسیر کارت تأیید را در Pages Worker/UI اضافه می‌کند و متد اتمیک مصرف Ticket و جدول افزایشی `agent_approval_tickets` را در همان SQLite داخلی Durable Object کلاس فعلی `UsageAccountObject` از `usage-worker` اضافه می‌کند. این **D1 نیست** و Binding، Namespace یا Durable Object class جدیدی ندارد. ترتیب انتشار در rollout: ابتدا `usage-worker` فعلی، سپس Pages Worker/UI. اگر Pages به نسخهٔ 19.11.9 بازگردد، نسخهٔ قبلی دیگر endpoint تأیید را فراخوانی نمی‌کند؛ جدول Ticket و رکوردهای قبلی می‌توانند بدون اثر بر سهمیه باقی بمانند. `usage-worker` را فقط برای rollback لازم نیست به نسخهٔ قبلی برگردانی؛ اگر برگرداندی، جدول ایجادشده در SQLite باقی می‌ماند اما متد `consumeAgentApproval` دیگر در دسترس نیست و کارت‌های تأیید نسخهٔ 19.11.10 کار نمی‌کنند. برای بازگشت کامل Pages، ZIP کامل 19.11.9 را بازگردان و فقط `site/` همان نسخه را منتشر کن. هیچ Production در این مرحله تغییر نکرده است.

## بازگشت از 19.11.9

این نسخه فقط Worker اصلی Pages، Tool Loop/Tool Registry، رابط نمایش وضعیت و فایل‌های مستندات/تست را تغییر می‌دهد. هیچ migration، schema داده، Binding، Secret، Durable Object یا D1 اضافه/تغییر نکرده است. برای بازگشت در Preview، ZIP کامل 19.11.8 را جایگزین و پوشهٔ `site/` همان نسخه (شامل `_worker.js`، `src/app.js` و `sw.js`) را منتشر کن. cache مرورگر نسخهٔ جدید با شناسهٔ `xynora-next-shell-v19.11.9` در فعال‌سازی Service Worker نسخهٔ بعدی پاک خواهد شد. هیچ دادهٔ پایدار تازه‌ای برای مهاجرت وجود ندارد و Production با این بسته تغییر نکرده است.

## بازگشت از 19.11.8

این نسخه مسیر Worker اصلی چت و UI مرورگر را برای ابزارهای Agent گسترش می‌دهد. برای بازگشت در Preview، ZIP کامل 19.11.7 را جایگزین کن و پوشهٔ `site/` همان نسخه (شامل `_worker.js` و `sw.js`) را منتشر کن. این تغییر به `usage-worker`، `billing-worker` و `tasks-worker` کد جدیدی تحمیل نمی‌کند؛ از سرویس‌ها و Bindingهای موجود استفاده می‌کند. هیچ D1، migration، جدول یا Binding جدیدی اضافه نشده است. حافظه فقط خوانده می‌شود؛ artifactهای فایل در مرورگر ساخته می‌شوند و سرور ذخیره نمی‌شوند؛ تولید تصویر همان سهمیهٔ موجود را مصرف می‌کند. کارهای زمان‌بندی‌شده‌ای که کاربر در نسخهٔ جدید ساخته، در Durable Object موجود Tasks باقی می‌مانند و از رابط Tasks نسخهٔ قبلی قابل مدیریت‌اند؛ قبل از بازگشت یا حذف/خاموش‌کردن هیچ Durable Object، کارهای فعال را بررسی کن. Production با این ZIP منتشر نشده و هیچ تنظیم Cloudflare تغییر نکرده است.

## بازگشت از 19.11.7

این نسخه فقط کد Worker (`worker/agent/utility-tools.js`، `tool-loop.js`، `chat.js`) و یک برچسب‌گذاری در صفحهٔ تاریخچه را تغییر می‌دهد؛ هیچ داده، schema، Binding، Secret، Durable Object یا D1 دست نخورده است و `usage-worker` نیازی به استقرار مجدد ندارد. برای بازگشت در Preview، ZIP کامل `SAYROX-19_11_6-AGENT-RUN-HISTORY.zip` را بازگردان و فقط پوشهٔ `site/` همان نسخه را (پس از `npm test` و `npm run build`) منتشر کن. رکوردهای تاریخچهٔ ساخته‌شده با ابزارهای جدید در 19.11.6 هم بدون مشکل نمایش داده می‌شوند (نام ابزار خام نشان داده می‌شود).

## بازگشت از 19.11.6

این نسخه فقط یک جدول افزایشی `agent_run_history` را در SQLite داخلی `UsageAccountObject` موجود ایجاد می‌کند و متدهای تاریخچه را به همان Worker اضافه می‌کند؛ این جدول D1 نیست و Binding یا کلاس Durable Object جدیدی اضافه نمی‌شود. برای بازگشت Pages، ZIP کامل 19.11.5 را نگه دار و فقط پوشهٔ `site/` همان نسخه را در Preview جایگزین کن. نسخهٔ Pages 19.11.5 اصلاً API تاریخچه را فراخوانی نمی‌کند؛ بنابراین چت و سهمیه ادامه می‌یابند. اگر `usage-worker` نسخهٔ 19.11.6 را نگه داری، جدول و رکوردهای تاریخچه باقی می‌مانند و برای سهمیه مشکلی ایجاد نمی‌کنند. اگر خود `usage-worker` را هم به نسخهٔ قبلی برگردانی، جدول همچنان در SQLite می‌ماند اما قابلیت تاریخچه تا استقرار دوبارهٔ Worker جدید در دسترس نیست. Durable Object یا داده‌های سهمیه را حذف نکن. Production را تغییر نده.

## بازگشت از 19.11.5

این نسخه مسیر نمایش پاسخ در مرورگر و راهنمای نگارش مشترک در System Context مربوط به Worker اصلی Pages را تغییر می‌دهد؛ خروجی `_worker.js` نیز باید همراه رابط نسخهٔ جدید منتشر شود. هیچ دادهٔ ذخیره‌شده، schema، API بیرونی، Binding، Secret، سرویس ذخیره‌سازی یا D1 تغییر نکرده است. برای بازگشت در Preview، ZIP کامل `SAYROX-19.11.4-AGENT-FUNCTION-CALLING.zip` را بازگردان و پوشهٔ `site/` همان نسخه (شامل `_worker.js` و `sw.js`) را فقط پس از اجرای تست و build خودش منتشر کن. نسخهٔ قبلی Service Worker نیز cache نسخهٔ جدید را در فعال‌سازی بعدی پاک می‌کند. Production را بدون تأیید جداگانه تغییر نده.

## بازگشت از 19.11.4

برای بازگشت از Function Calling و تحقیق عمیق‌تر به نسخهٔ 19.11.3، ZIP کامل `SAYROX-19.11.3-AGENT-WEB-RESEARCH.zip` را جایگزین کن و فقط پوشهٔ `site/` را پس از اجرای تست و build همان نسخه منتشر کن. این بسته به Secret، Binding، D1 یا Cloudflare Production دست نزده است.

# بازگشت به نسخهٔ قبلی


## بازگشت از 19.11.3

برای بازگشت از تحقیق وب Agent به نسخهٔ 19.11.2، ZIP کامل قبلی را جایگزین کن و فقط پوشهٔ `site/` را پس از اجرای تست و build همان نسخه منتشر کن. انتشار یا تغییر Cloudflare با این بسته انجام نشده است.

## بازگشت از 19.11.2

این نسخه هستهٔ Agent و System Context چت را در Worker اصلی تغییر می‌دهد و فایل‌های Worker ساخته‌شده را به‌روز می‌کند؛ هیچ schema، migration، حافظهٔ جدید، Binding، Secret، Durable Object، D1 یا Worker ذخیره‌سازی تغییر نکرده است. برای بازگشت در Preview، ZIP کامل 19.11.1 را نگه دار و پوشهٔ `site/` همان نسخه (شامل `_worker.js` و `sw.js`) را بازگردان. هیچ دادهٔ پایدار Agent برای مهاجرت یا حذف وجود ندارد. Production را تغییر نده.

## بازگشت از 19.11.1

این نسخه فقط پردازش محلی سند/Markdown در رابط را تغییر می‌دهد و کتابخانهٔ IndexedDB نسخهٔ 19.11.0 را حفظ می‌کند؛ schema ذخیره‌سازی، فایل‌های موجود، Worker، API، Binding، Secret، D1، مهاجرت داده و Production تغییر نکرده‌اند. برای بازگشت رابط در Preview، ZIP کامل 19.11.0 را نگه دار و پوشهٔ `site/` همان نسخه را بازگردان. فایل‌های ذخیره‌شده در IndexedDB حذف نمی‌شوند و در نسخهٔ قبلی کتابخانه همچنان قابل مشاهده‌اند. Production را تغییر نده.

## بازگشت از 19.11.0

این نسخه کتابخانهٔ فایل را از فهرست نام‌های سبک به مخزن محلی IndexedDB (`sayrox-file-library`) ارتقا می‌دهد؛ هیچ API، Worker، Binding، Durable Object، D1 یا فضای ذخیره‌سازی سرور تغییر نکرده است. برای بازگشت رابط به 19.10.9، پوشهٔ `site/` نسخهٔ قبلی را در Preview جایگزین کن. **داده‌های IndexedDB این نسخه را حذف نکن**: نسخهٔ 19.10.9 آن‌ها را نمایش نمی‌دهد، اما خود داده‌ها روی همان Origin باقی می‌مانند و با نصب دوبارهٔ 19.11.0 قابل خواندن خواهند بود. برای دسترسی به فایل‌ها، ZIP کامل 19.11.0 را نگه دار. Production را تغییر نده.

## بازگشت از 19.10.9

این نسخه parser ZIP موجود را سخت‌سازی می‌کند، استخراج انتخابی و لینک محلی Blob را به استودیو فایل اضافه می‌کند و ورودی ZIP چت را از مسیر محلی به Worker وصل می‌کند. هیچ schema، migration، Secret، Binding، Durable Object، D1، فضای ذخیره‌سازی سرور یا تنظیم Production تغییر نکرده است. برای بازگشت در Preview، ZIP کامل 19.10.8 را نگه دار و پوشهٔ `site/` و Worker تولیدشدهٔ همان نسخه را بازگردان. دادهٔ استخراج‌شده فقط در حافظهٔ نشست بوده و migration لازم نیست. لینک‌های Blob نسخهٔ قبلی/جدید با خروج از صفحه از بین می‌روند. Production را تغییر نده.


## بازگشت از 19.10.8

این نسخه پیوست و تحلیل XLSX، XLSM و CSV را به مسیر چت اضافه می‌کند و ورودی اسناد را با PDF یکپارچه می‌کند. parser صفحه‌گستردهٔ موجود بازاستفاده شده و هیچ schema، migration، Durable Object، Binding، Secret، دامنه، منبع ذخیره‌سازی، D1 یا تنظیم Production تغییر نکرده است. برای بازگشت در Preview، پوشهٔ `site/` و Worker داخل آن را از ZIP کامل نسخهٔ 19.10.7 جایگزین کن. دادهٔ ذخیره‌شدهٔ گفتگو فقط فرادادهٔ سند را دارد؛ متن استخراج‌شده در حافظهٔ نشست است و مهاجرت داده لازم نیست. Production را تغییر نده.

## بازگشت از 19.10.7

این نسخه پیوست PDF در گفتگوی اصلی را اضافه می‌کند و به همین دلیل هم کد رابط و هم Worker اصلی Pages را تغییر می‌دهد؛ موتور موجود PDF بازاستفاده شده و هیچ Secret، API جدید، Binding، Durable Object، schema، migration، D1 یا منبع ذخیره‌سازی Cloudflare تغییر نکرده است. برای بازگشت، ZIP کامل 19.10.6 را نگه دار و پوشهٔ `site/` همان نسخه (شامل `_worker.js`) را در Preview منتشر کن. تاریخچهٔ چت فقط فرادادهٔ سند را نگه می‌دارد و متن استخراج‌شده در حافظهٔ نشست است؛ بازگشت نیازی به مهاجرت یا پاک‌کردن داده ندارد. Production را تغییر نده.

## بازگشت از 19.10.6

این نسخه فقط رابط بلوک‌های کد گفتگو، ویرایش محلی پیام و پیش‌نمایش HTML ایزوله را تغییر می‌دهد. Worker، API، Secret، Binding، Durable Object، schema، مهاجرت داده، دامنه و Production تغییر نکرده‌اند. برای بازگشت، ZIP کامل نسخهٔ 19.10.5 را نگه دار و فقط پوشهٔ `site/` همان نسخه را در Preview جایگزین کن؛ نیازی به بازگرداندن داده یا تغییر Binding نیست.

1. انتشار Preview جدید را متوقف کن؛ Production با این بسته منتشر نمی‌شود.
2. نسخهٔ قبلیِ **ZIP کامل** را نگه دار و پوشهٔ `site/` همان نسخه را دوباره روی `xynora-next-preview` منتشر کن. `_worker.js` داخل `site/` است، پس Worker هم همراه آن برمی‌گردد.
3. در بازگشت، `site/vendor/` نیز با پوشهٔ قبلی جایگزین می‌شود؛ پس از بازگشت به نسخه‌ای که SDK محلی ندارد، Live Voice به‌طور عمدی غیرفعال می‌ماند.
4. Service Worker فقط cacheهای با پیشوند `xynora-next-shell-` را پاک می‌کند و به cacheهای دیگر دامنه دست نمی‌زند.
5. از 19.9.8 تا 19.9.10 هیچ schema، Binding یا سیاست سهمیه‌ای عوض نشده بود. در 19.9.11 فقط افزوده‌ها آمدند: سهمیهٔ `image_generation` در usage-worker، Worker جدید `tasks-worker` و Binding `TASKS_ACCOUNT`. بازگشت امن است: Binding یا Worker زمان‌بندی را می‌توانی باقی بگذاری یا حذف کنی؛ با نبود `TASKS_ACCOUNT` بخش کارها خودکار «پیکربندی‌نشده» می‌شود و چیز دیگری نمی‌شکند. داده‌ی Durable Objectها با بازگشت پاک نمی‌شود.
6. پس از بازگشت در Preview دیکته، TTS و مکالمهٔ زنده را جداگانه بررسی کن. Production را تغییر نده.


## بازگشت از 19.10.0

در این نسخه schema و lifecycle هیچ Durable Object تغییر نکرده و هیچ Worker یا Binding مستقر نشده است. برای بازگشت، نسخهٔ ZIP قبلی را نگه دار و فقط پوشهٔ `site/` همان نسخه را به Preview برگردان. `.gitignore`، اسکریپت‌های بررسی و مستندات روی دادهٔ زنده اثری ندارند. برای Tasks، guard پیش از Deploy صرفاً از انتشار با `APP_ORIGIN` نمونه جلوگیری می‌کند.


## بازگشت از 19.10.1

این نسخه فقط اصلاح پردازش استریم صوت و رویدادهای رابط را دارد؛ هیچ schema، migration، Binding یا Worker ذخیره‌سازی تغییر نکرده است. برای بازگشت، نسخهٔ ZIP قبلی را نگه دار و فقط پوشهٔ `site/` همان نسخه را به Preview برگردان.


## بازگشت از 19.10.2

این نسخه callbackهای SDK و تنظیمات مستند مدل گفتار فارسی را اصلاح می‌کند؛ هیچ schema، migration، Binding، Secret، دامنه یا منبع ذخیره‌سازی Cloudflare تغییر نکرده است. برای بازگشت، نسخهٔ ZIP قبلی را نگه دار و فقط پوشهٔ `site/` همان نسخه را در Preview منتشر کن.


## بازگشت از 19.10.3

این نسخه فقط رابط کادر نوشتار، رفتار کلید Enter و دسترس‌پذیری منوی ابزارها را تغییر می‌دهد؛ هیچ API، Worker، schema، migration، Binding، Secret، دامنه یا منبع ذخیره‌سازی Cloudflare تغییر نکرده است. برای بازگشت، ZIP کامل نسخهٔ قبلی را نگه دار و پوشهٔ `site/` همان نسخه را در Preview جایگزین کن.
