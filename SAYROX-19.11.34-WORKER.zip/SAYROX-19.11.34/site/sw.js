const CACHE = 'sayrox-shell-v19.11.34';
const SHELL = ['/', '/manifest.json', '/icon.svg',
  '/src/app.js', '/src/core/response-renderer.js', '/src/core/code-workspace.js', '/src/core/secure-html-preview.js', '/src/core/icons.js', '/src/core/orb.js', '/src/core/voice-lifecycle.js', '/src/core/speech-input.js', '/src/core/speech-pcm-worklet.js', '/src/core/stream.js', '/src/core/search-intent.js', '/src/styles/tokens.css', '/src/styles/content.css', '/src/styles/response-rendering.css', '/src/styles/code-workspace.css', '/src/styles/shell.css', '/src/styles/settings.css', '/src/styles/voice.css',
  '/src/core/settings-store.js', '/src/core/navigation-stack.js', '/src/core/chat-actions.js',
  '/src/features/settings/pages/shared.js', '/src/features/settings/pages/account.js',
  '/src/features/settings/pages/subscription.js', '/src/features/settings/pages/personalization.js',
  '/src/features/settings/pages/general.js', '/src/features/settings/pages/integrations.js',
  '/src/features/settings/pages/voice-studio.js', '/src/features/settings/pages/safety-security.js',
  '/src/features/settings/pages/storage-privacy.js', '/src/features/settings/pages/other.js',
  '/src/features/settings/registry.js', '/src/features/settings/voice-personas.js',
  '/src/features/settings/controller.js',
  '/src/features/files/policy.js','/src/features/files/library-store.js','/src/features/files/library.js','/src/features/files/zip.js','/src/features/files/spreadsheet.js','/src/features/files/pdf.js','/src/features/files/pdf-text.js','/src/features/files/ocr.js','/src/features/files/markdown.js','/src/features/files/documents.js','/src/features/files/studio.js','/src/styles/file-studio.css', '/src/styles/branding.css', '/src/styles/chat-image-input.css', '/src/styles/studio.css',
  '/src/features/chat/image-input.js', '/src/features/chat/pdf-input.js', '/src/features/chat/spreadsheet-input.js', '/src/features/chat/zip-input.js', '/src/features/chat/office-input.js', '/src/features/chat/message-payload.js'];
self.addEventListener('install', event => {
  const freshShell = SHELL.map(path => new Request(path, { cache: 'reload' }));
  event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(freshShell).then(() => cache.add(new Request('/vendor/elevenlabs-client.mjs', { cache: 'reload' })).catch(() => undefined))).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => (key.startsWith('sayrox-shell-') || key.startsWith('xynora-next-shell-')) && key !== CACHE).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin || url.pathname.startsWith('/api/')) return;
  if (request.mode === 'navigate') {
    // Only replace the offline app shell with a successful HTML document.
    // A 404/500 page (or a non-HTML navigation response) must never poison the
    // last known-good shell. Keep cache I/O inside the event lifetime as well.
    const navigation = fetch(request).then(async response => {
      const contentType = response.headers.get('content-type') || '';
      if (response.status === 200 && /^text\/html(?:\s*;|$)/i.test(contentType)) {
        try {
          const cache = await caches.open(CACHE);
          await cache.put('/', response.clone());
        } catch {
          // Caching is best-effort; the live navigation should still succeed.
        }
      }
      return response;
    });
    event.waitUntil(navigation.then(() => undefined, () => undefined));
    event.respondWith(navigation.catch(() => caches.match('/')));
    return;
  }
  event.respondWith(caches.match(request).then(cached => cached || fetch(request)));
});
