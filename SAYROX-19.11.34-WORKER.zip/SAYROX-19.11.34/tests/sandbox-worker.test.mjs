import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { webcrypto } from 'node:crypto';
import {
  MAX_CODE_CHARS, MAX_OUTPUT_BYTES, MAX_REQUEST_BYTES, MAX_DOCUMENTS, MAX_DOCUMENT_CHARS,
  readBoundedText, verifyInternalSignature, validateExecutionPayload,
  readProcessStreamLimited
} from '../sandbox-worker/src/security.mjs';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');
const secret = 'sayrox-sandbox-internal-secret-test-value-0123456789';
const b64url = bytes => Buffer.from(bytes).toString('base64url');

async function sign(timestamp, body) {
  const key = await webcrypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  return b64url(await webcrypto.subtle.sign('HMAC', key, new TextEncoder().encode(`${timestamp}.${body}`)));
}

test('sandbox worker verifies exact HMAC body, bounded timestamp and rejects replay-shaped alterations', async () => {
  const timestamp = String(Date.now());
  const body = JSON.stringify({ version: 1, jobId: 'a'.repeat(64), language: 'python', code: 'print(2 + 2)' });
  const signature = await sign(timestamp, body);
  assert.equal(await verifyInternalSignature(secret, timestamp, body, signature), true);
  assert.equal(await verifyInternalSignature(secret, timestamp, `${body} `, signature), false);
  assert.equal(await verifyInternalSignature(secret, String(Date.now() - 120_000), body, signature), false);
  assert.equal(await verifyInternalSignature('too-short', timestamp, body, signature), false);
  assert.equal(await verifyInternalSignature(secret, timestamp, body, 'not-a-signature'), false);
});

test('sandbox request parser bounds bytes and accepts only the Python schema', async () => {
  const request = new Request('https://sandbox.internal/internal/execute', { method: 'POST', body: 'small body' });
  assert.equal(await readBoundedText(request), 'small body');
  const tooLarge = new Request('https://sandbox.internal/internal/execute', { method: 'POST', body: 'x'.repeat(MAX_REQUEST_BYTES + 1) });
  await assert.rejects(() => readBoundedText(tooLarge), /REQUEST_TOO_LARGE/);
  assert.equal(validateExecutionPayload({ version: 1, jobId: 'a'.repeat(64), language: 'python', code: 'print(1)' }).ok, true);
  assert.equal(validateExecutionPayload({ version: 1, jobId: 'a'.repeat(64), language: 'javascript', code: '1+1' }).code, 'UNSUPPORTED_RUNTIME');
  assert.equal(validateExecutionPayload({ version: 1, jobId: 'bad', language: 'python', code: 'print(1)' }).code, 'INVALID_JOB_ID');
  assert.equal(validateExecutionPayload({ version: 1, jobId: 'a'.repeat(64), language: 'python', code: 'x'.repeat(MAX_CODE_CHARS + 1) }).code, 'INVALID_CODE');
  assert.equal(validateExecutionPayload({ version: 1, jobId: 'a'.repeat(64), language: 'python', code: 'print(1)', extra: true }).code, 'INVALID_PAYLOAD');
  const withFiles = validateExecutionPayload({ version: 1, jobId: 'a'.repeat(64), language: 'python', code: 'print(1)', files: [{ name: 'report.txt', text: 'safe text' }] });
  assert.equal(withFiles.ok, true);
  assert.deepEqual(withFiles.payload.files, [{ name: 'report.txt', text: 'safe text' }]);
  assert.equal(validateExecutionPayload({ version: 1, jobId: 'a'.repeat(64), language: 'python', code: 'print(1)', files: [{ name: '../report.txt', text: 'x' }] }).code, 'INVALID_FILES');
  assert.equal(validateExecutionPayload({ version: 1, jobId: 'a'.repeat(64), language: 'python', code: 'print(1)', files: Array.from({ length: MAX_DOCUMENTS + 1 }, (_, index) => ({ name: `file-${index}.txt`, text: 'x' })) }).code, 'INVALID_FILES');
  assert.equal(validateExecutionPayload({ version: 1, jobId: 'a'.repeat(64), language: 'python', code: 'print(1)', files: [{ name: 'big.txt', text: 'x'.repeat(MAX_DOCUMENT_CHARS + 1) }] }).code, 'INVALID_FILES');
});

test('sandbox output reader caps combined stdout/stderr and kills noisy processes', async () => {
  const state = { total: 0, truncated: false };
  let killed = 0;
  const stream = new ReadableStream({ start(controller) { controller.enqueue(new Uint8Array(MAX_OUTPUT_BYTES + 100)); controller.close(); } });
  const output = await readProcessStreamLimited(stream, state, () => { killed++; });
  assert.equal(new TextEncoder().encode(output).byteLength, MAX_OUTPUT_BYTES);
  assert.equal(state.total, MAX_OUTPUT_BYTES);
  assert.equal(state.truncated, true);
  assert.equal(killed, 1);
});

test('Cloudflare Container worker is private, per-job, no-network and time/output bounded without D1', async () => {
  const [source, configText, docker, dockerIgnore] = await Promise.all([
    read('sandbox-worker/src/index.js'), read('sandbox-worker/wrangler.jsonc'), read('sandbox-worker/Dockerfile'), read('sandbox-worker/.dockerignore')
  ]);
  const config = JSON.parse(configText);
  assert.equal(config.workers_dev, false);
  assert.equal(config.containers[0].class_name, 'CodeSandbox');
  assert.equal(config.containers[0].scheduling_policy, 'durable_object');
  assert.equal(config.containers[0].max_instances, 10);
  assert.equal(config.containers[0].images.python.build_context, '.');
  assert.equal(config.durable_objects.bindings[0].name, 'CODE_SANDBOX');
  assert.equal(config.exports.CodeSandbox.storage, 'sqlite');
  assert.equal(config.d1_databases, undefined);
  assert.match(source, /enableInternet:\s*false/);
  assert.match(source, /instance:\s*"lite"/);
  assert.match(source, /timeout.*--kill-after=2.*String\(PYTHON_TIMEOUT_SECONDS\)/s);
  assert.match(source, /python3.*-I.*-B.*-c.*PYTHON_RUNNER/s);
  assert.match(source, /RLIMIT_CPU/);
  assert.match(source, /RLIMIT_AS/);
  assert.match(source, /RLIMIT_FSIZE/);
  assert.match(source, /RLIMIT_NPROC/);
  assert.match(source, /container\.images\.python/);
  assert.match(source, /storage\.transaction/);
  assert.match(source, /setAlarm/);
  assert.match(source, /readProcessStreamLimited/);
  assert.doesNotMatch(source, /env\.(?:AUTH_SESSION_SECRET|GAPGPT_API_KEY|OPENROUTER_API_KEY)/);
  assert.doesNotMatch(source, /D1Database|d1_databases|env\.DB\b/i);
  assert.match(docker, /FROM python:3\.13-slim/);
  assert.match(docker, /WORKDIR \/workspace/);
  assert.match(docker, /USER sayrox/);
  assert.match(docker, /useradd.*--uid 10001/);
  assert.match(docker, /sleep.*infinity/);
  assert.doesNotMatch(docker, /pip install|npm install|curl .*secret/i);
  assert.match(dockerIgnore, /\*\*/);
  assert.match(dockerIgnore, /!Dockerfile/);
});

test('Sandbox Worker authenticates the private route, executes once per invocation and rejects replay', async () => {
  const vm = await import('node:vm');
  const source = await read('sandbox-worker/src/index.js');
  const executable = source
    .replace(/^import \{ DurableObject \} from "cloudflare:workers";\s*/m, '')
    .replace(/^import \{[\s\S]*?\} from "\.\/security\.mjs";\s*/m, '')
    .replace('export class CodeSandbox', 'class CodeSandbox')
    .replace('export default {', 'const defaultWorker = {')
    + '\nglobalThis.__sandboxModule = { CodeSandbox, defaultWorker };';

  class DurableObjectStub { constructor(ctx, env) { this.ctx = ctx; this.env = env; } }
  const context = vm.createContext({
    DurableObject: DurableObjectStub,
    readBoundedText, verifyInternalSignature, validateExecutionPayload, readProcessStreamLimited,
    Request, Response, Headers, URL, URLSearchParams, TextEncoder, TextDecoder, Uint8Array,
    ArrayBuffer, Date, JSON, Math, Number, String, Boolean, Object, Array, Map, Set, RegExp,
    Error, Promise, atob, btoa, crypto: webcrypto, ReadableStream
  });
  vm.runInContext(executable, context, { filename: 'sandbox-worker/src/index.js' });
  const { CodeSandbox, defaultWorker } = context.__sandboxModule;
  const records = new Map();
  let containerRuns = 0;
  let containerInput = null;
  const makeSandbox = () => {
    const values = new Map();
    const storage = {
      async transaction(callback) {
        const tx = {
          get: async key => values.get(key),
          put: async (key, value) => values.set(key, value)
        };
        return callback(tx);
      },
      async setAlarm(value) { this.alarmAt = value; },
      async delete(key) { values.delete(key); }
    };
    const outputStream = value => new ReadableStream({ start(controller) { if (value) controller.enqueue(new TextEncoder().encode(value)); controller.close(); } });
    const ctx = {
      storage,
      container: {
        running: true,
        images: { python: { name: 'python' } },
        async exec(command, options) {
          containerRuns++;
          assert.equal(command[0], 'timeout');
          assert.ok(command.includes('python3'));
          assert.ok(command.includes('-c'));
          assert.match(command.at(-1), /RLIMIT_CPU/);
          assert.match(command.at(-1), /RLIMIT_AS/);
          containerInput = JSON.parse(await new Response(options.stdin).text());
          assert.equal(containerInput.code, 'print(6 * 7)');
          assert.deepEqual(containerInput.files, [{ name: 'report.txt', text: 'hello from document' }]);
          return { stdout: outputStream('42\\n'), stderr: outputStream(''), exitCode: Promise.resolve(0), kill() {} };
        }
      }
    };
    return new CodeSandbox(ctx, {});
  };
  const namespace = {
    getByName(id) {
      if (!records.has(id)) records.set(id, makeSandbox());
      return records.get(id);
    }
  };
  const payload = { version: 1, jobId: 'b'.repeat(64), language: 'python', code: 'print(6 * 7)', files: [{ name: 'report.txt', text: 'hello from document' }] };
  const body = JSON.stringify(payload);
  const timestamp = String(Date.now());
  const signature = await sign(timestamp, body);
  const makeRequest = sig => new Request('https://sandbox.internal/internal/execute', {
    method: 'POST', headers: { 'content-type': 'application/json', 'x-sayrox-timestamp': timestamp, 'x-sayrox-signature': sig }, body
  });
  const env = { SAYROX_INTERNAL_SECRET: secret, CODE_SANDBOX: namespace };

  const unauthorized = await defaultWorker.fetch(makeRequest('A'.repeat(43)), env);
  assert.equal(unauthorized.status, 401);
  assert.equal(containerRuns, 0, 'invalid HMAC must never reach the Container');

  const first = await defaultWorker.fetch(makeRequest(signature), env);
  assert.equal(first.status, 200);
  const firstData = await first.json();
  assert.equal(firstData.ok, true);
  assert.equal(firstData.result.exitCode, 0);
  assert.equal(firstData.result.stdout, '42\\n');
  assert.equal(containerRuns, 1);
  assert.equal(containerInput.files[0].text, 'hello from document');
  assert.match(source, /document_%d\.txt/);
  assert.match(source, /input_dir = '\/workspace\/input'/);

  const replay = await defaultWorker.fetch(makeRequest(signature), env);
  assert.equal(replay.status, 409);
  assert.equal((await replay.json()).code, 'SANDBOX_JOB_REPLAYED');
  assert.equal(containerRuns, 1, 'the same signed job can never start twice');
});
