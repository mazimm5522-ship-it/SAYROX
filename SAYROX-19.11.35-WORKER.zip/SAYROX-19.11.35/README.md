# SAYROX 19.11.35

## Cloudflare Container Deploy Fix — Update 16

این hotfix خطای Deploy گزارش‌شده برای Python Sandbox را برطرف می‌کند. دلیل خطا این بود که `sandbox-worker/wrangler.jsonc` از `scheduling_policy: "durable_object"` استفاده می‌کند، اما هم‌زمان `max_instances` را نیز تنظیم کرده بود؛ Wrangler این فیلد را برای این سیاست رد می‌کند. فیلد ناسازگار حذف شده و سیاست زمان‌بندی، Worker name، کلاس `CodeSandbox`، binding، SQLite، نام image، Dockerfile و build context حفظ شده‌اند.

یک Preflight مستقل به نام `scripts/check-sandbox-deploy.mjs` اضافه شد و هم در `npm run deploy:sandbox` و هم Deploy Kit اجرا می‌شود. این کنترل، schema Container، فیلدهای مجاز، فایل Dockerfile، build context، Binding و export SQLite را قبل از Wrangler بررسی می‌کند. تست رگرسیون نیز ثابت می‌کند افزودن دوبارهٔ `max_instances` پیش از Dry Run متوقف می‌شود.

**نکتهٔ ظرفیت:** `max_instances` برای سیاست `durable_object` در Wrangler پشتیبانی نمی‌شود؛ تعداد instanceها تحت محدودیت‌های حساب Cloudflare است. این hotfix سقف اختصاصی ۱۰ instance را ادعا نمی‌کند. افزودن سقف برنامه‌ای نیازمند طراحی جداگانهٔ کنترل هم‌زمانی است.

جزئیات و محدودیت‌های تأیید: [`docs/RELEASE-19.11.35.md`](docs/RELEASE-19.11.35.md).

## قواعد انتشار

- پیش از هر Deploy، `npm test`، Build، `verify:dev` و `npm run check:sandbox-deploy` باید موفق شوند.
- Deploy Kit هر شش Worker موجود را ابتدا Dry Run می‌کند و فقط پس از موفقیت همهٔ Dry Runها وارد مرحلهٔ انتشار می‌شود.
- `SAYROX_APP_ORIGIN` باید در Workers Builds به Origin واقعی HTTPS Worker اصلی تنظیم شود. هیچ Origin نمونه‌ای را به Production نبرید.
- هیچ Secret، فایل `.env` یا کلید API را در ZIP یا GitHub قرار ندهید.
- برای Rollback، سازگاری Container را حفظ کنید؛ `max_instances` را دوباره به سیاست `durable_object` اضافه نکنید.

## معماری

هیچ Worker، Agent، Provider، API، Tool Loop، Durable Object class، Binding، Namespace، Secret، جدول، migration یا D1 جدیدی ایجاد نشده است.
