// Core helpers, persisted state, theme
// Part of the SAYROX app closure: parts are concatenated in file order by scripts/build-app.mjs.
// Do not edit site/src/app.js directly.
const $=s=>document.querySelector(s);
const svg=(name)=>window.SayroxIcons.svg(name,'row-icon');
function safeGet(key,fallback=''){
  try{
    const value=localStorage.getItem(key);
    return value===null?fallback:value
  }catch{return fallback}
}
function safeRemove(key){try{localStorage.removeItem(key)}catch{}}
function safeArray(key){
  try{
    const value=JSON.parse(safeGet(key,'[]'));
    return Array.isArray(value)?value:[]
  }catch{return []}
}
function safeObject(key){
  try{
    const value=JSON.parse(safeGet(key,'{}'));
    return value&&typeof value==='object'&&!Array.isArray(value)?value:{}
  }catch{return {}}
}
function hydrateIcons(root=document){
  root.querySelectorAll('[data-icon]').forEach(el=>{
    if(el.dataset.iconDone)return;
    el.dataset.iconDone='1';
    el.insertAdjacentHTML('afterbegin',window.SayroxIcons.svg(el.dataset.icon))
  })
}
hydrateIcons();
const settingsStore=new window.SayroxCore.SettingsStore({initial:safeObject('xynora-settings')});
const storedSearchMode=safeGet('xynora-search-mode','');
const storedConversationMode=safeGet('xynora-conversation-mode','');
const validConversationModes=['auto','fast','precise','creative','deep','coding'];
const initialDeepMode=safeGet('xynora-deep-mode','0')==='1';
const initialConversationMode=validConversationModes.includes(storedConversationMode)?storedConversationMode:(initialDeepMode?'deep':'auto');
const initialSearchMode=['auto','always','off'].includes(storedSearchMode)?storedSearchMode:(safeGet('xynora-web-search','0')==='1'?'always':'auto');
let state={
  theme:safeGet('xynora-theme','dark')||'dark',
  themeMode:safeGet('xynora-theme-mode',safeGet('xynora-theme','dark'))||'dark',
  work:false,
  view:'chat',
  detail:null,
  model:safeGet('xynora-model','auto')||'auto',
  chats:safeArray('xynora-chats'),
  active:null,
  files:safeArray('xynora-files'),
  projects:safeArray('xynora-projects'),
  tasks:safeArray('xynora-tasks'),
  voiceMuted:false,
  busy:false,
  requestController:null,
  deepMode:initialConversationMode==='deep',
  conversationMode:initialConversationMode,
  searchMode:initialSearchMode,
  webSearchTopic:safeGet('xynora-web-search-topic','general')==='news'?'news':'general',
  user:null,
  guest:false,
  authReady:false,
  voiceActive:false,
  voiceProcessing:false,
  voiceAudio:null,
  voiceAudioUrl:null,
  liveConversation:null,
  voiceStartController:null,
  voiceMeterTimer:0,
  voiceSessionTimer:0,
  voiceStopping:false,
  voiceReconnectPending:false,
  lastVoiceMessage:'',
  settings:settingsStore.getAll()
};
if(!Array.isArray(state.chats))state.chats=[];
const pendingImageAttachments=[];
const pendingPdfAttachments=[];
const pendingSpreadsheetAttachments=[];
const pendingZipAttachments=[];
const pendingOfficeAttachments=[];
const imagePayloadsByMessage=new Map();
const documentTextPayloadsByMessage=new Map();
function storeImagePayloads(messageId,images){
  if(!images?.length)return;
  imagePayloadsByMessage.set(messageId,images.map(image=>({name:image.name,mimeType:image.mimeType,dataUrl:image.dataUrl,size:image.size})));
  let total=[...imagePayloadsByMessage.values()].flat().reduce((sum,image)=>sum+(image.dataUrl?.length||0),0);
  for(const [id,items] of imagePayloadsByMessage){
    if(total<=8_000_000)break;
    imagePayloadsByMessage.delete(id);
    total-=items.reduce((sum,image)=>sum+(image.dataUrl?.length||0),0)
  }
}
function storeDocumentTextPayloads(messageId,documents){
  if(!documents?.length)return;
  documentTextPayloadsByMessage.set(messageId,documents.map(document=>({kind:document.kind||'pdf',name:document.name,text:document.text,sourceChars:document.sourceChars,includedChars:document.includedChars,truncated:document.truncated,extension:document.extension})));
  let total=[...documentTextPayloadsByMessage.values()].flat().reduce((sum,document)=>sum+(document.text?.length||0),0);
  for(const [id,items] of documentTextPayloadsByMessage){
    if(total<=480_000)break;
    documentTextPayloadsByMessage.delete(id);
    total-=items.reduce((sum,document)=>sum+(document.text?.length||0),0)
  }
}
function clearVolatilePayloadsForChat(chat){
  for(const message of chat?.messages||[]){imagePayloadsByMessage.delete(message.id);documentTextPayloadsByMessage.delete(message.id)}
}
function persist(){
  try{
    localStorage.setItem('xynora-theme',state.theme);
    localStorage.setItem('xynora-theme-mode',state.themeMode);
    localStorage.setItem('xynora-model',state.model);
    localStorage.setItem('xynora-deep-mode',state.deepMode?'1':'0');
    localStorage.setItem('xynora-conversation-mode',validConversationModes.includes(state.conversationMode)?state.conversationMode:'auto');
    localStorage.setItem('xynora-search-mode',state.searchMode);
    localStorage.setItem('xynora-web-search-topic',state.webSearchTopic==='news'?'news':'general');
    safeRemove('xynora-web-search');
    if(state.settings.storeChat===false)localStorage.removeItem('xynora-chats');else localStorage.setItem('xynora-chats',JSON.stringify(state.chats.filter(c=>!c.temp).slice(-80)));
    localStorage.setItem('xynora-files',JSON.stringify(state.files));
    localStorage.setItem('xynora-projects',JSON.stringify(state.projects));
    localStorage.setItem('xynora-tasks',JSON.stringify(state.tasks));
    localStorage.setItem('xynora-settings',JSON.stringify(state.settings));
    settingsStore.replace(state.settings);
    return true
  }catch{return false}
}
function toast(msg){
  const el=$('#toast');
  el.textContent=msg;
  el.classList.add('show');
  clearTimeout(toast.t);
  toast.t=setTimeout(()=>el.classList.remove('show'),2600)
}
function applyTheme(){
  const resolved=state.themeMode==='system'?((window.matchMedia?.('(prefers-color-scheme: dark)')?.matches)??true?'dark':'light'):state.themeMode;
  state.theme=resolved;
  document.documentElement.dataset.theme=resolved;
  document.querySelector('meta[name="theme-color"]').content=resolved==='dark'?'#000000':'#ffffff'
}
function setTheme(mode){state.themeMode=mode;applyTheme();persist()}
applyTheme();
window.matchMedia?.('(prefers-color-scheme: dark)').addEventListener?.('change',()=>{if(state.themeMode==='system'){applyTheme();persist()}});
