// Attachments, message list, history drawer, add message
// Part of the SAYROX app closure: parts are concatenated in file order by scripts/build-app.mjs.
// Do not edit site/src/app.js directly.
function renderPendingImages(){
  const host=$('#composerAttachments');
  if(!host)return;
  host.replaceChildren();
  pendingImageAttachments.forEach((image,index)=>{
    const item=document.createElement('div');
    item.className='composer-attachment';
    const preview=document.createElement('img');
    preview.src=image.dataUrl;
    preview.alt=image.name;
    preview.loading='lazy';
    const name=document.createElement('span');
    name.className='composer-attachment-name';
    name.textContent=image.name;
    const remove=document.createElement('button');
    remove.type='button';
    remove.className='composer-attachment-remove';
    remove.textContent='×';
    remove.setAttribute('aria-label',`حذف تصویر ${image.name}`);
    remove.addEventListener('click',()=>{
      pendingImageAttachments.splice(index,1);
      renderPendingImages();
      updateComposerButton()
    });
    item.append(preview,name,remove);
    host.appendChild(item);
  });
  const pendingDocuments=[...pendingPdfAttachments,...pendingSpreadsheetAttachments,...pendingZipAttachments,...pendingOfficeAttachments];
  pendingDocuments.forEach(doc=>{
    const collection=doc.kind==='spreadsheet'?pendingSpreadsheetAttachments:doc.kind==='archive'?pendingZipAttachments:doc.kind==='office'?pendingOfficeAttachments:pendingPdfAttachments;
    const localIndex=collection.indexOf(doc);
    const item=document.createElement('div');item.className='composer-document-attachment';
    const badge=document.createElement('span');badge.className='composer-document-badge';badge.textContent=doc.kind==='spreadsheet'?(doc.extension==='csv'?'CSV':doc.extension==='xlsm'?'XLSM':'XLSX'):doc.kind==='archive'?'ZIP':doc.kind==='office'?doc.extension.toUpperCase():'PDF';
    const details=document.createElement('span');details.className='composer-document-details';
    const name=document.createElement('strong');name.textContent=doc.name;
    const meta=document.createElement('small');meta.textContent=`${window.SayroxFilePolicy.formatBytes(doc.size)} · ${doc.includedChars.toLocaleString('fa-IR')} نویسه استخراج‌شده${doc.truncated?' · متن محدود شده':''}${doc.sheetCount?` · ${doc.sheetCount} برگه`:''}${doc.processedFiles?` · ${doc.processedFiles} فایل متنی`:''}`;
    const privacy=document.createElement('small');privacy.className='composer-document-privacy';privacy.textContent=doc.kind==='archive'?'فقط فایل‌های متنی منتخب و امن استخراج شدند؛ فایل ZIP اصلی ارسال نمی‌شود.':'فایل اصلی ارسال نمی‌شود؛ فقط متن استخراج‌شده برای تحلیل فرستاده می‌شود.';
    if(doc.macrosIgnored){const warning=document.createElement('small');warning.className='composer-document-privacy';warning.textContent='ماکروها و کدهای VBA اجرا یا ارسال نمی‌شوند.';details.append(name,meta,warning,privacy)}else details.append(name,meta,privacy);
    const remove=document.createElement('button');remove.type='button';remove.className='composer-attachment-remove';remove.textContent='×';remove.setAttribute('aria-label',`حذف فایل ${doc.name}`);
    remove.addEventListener('click',()=>{collection.splice(localIndex,1);renderPendingImages();updateComposerButton()});
    item.append(badge,details,remove);host.appendChild(item);
  });
  host.classList.toggle('hidden',pendingImageAttachments.length===0&&pendingPdfAttachments.length===0&&pendingSpreadsheetAttachments.length===0&&pendingZipAttachments.length===0&&pendingOfficeAttachments.length===0);
  syncEmptyChatBrand();
}
function renderMessageAttachments(message,host){
  const meta=Array.isArray(message.attachments)?message.attachments:[];
  const documents=Array.isArray(message.documents)?message.documents:[];
  if(!meta.length&&!documents.length)return;
  const payloads=imagePayloadsByMessage.get(message.id)||[];
  const wrap=document.createElement('div');
  wrap.className='message-attachments';
  meta.forEach((attachment,index)=>{
    const payload=payloads[index];
    if(payload?.dataUrl){
      const image=document.createElement('img');
      image.className='message-attachment-image';
      image.src=payload.dataUrl;
      image.alt=attachment.name||'تصویر پیوست‌شده';
      image.loading='lazy';
      wrap.appendChild(image)
    }
  else{
      const missing=document.createElement('span');
      missing.className='message-attachment-unavailable';
      missing.textContent=`تصویر ${attachment.name||''} · برای تحلیل دوباره، مجدداً پیوست کن`;
      wrap.appendChild(missing)
    }
  });
  documents.forEach(documentMeta=>{
    const card=document.createElement('div');card.className='message-attachment-document';
    const badge=document.createElement('span');badge.className='message-document-badge';badge.textContent=documentMeta.kind==='spreadsheet'?(documentMeta.extension==='csv'?'CSV':documentMeta.extension==='xlsm'?'XLSM':'XLSX'):documentMeta.kind==='archive'?'ZIP':documentMeta.kind==='office'?String(documentMeta.extension||'OFFICE').toUpperCase():'PDF';
    const details=document.createElement('span');details.className='message-document-details';
    const name=document.createElement('strong');name.textContent=documentMeta.name||'سند پیوست‌شده';
    const available=documentTextPayloadsByMessage.has(message.id);
    const status=document.createElement('small');
    status.textContent=available?`${Number(documentMeta.includedChars||0).toLocaleString('fa-IR')} نویسه برای تحلیل آماده است${documentMeta.ocr?' · OCR':''}${documentMeta.truncated?' · متن محدود شده':''}`:'متن سند در این نشست موجود نیست؛ برای تحلیل دوباره فایل را مجدداً پیوست کن.';
    const privacy=document.createElement('small');privacy.className='message-document-privacy';privacy.textContent=documentMeta.kind==='archive'?'فایل ZIP اصلی ارسال نشد؛ فقط متن‌های استخراج‌شده از آرشیو ارسال شد.':'در زمان ارسال، فقط متن استخراج‌شده برای تحلیل فرستاده شد؛ فایل اصلی ارسال نشد.';
    details.append(name,status,privacy);card.append(badge,details);wrap.appendChild(card);
  });
  host.appendChild(wrap);
}
function syncEmptyChatBrand(){
  const chat=activeChat();
  const hasConversation=Boolean(chat&&Array.isArray(chat.messages)&&chat.messages.some(message=>message&&!message.internal));
  const input=$('#promptInput');
  const hasDraft=Boolean(input?.value?.trim()||pendingImageAttachments.length||pendingPdfAttachments.length||pendingSpreadsheetAttachments.length||pendingZipAttachments.length||pendingOfficeAttachments.length);
  const showBrand=!hasConversation&&!hasDraft;
  $('#homeActions')?.classList.toggle('hidden',!showBrand);
  $('#homeSpace')?.classList.toggle('hidden',!showBrand);
}
function renderMessages(){
  closeUserMessageMenu();
  const c=activeChat(),box=$('#messages');
  box.innerHTML='';
  const hasConversation=Boolean(c&&Array.isArray(c.messages)&&c.messages.some(message=>message&&!message.internal));
  $('#topActions')?.classList.toggle('hidden',!hasConversation);
  $('#tempChatBtn')?.classList.toggle('hidden',hasConversation);
  $('#tempChatBtn')?.classList.toggle('is-on',Boolean(c?.temp));
  syncEmptyChatBrand();
  if(hasConversation){
    const latestVisibleIndex=c.messages.reduce((latest,message,index)=>message?.internal?latest:index,-1);
    c.messages.forEach((m,i)=>{
      if(m?.internal)return;
      const el=document.createElement('article');
      el.className='message '+(m.role==='user'?'user':'assistant');
      el.dataset.messageIndex=String(i);
      if(m.role==='user'){
        el.dataset.contextMessage='user';
        el.tabIndex=0;
        el.setAttribute('aria-haspopup','menu');
        el.setAttribute('aria-expanded','false');
        el.setAttribute('aria-label','پیام شما؛ برای نمایش گزینه‌ها لمس طولانی یا کلیک راست کنید');
        renderMessageAttachments(m,el);
        const text=document.createElement('div');
        text.className='message-text';
        text.textContent=m.content;
        const long=String(m.content||'').length>420||String(m.content||'').split('\n').length>7;
        if(long){
          text.classList.add('is-collapsed');
          const expand=document.createElement('button');
          expand.className='message-expand';
          expand.type='button';
          expand.textContent='نمایش ادامه‌ی پیام ↓';
          expand.setAttribute('aria-expanded','false');
          expand.addEventListener('click',()=>{
            const open=text.classList.toggle('is-collapsed')===false;
            expand.textContent=open?'نمایش کمتر ↑':'نمایش ادامه‌ی پیام ↓';
            expand.setAttribute('aria-expanded',String(open))
          });
          el.append(text,expand)
        }else el.appendChild(text);
      }else{
        const body=document.createElement('div');
        body.className='assistant-body';
        appendSafeMessageContent(body,m.content);
        if((Array.isArray(m.sources)&&m.sources.length)||m.searchMeta){
          const sourceBox=document.createElement('div');
          sourceBox.className='answer-sources';
          const heading=document.createElement('div');
          heading.className='answer-sources-title';
          const meta=m.searchMeta;
          heading.textContent=`${meta?.topic==='news'?'منابع جست‌وجوی خبری':meta?.topic==='finance'?'منابع بازار و قیمت':'منابع جست‌وجوی وب'} · ${meta?.mode==='auto'?'تشخیص خودکار':'جست‌وجوی دستی'} · ${(m.sources||[]).length} منبع${meta?.timeRange==='week'?' · هفته‌ی اخیر':''}${meta?.timeRange==='day'?' · امروز':''}${meta?.responseTimeMs?` · ${Math.round(meta.responseTimeMs/100)/10} ثانیه`:''}`;
          sourceBox.appendChild(heading);
          if(meta?.reason){
            const reason=document.createElement('div');
            reason.className='search-intent-reason';
            reason.textContent=`دلیل جست‌وجو: ${meta.reason}`;
            sourceBox.appendChild(reason)
          }
          (m.sources||[]).forEach((src,index)=>{
            try{
              const u=new URL(src.url);
              if(!['https:','http:'].includes(u.protocol))return;
              const a=document.createElement('a');
              a.href=u.href;
              a.target='_blank';
              a.rel='noopener noreferrer';
              const title=document.createElement('span');
              title.className='source-link-title';
              title.textContent=`[${index+1}] ${src.title||u.hostname}`;
              const details=document.createElement('span');
              details.className='source-link-meta';
              details.textContent=[src.domain||u.hostname,src.publishedDate].filter(Boolean).join(' · ');
              a.append(title,details);
              sourceBox.appendChild(a)
            }catch{}
          });
          if(!sourceBox.querySelector('a')){
            const empty=document.createElement('div');
            empty.className='source-empty';
            empty.textContent='برای این عبارت منبع معتبری پیدا نشد؛ پاسخ را با احتیاط بررسی کن.';
            sourceBox.appendChild(empty)
          }
          body.appendChild(sourceBox)
        }
        el.appendChild(body);
        // Assistant-side images are volatile local payloads; only their safe metadata is persisted.
        if(Array.isArray(m.attachments)&&m.attachments.length)renderMessageAttachments(m,el);
        const tools=document.createElement('div');
        tools.className='message-tools';
        tools.innerHTML=`
          <div class="message-more-wrap"><button data-tool="more" title="گزینه‌های بیشتر" aria-label="گزینه‌های بیشتر"><svg viewBox="0 0 24 24"><circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/></svg></button><div class="message-more-menu"><button data-tool="retry">تولید دوباره‌ی پاسخ</button>${i===latestVisibleIndex?'<button data-tool="continue">ادامه‌ی پاسخ</button>':''}<button data-tool="delete" class="danger-action">حذف این پاسخ</button></div></div>
          <button data-tool="share" title="اشتراک‌گذاری" aria-label="اشتراک‌گذاری"><svg viewBox="0 0 24 24"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="m8.7 10.7 6.6-4.4m-6.6 7 6.6 4.2"/></svg></button>
          <button data-tool="speak" title="خواندن با صدا" aria-label="خواندن با صدا"><svg viewBox="0 0 24 24"><path d="M4 10v4m4-8v12m4-15v18m4-14v10m4-13v16"/></svg></button>
          <button data-tool="dislike" title="نپسندیدن" aria-label="نپسندیدن" aria-pressed="${m.reaction==='dislike'}"><svg viewBox="0 0 24 24"><path d="M7 10v11H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2zm0 0 4-8a3 3 0 0 1 3 3v4h5a3 3 0 0 1 3 3l-2 8a3 3 0 0 1-3 2H7"/></svg></button>
          <button data-tool="like" title="پسندیدن" aria-label="پسندیدن" aria-pressed="${m.reaction==='like'}"><svg viewBox="0 0 24 24"><path d="M7 14V3H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2zm0 0 4 8a3 3 0 0 0 3-3v-4h5a3 3 0 0 0 3-3l-2-8a3 3 0 0 0-3-2H7"/></svg></button>
          <button data-tool="copy" title="کپی" aria-label="کپی"><svg viewBox="0 0 24 24"><rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/></svg></button>`;
        tools.addEventListener('click',async e=>{
          const b=e.target.closest('button[data-tool]');
          if(!b)return;
          const chat=activeChat(),msg=chat?.messages[i];
          if(!msg)return;
          const act=b.dataset.tool;
          if(act==='more'){
            const menu=b.parentElement.querySelector('.message-more-menu');
            menu.classList.toggle('open');
            return
          }
          tools.querySelectorAll('.message-more-menu').forEach(x=>x.classList.remove('open'));
          if(act==='copy'){
            try{await navigator.clipboard.writeText(msg.content);toast('پاسخ کپی شد')}catch{toast('کپی در این مرورگر در دسترس نیست')}
          }
          else if(act==='share'){
            if(navigator.share){
              try{await navigator.share({title:'پاسخ SAYROX',text:msg.content})}catch(err){if(err.name!=='AbortError')toast('اشتراک‌گذاری انجام نشد')}
            }else{
              try{
                await navigator.clipboard.writeText(msg.content);
                toast('متن برای اشتراک‌گذاری کپی شد')
              }catch{toast('اشتراک‌گذاری در این مرورگر در دسترس نیست')}
            }
          }
          else if(act==='speak'){speakAssistant(msg.content)}
          else if(act==='like'||act==='dislike'){
            msg.reaction=msg.reaction===act?null:act;
            persist();
            b.setAttribute('aria-pressed',String(msg.reaction===act));
            b.classList.toggle('active',msg.reaction===act);
            toast(act==='like'?'بازخورد ثبت شد':'بازخورد ثبت شد')
          }
          else if(act==='retry'){
            const lastUser=chat.messages.slice(0,i).reverse().find(x=>x.role==='user'&&!x.internal);
            if(lastUser){
              chat.messages=chat.messages.slice(0,i);
              persist();
              renderMessages();
              sendMessage(lastUser.content,true,{messageId:lastUser.id})
            }
          }
          else if(act==='continue'){
            if(state.busy){toast('ابتدا پاسخ فعلی را متوقف کن.');return}
            const prompt=window.SayroxChatActions.appendContinuationInstruction(chat,i);
            if(!prompt){toast('ادامه فقط برای آخرین پاسخ دستیار در دسترس است.');return}
            persist();
            renderMessages();
            sendMessage(prompt,true,{skipSearch:true})
          }
          else if(act==='delete'){
            showModal('حذف پاسخ','<p>این پاسخ از گفتگوی فعلی حذف شود؟</p>','حذف پاسخ',()=>{
              chat.messages.splice(i,1);
              persist();
              renderMessages();
              toast('پاسخ حذف شد')
            });
            $('#modalOk').classList.add('danger-btn');
            const old=$('#modalOk').onclick;
            $('#modalOk').onclick=()=>{old();$('#modalOk').classList.remove('danger-btn')};
            $('#modalCancel').onclick=()=>{
              $('#modalBackdrop').classList.remove('open');
              $('#modalOk').classList.remove('danger-btn')
            }
          }
        });
        el.appendChild(tools);
      }
      box.appendChild(el);
    });
  }
  updateTabs();
  requestAnimationFrame(()=>{$('#chatScroll').scrollTop=$('#chatScroll').scrollHeight});
}
function beginEditUserMessage(chatId,messageIndex,article){
  closeUserMessageMenu();
  if(state.busy){toast('هنگام تولید پاسخ نمی‌توان پیام را ویرایش کرد.');return}
  const chat=state.chats.find(item=>item.id===chatId),message=chat?.messages[messageIndex];
  if(!chat||!message||message.role!=='user'||message.internal||state.active!==chatId)return;
  if(article.querySelector('.user-message-editor'))return;
  const editor=document.createElement('form');
  editor.className='user-message-editor';
  const area=document.createElement('textarea');
  area.value=String(message.content||'');
  area.maxLength=24000;
  area.rows=Math.min(8,Math.max(3,area.value.split('\n').length+1));
  area.setAttribute('aria-label','ویرایش پیام');
  const actions=document.createElement('div');
  actions.className='user-message-editor-actions';
  const cancel=document.createElement('button');
  cancel.type='button';
  cancel.className='secondary-btn';
  cancel.textContent='انصراف';
  const save=document.createElement('button');
  save.type='submit';
  save.className='primary-btn';
  save.textContent='ذخیره و تولید دوباره';
  actions.append(cancel,save);
  editor.append(area,actions);
  article.appendChild(editor);
  article.querySelector('.message-text')?.classList.add('hidden');
  article.querySelector('.message-expand')?.classList.add('hidden');
  cancel.addEventListener('click',()=>renderMessages());
  editor.addEventListener('submit',event=>{
    event.preventDefault();
    const updated=area.value.trim();
    if(!updated){toast('متن پیام نمی‌تواند خالی باشد.');area.focus();return}
    if(updated.length>24000){toast('حداکثر طول پیام ۲۴ هزار نویسه است.');return}
    const current=state.chats.find(item=>item.id===chatId);
    if(state.busy||state.active!==chatId||!window.SayroxChatActions.editUserMessage(current,messageIndex,updated)){toast('ویرایش پیام انجام نشد.');return}
    persist();
    renderMessages();
    toast('پیام ویرایش شد؛ پاسخ تازه در حال تولید است.');
    sendMessage(updated,true,{messageId:current.messages[messageIndex]?.id})
  });
  area.focus();
  area.setSelectionRange(area.value.length,area.value.length);
}
function renderRecent(filter=''){
  const list=$('#recentList');
  list.innerHTML='';
  const matches=window.SayroxChatActions.searchChats(state.chats.filter(chat=>chat&&!chat.archived),filter);
  $('#recentTitle').style.display=(filter||matches.length)?'block':'none';
  if(!matches.length&&filter){
    const empty=document.createElement('div');
    empty.style.cssText='padding:12px;color:var(--subtle);font-size:12px';
    empty.textContent='گفتگویی با این عنوان یا متن پیدا نشد';
    list.appendChild(empty)
  }
  for(const result of matches){
    const c=result.chat,row=document.createElement('div');
    row.className='recent-row'+(c.id===state.active?' active':'');
    const b=document.createElement('button');
    b.className='recent-item';
    b.type='button';
    const content=document.createElement('span');
    content.className='recent-item-content';
    const title=document.createElement('span');
    title.className='recent-item-title';
    title.textContent=c.title||'گفتگوی جدید';
    content.appendChild(title);
    if(filter&&result.messageMatch){
      const snippet=document.createElement('span');
      snippet.className='recent-item-match';
      snippet.textContent=`${result.messageMatch.role==='user'?'پیام شما':'پاسخ SAYROX'}: ${result.messageMatch.excerpt}`;
      content.appendChild(snippet)
    }
    b.appendChild(content);
    b.title=c.title||'گفتگوی جدید';
    b.addEventListener('click',()=>{
      state.active=c.id;
      state.work=false;
      updateTabs();
      renderMessages();
      hideDrawer();
      setView('chat')
    });
    const del=document.createElement('button');
    del.className='recent-delete';
    del.type='button';
    del.title='حذف گفتگو';
    del.setAttribute('aria-label','حذف گفتگو');
    del.innerHTML='<svg viewBox="0 0 24 24"><path d="M3 6h18m-2 0-1 14H6L5 6m4 0V4h6v2m-5 4v6m4-6v6"/></svg>';
    del.addEventListener('click',()=>confirmDeleteChat(c.id));
    row.append(b,del);
    list.appendChild(row)
  }
}
function confirmDeleteChat(id){
  const c=state.chats.find(x=>x.id===id);
  if(!c)return;
  showModal('حذف گفتگو','<p>این گفتگو برای همیشه از حافظه‌ی همین مرورگر حذف شود؟</p>','حذف گفتگو',()=>{
    clearVolatilePayloadsForChat(c);
    state.chats=state.chats.filter(x=>x.id!==id);
    if(state.active===id)state.active=null;
    persist();
    renderRecent($('#chatSearch').value);
    renderMessages();
    toast('گفتگو حذف شد')
  });
  $('#modalOk').classList.add('danger-btn');
  const old=$('#modalOk').onclick;
  $('#modalOk').onclick=()=>{old();$('#modalOk').classList.remove('danger-btn')};
  $('#modalCancel').onclick=()=>{
    $('#modalBackdrop').classList.remove('open');
    $('#modalOk').classList.remove('danger-btn')
  };
}
function openDrawer(){
  $('#drawer').classList.add('open');
  $('#drawerBackdrop').classList.add('open');
  renderRecent()
}
function hideDrawer(){
  $('#drawer').classList.remove('open');
  $('#drawerBackdrop').classList.remove('open');
  $('#drawerSearchBox').classList.remove('active')
}
function addMessage(role,content,meta={},chatId=state.active,volatileImages=[],volatileDocuments=[]){
  let c=state.chats.find(x=>x.id===chatId);
  if(!c){newChat();c=activeChat();chatId=c.id}
  const message={id:crypto.randomUUID?.()||String(Date.now()),role,content,at:Date.now(),...meta};
  c.messages.push(message);
  if(volatileImages.length)storeImagePayloads(message.id,volatileImages);
  if(volatileDocuments.length)storeDocumentTextPayloads(message.id,volatileDocuments);
  if(role==='user'&&c.title==='گفتگوی جدید')c.title=content.slice(0,36)+(content.length>36?'…':'');
  saveChat(chatId);
  if(state.active===chatId)renderMessages();
  return message
}
