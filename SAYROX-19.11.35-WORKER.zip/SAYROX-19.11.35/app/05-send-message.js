// Composer, Agent-owned research, sendMessage, model picker, spoken replies
// Part of the SAYROX app closure: parts are concatenated in file order by scripts/build-app.mjs.
// Do not edit site/src/app.js directly.
let pendingAuthSend=null;
function resumePendingAuthSend(){
  const pending=pendingAuthSend;
  if(!pending)return;
  pendingAuthSend=null;
  queueMicrotask(()=>{
    if(pending.kind==='retry'){
      const chat=state.chats.find(item=>item.id===pending.chatId);
      const message=chat?.messages.find(item=>item.id===pending.messageId&&item.role==='user');
      if(!message){toast('پیام قبلی برای ادامه پیدا نشد؛ متن را دوباره ارسال کن.');return}
      state.active=pending.chatId;
      renderMessages();
      sendMessage(message.content,true,{messageId:message.id});
      return;
    }
    if(pending.text&&!$('#promptInput').value.trim())$('#promptInput').value=pending.text;
    resizeInput();
    updateComposerButton();
    sendMessage();
  });
}
function looksLikeCodeRequest(text){
  return /\b(code|coding|program|javascript|typescript|python|html|css|react|sql|api|function|class|script|bug|debug)\b|کد|کدنویسی|برنامه.?نویسی|اسکریپت|تابع|باگ|دیباگ|سورس|برنامه بساز|وب.?سایت/i.test(text)
}
function safeAgentOutputFilename(value,extension){
  const base=String(value||'sayrox-output').replace(/\.[a-z0-9]{2,5}$/i,'').replace(/[\\/:*?"<>|\u0000-\u001f]/g,'-').replace(/\s+/g,' ').trim().slice(0,80)||'sayrox-output';
  return `${base}.${extension}`;
}
async function deliverAgentFileArtifact(artifact){
  if(!artifact||typeof artifact!=='object'||Array.isArray(artifact))throw new Error('ساختار فایل خروجی معتبر نیست.');
  const format=String(artifact.format||'').toLowerCase();
  if(!['docx','pdf','xlsx','pptx'].includes(format))throw new Error('قالب فایل خروجی پشتیبانی نمی‌شود.');
  const title=String(artifact.title||'سند ساخته‌شده با SAYROX').replace(/[\u0000-\u001f]/g,' ').trim().slice(0,120)||'سند ساخته‌شده با SAYROX';
  const filename=safeAgentOutputFilename(artifact.filename,format);
  const tools=window.SayroxFileStudio?.tools;
  if(!tools)throw new Error('موتور ساخت فایل در مرورگر بارگذاری نشده است.');
  let blob;
  if(format==='docx'||format==='pdf'||format==='pptx'){
    if(typeof artifact.content!=='string'||artifact.content.trim().length<5||artifact.content.length>85000)throw new Error('محتوای سند خالی یا بیش از حد مجاز است.');
    blob=format==='docx'?await tools.createDocx(artifact.content,{title}):format==='pptx'?await tools.createPptx(artifact.content,{title}):await tools.createTextPdf(artifact.content,{title});
  }else{
    if(!Array.isArray(artifact.rows)||artifact.rows.length<1||artifact.rows.length>1200)throw new Error('ردیف‌های Excel معتبر نیستند.');
    let cellCount=0;
    for(const row of artifact.rows){
      if(!Array.isArray(row)||row.length<1||row.length>30)throw new Error('ساختار یکی از ردیف‌های Excel معتبر نیست.');
      cellCount+=row.length;
      if(cellCount>20000)throw new Error('تعداد سلول‌های Excel از حد مجاز بیشتر است.');
      for(const cell of row){
        if(!(cell===null||typeof cell==='string'||typeof cell==='number'||typeof cell==='boolean'))throw new Error('نوع دادهٔ یکی از سلول‌های Excel پشتیبانی نمی‌شود.');
        if(typeof cell==='string'&&(cell.length>500||/^\s*[=+@]/.test(cell)))throw new Error('یک سلول Excel دارای متن ناامن یا بیش از حد بلند است.');
        if(typeof cell==='number'&&!Number.isFinite(cell))throw new Error('مقدار عددی Excel معتبر نیست.');
      }
    }
    blob=await tools.createXlsx([{name:title,rows:artifact.rows}]);
  }
  if(!(blob instanceof Blob)||blob.size<1||blob.size>20*1024*1024)throw new Error('فایل تولیدشده خالی یا بزرگ‌تر از ۲۰ مگابایت است.');
  const expectedMime={docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',pdf:'application/pdf',xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation'}[format];
  const output=blob.type===expectedMime?blob:new Blob([blob],{type:expectedMime});
  const url=URL.createObjectURL(output);
  const link=document.createElement('a');
  link.href=url;link.download=filename;link.rel='noopener';link.style.display='none';
  document.body.appendChild(link);
  try{link.click()}finally{link.remove();window.setTimeout(()=>URL.revokeObjectURL(url),60000)}
  return {filename,size:output.size,format};
}
function normalizeAgentImageOutput(payload){
  const image=payload?.image;
  if(!image||typeof image!=='object'||typeof image.dataUrl!=='string'||image.dataUrl.length>9000000||!/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(image.dataUrl))throw new Error('خروجی تصویر Agent معتبر نیست.');
  const mimeType=String(image.mimeType||image.dataUrl.slice(5,image.dataUrl.indexOf(';'))).toLowerCase();
  if(!['image/png','image/jpeg','image/webp'].includes(mimeType))throw new Error('قالب تصویر خروجی پشتیبانی نمی‌شود.');
  const extension=mimeType==='image/jpeg'?'jpg':mimeType.split('/')[1];
  return {name:`SAYROX-generated-image.${extension}`,mimeType,dataUrl:image.dataUrl,size:Number.isFinite(image.bytes)?image.bytes:Math.floor((image.dataUrl.length-image.dataUrl.indexOf(',')-1)*3/4)};
}

function createPendingStatus(label,caption='در حال آماده‌سازی درخواست…',orbState='thinking'){
  const el=document.createElement('div');
  el.className='message assistant';
  el.innerHTML=`<div class="deep-status-card"><span class="deep-status-orb" data-orb data-orb-rings="0" data-orb-quality="1" data-state="${orbState}"></span><span><strong>${escapeHtml(label)}</strong><span class="pending-caption">${escapeHtml(caption)}</span></span><i class="deep-pulse"></i></div>`;
  $('#messages').appendChild(el);
  window.SayroxOrb.mountAll(el);
  $('#chatScroll').scrollTop=$('#chatScroll').scrollHeight;
  return el
}
function updatePendingStatus(el,label,caption,orbState='thinking'){
  const title=el?.querySelector('.deep-status-card strong'),cap=el?.querySelector('.pending-caption'),orb=el?.querySelector('[data-orb]');
  if(title)title.textContent=label;
  if(cap)cap.textContent=caption;
  if(orb&&orbState){
    orb.dataset.state=orbState;
    window.SayroxOrb?.get(orb)?.setState(orbState)
  }
}
function renderAgentApprovalCard(messageElement,approval,chatId){
  if(!messageElement||!approval||typeof approval.ticket!=='string'||!approval.ticket)return;
  const card=document.createElement('section');
  card.className='agent-approval-card';
  card.setAttribute('role','group');
  card.setAttribute('aria-label','تأیید عملیات حساس');
  const heading=document.createElement('div');heading.className='agent-approval-heading';
  const symbol=document.createElement('span');symbol.className='agent-approval-symbol';symbol.textContent='!';
  const title=document.createElement('strong');title.textContent=String(approval.title||'تأیید عملیات حساس').slice(0,100);
  heading.append(symbol,title);
  const impact=document.createElement('p');impact.className='agent-approval-impact';
  impact.textContent=String(approval.impact||'این عملیات پیش از تأیید شما اجرا نمی‌شود.').slice(0,1200);
  const details=document.createElement('ol');details.className='agent-approval-details';
  if(Array.isArray(approval.details))for(const item of approval.details.slice(0,11)){if(typeof item!=='string')continue;const line=document.createElement('li');line.textContent=item.slice(0,2200);details.appendChild(line)}
  const expiry=document.createElement('small');expiry.className='agent-approval-expiry';
  expiry.textContent='این مجوز فقط برای همین عملیات است و حداکثر تا پنج دقیقه اعتبار دارد.';
  const actions=document.createElement('div');actions.className='agent-approval-actions';
  const approve=document.createElement('button');approve.type='button';approve.className='agent-approval-accept';approve.textContent='تأیید و اجرا';
  const deny=document.createElement('button');deny.type='button';deny.className='agent-approval-deny';deny.textContent='لغو عملیات';
  const status=document.createElement('div');status.className='agent-approval-status';status.setAttribute('aria-live','polite');
  actions.append(approve,deny);card.append(heading,impact);if(details.childElementCount)card.appendChild(details);card.append(expiry,actions,status);
  messageElement.appendChild(card);
  const setBusy=value=>{approve.disabled=value;deny.disabled=value;card.classList.toggle('is-busy',value)};
  const decide=async decision=>{
    setBusy(true);status.textContent=decision==='approve'?'در حال بررسی مجوز و اجرای عملیات…':'در حال ثبت لغو عملیات…';
    try{
      const response=await fetch('/api/agent/approval',{method:'POST',credentials:'same-origin',headers:{'content-type':'application/json'},body:JSON.stringify({ticket:approval.ticket,decision})});
      const data=await response.json().catch(()=>({}));
      if(!response.ok||data.ok!==true){
        const terminal=response.status===400||response.status===403||response.status===409||response.status===502||data.code==='APPROVAL_REPLAYED';
        if(terminal){actions.remove();expiry.remove();card.classList.add('is-settled','is-failed');status.textContent=data.message||'این مجوز دیگر قابل استفاده نیست؛ برای تلاش دوباره درخواست تازه‌ای بفرست.';return}
        throw new Error(data.message||'تأیید عملیات از سرور دریافت نشد.');
      }
      actions.remove();expiry.remove();
      if(decision==='deny'||data.approved!==true){status.textContent=data.message||'عملیات لغو شد؛ هیچ تغییری انجام نشد.';card.classList.add('is-settled');return}
      status.textContent=data.message||'عملیات با موفقیت اجرا شد.';card.classList.add('is-settled');
      if(data.toolId==='browser_interact'){
        const pages=Array.isArray(data.result?.pages)?data.result.pages:[];
        const page=pages.filter(item=>item&&typeof item.url==='string').slice(-1)[0];
        const safeText=value=>String(value||'').replace(/```/g,'`\u200b``').slice(0,6500);
        const parts=['**نتیجهٔ تعامل با مرورگر**',page?.title?`صفحه: ${safeText(page.title)}`:'صفحه بررسی شد.'];
        if(page?.url)parts.push(`نشانی: ${page.url}`);
        if(page?.text)parts.push(safeText(page.text));
        const attachments=[];const images=[];
        if(data.image){const captured=normalizeAgentImageOutput({prompt:data.image.prompt,ratio:data.image.ratio,model:data.image.model,image:data.image.image});attachments.push({name:captured.name,mimeType:captured.mimeType,size:captured.size});images.push(captured)}
        addMessage('assistant',parts.join('\n\n'),{attachments},chatId,images);
      }else if(data.image){
        const generated=normalizeAgentImageOutput({prompt:data.image.prompt,ratio:data.image.ratio,model:data.image.model,image:data.image.image});
        addMessage('assistant','تصویر با موفقیت ساخته شد.',{attachments:[{name:generated.name,mimeType:generated.mimeType,size:generated.size}]},chatId,[generated]);
      }else if(data.toolId==='create_scheduled_task'){
        const task=data.result?.task;
        const detail=task?.title?` «${String(task.title).slice(0,80)}»`:'';
        addMessage('assistant',`کار زمان‌بندی‌شده${detail} با موفقیت در حساب شما ثبت شد.`,{},chatId);
      }else if(data.toolId==='execute_python'){
        const result=data.result||{};
        const safeBlock=value=>String(value||'').replace(/```/g,'`\u200b``').slice(0,18000);
        const parts=[`**نتیجهٔ اجرای Python**`,`کد خروج: ${Number.isInteger(result.exitCode)?result.exitCode:'نامشخص'}`];
        if(result.timedOut)parts.push('زمان اجرای مجاز به پایان رسید.');
        if(result.outputTruncated)parts.push('خروجی به سقف امن محدود شد.');
        if(result.stdout)parts.push(`خروجی استاندارد:\n\`\`\`text\n${safeBlock(result.stdout)}\n\`\`\``);
        if(result.stderr)parts.push(`خطا/هشدار:\n\`\`\`text\n${safeBlock(result.stderr)}\n\`\`\``);
        addMessage('assistant',parts.join('\n\n'),{},chatId);
      }else{
        addMessage('assistant',data.message||'عملیات با موفقیت انجام شد.',{},chatId);
      }
    }catch(error){
      status.textContent=String(error?.message||'اجرای عملیات ناموفق بود.').slice(0,240);
      setBusy(false);
    }
  };
  approve.addEventListener('click',()=>decide('approve'));
  deny.addEventListener('click',()=>decide('deny'));
}
async function sendMessage(textOverride,retry=false,options={}){
  const input=$('#promptInput'),stagedImages=retry?[]:pendingImageAttachments.slice(),stagedPdfs=retry?[]:pendingPdfAttachments.slice(),stagedSpreadsheets=retry?[]:pendingSpreadsheetAttachments.slice(),stagedArchives=retry?[]:pendingZipAttachments.slice(),stagedOffice=retry?[]:pendingOfficeAttachments.slice(),stagedDocuments=[...stagedPdfs,...stagedSpreadsheets,...stagedArchives,...stagedOffice];
  let text=(textOverride??input.value).trim();
  if(!text&&(stagedImages.length||stagedDocuments.length))text=stagedDocuments.length?'لطفاً سند یا آرشیو پیوست‌شده را بررسی کن، خلاصه و نکات مهم آن را بگو و برای پرسش‌های بعدی آماده باش.':'لطفاً تصویر پیوست‌شده را بررسی کن و محتوای قابل مشاهده را توضیح بده.';
  if(!text){toast('ابتدا پیام بنویس یا یک فایل پشتیبانی‌شده پیوست کن.');return ''}
  if(state.busy){toast('درخواست قبلی هنوز در حال اجراست.');return ''}
  if(text.length>24000){
    toast('هر پیام حداکثر ۲۴ هزار نویسه می‌تواند داشته باشد. متن را به چند پیام تقسیم کن.');
    return ''
  }
  if(retry&&options.messageId){
    const prior=activeChat()?.messages.find(message=>message.id===options.messageId);
    if(prior?.attachments?.length&&!imagePayloadsByMessage.has(prior.id)){
      toast('داده‌ی تصویر قبلی دیگر در مرورگر موجود نیست؛ تصویر را دوباره پیوست کن.');
      return ''
    }
    if(prior?.documents?.length&&!documentTextPayloadsByMessage.has(prior.id)){
      toast('متن سند قبلی در حافظهٔ این نشست نیست؛ فایل را دوباره پیوست کن.');
      return ''
    }
  }
  if(!state.user&&state.guest){
    if(!retry&&!activeChat())newChat();
    const guestChatId=activeChat()?.id;
    if(!guestChatId){toast('گفتگوی محلی ساخته نشد؛ دوباره تلاش کن.');return ''}
    if(!retry){
      input.value='';
      resizeInput();
      updateComposerButton();
      const imageMeta=stagedImages.map(image=>({name:image.name,mimeType:image.mimeType,size:image.size,width:image.width,height:image.height}));
      const documentMeta=stagedDocuments.map(document=>({kind:document.kind||'pdf',name:document.name,mimeType:document.mimeType,size:document.size,extension:document.extension,includedChars:document.includedChars,sourceChars:document.sourceChars,truncated:document.truncated,ocr:document.ocr===true}));
      const meta={...(imageMeta.length?{attachments:imageMeta}:{}),...(documentMeta.length?{documents:documentMeta}:{})};
      addMessage('user',text,meta,guestChatId,stagedImages,stagedDocuments);
      pendingImageAttachments.splice(0,pendingImageAttachments.length);
      pendingPdfAttachments.splice(0,pendingPdfAttachments.length);
      pendingSpreadsheetAttachments.splice(0,pendingSpreadsheetAttachments.length);
      pendingZipAttachments.splice(0,pendingZipAttachments.length);
      pendingOfficeAttachments.splice(0,pendingOfficeAttachments.length);
      renderPendingImages();
    }
    addMessage('assistant','این گفتگوی پیش‌نمایش در همین دستگاه اجرا می‌شود. پیام و ظاهر گفتگو را می‌توانی آزمایش کنی؛ برای دریافت پاسخ واقعی از مدل، جست‌وجوی وب، تحلیل فایل یا ابزارهای ابری باید با Google یا ایمیل وارد حساب SAYROX شوی.',{localPreview:true},guestChatId);
    toast('پیام در پیش‌نمایش محلی ثبت شد؛ هیچ درخواستی به مدل ارسال نشد.');
    return '';
  }
  pendingAuthSend={kind:'draft',text};
  if(!requireAccountForProtectedApis())return '';
  pendingAuthSend=null;
  if(!activeChat())newChat();
  const chatId=activeChat().id;
  if(!retry){
    input.value='';
    resizeInput();
    updateComposerButton();
    pendingImageAttachments.splice(0,pendingImageAttachments.length);
    pendingPdfAttachments.splice(0,pendingPdfAttachments.length);
    pendingSpreadsheetAttachments.splice(0,pendingSpreadsheetAttachments.length);
    pendingZipAttachments.splice(0,pendingZipAttachments.length);
    pendingOfficeAttachments.splice(0,pendingOfficeAttachments.length);
    renderPendingImages();
    const metadata=stagedImages.map(image=>({name:image.name,mimeType:image.mimeType,size:image.size,width:image.width,height:image.height}));
    const documentMetadata=stagedDocuments.map(document=>({kind:document.kind||'pdf',name:document.name,mimeType:document.mimeType,size:document.size,extension:document.extension,includedChars:document.includedChars,sourceChars:document.sourceChars,truncated:document.truncated,ocr:document.ocr===true}));
    const messageMeta={...(metadata.length?{attachments:metadata}:{}),...(documentMetadata.length?{documents:documentMetadata}:{})};
    addMessage('user',text,messageMeta,chatId,stagedImages,stagedDocuments);
  }
  const coding=state.conversationMode==='coding'||looksLikeCodeRequest(text);
  const aborter=new AbortController();
  state.requestController=aborter;
  state.busy=true;
  updateComposerButton();
  const priorMessage=retry&&options.messageId?activeChat()?.messages.find(message=>message.id===options.messageId):null;
  const hasImageContext=stagedImages.length>0||Boolean(priorMessage?.attachments?.length);
  const hasDocumentContext=stagedDocuments.length>0||Boolean(priorMessage?.documents?.length);
  const hasFileContext=hasImageContext||hasDocumentContext;
  const initialOrbState=hasFileContext?'processing':coding?'coding':'thinking';
  const initialStatusLabel=hasFileContext?'در حال آماده‌سازی فایل و پیوست':coding?'در حال آماده‌سازی درخواست کدنویسی':state.deepMode?'در حال آماده‌سازی تفکر عمیق':'در حال اتصال به موتور هوش مصنوعی';
  const initialStatusCaption=hasFileContext?'پیوست‌ها برای تحلیل آماده می‌شوند؛ متن سند روی دستگاه استخراج شده است…':coding?'درخواست برنامه‌نویسی شناسایی شد؛ محیط کدنویسی در حال آماده‌سازی است…':state.deepMode?'Main Agent در حال آماده‌سازی تحقیق و تحلیل عمیق است…':'Main Agent ابتدا درخواست را تحلیل می‌کند و فقط در صورت نیاز ابزارهای واقعی را اجرا می‌کند…';
  const pending=createPendingStatus(initialStatusLabel,initialStatusCaption,initialOrbState);
  let visibleText=null,providerNotice='',receivedFirstToken=false,visibleRenderFrame=0,visibleRenderLatest='',pendingApproval=null;
  try{
    const preparationOrbState=coding?'coding':hasFileContext?'processing':'thinking';
    const preparationLabel=coding?'در حال آماده‌سازی پاسخ کدنویسی':state.deepMode?'در حال آماده‌سازی تفکر عمیق':hasFileContext?'در حال تحلیل فایل و پیوست‌ها':'در حال انتظار برای پاسخ مدل';
    const preparationCaption=coding?'درخواست برنامه‌نویسی آماده شد؛ پاسخ کد در حال تولید خواهد بود…':state.deepMode?'Main Agent درخواست را برای تحقیق و تحلیل عمیق ارزیابی می‌کند…':hasFileContext?'محتوای پیوست‌ها آماده شد؛ درخواست تحلیل به مدل ارسال می‌شود…':'Main Agent درخواست را تحلیل می‌کند و در صورت نیاز ابزارهای واقعی را اجرا می‌کند…';
    updatePendingStatus(pending,preparationLabel,preparationCaption,preparationOrbState);
    const chat=state.chats.find(x=>x.id===chatId);
    if(!chat)throw new Error('گفتگو پیش از دریافت پاسخ حذف شده است.');
    const messages=window.SayroxChatPayload.buildChatMessages(chat.messages,imagePayloadsByMessage);
    const documentContext=window.SayroxChatPayload.buildDocumentContext(chat.messages,documentTextPayloadsByMessage);
    const requestContext={
   workMode:state.work===true,
   conversationMode:state.conversationMode||'auto',
   webSearchPreference:state.searchMode||'auto',
   webSearchTopic:state.webSearchTopic||'general',
   researchMode:state.deepMode?'deep':'quick',
   preferences:{
    customInstructions:state.settings.useCustomInstructions!==false?String(state.settings.customInstructions||'').slice(0,4000):'',
    displayName:state.settings.useDisplayName===true?String(state.settings.displayNameOverride||state.user?.displayName||'').slice(0,60):'',
    responseStyle:['concise','balanced','detailed'].includes(state.settings.responseStyle)?state.settings.responseStyle:'balanced',
    quickAnswers:state.settings.quickAnswers===true
   },
   documents:documentContext.documents,
   documentsUnavailable:documentContext.unavailableCount,
   documentsOmitted:documentContext.omittedCount,
   timezone:(()=>{try{return Intl.DateTimeFormat().resolvedOptions().timeZone||'Asia/Tehran'}catch{return 'Asia/Tehran'}})(),
  };
    const requestMessages=window.SayroxChatPayload.fitContextMessages(messages);
    const protocol=location.protocol;
    if(!['https:','http:'].includes(protocol))throw new Error('برای پاسخ واقعی باید برنامه از طریق Cloudflare Worker و HTTPS اجرا شود. فایل محلی فقط رابط کاربری را نمایش می‌دهد.');
    const response=await fetch('/api/chat',{
      method:'POST',
      credentials:'same-origin',
      headers:{'content-type':'application/json'},
      body:JSON.stringify({
        messages:requestMessages,
        context:requestContext,
        conversationId:chatId,
        model:state.model,
        stream:true,
        temporary:chat.temp===true,
        reasoningEffort:state.deepMode?'high':undefined
      }),
      signal:aborter.signal
    });
    const ctype=response.headers.get('content-type')||'';
    if(response.headers.get('x-xy-memory-saved')==='true')toast('این نکته طبق درخواستت در حافظه SAYROX ذخیره شد.');
    const agentSpecialist=response.headers.get('x-sayrox-agent-specialist')||'main';
    const agentRoleLabels={research:'پژوهشگر',coding:'برنامه‌نویس',documents:'متخصص اسناد',data:'تحلیلگر داده',creative:'متخصص خلاق'};
    if(agentRoleLabels[agentSpecialist])providerNotice+=`Main Agent نقش ${agentRoleLabels[agentSpecialist]} را برای این درخواست انتخاب کرد. `;
    const agentResearch=response.headers.get('x-sayrox-agent-research');
    let agentSources=[];
    let agentStreamSummary=null;
    const encodedAgentSources=response.headers.get('x-sayrox-agent-sources');
    if(encodedAgentSources){
      try{
        const parsed=JSON.parse(decodeURIComponent(encodedAgentSources));
        if(Array.isArray(parsed))agentSources=parsed.filter(item=>item&&typeof item.title==='string'&&/^https?:\/\//i.test(item.url||'')).slice(0,6)
      }catch{}
    }
    if(!ctype.includes('text/event-stream')&&agentResearch==='completed'){
      const sourceCount=Number(response.headers.get('x-sayrox-agent-source-count')||0);
      const researchMode=response.headers.get('x-sayrox-agent-research-mode');
      const partial=response.headers.get('x-sayrox-agent-research-partial')==='true';
      providerNotice+=`Agent جست‌وجوی واقعی وب را انجام داد${researchMode==='deep'?' و صفحات منتخب را برای تحقیق عمیق خواند':''}؛ ${sourceCount} منبع بررسی شد${partial?' (با محدودیت جزئی در بعضی مراحل)':''}. `;
      updatePendingStatus(pending,'تحقیق وب تکمیل شد',providerNotice+'اکنون پاسخ بر اساس منابع جمع‌آوری‌شده آماده می‌شود…','thinking');
    }else if(!ctype.includes('text/event-stream')&&agentResearch==='unavailable'){
      providerNotice+='ابزار تحقیق وب برای این اجرا در دسترس نبود؛ اطلاعات متغیر بدون راستی‌آزمایی وب قطعی فرض نمی‌شوند. ';
    }
    const fallbackProvider=response.headers.get('x-xy-fallback-provider');
    if(!ctype.includes('text/event-stream')&&fallbackProvider){
      providerNotice=`GapGPT در دسترس نبود؛ مسیر جایگزین ${fallbackProvider==='openrouter'?'OpenRouter':'GapGPT'} استفاده شد. `;
      toast(`GapGPT در دسترس نبود؛ پاسخ از ${fallbackProvider==='openrouter'?'OpenRouter':'GapGPT'} دریافت شد.`)
    }
    if(!ctype.includes('text/event-stream')&&state.deepMode&&response.headers.get('x-xy-reasoning')==='unsupported')providerNotice+='این Provider حالت reasoning را پشتیبانی نکرد؛ پاسخ عادی دریافت می‌شود. ';
    if(!response.ok){
      const data=await response.json().catch(()=>({}));
      const authError=protectedApiAuthError(response,data);
      if(authError)throw authError;
      const requestId=data.requestId||response.headers.get('x-xy-request-id');
      throw new Error((data.message||`خطای سرور ${response.status}`)+(requestId?` (کد پیگیری: ${String(requestId).slice(0,8)})`:''))
    }
    let answer='';
    const generatedImages=[];
    const generatedFiles=[];
    const agentOutputNotice=[];
    const toolLabels={
      web_research:'تحقیق وب',read_url:'خواندن لینک',calculate:'محاسبه',current_time:'بررسی زمان',
      inspect_attached_files:'بررسی فایل‌های پیوست',create_file:'ساخت فایل',search_memory:'جست‌وجوی حافظه',
      generate_image:'تولید تصویر',create_scheduled_task:'ایجاد زمان‌بندی',browser_inspect:'مرور و بررسی صفحه',browser_interact:'تعامل با وب‌سایت'
    };
    const applyAgentProgress=payload=>{
      const type=String(payload?.type||'');
      const tool=String(payload?.tool||'');
      const toolLabel=toolLabels[tool]||'ابزار';
      if(type==='thinking')updatePendingStatus(pending,'Agent در حال بررسی درخواست','مدل در حال ارزیابی درخواست و انتخاب گام مناسب است…','thinking');
      else if(type==='tool_requested')updatePendingStatus(pending,'ابزار مناسب شناسایی شد',`${toolLabel} برای این درخواست انتخاب شد؛ در حال آماده‌سازی اجرا…`,'thinking');
      else if(type==='tool_started')updatePendingStatus(pending,`در حال ${toolLabel}`,`Worker اجرای واقعی ابزار ${toolLabel} را آغاز کرده است…`,tool==='web_research'||tool==='read_url'?'searching':'processing');
      else if(type==='tool_completed')updatePendingStatus(pending,`${toolLabel} تکمیل شد`,'نتیجهٔ واقعی ابزار دریافت شد؛ Agent در حال بررسی آن است…','thinking');
      else if(type==='tool_failed')updatePendingStatus(pending,`اجرای ${toolLabel} ناموفق بود`,'Agent خطای ابزار را دریافت کرده و در صورت امکان مسیر پاسخ را اصلاح می‌کند…','thinking');
      else if(type==='approval_required'){pendingApproval=payload?.approval||null;updatePendingStatus(pending,'در انتظار تأیید شما','Worker اجرای عملیات را متوقف کرده است؛ بدون تأیید صریح هیچ تغییری انجام نمی‌شود.','thinking')}
      else if(type==='verifying')updatePendingStatus(pending,'در حال بررسی نتیجه','Agent نتیجهٔ ابزار را ارزیابی می‌کند و تصمیم می‌گیرد آیا گام دیگری لازم است…','thinking');
      else if(type==='responding')updatePendingStatus(pending,'در حال آماده‌سازی پاسخ نهایی','مراحل ابزار به پایان رسیده‌اند؛ پاسخ بر اساس نتایج واقعی آماده می‌شود…','thinking');
      else if(type==='completed')updatePendingStatus(pending,'پاسخ آماده شد','همهٔ مراحل Agent با موفقیت کامل شدند.','speaking');
      else if(type==='failed')updatePendingStatus(pending,'اجرای Agent ناموفق بود','پاسخ کامل دریافت نشد؛ جزئیات خطا نمایش داده می‌شود.','thinking');
      else if(type==='cancelled')updatePendingStatus(pending,'درخواست متوقف شد','اجرای Agent به درخواست کاربر متوقف شد.','thinking');
      else if(type==='summary'){
        agentStreamSummary=payload;
        const research=payload?.research||{};
        agentSources=Array.isArray(payload?.sources)?payload.sources.filter(item=>item&&typeof item.title==='string'&&/^https?:\/\//i.test(item.url||'')).slice(0,6):[];
        if(research.status==='completed'){
          const count=Number(research.sourceCount)||agentSources.length;
          providerNotice+=`Agent جست‌وجوی واقعی وب را انجام داد${research.mode==='deep'?' و صفحات منتخب را برای تحقیق عمیق خواند':''}؛ ${count} منبع بررسی شد${research.partial?' (با محدودیت جزئی در بعضی مراحل)':''}. `;
          updatePendingStatus(pending,'تحقیق وب تکمیل شد','اکنون پاسخ بر اساس منابع جمع‌آوری‌شده آماده می‌شود…','thinking');
        }else if(research.status==='unavailable')providerNotice+='ابزار تحقیق وب برای این اجرا در دسترس نبود؛ اطلاعات متغیر بدون راستی‌آزمایی وب قطعی فرض نمی‌شوند. ';
        if(payload.fallback){providerNotice=`موتور اصلی در دسترس نبود؛ مسیر جایگزین ${payload.provider==='openrouter'?'OpenRouter':'GapGPT'} استفاده شد. `;toast(`مسیر جایگزین ${payload.provider==='openrouter'?'OpenRouter':'GapGPT'} استفاده شد.`)}
        if(state.deepMode&&payload.reasoning==='unsupported')providerNotice+='این Provider حالت reasoning را پشتیبانی نکرد؛ پاسخ عادی دریافت می‌شود. ';
      }
    };
    const handleAgentOutputEvent=async(eventName,payload)=>{
      if(eventName==='sayrox_agent'){
        applyAgentProgress(payload);
      }else if(eventName==='sayrox_image'){
        if(generatedImages.length>=1){agentOutputNotice.push('بیش از یک تصویر از Agent دریافت شد؛ فقط تصویر نخست نمایش داده شد.');return}
        try{generatedImages.push(normalizeAgentImageOutput(payload))}
        catch(error){agentOutputNotice.push(`تصویر ساخته شد اما در گفتگو قابل نمایش نیست: ${String(error?.message||'خروجی نامعتبر').slice(0,180)}`);toast('خروجی تصویر معتبر نبود و نمایش داده نشد.')}
      }else if(eventName==='sayrox_file'){
        if(generatedFiles.length>=1)throw new Error('در هر نوبت فقط یک فایل Agent پذیرفته می‌شود.');
        try{generatedFiles.push(await deliverAgentFileArtifact(payload?.artifact));toast(`فایل ${generatedFiles[0].filename} برای دانلود آماده شد.`)}
        catch(error){agentOutputNotice.push(`ساخت فایل در مرورگر کامل نشد: ${String(error?.message||'خطای ناشناخته').slice(0,220)}`);toast('Agent محتوا را آماده کرد، اما ساخت فایل در مرورگر ناموفق بود.')}
      }
    };
    if(ctype.includes('text/event-stream'))answer=await window.SayroxStream.readEventStream(response,(delta,all)=>{
      if(!receivedFirstToken){
        receivedFirstToken=true;
        updatePendingStatus(pending,coding?'در حال تولید کد':'در حال تولید پاسخ',providerNotice+(coding?'کد تا پایان تولید پنهان می‌ماند.':state.deepMode?'پاسخ در حالت تفکر عمیق در حال تولید است…':'پاسخ مدل در حال تولید است…'),coding?'coding':'speaking')
      }
      if(!coding&&!state.deepMode){
        if(!visibleText){
          visibleText=document.createElement('div');
          visibleText.className='message-text assistant-body';
          pending.innerHTML='';
          pending.appendChild(visibleText)
        }
        visibleRenderLatest=all;
        if(!visibleRenderFrame){
          const paint=()=>{visibleRenderFrame=0;if(visibleText&&visibleRenderLatest)window.SayroxResponseRenderer?.render(visibleText,visibleRenderLatest,{streaming:true})};
          visibleRenderFrame=window.requestAnimationFrame?window.requestAnimationFrame(paint):window.setTimeout(paint,32);
        }
        $('#chatScroll').scrollTop=$('#chatScroll').scrollHeight
      }
    },handleAgentOutputEvent);
  else{
      updatePendingStatus(pending,coding?'در حال دریافت کد':'در حال دریافت پاسخ','پاسخ از موتور دریافت شده و در حال تکمیل است…',coding?'coding':'speaking');
      const data=await response.json().catch(()=>({}));
      answer=data.choices?.[0]?.message?.content||data.answer||'';
      const agentOutput=data.agentOutput||{};
      if(Array.isArray(agentOutput.images)&&agentOutput.images.length){try{generatedImages.push(normalizeAgentImageOutput(agentOutput.images[0]))}catch(error){agentOutputNotice.push(`تصویر ساخته شد اما در گفتگو قابل نمایش نیست: ${String(error?.message||'خروجی نامعتبر').slice(0,180)}`)}}
      if(Array.isArray(agentOutput.artifacts)&&agentOutput.artifacts.length){await handleAgentOutputEvent('sayrox_file',{artifact:agentOutput.artifacts[0]})}
    }
    if(!answer.trim())throw new Error('پاسخ خالی از موتور دریافت شد.');
    pending.remove();
    const finalAnswer=agentOutputNotice.length?`${answer.trim()}\n\n${agentOutputNotice.join('\n')}`:answer;
    const assistantMeta={sources:agentSources,...(agentSources.length?{searchMeta:{mode:agentStreamSummary?.research?.mode||response.headers.get('x-sayrox-agent-research-mode')||'quick',reason:'agent_web_research'}}:{}),...(generatedImages.length?{attachments:generatedImages.map(image=>({name:image.name,mimeType:image.mimeType,size:image.size}))}:{})};
    addMessage('assistant',finalAnswer,assistantMeta,chatId,generatedImages);
    if(pendingApproval)renderAgentApprovalCard($('#messages')?.lastElementChild,pendingApproval,chatId);
    answer=finalAnswer;
    if(state.settings.autoSpeak===true)await speakAssistant(answer);
    return answer;
  }catch(err){
    pending.remove();
    if(err.authGate){
      const failedChat=state.chats.find(item=>item.id===chatId);
      const failedUser=failedChat?.messages.slice().reverse().find(message=>message.role==='user'&&!message.internal);
      if(failedUser)pendingAuthSend={kind:'retry',chatId,messageId:failedUser.id};
      toast('نشست حساب نیاز به ورود دوباره داشت؛ بعد از ورود، همین پیام خودکار ادامه پیدا می‌کند.');
      return ''
    }
    const note=document.createElement('div');
    note.className='error-note';
    const message=document.createElement('span');
    message.textContent=err.name==='AbortError'?'درخواست متوقف شد.':(err.message||'ارتباط برقرار نشد.');
    note.appendChild(message);
    if(err.name!=='AbortError'){
      const retryButton=document.createElement('button');
      retryButton.type='button';
      retryButton.className='error-retry';
      retryButton.textContent='تلاش دوباره';
      retryButton.addEventListener('click',()=>{
        retryButton.disabled=true;
        retryButton.textContent='در حال تلاش…';
        const prior=state.chats.find(x=>x.id===chatId)?.messages.slice().reverse().find(x=>x.role==='user');
        if(prior&&state.active===chatId)sendMessage(prior.content,true,{messageId:prior.id});else{retryButton.disabled=false;retryButton.textContent='تلاش دوباره'}
      });
      note.appendChild(retryButton)
    }
    if(state.active===chatId)$('#messages').appendChild(note);
    toast(err.name==='AbortError'?'درخواست متوقف شد':'پاسخ واقعی دریافت نشد');
    return ''
  }
 finally{state.busy=false;state.requestController=null;updateComposerButton()}
}
function resizeInput(){
  const el=$('#promptInput');
  el.style.height='auto';
  el.style.height=Math.min(el.scrollHeight,132)+'px'
}
function updateComposerButton(){
  const has=!!$('#promptInput').value.trim()||pendingImageAttachments.length>0||pendingPdfAttachments.length>0||pendingSpreadsheetAttachments.length>0||pendingZipAttachments.length>0||pendingOfficeAttachments.length>0;
  const voice=$('#voiceBtn'),stop=$('#stopBtn'),composer=$('#composer');
  stop.classList.toggle('hidden',!state.busy);
  voice.classList.toggle('hidden',state.busy);
  composer.setAttribute('aria-busy',String(state.busy));
  composer.dataset.mode=state.busy?'busy':has?'send':'voice';
  voice.innerHTML=window.SayroxIcons.svg(has?'send':'wave');
  voice.setAttribute('aria-label',has?'ارسال پیام':'شروع مکالمه صوتی');
  voice.title=has?'ارسال پیام':'حالت صوتی'
}
function formatModelDisplayName(modelId){
  const id=String(modelId||'auto');
  if(id==='auto')return '✦ SAYROX · خودکار';
  const model=window.__sayroxModelCatalog?.find(item=>item.id===id);
  if(model)return `${model.brandIcon||'◇'} ${model.label||id} · ${model.providerIcon||'✦'} ${model.providerName||'SAYROX'}`;
  if(id.startsWith('avalai::'))return `🟣 ${id.slice(8).split('/').pop()} · AvalAI`;
  if(id.startsWith('hooshgar::'))return `🧠 ${id.slice(10).split('/').pop()} · Hooshgar`;
  const key=id.toLowerCase();
  const brands=[[/claude|anthropic/,'◈'],[/gpt-|openai/,'✳'],[/gemini|google/,'✦'],[/grok|xai/,'𝕏'],[/deepseek/,'🐋'],[/qwen|alibaba/,'◇'],[/kimi|moonshot/,'☾'],[/glm|z\.ai/,'🧠'],[/llama|meta/,'∞'],[/mistral/,'⚡']];
  const icon=brands.find(([pattern])=>pattern.test(key))?.[1]||'🇮🇷';
  return `${icon} ${id.split('/').pop()}`
}
async function showModelPicker(){
  let selectedModel=state.model||'auto';
  showModal('انتخاب مدل هوش مصنوعی',`<p class="model-picker-caption">مدل‌های فعال در درگاه‌های متصل SAYROX را جست‌وجو و انتخاب کن.</p><label class="model-picker-search-label" for="modelSearch">جست‌وجوی مدل</label><input id="modelSearch" class="field model-picker-search" type="search" placeholder="مثلاً GPT، Claude، Gemini…" autocomplete="off"><div id="modelPickerStatus" class="model-picker-status" role="status">در حال دریافت فهرست زنده مدل‌ها…</div><div id="modelOptions" class="model-option-list" role="radiogroup" aria-label="مدل‌های هوش مصنوعی"></div>`,'انتخاب مدل',()=>{
    if(!selectedModel)return;
    state.model=selectedModel;
    $('#modelName').textContent=formatModelDisplayName(selectedModel);
    updateComposerButton();persist();toast('مدل انتخاب شد')
  });
  const status=$('#modelPickerStatus'),list=$('#modelOptions'),search=$('#modelSearch');
  if(!status||!list)return;
  const render=models=>{
    const query=String(search?.value||'').normalize('NFKC').toLocaleLowerCase('fa-IR').trim();
    list.replaceChildren();
    const filtered=models.filter(model=>!query||`${model.label} ${model.id} ${model.brand} ${model.providerName}`.toLocaleLowerCase('fa-IR').includes(query));
    for(const model of filtered){
      const button=document.createElement('button');button.type='button';button.className='model-option'+(model.id===selectedModel?' is-selected':'');button.setAttribute('role','radio');button.setAttribute('aria-checked',String(model.id===selectedModel));
      const mark=document.createElement('span');mark.className='model-option-mark';mark.textContent=model.brandIcon||model.providerIcon||'◇';
      const copy=document.createElement('span');copy.className='model-option-copy';
      const title=document.createElement('strong');title.textContent=model.label||model.id;
      const meta=document.createElement('small');meta.textContent=model.id==='auto'?'انتخاب خودکار توسط SAYROX':`${model.brand||'مدل هوش مصنوعی'} · ${model.providerIcon||'✦'} ${model.providerName||'SAYROX'}${model.supportsVision?' · تصویر':''}`;
      copy.append(title,meta);
      const check=document.createElement('span');check.className='model-option-check';check.textContent=model.id===selectedModel?'✓':'○';
      button.append(mark,copy,check);button.addEventListener('click',()=>{selectedModel=model.id;render(models)});list.appendChild(button)
    }
    if(!filtered.length){const empty=document.createElement('p');empty.className='model-picker-empty';empty.textContent='مدلی با این نام پیدا نشد.';list.appendChild(empty)}
  };
  search?.addEventListener('input',()=>render(window.__sayroxModelCatalog||[]));
  try{
    const response=await fetch('/api/models',{headers:{accept:'application/json'}});
    if(!response.ok)throw new Error('فهرست مدل‌ها در دسترس نیست');
    const data=await response.json();
    const models=Array.isArray(data.models)?data.models:[];
    window.__sayroxModelCatalog=models;
    if(!models.length)throw new Error('هیچ مدل فعالی برنگشت');
    if(!models.some(item=>item.id===selectedModel))selectedModel='auto';
    status.textContent=models.some(item=>item.source==='live')?'فهرست زندهٔ درگاه‌های متصل · فقط مدل‌های قابل‌دسترسی حساب شما':'مدل‌های پیکربندی‌شده · برای دریافت مدل‌های زنده، کلید API درگاه‌ها را در Worker تنظیم کن';
    render(models)
  }catch{
    const fallback=[{id:'auto',label:'مدل خودکار · SAYROX',provider:'auto',providerName:'چنددرگاهی SAYROX',providerIcon:'✦',brand:'SAYROX',brandIcon:'✦'}];
    window.__sayroxModelCatalog=fallback;selectedModel='auto';status.textContent='فهرست زنده در دسترس نیست؛ فقط انتخاب خودکار نمایش داده می‌شود.';render(fallback);toast('فهرست مدل‌ها دریافت نشد')
  }
}
function showModal(title,body,ok='تأیید',callback=()=>{}){
  $('#modalTitle').textContent=title;
  $('#modalBody').innerHTML=body;
  $('#modalOk').textContent=ok;
  $('#modalBackdrop').classList.add('open');
  $('#modalOk').onclick=()=>{callback();$('#modalBackdrop').classList.remove('open')};
  $('#modalCancel').onclick=()=>$('#modalBackdrop').classList.remove('open')
}
async function speakAssistant(text){
  if(!text)return;
  try{
    if(['http:','https:'].includes(location.protocol)){
      const health=await fetch('/api/health').then(r=>r.json()).catch(()=>null);
      if(health?.providers?.tts){
        if(!requireAccountForProtectedApis())return;
        const response=await fetch('/api/tts',{
          method:'POST',
          credentials:'same-origin',
          headers:{'content-type':'application/json'},
          body:JSON.stringify({text,voice:safeGet('xynora-voice','aria'),rate:Number(state.settings.voiceRate)||1})
        });
        if(!response.ok){
          const data=await response.json().catch(()=>({}));
          const authError=protectedApiAuthError(response,data);
          if(authError)throw authError;
          throw new Error(data.message||'خطای موتور صوتی')
        }
        const blob=await response.blob();
        const url=URL.createObjectURL(blob);
        const audio=new Audio(url);
        audio.volume=Math.min(1,Math.max(.1,Number(state.settings.voiceVolume)||1));
        state.voiceAudio=audio;
        state.voiceAudioUrl=url;
        audio.onended=()=>{
          URL.revokeObjectURL(url);
          state.voiceAudio=null;
          state.voiceAudioUrl=null
        };
        audio.onerror=()=>{
          URL.revokeObjectURL(url);
          state.voiceAudio=null;
          state.voiceAudioUrl=null
        };
        try{await audio.play();return}catch(playError){
          URL.revokeObjectURL(url);
          state.voiceAudio=null;
          state.voiceAudioUrl=null;
          throw playError
        }
      }
    }
  }catch(err){
    if(err.authGate)return;
    toast(`صدای اختصاصی در دسترس نیست: ${err.message}`)
  }
  if('speechSynthesis'in window){
    speechSynthesis.cancel();
    const u=new SpeechSynthesisUtterance(text);
    u.lang='fa-IR';
    u.rate=Math.min(1.25,Math.max(.75,Number(state.settings.voiceRate)||1));
    u.volume=Math.min(1,Math.max(.1,Number(state.settings.voiceVolume)||1));
    speechSynthesis.speak(u)
  }
}
