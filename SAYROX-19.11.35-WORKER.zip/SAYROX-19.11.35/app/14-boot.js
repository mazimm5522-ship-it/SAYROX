// Voice control bindings, auth init, first render, service worker
// Part of the SAYROX app closure: parts are concatenated in file order by scripts/build-app.mjs.
// Do not edit site/src/app.js directly.
// Settings navigation and actions are owned by the isolated settings feature.
// Voice controls, Orb lifecycle and browser speech recognition.
$('#stopBtn').onclick=()=>{state.requestController?.abort();toast('درخواست متوقف شد')};
$('#voiceEnd').onclick=()=>{void stopVoiceSession()};
$('#voiceMute').onclick=()=>{void toggleLiveVoiceMute()};
$('#voiceReconnect').onclick=()=>{void reconnectLiveVoice()};
window.addEventListener('offline',()=>{
  if(state.voiceActive)showVoiceReconnect('اینترنت قطع شده؛ بعد از وصل‌شدن، دوباره تلاش کن.')
});
window.addEventListener('online',()=>{
  if(state.voiceActive&&!state.liveConversation)showVoiceReconnect('اینترنت وصل شد؛ برای ادامه دوباره متصل شو.')
});
$('#voiceVolumeControl').addEventListener('input',e=>{void setLiveVoiceVolume(e.target.value,false)});
$('#voiceVolumeControl').addEventListener('change',e=>{void setLiveVoiceVolume(e.target.value,true)});
$('#modelName').textContent=formatModelDisplayName(state.model);
updateToolMenu();
setAuthMode('login');
initAuth().then(()=>{
  const paymentResult=new URLSearchParams(location.search).get('payment');
  if(paymentResult){
    const cleanUrl=new URL(location.href);
    cleanUrl.searchParams.delete('payment');
    cleanUrl.searchParams.delete('order');
    history.replaceState({},'',cleanUrl.pathname+cleanUrl.search+cleanUrl.hash);
    toast(paymentResult==='success'?'پرداخت تأیید شد؛ اشتراک به حساب تو متصل شد.':paymentResult==='cancelled'?'پرداخت لغو شد.':'پرداخت تأیید نشد. برای بررسی وضعیت سفارش دوباره به بخش Plus سر بزن.')
  }
});// Ensure a first empty chat exists only when the user starts typing/sending.
if(state.chats.length){
  state.chats.sort((a,b)=>b.updated-a.updated);
  const visibleChats=state.chats.filter(chat=>chat&&!chat.archived);
  state.active=state.settings['pref:اجرای خودکار آخرین گفتگو']===false?null:(visibleChats[0]?.id||null);
  renderMessages()
}else{renderMessages()}
renderRecent();
if('serviceWorker'in navigator&&location.protocol.startsWith('http'))window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js',{updateViaCache:'none'}).catch(()=>{}));
document.addEventListener('visibilitychange',()=>{
  if(document.visibilityState==='visible')checkTaskInbox()
});
