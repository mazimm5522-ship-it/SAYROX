import { DurableObject } from 'cloudflare:workers';
import { readInternalJson } from './request.js';

const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const HASH = /^[A-Za-z0-9_-]{43}$/;
const MEMORY_CATEGORIES = new Set(['preference', 'profile', 'project', 'work', 'other']);
const json = (data, status = 200) => new Response(JSON.stringify(data), {
  status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }
});

/** One account per Durable Object ID; all writes use SQLite transactions. */
export class AccountObject extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    ctx.blockConcurrencyWhile(async () => {
      this.ctx.storage.sql.exec(`
        CREATE TABLE IF NOT EXISTS account (
          id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE, password_hash TEXT NOT NULL,
          display_name TEXT NOT NULL, created_at INTEGER NOT NULL
        );
      
        CREATE TABLE IF NOT EXISTS sessions (
          token_hash TEXT PRIMARY KEY, created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_sessions_expiry ON sessions(expires_at);
        CREATE TABLE IF NOT EXISTS google_identity (
          singleton INTEGER PRIMARY KEY CHECK(singleton=1), account_key TEXT NOT NULL, email TEXT NOT NULL, linked_at INTEGER NOT NULL
        );
        CREATE TABLE IF NOT EXISTS memory_settings (
          singleton INTEGER PRIMARY KEY CHECK(singleton=1), enabled INTEGER NOT NULL DEFAULT 0, updated_at INTEGER NOT NULL DEFAULT 0
        );
        INSERT OR IGNORE INTO memory_settings(singleton, enabled, updated_at) VALUES(1, 0, 0);
        CREATE TABLE IF NOT EXISTS memories (
          id TEXT PRIMARY KEY, category TEXT NOT NULL, content TEXT NOT NULL,
          source TEXT NOT NULL DEFAULT 'manual', created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_memories_updated ON memories(updated_at DESC);
      `);
      try { this.ctx.storage.sql.exec('ALTER TABLE account ADD COLUMN google_sub TEXT'); }
      catch (error) {
        if (!String(error?.message || error).toLowerCase().includes('duplicate column')) throw error;
      }
    });
  }

  async fetch(request) {
    const url = new URL(request.url);
    if (request.method !== 'POST') return json({ ok: false, error: 'METHOD_NOT_ALLOWED' }, 405);
    const body = await readInternalJson(request);
    if (!body) return json({ ok: false, error: 'INVALID_REQUEST_BODY' }, 400);
    const now = Math.floor(Date.now() / 1000);
    const sql = this.ctx.storage.sql;
    try {
      switch (url.pathname) {
        case '/internal/signup': {
          const email = String(body.email || '').trim().toLowerCase();
          if (!EMAIL.test(email) || typeof body.userId !== 'string' || typeof body.passwordHash !== 'string' || body.passwordHash.length > 160 || typeof body.displayName !== 'string') return json({ ok: false, error: 'INVALID_ACCOUNT' }, 400);
          const existing = sql.exec('SELECT id FROM account LIMIT 1').toArray()[0];
          if (existing) return json({ ok: false, error: 'ACCOUNT_EXISTS' }, 409);
          sql.exec('INSERT INTO account(id,email,password_hash,display_name,created_at) VALUES(?,?,?,?,?)', body.userId, email, body.passwordHash, body.displayName.slice(0, 60), Number(body.createdAt) || now);
          return json({ ok: true, user: this.user() }, 201);
        }
        case '/internal/google-identity/get': {
          const identity = sql.exec('SELECT account_key,email,linked_at FROM google_identity WHERE singleton=1').toArray()[0] || null;
          return json({ ok: true, identity });
        }
        case '/internal/google-identity/claim': {
          const accountKey = String(body.accountKey || '');
          const email = String(body.email || '').trim().toLowerCase();
          if (!HASH.test(accountKey) || !EMAIL.test(email)) return json({ ok: false, error: 'INVALID_GOOGLE_IDENTITY' }, 400);
          const result = this.ctx.storage.transactionSync(() => {
            const current = sql.exec('SELECT account_key,email FROM google_identity WHERE singleton=1').toArray()[0];
            if (current) return current.account_key === accountKey && current.email === email
              ? { ok: true, created: false }
              : { ok: false, error: 'GOOGLE_IDENTITY_ALREADY_LINKED' };
            sql.exec('INSERT INTO google_identity(singleton,account_key,email,linked_at) VALUES(1,?,?,?)', accountKey, email, Number(body.linkedAt) || now);
            return { ok: true, created: true };
          });
          return result.ok ? json(result) : json(result, 409);
        }
        case '/internal/google-identity/delete': {
          const accountKey = String(body.accountKey || '');
          if (HASH.test(accountKey)) sql.exec('DELETE FROM google_identity WHERE singleton=1 AND account_key=?', accountKey);
          return json({ ok: true });
        }
        case '/internal/google-link': {
          const email = String(body.email || '').trim().toLowerCase();
          const googleSub = String(body.googleSub || '');
          const current = this.user();
          if (!current || current.id !== body.userId || current.email !== email || !/^[A-Za-z0-9._-]{1,255}$/.test(googleSub)) {
            return json({ ok: false, error: 'ACCOUNT_SESSION_MISMATCH' }, 403);
          }
          const result = this.ctx.storage.sql.exec(
            'UPDATE account SET google_sub=? WHERE id=? AND email=? AND (google_sub IS NULL OR google_sub=?)',
            googleSub, current.id, email, googleSub
          );
          const updated = this.user();
          if (!updated || updated.google_sub !== googleSub) return json({ ok: false, error: 'GOOGLE_IDENTITY_CONFLICT' }, 409);
          return json({ ok: true, user: updated });
        }
        case '/internal/google-login': {
          const email = String(body.email || '').trim().toLowerCase();
          const googleSub = String(body.googleSub || '');
          const displayName = String(body.displayName || '').replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 60);
          if (!EMAIL.test(email) || !/^[A-Za-z0-9._-]{1,255}$/.test(googleSub) || !displayName || typeof body.userId !== 'string') return json({ ok: false, error: 'INVALID_GOOGLE_ACCOUNT' }, 400);
          const result = this.ctx.storage.transactionSync(() => {
            const current = sql.exec('SELECT id,email,google_sub FROM account LIMIT 1').toArray()[0];
            if (current) {
              if (current.email !== email || (current.google_sub && current.google_sub !== googleSub)) return { conflict: true };
              // Existing password accounts must explicitly connect Google from an authenticated session.
              // Email matching alone is not proof that the pre-existing SAYROX account owner controls it.
              if (!current.google_sub && current.password_hash) return { linkRequired: true };
              if (!current.google_sub) sql.exec('UPDATE account SET google_sub=? WHERE id=? AND google_sub IS NULL', googleSub, current.id);
              return { user: this.user() };
            }
            sql.exec('INSERT INTO account(id,email,password_hash,display_name,created_at,google_sub) VALUES(?,?,?,?,?,?)', body.userId, email, '', displayName, Number(body.createdAt) || now, googleSub);
            return { user: this.user() };
          });
          return result.linkRequired ? json({ ok: false, error: 'GOOGLE_LINK_REQUIRED' }, 409) : result.conflict ? json({ ok: false, error: 'GOOGLE_IDENTITY_CONFLICT' }, 409) : json({ ok: true, user: result.user }, 200);
        }
        case '/internal/get-user': {
          const user = this.user();
          return user ? json({ ok: true, user }) : json({ ok: false, error: 'USER_NOT_FOUND' }, 404);
        }
        case '/internal/update-password-hash': {
          if (typeof body.passwordHash !== 'string' || body.passwordHash.length > 160) return json({ ok: false, error: 'INVALID_PASSWORD_HASH' }, 400);
          const result = sql.exec('UPDATE account SET password_hash=?', body.passwordHash);
          return json({ ok: true, changes: result.rowsWritten });
        }
        case '/internal/create-session': {
          if (!HASH.test(String(body.tokenHash || '')) || !Number.isSafeInteger(Number(body.expiresAt)) || Number(body.expiresAt) <= now) return json({ ok: false, error: 'INVALID_SESSION' }, 400);
          sql.exec('DELETE FROM sessions WHERE expires_at<=?', now);
          sql.exec('INSERT OR REPLACE INTO sessions(token_hash,created_at,expires_at) VALUES(?,?,?)', body.tokenHash, Number(body.createdAt) || now, Number(body.expiresAt));
          return json({ ok: true });
        }
        case '/internal/validate-session': {
          if (!HASH.test(String(body.tokenHash || ''))) return json({ ok: false, error: 'INVALID_SESSION' }, 400);
          const row = sql.exec('SELECT token_hash FROM sessions WHERE token_hash=? AND expires_at>?', body.tokenHash, Number(body.now) || now).toArray()[0];
          const user = row ? this.user() : null;
          return user ? json({ ok: true, user }) : json({ ok: false, error: 'SESSION_NOT_FOUND' }, 404);
        }
        case '/internal/delete-session':
          if (HASH.test(String(body.tokenHash || ''))) sql.exec('DELETE FROM sessions WHERE token_hash=?', body.tokenHash);
          return json({ ok: true });
        case '/internal/memory/list': {
          const settings = sql.exec('SELECT enabled FROM memory_settings WHERE singleton=1').toArray()[0];
          const items = sql.exec('SELECT id,category,content,source,created_at,updated_at FROM memories ORDER BY updated_at DESC LIMIT 50').toArray();
          return json({ ok: true, enabled: Boolean(settings?.enabled), items });
        }
        case '/internal/memory/set-enabled':
          if (typeof body.enabled !== 'boolean') return json({ ok: false, error: 'invalid_memory_setting' }, 400);
          sql.exec('UPDATE memory_settings SET enabled=?,updated_at=? WHERE singleton=1', body.enabled ? 1 : 0, Number(body.updatedAt) || Date.now());
          return json({ ok: true, enabled: body.enabled });
        case '/internal/memory/create': {
          const count = sql.exec('SELECT COUNT(*) AS count FROM memories').toArray()[0]?.count || 0;
          const enabled = sql.exec('SELECT enabled FROM memory_settings WHERE singleton=1').toArray()[0]?.enabled;
          if (!enabled) return json({ ok: false, error: 'memory_disabled' }, 409);
          if (count >= 50) return json({ ok: false, error: 'memory_limit_reached' }, 409);
          if (typeof body.id !== 'string' || !MEMORY_CATEGORIES.has(body.category) || typeof body.content !== 'string' || body.content.length < 1 || body.content.length > 500) return json({ ok: false, error: 'invalid_memory_item' }, 400);
          const createdAt = Number(body.createdAt) || Date.now();
          sql.exec('INSERT INTO memories(id,category,content,source,created_at,updated_at) VALUES(?,?,?,?,?,?)', body.id, body.category, body.content, String(body.source || 'manual').slice(0, 24), createdAt, createdAt);
          return json({ ok: true, item: { id: body.id, category: body.category, content: body.content, source: body.source || 'manual', created_at: createdAt, updated_at: createdAt } }, 201);
        }
        case '/internal/memory/update': {
          if (typeof body.id !== 'string' || !MEMORY_CATEGORIES.has(body.category) || typeof body.content !== 'string' || body.content.length < 1 || body.content.length > 500) return json({ ok: false, error: 'invalid_memory_item' }, 400);
          const result = sql.exec('UPDATE memories SET category=?,content=?,updated_at=? WHERE id=?', body.category, body.content, Number(body.updatedAt) || Date.now(), body.id);
          return result.rowsWritten ? json({ ok: true }) : json({ ok: false, error: 'memory_not_found' }, 404);
        }
        case '/internal/memory/delete':
          sql.exec('DELETE FROM memories WHERE id=?', String(body.id || ''));
          return json({ ok: true });
        case '/internal/memory/clear':
          sql.exec('DELETE FROM memories');
          return json({ ok: true });
        default: return json({ ok: false, error: 'NOT_FOUND' }, 404);
      }
    } catch (error) {
      if (String(error?.message || '').includes('UNIQUE')) return json({ ok: false, error: 'ACCOUNT_EXISTS' }, 409);
      return json({ ok: false, error: 'STORAGE_ERROR' }, 500);
    }
  }

  user() {
    return this.ctx.storage.sql.exec('SELECT id,email,password_hash,display_name,created_at,google_sub FROM account LIMIT 1').toArray()[0] || null;
  }
}

/** Fixed-window rate limiter with bounded per-shard Durable Object cardinality. */
export class AuthRateLimiter extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    ctx.blockConcurrencyWhile(async () => {
      this.ctx.storage.sql.exec(`CREATE TABLE IF NOT EXISTS rate_buckets (
        bucket_key TEXT PRIMARY KEY, window_start INTEGER NOT NULL, attempts INTEGER NOT NULL
      ); CREATE INDEX IF NOT EXISTS idx_rate_window ON rate_buckets(window_start);`);
    });
  }
  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname !== '/internal/check' || request.method !== 'POST') return json({ ok: false, error: 'NOT_FOUND' }, 404);
    const body = await readInternalJson(request);
    if (!body) return json({ ok: false, error: 'INVALID_REQUEST_BODY' }, 400);
    const bucketKey = String(body.bucketKey || '');
    const now = Number(body.now), maxAttempts = Number(body.maxAttempts), windowMs = Number(body.windowMs);
    if (!bucketKey || bucketKey.length > 180 || !Number.isSafeInteger(now) || !Number.isSafeInteger(maxAttempts) || maxAttempts < 1 || maxAttempts > 1000 || !Number.isSafeInteger(windowMs) || windowMs < 1000 || windowMs > 86_400_000) return json({ ok: false, error: 'INVALID_RATE_LIMIT' }, 400);
    const windowStart = Math.floor(now / windowMs) * windowMs;
    const result = this.ctx.storage.transactionSync(() => {
      const sql = this.ctx.storage.sql;
      sql.exec('DELETE FROM rate_buckets WHERE window_start<?', windowStart - 86_400_000);
      const row = sql.exec('SELECT window_start,attempts FROM rate_buckets WHERE bucket_key=?', bucketKey).toArray()[0];
      const attempts = row?.window_start === windowStart ? Number(row.attempts) : 0;
      const allowed = attempts < maxAttempts;
      const next = attempts + (allowed ? 1 : 0);
      sql.exec('INSERT INTO rate_buckets(bucket_key,window_start,attempts) VALUES(?,?,?) ON CONFLICT(bucket_key) DO UPDATE SET window_start=excluded.window_start,attempts=excluded.attempts', bucketKey, windowStart, next);
      return { allowed, attempts: next, retryAfterSeconds: Math.max(1, Math.ceil((windowStart + windowMs - now) / 1000)) };
    });
    return json({ ok: true, ...result });
  }
}
