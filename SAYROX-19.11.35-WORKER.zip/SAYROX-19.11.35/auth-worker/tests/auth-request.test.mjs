import test from 'node:test';
import assert from 'node:assert/strict';
import { MAX_INTERNAL_JSON_BYTES, readInternalJson } from '../src/request.js';

function request(body, headers = {}) {
  return new Request('https://auth-storage.internal/internal/test', {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...headers },
    body
  });
}

test('internal auth RPC reader accepts bounded JSON objects', async () => {
  const value = { action: 'memory-create', content: 'سلام', count: 3 };
  assert.deepEqual(await readInternalJson(request(JSON.stringify(value))), value);
});

test('internal auth RPC reader rejects malformed, non-object, wrong-media and missing bodies', async () => {
  assert.equal(await readInternalJson(request('{broken')), null);
  assert.equal(await readInternalJson(request('[]')), null);
  assert.equal(await readInternalJson(request('null')), null);
  assert.equal(await readInternalJson(request('{}', { 'content-type': 'text/plain' })), null);
  assert.equal(await readInternalJson(new Request('https://auth-storage.internal/internal/test', { method: 'POST', headers: { 'content-type': 'application/json' } })), null);
});

test('internal auth RPC reader rejects oversized declared and streamed bodies', async () => {
  assert.equal(await readInternalJson(request('{}', { 'content-length': String(MAX_INTERNAL_JSON_BYTES + 1) })), null);
  const oversized = JSON.stringify({ content: 'x'.repeat(MAX_INTERNAL_JSON_BYTES) });
  assert.equal(await readInternalJson(request(oversized)), null);
});

test('internal auth RPC reader rejects invalid UTF-8 and invalid limits', async () => {
  const body = new ReadableStream({ start(controller) { controller.enqueue(new Uint8Array([0xc3, 0x28])); controller.close(); } });
  const invalidUtf8 = new Request('https://auth-storage.internal/internal/test', { method: 'POST', headers: { 'content-type': 'application/json' }, body, duplex: 'half' });
  assert.equal(await readInternalJson(invalidUtf8), null);
  assert.equal(await readInternalJson(request('{}'), MAX_INTERNAL_JSON_BYTES + 1), null);
});

console.log('Auth RPC hardening tests passed: bounded streaming body, strict JSON shape, media type and UTF-8');
