# کارت تأیید عملیات حساس — SAYROX 19.11.22

## رفتار برای کاربر

وقتی Main Agent برای ابزاری که اثر جانبی دارد نیاز به مجوز داشته باشد، اجرا پیش از فراخوانی handler متوقف می‌شود. پیام گفتگو یک کارت با عنوان، توضیح اثر، اعتبار پنج‌دقیقه‌ای و دو انتخاب نشان می‌دهد:

- **تأیید و اجرا:** فقط همان ابزار، همان Run و همان آرگومان‌هایی که Worker در Ticket رمزنگاری‌شده قرار داده اجرا می‌شوند.
- **لغو عملیات:** Ticket مصرف می‌شود و اجرای ابزار انجام نمی‌شود. لغو را نمی‌توان با همان کارت برگرداند؛ درخواست باید دوباره ساخته شود.

اگر سرور یا ذخیره‌ساز مجوز در دسترس نباشد، سیستم fail-closed است و عملیات انجام نمی‌شود. اگر اجرا پس از مصرف Ticket شکست بخورد، همان مجوز دوباره استفاده نمی‌شود؛ کاربر باید درخواست تازه‌ای بفرستد.

## مرز امنیتی

1. `worker/agent/tool-loop.js` در پاسخ `APPROVAL_REQUIRED` پیش از handler با `pendingApproval` متوقف می‌شود.
2. `worker/agent/approval-tickets.js` دادهٔ مجوز را با AES-GCM و AAD نسخه‌دار رمز می‌کند. کلید از `AUTH_SESSION_SECRET` با domain separation مشتق می‌شود. Ticket به accountKey، runId، toolId، callId و hash آرگومان‌های canonical متصل است.
3. Ticket پنج دقیقه اعتبار دارد؛ دست‌کاری، حساب دیگر، زمان نامعتبر و hash متفاوت رد می‌شود.
4. مرورگر فقط `{ ticket, decision }` می‌فرستد. endpoint حساب را از نشست تأییدشده می‌گیرد و نه از body مرورگر. route دارای same-origin defense، احراز هویت و rate limit است.
5. `worker/features/agent-approval.js` فقط آداپتورهای صریح را می‌شناسد، همان validator را دوباره اجرا می‌کند، و Grant را خودش سمت سرور می‌سازد.
6. `USAGE_ACCOUNT.consumeAgentApproval` با تراکنش SQLite داخلی و unique `ticket_id` یک‌بارمصرفی را اتمیک اعمال می‌کند. جدول فقط شناسه، حساب، انقضا، زمان مصرف و تصمیم را ثبت می‌کند؛ محتوای args را نگه نمی‌دارد.
7. کارت در localStorage ذخیره نمی‌شود. آرگومان ابزار، prompt حساس یا token در رویدادهای وضعیت عمومی نمایش داده نمی‌شود.

## ابزارهای پشتیبانی‌شده در 19.11.22

در نسخهٔ 19.11.11 ابزار `execute_python` نیز فقط از مسیر کارت تأیید و با ریسک مستقل `sandbox_execution` قابل اجراست؛ در 19.11.22 دو ابزار مدیریت وظیفه هم از همین Ticket یک‌بارمصرف استفاده می‌کنند؛ شرح معماری در `AGENT-SANDBOX.md` و `AGENT-UPDATE-19.11.22.md` است.

| ابزار | اثر | رفتار پس از تأیید |
|---|---|---|
| `generate_image` | مصرف سهمیهٔ تولید تصویر و فراخوانی Provider تصویری | یک تصویر با quota و Provider موجود ساخته و به چت تحویل می‌شود |
| `create_scheduled_task` | ثبت کار در حساب و اجرای خودکار آتی | همان Scheduler و محدودیت پلن موجود کار را ثبت می‌کند |
| `manage_scheduled_task` | توقف، فعال‌سازی، اجرای فوری یا ویرایش یک کار | فقط متدهای موجود و `updateTask` اتمیک در همان TaskAccountObject |
| `delete_scheduled_task` | حذف دائمی یک کار | فقط همان شناسه در DO همان حساب؛ تاریخچهٔ اجرا باقی می‌ماند |

سیاست کلی `worker/agent/policy.js` برای `modify`، `delete`، `external_send`، `financial` و `deployment` تأیید لازم می‌داند. تا وقتی آداپتور واقعی و validator مخصوص برای یک ابزار ساخته و تست نشده باشد، endpoint آن را نمی‌پذیرد. ریسک‌های `credentials`، `arbitrary_code` و `unrestricted_network` همیشه مسدودند و هیچ کارت تأییدی آن‌ها را فعال نمی‌کند.

## وابستگی و استقرار

- از Binding موجود `USAGE_ACCOUNT` و کلاس موجود `UsageAccountObject` استفاده می‌شود.
- جدول `agent_approval_tickets` با `CREATE TABLE IF NOT EXISTS` در Constructor همان Durable Object ایجاد می‌شود؛ migration کلاس یا Namespace جدید لازم نیست.
- این پایگاه داده **Cloudflare D1 نیست**؛ SQLite داخل Durable Object است. هیچ `d1_databases`، `env.DB`، D1 migration یا D1 binding اضافه نشده است.
- اگر انتشار انجام می‌دهی، ابتدا کد `usage-worker` را منتشر کن تا `consumeAgentApproval` فعال باشد؛ سپس Worker اصلی `sayrox` و Static Assets آن را منتشر کن. کلید `AUTH_SESSION_SECRET` باید همان Secret معتبر و حداقل ۳۲ نویسه‌ای موجود باشد؛ Secret جدیدی لازم نیست.
- Production در ساخت این ZIP منتشر نشده است. ابتدا Preview را با ورود حساب، یک کارت زمان‌بندی تستی، لغو، انقضا و replay آزمایش کن.

## تست‌ها و محدودیت‌ها

تست‌ها رمزنگاری و دست‌کاری Ticket، انقضا و اتصال به حساب، hash قطعی args، توقف handler قبل از تأیید، لغو بدون اجرا، اجرای ابزار زمان‌بندی با Mock و جلوگیری از اجرای دوباره را پوشش می‌دهند. اجرای واقعی Provider تصویری و Scheduler زنده به Secrets و Bindingهای محیط Cloudflare نیاز دارد و در تست محلی ادعا نمی‌شود.

در صورت شکست ابزار پس از تأیید، Ticket سوخته می‌شود تا side effect تکراری اتفاق نیفتد. این طراحی at-most-once است: جلوی اجرای دوباره را می‌گیرد، اما تضمین نمی‌کند عملیات شبکه‌ای ناموفق را خودکار retry کند.
