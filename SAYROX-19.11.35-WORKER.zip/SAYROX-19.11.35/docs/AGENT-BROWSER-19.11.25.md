# SAYROX 19.11.25 — Advanced Browser Intelligence (Update 6)

## هدف

تقویت همان Browser Engine موجود برای استفادهٔ چندمرحله‌ای در یک گفتگوی چت، بدون Browser Engine دوم، بدون تکرار CDP، بدون Worker/DO موازی و بدون D1.

## تغییرات

1. **Conversation-bound session reuse**: `conversationId` از درخواست چت رابط ارسال و به ابزارهای browser و approval ticket منتقل می‌شود. نشست به همان حساب و گفتگو محدود است.
2. **Encrypted browser state**: `sessionId`، targetها، tabها، allowlist، active tab و وضعیت اقدام در جدول `agent_browser_sessions` داخل SQLite همان `USAGE_ACCOUNT` فعلی ذخیره می‌شود. payload با AES-GCM و AAD متصل به account + conversation رمز می‌شود.
3. **Atomic lease**: برای هر conversation فقط یک درخواست مرورگر مالک lease است؛ عملیات هم‌زمان با `BROWSER_SESSION_BUSY` متوقف می‌شود. هر حساب حداکثر ۱۰ رکورد نشست فعال دارد و رکوردهای منقضی هنگام claim بعدی پاک می‌شوند. lease ۵۵ ثانیه است و با هر ذخیره تمدید می‌شود؛ Tool timeout فعلی ۴۰ ثانیه است.
4. **Reconnect**: Browser Run با `getSession(sessionId)` بررسی می‌شود، targetهای زنده از `devtools.listTargets()` خوانده و CDP به target موجود وصل می‌شود. target مفقود به‌عنوان نشست قابل‌بازیابی فرض نمی‌شود.
5. **Fixed host allowlist**: ادامهٔ نشست allowlist قبلی را حفظ می‌کند و دامنهٔ جدید را خودکار اضافه نمی‌کند. `sessionMode: "new"` نشست قبلی را می‌بندد و نشست تازه‌ای با allowlist جدید ایجاد می‌کند.
6. **Uncertain-action guard**: پیش از `click/fill/press/scroll`، وضعیت `inFlight` پیش از اجرای CDP ذخیره می‌شود. پس از موفقیت یا شکست قطعیِ مسدودشده پاک می‌شود. اگر اتصال هنگام dispatch قطع شود، حالت نامشخص باقی می‌ماند و اقدام تغییردهندهٔ بعدی مسدود می‌شود؛ فقط‌خواندنی inspect مجاز است و هشدار صریح برمی‌گرداند.
7. **Explicit close**: ابزار `browser_close_session` نشست جاری گفتگوی SAYROX را می‌بندد و payload ذخیره‌شده را حذف می‌کند.
8. **Approval continuity**: conversation ID داخل Approval Ticket رمزگذاری‌شده حفظ می‌شود تا اجرای تعامل تأییدشده به همان نشست گفتگو متصل شود.
9. **Ephemeral fallback**: چت موقت یا محیطی که context/Secret/USAGE_ACCOUNT معتبر ندارد، همچنان از رفتار نشست موقت با بستن در پایان استفاده می‌کند.

## فایل‌های اصلی تغییرکرده

- `worker/agent/browser-tools.js`
- `worker/features/agent-history.js`
- `worker/agent/approval-tickets.js`
- `worker/features/agent-approval.js`
- `worker/providers/chat.js`
- `app/05-send-message.js`
- `usage-worker/src/index.js`
- `tests/agent-browser.test.mjs`
- `usage-worker/tests/agent-history-storage.test.mjs`
- `docs/AGENT-BROWSER.md`

## ذخیره‌سازی و معماری

فقط جدول افزایشی `agent_browser_sessions` در SQLite داخلی همان `UsageAccountObject` فعلی اضافه شده است. این جدول با `CREATE TABLE IF NOT EXISTS` ساخته می‌شود. هیچ D1 database/binding/migration، DO class، namespace، worker، service binding یا scheduler تازه‌ای اضافه نشده است. Secret جدیدی درخواست نشده؛ همان `AUTH_SESSION_SECRET` موجود با domain separation همان helper تاریخچهٔ Agent استفاده شده است.

## محدودیت‌های واقعی

- TTL رکورد نشست: ۱۵ دقیقه؛ Browser Run keepAlive: ۲۰ دقیقه (حداکثر مجاز فعلی API).
- نشست دائمی یا cross-device تضمین نمی‌شود؛ reconnect فقط تا وقتی Browser Run session زنده است کار می‌کند.
- Local automated tests از fake Browser binding استفاده می‌کنند؛ Browser Run واقعی، بار صفحهٔ واقعی و account configuration در Cloudflare تست نشده‌اند.
- فعالیت‌های دارای نتیجهٔ نامعلوم خودکار تکرار نمی‌شوند؛ کاربر باید فقط وضعیت صفحه را بررسی کند یا نشست تازه بسازد.
- Deploy واقعی در این کار انجام نشده است.

## تست‌های اضافه‌شده

- رمزگذاری state در حالت ذخیره‌شده (session ID در payload خام پیدا نمی‌شود).
- reconnect بدون acquire جدید در پیام دوم همان گفتگو.
- close و حذف state.
- مسدودشدن دامنهٔ جدید در نشست جاری و شروع نشست تازه با allowlist جدید.
- باقی‌ماندن `inFlight` بعد از قطع اتصال در اقدام تغییردهنده و رد اقدام تکراری.
- ادامهٔ inspect فقط‌خواندنی برای recovery و هشدار outcome نامشخص.
- ادامهٔ URL در پیام بعدی و تشخیص دستور بستن نشست.
- lease storage: exclusivity، stale lease، release، delete و expiry.

## Rollback

برای rollback کد اصلی به `19.11.24` برگردد. چون جدول جدید در SQLite داخلی همان DO افزایشی است، رکوردها و جدول حذف نمی‌شوند و به نسخهٔ قبلی آسیب نمی‌زنند. نسخهٔ قبلی API جدید مرورگر را فراخوانی نمی‌کند. Browser Run sessionهای باز حداکثر تا ۲۰ دقیقه idle timeout می‌شوند؛ با rollback ممکن است تا آن زمان توسط کد تازه بسته نشوند. پاک‌سازی دستی DO/Namespace لازم نیست و نباید انجام شود. اگر `usage-worker` هم rollback شود، جدول و داده باقی می‌مانند و متدهای نسخهٔ جدید دیگر در دسترس نخواهند بود تا نسخهٔ 19.11.25 دوباره مستقر شود.

## نتیجهٔ اعتبارسنجی نسخهٔ 19.11.25

- تست کامل محلی: ۱۷۳ از ۱۷۳ موفق، صفر شکست و صفر تست ردشده؛ شامل تست‌های Browser، Approval، Storage/SQLite، API و رگرسیون کل پروژه.
- `build:app` و `build:worker` موفق؛ هر دو `--check` نیز خروجی را همگام با سورس تأیید کردند. `verify:dev` تعداد ۶۲ فایل سایت را تأیید کرد.
- کنترل‌های Wrangler نشان دادند هیچ D1 database یا binding جدیدی در تنظیمات ایجاد نشده است؛ bindingهای قبلی Browser و Durable Object حفظ شده‌اند.
- SDK محلی ElevenLabs در محیط ساخت حاضر نیست؛ `verify:dev` با هشدار صریح دربارهٔ غیرفعال‌ماندن Live Voice موفق شد.
- Browser Run زنده در حساب Cloudflare و Deployment واقعی از این محیط آزمایش/اجرا نشده‌اند؛ تست‌های نشست با fake Browser binding انجام شده‌اند.
