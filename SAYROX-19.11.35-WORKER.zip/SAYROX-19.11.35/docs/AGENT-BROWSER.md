# SAYROX Agent — Browser Engine (Current: 19.11.25)

## Scope

این نسخه Browser Run/CDP موجود را تقویت می‌کند؛ `browser_inspect`، `browser_interact`، Tool Registry، Tool Loop، Approval Tickets، سهمیهٔ `search` و `USAGE_ACCOUNT` موجود حفظ و بازاستفاده شده‌اند. Browser Engine، Scheduler، Worker، Durable Object class، Namespace یا Binding موازی ساخته نشده است.

- `browser_inspect`: رندر و استخراج فقط‌خواندنی از صفحات عمومی JavaScript، همراه با اسکرین‌شات محدود.
- `browser_interact`: کلیک، تکمیل فیلدهای غیرحساس، کلید و اسکرول؛ فقط از مسیر کارت تأیید یک‌بارمصرف و متصل به حساب اجرا می‌شود.
- `browser_close_session`: بستن نشست محدود به همین گفتگوی SAYROX و حذف وضعیت رمزگذاری‌شدهٔ نشست.
- هر سه ابزار به همان `worker/agent/browser-tools.js` و Browser Run binding فعلی متصل‌اند.

## مدل نشست

از 19.11.25، در گفتگوی غیرموقت و احراز‌شده، نشست Browser Run می‌تواند بین پیام‌های همان گفتگو بازیابی شود. شناسهٔ گفتگو از `conversationId` واقعی رابط می‌آید؛ نشست با شناسهٔ حساب و گفتگو محدود شده و در SQLite داخلی همان `UsageAccountObject` موجود، در جدول افزایشی `agent_browser_sessions` ذخیره می‌شود. شناسهٔ نشست Browser و شناسهٔ targetها داخل payload با AES-GCM رمز می‌شوند؛ AAD شامل account و conversation است. رکورد بعد از ۱۵ دقیقه منقضی می‌شود و برای هر حساب حداکثر ۱۰ رکورد نشست فعال نگه داشته می‌شود؛ خود Browser Run با `keepAlive` حداکثر ۲۰ دقیقهٔ مستندشده تنظیم می‌شود؛ این نشست دائمی نیست.

برای هر گفتگو lease اتمیک وجود دارد تا دو درخواست هم‌زمان نتوانند یک نشست را کنترل کنند. قبل از شروع هر اقدام تغییردهنده، پرچم `inFlight` به‌صورت رمزگذاری‌شده ذخیره می‌شود. اگر Worker هنگام اقدام قطع شود و نتیجه نامعلوم بماند، تعامل بعدی خودکار تکرار نمی‌شود؛ ابتدا فقط‌خواندنی می‌توان صفحه را بررسی کرد یا کاربر می‌تواند صریحاً نشست تازه بخواهد. شروع نشست تازه ابتدا نشست قبلی را می‌بندد و سپس allowlist جدید را تنظیم می‌کند.

نشست فقط در همان account + conversation قابل بازیابی است. چت موقت، درخواست فاقد شناسهٔ گفتگوی معتبر، حساب فاقد Secret/USAGE_ACCOUNT یا محیط Browser ناقص از نشست ماندگار استفاده نمی‌کنند و مسیر موقت قبلی حفظ می‌شود. URL بعدی باید در allowlist نشست باشد؛ برای دامنهٔ دیگر، شروع صریح نشست جدید لازم است. هر صفحه و لینک خروجی دادهٔ غیرقابل‌اعتماد محسوب می‌شوند.

## حدود و محافظت‌ها

- فقط hostname عمومی HTTP/HTTPS؛ URL دارای credential، IP literal، localhost، شبکهٔ خصوصی و پورت غیرمعمول رد می‌شود.
- allowlist نشست ثابت است و در ادامه بزرگ نمی‌شود؛ مقصد اعلام‌نشده مسدود است.
- حداکثر ۱۰ action، پنج tab، selector/input محدود و یک JPEG محدود در هر invocation.
- رمز عبور، فیلد مخفی/فایل، اطلاعات پرداخت، OTP و credential autocomplete قابل‌پرکردن نیستند.
- submit، پرداخت، خرید، حذف، انتقال، تأیید نهایی و اجرای JavaScript دلخواه پشتیبانی نمی‌شوند.
- quota موجود `search` برای هر invocation رزرو/ثبت می‌شود؛ quota یا سرویس ذخیره‌سازی جدیدی اضافه نشده است.
- هیچ D1، Binding، Namespace، DO class یا Worker جدیدی اضافه نشده است.

## استقرار و محدودیت عملیاتی

`wrangler.jsonc` همان Browser binding با نام `BROWSER` و `USAGE_ACCOUNT` موجود را استفاده می‌کند. جدول SQLite داخلی به‌صورت افزایشی و با `CREATE TABLE IF NOT EXISTS` هنگام راه‌اندازی همان `UsageAccountObject` ایجاد می‌شود؛ D1 یا migration بیرونی وجود ندارد. Secret `AUTH_SESSION_SECRET` باید در Worker اصلی و usage-worker موجود یکسان و پایدار بماند، چون از همان ریشهٔ کلید رمزنگاری استفاده می‌شود.

Cloudflare Browser Run امکان `getSession()` و `connectSession()` برای بازیابی نشست و `devtools.listTargets()` برای reconnect را مستند کرده است. `keepAlive` از ۱۰ ثانیه تا ۲۰ دقیقه مجاز است؛ نشست‌های این محصول به علت بی‌فعالیتی یا پایان عمر حداکثر ۲۰ دقیقه‌ای از بین می‌روند. منبع: [Browser binding API](https://developers.cloudflare.com/browser-run/reference/browser-binding-api/).

این ZIP به‌تنهایی به معنی اتصال زنده Browser Run نیست. حساب Cloudflare باید Browser Run را فعال داشته باشد و binding در Worker منتشرشده موجود باشد. انتشار واقعی انجام نشده است.

## تست‌ها

`tests/agent-browser.test.mjs` مسیر ephemeral، نگهداری نشست گفتگو، encryption-at-rest، reconnect، جداسازی hostname، شروع نشست تازه، قفل نتیجهٔ اقدام نامشخص، close و approval را با fake Browser binding پوشش می‌دهد. `usage-worker/tests/agent-history-storage.test.mjs` lease اتمیک، جلوگیری از دسترسی هم‌زمان، stale-lease، حذف و expiry را روی SQLite داخلی تست می‌کند. تست محلی جای آزمون Browser Run واقعی در Cloudflare را نمی‌گیرد.
