# SAYROX Agent — تقویت هستهٔ موجود 19.11.21

## تصمیم معماری

این به‌روزرسانی ادامهٔ همان Agent موجود است. هیچ موتور، Runtime، Planner، Tool Loop، Registry، Memory Store یا ذخیره‌ساز موازی ایجاد نشده است. مسیر اجرایی موجود بدون تغییر حفظ شده است.

## تغییرهای پیاده‌سازی‌شده

### 1. قرارداد Provider Schema

`worker/agent/tool-registry.js` اکنون هنگام ساخت Registry، Schema هر ابزارِ قابل‌ارائه به مدل را بررسی می‌کند:

- Schema باید object ساده و JSON-safe باشد و حداکثر ۲۴٬۰۰۰ بایت داشته باشد.
- `type` باید `function` باشد و `function.name` باید دقیقاً با `item.id` برابر باشد.
- توضیح تابع باید رشتهٔ غیرخالی و حداکثر ۱٬۲۰۰ نویسه باشد.
- `parameters` باید object با `type=object`، `additionalProperties=false` و `properties` معتبر باشد.
- تعداد propertyها حداکثر ۶۴ است؛ نام‌ها محدود و `required` باید یکتا و زیرمجموعهٔ propertyهای تعریف‌شده باشد.
- Schema ابتدا JSON-clone می‌شود و سپس تمام لایه‌ها به‌صورت recursive freeze می‌شوند.
- ابزارهای داخلی بدون `providerSchema` همچنان مجازند، اما به مدل ارائه نمی‌شوند.

### 2. معنی استاندارد شکست Handler

اگر Handler مقدار شیء JSON با `ok:false` بازگرداند، Registry آن را شکست واقعی ابزار در نظر می‌گیرد. `code` به حروف بزرگ تبدیل و با الگوی کد امن اعتبارسنجی می‌شود؛ پیام کنترل‌کاراکترزدایی و تا ۵۰۰ نویسه محدود می‌شود. نبود کد/پیام معتبر به مقادیر امن پیش‌فرض تبدیل می‌شود.

در نتیجه رویداد Tool Loop به‌جای `tool_completed`، رویداد `tool_failed` می‌فرستد و تاریخچه نیز status درست می‌گیرد. مدل هنوز کد و پیام شکست را دریافت می‌کند تا بتواند پاسخ صادقانه و مسیر جایگزین ارائه دهد. اجرای ناموفق همچنان یک مرحلهٔ مصرف‌شده محسوب می‌شود تا تلاش‌های شکست‌خورده نتوانند سقف مراحل را دور بزنند.

## فایل‌های تغییرکرده

- `worker/agent/tool-registry.js` — سخت‌سازی ثبت Schema و استانداردسازی شکست Handler.
- `site/_worker.js` — خروجی تولیدشده از همان سورس Worker؛ دستی ویرایش نشده است.
- `tests/agent-hardening.test.mjs` — تست‌های جدید برای Schema نامنطبق/باز، immutability و شکست Handler/Tool Loop.
- `tests/agent-tool-loop.test.mjs` — fixture حساس به‌روزرسانی شد تا Schema نام ابزارش با ID آن هماهنگ باشد.
- `tests/agent-utility-tools.test.mjs` — محاسبهٔ نامعتبر اکنون به‌درستی شکست ابزار محسوب می‌شود.
- `docs/AGENT-CORE.md`, `docs/CHANGELOG.md`, `docs/ROLLBACK.md`, `README.md` — قرارداد، تاریخچه و بازگشت نسخه به‌روز شدند.
- `package.json`, `docs/quota-policy.json`, `site/sw.js`, صفحهٔ About و تست زیرساخت — نسخه به 19.11.21 و cache رابط هم‌نسخه شد.

## آزمون و تأیید

`npm test`: ۱۶۴ تست موفق، صفر شکست در اجرای محلی. `site/_worker.js` با `scripts/build-worker.mjs` از `worker/**/*.js` تولید شده است. این عدد نتیجهٔ آزمون محلی است؛ صحت اتصال Provider واقعی و Deploy Cloudflare از آن نتیجه نمی‌شود.

## زیرساخت و محدودیت‌ها

- D1 استفاده/ایجاد نشده است.
- هیچ Binding، Worker مستقل، Secret، جدول، Migration یا Durable Object class جدیدی اضافه نشده است.
- storage موجود همچنان SQLite داخلی Durable Objectهای پروژه است.
- Deploy زنده انجام نشده است.
