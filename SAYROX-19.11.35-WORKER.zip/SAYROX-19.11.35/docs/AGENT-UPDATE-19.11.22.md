# SAYROX Agent — مدیریت وظایف زمان‌بندی‌شده 19.11.22 (Update 3)

## هدف انتشار

این نسخه دسترسی Main Agent به مدیریت وظایف زمان‌بندی‌شدهٔ موجود را کامل می‌کند. Scheduler جدید، موتور Agent جدید، Worker ذخیره‌سازی جدید یا مخزن دادهٔ موازی ساخته نشده است. مسیر اجرای قبلی، Tool Registry، Tool Loop، Approval Ticket، Binding `TASKS_ACCOUNT` و کلاس `TaskAccountObject` موجود حفظ شده‌اند.

## قابلیت‌های متصل‌شده به Agent

| ابزار | سطح دسترسی | عملیات |
|---|---|---|
| `list_scheduled_tasks` | فقط‌خواندنی | فهرست‌کردن وظایف همان حساب و خلاصهٔ وضعیت اجرا |
| `manage_scheduled_task` | `modify` + تأیید | `pause`، `resume`، `run_now` و `update` |
| `delete_scheduled_task` | `delete` + تأیید جداگانه | حذف وظیفهٔ مشخص در همان حساب |
| `create_scheduled_task` | حفظ‌شده | همان ایجاد وظیفهٔ قبلی با قرارداد/تأیید موجود |

ابزارهای جدید فقط وقتی intent متناظر روشن باشد، برای حساب احراز‌شده و گفتگوی غیرموقت به Registry موجود ثبت می‌شوند. Agent باید در صورت ابهام ابتدا فهرست را بخواند و از شناسهٔ واقعی وظیفه استفاده کند؛ شناسه یا مالکیت را حدس نمی‌زند.

## مرزهای امنیت و حریم خصوصی

- تمام عملیات با کلید حساب حاصل از نشست معتبر و Binding موجود `TASKS_ACCOUNT` اجرا می‌شوند؛ شناسهٔ حساب از ورودی مدل یا body مرورگر پذیرفته نمی‌شود.
- فهرست فقط خلاصهٔ موردنیاز را به مدل می‌دهد؛ prompt خصوصی و متن کامل خروجی/خطای اجرا افشا نمی‌شود.
- تغییرات و حذف از مسیر Approval Ticket رمزنگاری‌شدهٔ موجود عبور می‌کنند. Ticket به حساب، run، tool و آرگومان‌های canonical متصل و یک‌بارمصرف است.
- حذف ریسک مستقل `delete` دارد؛ تأیید عملیات modify مجوز حذف محسوب نمی‌شود.
- اعتبارسنجی ورودی هم در adapter ابزار Agent و هم در `TaskAccountObject` انجام می‌شود.
- ویرایش فقط کلیدهای مجاز `title`، `prompt`، `useSearch` و `schedule` را می‌پذیرد؛ تغییر خالی/نامعتبر رد می‌شود.
- تغییر metadata بدون تغییر schedule، زمان اجرای بعدی را بی‌دلیل جابه‌جا نمی‌کند؛ وضعیت paused حفظ می‌شود.
- pause، resume، run-now، update و delete در زمان وجود اجرای فعال (`dispatched`/`running`) رد می‌شوند تا عملیات در حال اجرا دچار race نشود.
- run-now در صورت وجود همان occurrence در صف، اجرای تکراری صف نمی‌کند.
- شناسهٔ ناشناخته برای delete پاسخ NOT_FOUND می‌دهد و موفقیت کاذب ثبت نمی‌شود.

## مسیرهای کد تقویت‌شده

- `worker/agent/scheduled-task-tools.js` — ابزارهای list/manage/delete در کنار ابزار create فعلی.
- `worker/agent/capability-intent.js` — intentهای مدیریت وظایف و تفکیک از intent ایجاد وظیفه.
- `worker/providers/chat.js` — ثبت شرطی ابزارها در همان چرخهٔ Agent و نمایش جزئیات کارت تأیید.
- `worker/features/agent-approval.js` — adapterهای صریح مدیریت و حذف روی همان Ticket موجود.
- `tasks-worker/src/index.js` — متد اتمیک `updateTask`، guard اجرای فعال و بهبود رفتار delete/setEnabled/runNow.
- `worker/features/tasks.js` — endpoint احرازشدهٔ `POST /api/tasks/update` در API موجود.

## ذخیره‌سازی و سازگاری

- داده همچنان در SQLite داخلی Durable Object فعلی Task ذخیره می‌شود.
- هیچ Cloudflare D1، binding جدید، جدول جدید، migration، Durable Object class، Namespace، Worker یا Scheduler موازی اضافه نشده است.
- schema ذخیره‌سازی وظایف تغییر نکرده است؛ `updateTask` فقط رکورد موجود را به‌صورت تراکنشی به‌روزرسانی می‌کند.
- برای Deploy، مطابق Deploy Kit، Tasks Worker موجود و Worker اصلی موجود به‌روز می‌شوند؛ هیچ DO یا داده‌ای نباید reset یا حذف شود.

## تست و پذیرش محلی

تست‌های اضافه/به‌روزشده، intent، validation، account scoping، privacy، adapterها، Ticket یک‌بارمصرف، update اتمیک، حفظ paused state و next-run، active-run lock، run-now deduplication، not-found، endpoint و نبود D1 را پوشش می‌دهند.

نتیجهٔ مجموعهٔ محلی: **167 تست موفق، 0 شکست، 0 تست ردشده**.

`build:app` و `build:worker` اجرا شده‌اند؛ بررسی همگامی خروجی‌های تولیدی و `verify:dev` نیز موفق است. `verify:dev` اعلام می‌کند SDK محلی ElevenLabs در محیط ساخته نشده و Live Voice تا ساخت SDK غیرفعال می‌ماند. بنابراین این بسته را نباید معادل تأیید Providerهای زنده یا Deploy Production دانست؛ اجرای Preview روی حساب Cloudflare هنوز لازم است.

## بازگشت نسخه

این تغییر migration یا تغییر schema ندارد. برای rollback، Worker اصلی و Tasks Worker و فایل‌های `site/` را با هم به نسخهٔ 19.11.21 بازگردان. Durable Objectها، SQLite داخلی و داده‌های حساب را حذف یا reset نکن. API جدید update پس از rollback در دسترس نخواهد بود، اما رکوردهای موجود سالم باقی می‌مانند.
