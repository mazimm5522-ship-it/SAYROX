# SAYROX Agent — بازیابی امن اجرای طولانی 19.11.23 (Update 4)

## هدف

تقویت اجرای Agent موجود با checkpoint/resume محدود و امن، بدون ساخت موتور دوم. مسیر اجرا همچنان `worker/providers/chat.js` → `worker/agent/tool-loop.js` → همان Tool Registry و ابزارهای موجود است. زمان‌بندی‌های کاربر همچنان در `TaskAccountObject` فعلی می‌مانند؛ این نسخه Scheduler دیگری نمی‌سازد.

## تغییرات اجرایی

- `worker/agent/tool-loop.js`: وضعیت گفتگو، دورها، شمار ابزارها، فهرست فراخوانی‌های معلق، cursor اجرای batch و نتایج حداقلی را در callback checkpoint منتشر می‌کند. در Resume، conversation ذخیره‌شده و cursor استفاده می‌شود؛ ابزارهای قبلاً تکمیل‌شده تکرار نمی‌شوند. ابزار الزامی وقتی واقعاً فراخوانی شد از نظر الزام فراخوانی انجام‌شده محسوب می‌شود؛ اگر خود ابزار شکست بخورد، همان شکست به مدل می‌رسد تا پاسخ محدود و صادقانه بدهد، نه اینکه Tool Loop بی‌نهایت آن را اجباری کند.
- پیش از هر Handler، ذخیرهٔ durable وضعیت `in_flight` لازم است. اگر ذخیرهٔ آن ممکن نباشد، Handler اجرا نمی‌شود و خطای `CHECKPOINT_WRITE_FAILED` بازمی‌گردد.
- بعد از هر نتیجهٔ Handler، پیام `role=tool` و cursor جدید در checkpoint امن ثبت می‌شوند. دادهٔ نتایج در state فقط به شناسهٔ ابزار، شناسهٔ فراخوانی، موفق/ناموفق و کد محدود است؛ محتوای کافی برای ادامه در conversation رمز‌شده قرار دارد.
- خطای Provider/لغو در یک مرز امن، checkpoint را `ready` می‌کند. تکمیل موفق، ورود به تأیید عملیات یا حذف تاریخچه، checkpoint همان Run را حذف می‌کند.
- `worker/providers/chat.js`: Run ID اولیه در Resume حفظ می‌شود، ولی quota reservation تلاش جدید شناسهٔ تازه می‌گیرد. Provider و مدل ثبت‌شده pin می‌شوند. Resume فقط با همان Provider/مدل و registry سازگار مجاز است؛ fallback خاموش می‌شود.
- checkpoint فقط برای حساب معتبر، پیام غیرموقت، non-stream و درخواست text-only ثبت می‌شود. ورودی و conversation رمز‌شده و با AAD به accountKey و runId متصل‌اند.
- `worker/features/agent-history.js`: کلید AES-GCM با domain separation از `AUTH_SESSION_SECRET` مشتق می‌شود؛ ciphertext با base64url IV به Durable Object موجود سپرده می‌شود. دادهٔ plaintext فقط در حافظهٔ درخواست است.
- `usage-worker/src/index.js`: جدول افزایشی `agent_run_checkpoints` و lease اتمیک به `UsageAccountObject` فعلی اضافه شد. TTL=30 دقیقه، lease=3 دقیقه؛ حداکثر ciphertext=700KB. با حذف/پاک‌کردن تاریخچه، checkpointهای متناظر نیز حذف می‌شوند. `resumeAvailable` فقط metadata وضعیت checkpoint را اعلام می‌کند.
- `worker/routes/api.js`: مسیر `POST /api/agent/resume` با same-origin، rate limit، احراز هویت، runId محدود و claim اتمیک اضافه شد. درخواست مرورگر نمی‌تواند snapshot یا آرگومان ابزار را تزریق کند.
- `app/15-agent-history.js`: دکمهٔ Resume فقط برای رکوردی ظاهر می‌شود که checkpoint آماده داشته باشد؛ خروجی ادامه پس از پاسخ در صفحه باقی می‌ماند.

## مدل ایمنی و بازیابی

| وضعیت ذخیره‌شده | رفتار |
|---|---|
| `leased` | مرز امن؛ پس از انقضای lease قابل claim است |
| `ready` | مرز امن؛ قابل claim فوری است |
| `in_flight` | Handler ممکن است اثر جانبی انجام داده باشد؛ Resume خودکار با `CHECKPOINT_UNSAFE` رد می‌شود |

Claim در transaction اتمیک است. lease زنده مانع claim دوم می‌شود. اگر اجرای اول هنگام Handler قطع شود، سیستم به‌جای تکرار کورکورانهٔ Handler، Resume را مسدود می‌کند. این انتخاب عمداً availability را فدای جلوگیری از اثر جانبی تکراری می‌کند.

## ذخیره‌سازی و محدودیت‌ها

- تنها storage استفاده‌شده SQLite داخلی همان `USAGE_ACCOUNT` Durable Object است.
- جدول `agent_run_checkpoints` با `CREATE TABLE IF NOT EXISTS` ساخته می‌شود؛ migration کلاس Durable Object یا تغییر نام کلاس وجود ندارد.
- هیچ Cloudflare D1، binding، Worker، namespace، Scheduler، Registry یا موتور Agent جدیدی ساخته نشده است.
- `AUTH_SESSION_SECRET` باید پایدار بماند؛ چرخش آن باعث می‌شود checkpointهای قبلی رمزگشایی نشوند و به‌عنوان نامعتبر حذف شوند.
- حداکثر متن checkpoint برابر ۵۱۲ کیلوبایت و عمر آن ۳۰ دقیقه است. فایل/متن بزرگ‌تر در checkpoint ذخیره نمی‌شود؛ مسیر ابزار همچنان fail-closed است.
- چت موقت، stream، درخواست‌های تصویری، اجرای دارای approval pending و اجرای انجام‌شده قابل Resume نیستند.
- اگر Worker دقیقاً در وضعیت `in_flight` متوقف شود، کاربر Resume خودکار نمی‌گیرد. برای عملیات جانبی این محدودیت عمدی است.

## تست و پذیرش

تست‌ها شامل claim/release اتمیک، lease رقابتی، expiry، عدم امکان Resume در `in_flight`، رمزنگاری AES-GCM و account binding، بازیابی بعد از خطای Provider بدون اجرای دوبارهٔ ابزار، fail-closed هنگام شکست persistence، کنترل احراز هویت route و رفتار شکست ابزار اجباری هستند. آزمون کامل نهایی: ۱۷۰ تست موفق از ۱۷۰ تست، بدون شکست و بدون تست ردشده. `build:app` و `build:worker` موفق شدند؛ `verify:dev` نیز ۶۱ فایل را تأیید کرد. SDK محلی ElevenLabs ساخته نشده و Live Voice در این Build غیرفعال باقی می‌ماند. کنترل `check:tasks-deploy` به‌درستی انتشار را متوقف کرد چون `APP_ORIGIN` هنوز مقدار نمونه است؛ تا جایگزینی Origin دقیق، Deploy مجاز نیست.

تست‌های محلی و build به معنی اجرای واقعی Cloudflare/Provider نیستند. پیش از rollout، `usage-worker` باید قبل از Worker اصلی منتشر شود؛ سپس در Preview با حساب آزمایشی و Provider واقعی تست Resume شود. `AUTH_SESSION_SECRET` نباید بین دو Worker متفاوت باشد.

## فایل‌های تغییرکرده

- `worker/agent/tool-loop.js`
- `worker/providers/chat.js`
- `worker/features/agent-history.js`
- `worker/routes/api.js`
- `usage-worker/src/index.js`
- `app/15-agent-history.js`
- تست‌های Tool Loop، history، API route و SQLite storage
- مستندات معماری، capability، changelog، rollback و UI/version metadata
