# بررسی هدفمند امنیت وابستگی‌ها — 19.11.35

تاریخ بررسی: 2026-11-08. دامنه این سند فقط pinهای مستقیم زنجیرهٔ ساخت است و نباید به‌عنوان گزارش کامل SCA یا اسکن تمام dependencyهای انتقالی تعبیر شود.

| مصرف | قبلی | نسخهٔ این انتشار | وضعیت |
|---|---:|---:|---|
| `esbuild` در پروژهٔ اصلی | 0.24.2 | 0.28.2 | ارتقا برای عبور از GHSA-67mh-4wv8-2f99 و اصلاحات نسخهٔ 0.28.1+ |
| `fflate` در Deploy Kit | 0.8.2 | 0.8.3 | رفع CVE-2026-45820 در مسیر ZIP64 `unzipSync()` |
| `wrangler` در هر دو manifest | 4.158.0 | 4.158.0 | بدون تغییر؛ نسخه دقیق pin است |
| `@elevenlabs/client` | 1.32.1 | 1.32.1 | بدون تغییر؛ قرارداد SDK در این انتشار بازآزمایی نشده است |

## شواهد عمومی

- CVE-2026-45820 در `fflate` نسخه‌های 0.8.0 تا قبل از 0.8.3 را در پردازش ZIP64 معیوب تحت تأثیر قرار می‌دهد؛ نسخهٔ رفع‌شده 0.8.3 است: https://github.com/advisories/GHSA-px8p-9vwx-vf98 و https://advisories.gitlab.com/npm/fflate/CVE-2026-45820/.
- GHSA-67mh-4wv8-2f99 نسخه‌های `esbuild` تا 0.24.2 را در dev server تحت تأثیر قرار می‌دهد؛ نسخهٔ اصلاح‌شده 0.25.0 است: https://github.com/advisories/GHSA-67mh-4wv8-2f99.
- اصلاحیهٔ Windows dev-server در esbuild از 0.28.1 به بعد اعمال شده است: https://github.com/advisories/GHSA-g7r4-m6w7-qqqr.
- فهرست نسخه‌های esbuild نشان می‌دهد 0.28.2 نسخهٔ منتشرشدهٔ جاری در تاریخ بررسی بوده است: https://security.snyk.io/package/npm/esbuild/versions.

## محدودیت اسکن

رجیستری `registry.npmjs.org` در محیط ساخت DNS resolution نداشت. به همین دلیل `npm install`، تولید `package-lock.json` و `npm audit` روی dependency tree واقعی انجام نشد. نسخه‌های مستقیم به‌صورت دقیق pin شده‌اند، ولی این کار به‌تنهایی نسخه‌های transitive را تثبیت نمی‌کند. قبل از Deploy باید در محیط دارای دسترسی npm، نصب clean انجام شود، lockfile ثبت شود و اسکن کامل dependencyها بدون هشدار حل‌نشده اجرا شود.


در نسخهٔ 19.11.35، pinهای مستقیم وابستگی تغییر نکردند. اصلاح این نسخه مربوط به schema رسمی Cloudflare Containers در سیاست `durable_object` است؛ Wrangler CLI در محیط آفلاین اجرا نشد و نباید این سند را تأیید Dry Run واقعی تلقی کرد.
