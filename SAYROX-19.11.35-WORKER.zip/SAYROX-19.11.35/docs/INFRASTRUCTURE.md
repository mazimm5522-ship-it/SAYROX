# زیرساخت انتشار SAYROX 19.11.35 — اکانت Cloudflare

این سند معماری انتشار مستقل SAYROX را مشخص می‌کند. تمام Workerها و Durable Object Namespaceها در همان اکانت Cloudflare تازه ساخته می‌شوند. هیچ ارجاعی به Workerهای اکانت قبلی یا پروژهٔ قبلی لازم نیست.

## Workerها و Bindingها

| Worker | مسئولیت | Durable Object class / Binding |
|---|---|---|
| `sayrox` | API اصلی، رابط و Static Assets | `AUTH_ACCOUNTS`, `AUTH_RATE_LIMITER`, `BILLING_ACCOUNT`, `USAGE_ACCOUNT`, `TASKS_ACCOUNT` |
| `sayrox-auth-storage` | حساب‌ها، نشست‌ها، حافظه و محدودیت ورود | `AccountObject`, `AuthRateLimiter` |
| `sayrox-billing-storage` | سفارش و اشتراک | `BillingAccountObject` |
| `sayrox-usage-storage` | سهمیه، تاریخچه Agent و مجوزهای یک‌بارمصرف | `UsageAccountObject` |
| `sayrox-tasks-storage` | زمان‌بندی و اجرای Alarm | `TaskAccountObject` |
| `sayrox-code-sandbox-preview` | اجرای Python محدود در Container ایزوله؛ در وضعیت فعلی بدون اتصال عمومی از Main Worker | `CodeSandbox` |

Worker اصلی متصل می‌شود به کلاس‌های Durable Object از Workerهای بالا با `script_name`. Deploy Kit ابتدا Workerهای ذخیره‌سازی را منتشر می‌کند و سپس Worker اصلی را؛ بنابراین Bindingها به اسکریپت‌های تازهٔ همان اکانت اشاره می‌کنند.

از نسخهٔ 19.11.30، Workerهای داخلی `sayrox-auth-storage`، `sayrox-billing-storage`، `sayrox-usage-storage`، `sayrox-tasks-storage` و `sayrox-code-sandbox-preview` با `workers_dev: false` منتشر می‌شوند. آن‌ها endpoint عمومی `workers.dev` ندارند و فقط از Bindingهای داخلی Main Worker/DOها مصرف می‌شوند. Deploy preflight این سیاست را کنترل می‌کند. فقط Worker اصلی `sayrox` عمومی باقی می‌ماند.

در نسخهٔ 19.11.31، Reader سمت مرورگر برای SSE اندازهٔ فریم/جریان/پاسخ را محدود می‌کند و پایان صریح جریان را بررسی می‌کند. نسخهٔ 19.11.32 رنگ‌آمیزی معنایی اعداد و هم‌ترازی خودکار ستون‌های عددی را به Markdown/Response موجود افزود. نسخهٔ 19.11.33 همان parser و renderer را برای نمودارهای داده‌محور SVG و راهنمای ساختار پاسخ توسعه می‌دهد؛ Binding یا سرویس جدیدی نیاز نیست.

در نسخهٔ 19.11.34، Cache آفلاین فقط با پاسخ 200 HTML جایگزین می‌شود؛ Asset audit محدود به فایل اختیاری SDK است؛ و Deploy preflight تنها یک Origin استاندارد HTTPS می‌پذیرد. زنجیرهٔ ساخت از `fflate@0.8.3` و `esbuild@0.28.2` استفاده می‌کند؛ اسکن کامل انتقالی تا تولید lockfile در محیط دارای registry باز است.

در نسخهٔ 19.11.35، خطای Wrangler در `sandbox-worker/wrangler.jsonc` رفع شد: چون Container از `scheduling_policy: "durable_object"` استفاده می‌کند، `max_instances` مجاز نیست و حذف شده است. Cloudflare این گزینه را فقط برای سیاست `default` می‌پذیرد؛ در سیاست Durable Object شمارش instance تابع محدودیت حساب است و هر سقف اختصاصی باید در منطق برنامه پیاده شود. کلاس، binding، SQLite، named image، Dockerfile و Worker name بدون تغییر مانده‌اند.

## قانون D1

هیچ فایل Wrangler در این پروژه `d1_databases` تعریف نمی‌کند و هیچ D1 migration وجود ندارد. جداول داخلی هر Durable Object در SQLite داخلی همان Durable Object نگهداری می‌شوند؛ این سرویس Cloudflare D1 نیست.

## تنظیمات انتشار

Deploy Kit پنج فایل در ریشهٔ مخزن خصوصی GitHub دارد. متغیر Build به نام `SAYROX_APP_ORIGIN` باید دقیقاً برابر Origin عمومی Worker اصلی باشد، مانند `https://sayrox.SUBDOMAIN.workers.dev`، بدون اسلش انتهایی. این مقدار برای `APP_ORIGIN` در Worker زمان‌بندی استفاده می‌شود و باید از صفحه Overview کپی شود.

اسکریپت Deploy پیش از هرگونه انتشار، Origin را اعتبارسنجی می‌کند. سپس ترتیب زیر را اجرا می‌کند:

1. `sayrox-auth-storage`
2. `sayrox-billing-storage`
3. `sayrox-usage-storage`
4. `sayrox-tasks-storage`
5. `sayrox-code-sandbox-preview` (Sandbox موجود؛ بدون فعال‌شدن Service Binding همچنان در محصول غیرفعال است)
6. `sayrox`

اگر Build، تست‌ها یا اعتبارسنجی Origin شکست بخورد، Deploy متوقف می‌شود.

## Secrets

Secretها فقط در تنظیمات Cloudflare Worker ثبت می‌شوند؛ هرگز در ZIP یا GitHub قرار نمی‌گیرند.

- Worker `sayrox`: `GAPGPT_API_KEY`, `AUTH_SESSION_SECRET`, `TASKS_INTERNAL_SECRET`
- اختیاری در Worker `sayrox`: `AVALAI_API_KEY`, `HOOSHGAR_API_KEY`؛ برای مدل‌های پیش‌فرض هر درگاه نیز `AVALAI_DEFAULT_MODEL` و `HOOSHGAR_DEFAULT_MODEL` را به‌صورت متغیر غیرمحرمانه ثبت کن.
- Worker `sayrox-tasks-storage`: همان `TASKS_INTERNAL_SECRET`
- Worker `sayrox-code-sandbox-preview`: `SAYROX_INTERNAL_SECRET`؛ فقط در صورت فعال‌سازی Service Binding موجود و با مقدار یکسان `CODE_SANDBOX_INTERNAL_SECRET` در Worker اصلی
- اختیاری در `sayrox`: `TAVILY_API_KEY`, `ELEVENLABS_API_KEY`
- `GAPGPT_DEFAULT_MODEL`، `AVALAI_DEFAULT_MODEL` و `HOOSHGAR_DEFAULT_MODEL` باید شناسهٔ واقعی مدلی باشند که در حساب همان درگاه فعال است. `AI_PROVIDER` در صورت نیاز می‌تواند `gapgpt`، `avalai` یا `hooshgar` باشد؛ ترتیب با fallback به بقیهٔ درگاه‌های دارای کلید ادامه پیدا می‌کند. Base URL پیش‌فرض AvalAI و Hooshgar به‌ترتیب `https://api.avalai.ir/v1` و `https://api.hooshgar.ir/v1` است. Base URL سفارشی فقط HTTPS بدون userinfo/query/fragment پذیرفته می‌شود.

`PAYMENTS_ENABLED=false` باقی می‌ماند تا Callback و Verify زرین‌پال جداگانه آزمایش شوند. Sandbox اجرای کد در این انتشار عمداً غیرفعال باقی می‌ماند؛ Worker ایزوله قابل انتشار است اما تا اتصال Service Binding و Secrets مشترک به Worker اصلی، قابلیت Python در محصول فعال نیست.

## درگاه‌های چت اختیاری

AvalAI و Hooshgar از همان Provider Registry و مسیر Chat Completions موجود استفاده می‌کنند؛ Worker/DO یا دیتابیس موازی ندارند. کلیدهایشان در فایل‌های Wrangler یا GitHub Kit قرار نمی‌گیرند. پس از ثبت کلید و مدل پیش‌فرض، `/api/models`، چت متنی و SSE را در Preview آزمایش کن. قابلیت tool calling و vision وابسته به مدل و قرارداد واقعی سرویس است و باید برای هر مدل جداگانه تأیید شود.

## محدودیت‌ها و تأیید پس از انتشار

- حساب‌ها و فضای ذخیره‌سازی از صفر ایجاد می‌شوند؛ داده‌ای از اکانت قبلی منتقل نمی‌شود.
- ایجاد Workerها و Namespaceها به دسترسی Deploy مجاز در Cloudflare نیاز دارد.
- تست‌های محلی جای تست زندهٔ API گپ، Secrets، ثبت‌نام، ورود، نشست، سهمیه و زمان‌بندی را نمی‌گیرند.
- تا پیش از ثبت Secretها و انجام Smoke Test، سایت را آمادهٔ عرضهٔ عمومی تلقی نکن.
