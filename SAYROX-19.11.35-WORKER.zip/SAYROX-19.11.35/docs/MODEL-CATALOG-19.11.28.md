# SAYROX 19.11.28 — کاتالوگ مدل‌ها و برندها

## دامنهٔ واقعی این نسخه

در نسخهٔ 19.11.27 چت SAYROX از قبل فقط از GapGPT استفاده می‌کرد، اما انتخاب‌گر تنها مدل پیش‌فرض و مدل‌هایی را نشان می‌داد که اپراتور دستی در `XYNORA_MODEL_CATALOG` ثبت کرده بود. این نسخه همان Provider و همان Chat Completions را حفظ می‌کند و فهرست مدل‌های قابل‌دسترسی کلید GapGPT را از endpoint سازگار `GET {GAPGPT_BASE_URL}/models` دریافت می‌کند.

- پیش‌فرض `GAPGPT_BASE_URL`: `https://api.gapgpt.app/v1`.
- درخواست فهرست فقط از Worker و با `Authorization: Bearer GAPGPT_API_KEY` انجام می‌شود.
- شناسهٔ مدل تنها وقتی به UI و allowlist انتخاب مدل می‌رسد که Provider آن را برگردانده باشد یا اپراتور آن را در `XYNORA_MODEL_CATALOG` ثبت کرده باشد.
- `/api/models` هیچ API key، Base URL یا دادهٔ حساب را برنمی‌گرداند.
- مسیر `/api/models` با rate limit موجود `models-read` (۶۰ درخواست در دقیقه) محافظت می‌شود. فهرست زنده برای ۹۰ ثانیه در حافظهٔ Worker cache می‌شود. timeout کشف ۳٫۵ ثانیه، سقف بدنه ۹۶KB و سقف پردازش ۱۲۰ مدل است.
- مدل‌های شناخته‌شدهٔ embedding، image، video، speech، audio، transcription، moderation، rerank و TTS از انتخاب‌گر چت کنار گذاشته می‌شوند. این فیلتر فقط بر اساس metadata و نام مدل است؛ قابلیت tool calling باید با آزمون واقعی همان مدل بررسی شود.
- پشتیبانی تصویر فقط وقتی فعال می‌شود که Provider آن را در `supports_vision`, `vision` یا `modalities` اعلام کند، یا اپراتور آن را صریحاً در تنظیمات ثبت کرده باشد.
- اگر API فهرست مدل‌ها در دسترس نباشد، مدل‌های دستی/پیش‌فرض موجود حفظ می‌شوند؛ خطای کشف به‌معنی فعال بودن مدل‌های کشف‌نشده نیست.

## برند و نماد در UI

هر کارت دو هویت را از هم جدا می‌کند:

1. **درگاه دسترسی:** گپ‌جی‌پی‌تی 🇮🇷
2. **سازندهٔ مدل:** OpenAI ✳، Anthropic ◈، Google ✦، xAI 𝕏، DeepSeek 🐋، Qwen ◇، Moonshot ☾، Z.ai 🧠، Meta ∞، Mistral ⚡، MiniMax ◉ یا Cohere ◍.

این نمادها glyphهای رابط کاربری‌اند و لوگوی رسمی شرکت‌ها نیستند. شناسهٔ اصلی مدل در متادیتا حفظ می‌شود و متن برچسب از نام Provider یا نام قابل‌خواندن مدل ساخته می‌شود.

## ارائه‌دهندگان ایرانی بررسی‌شده اما هنوز متصل‌نشده

- **AvalAI:** مستند رسمی، endpoint عمومی `/public/models` و endpoint احرازشده `/v1/models` دارد؛ Base URL مستند `https://api.avalai.ir/v1` است.
- **Liara AI:** کاتالوگ مدل‌ها و API اختصاصی خود را دارد؛ قرارداد احراز هویت و Chat Completions باید قبل از افزودن Provider در پروژه تأیید شود.
- **BoxAPI:** مستندات عمومی برای API چت و endpoint ویژهٔ شبکهٔ داخلی دارد؛ مدل‌ها و endpointهای هر محصول باید جداگانه verify شوند.
- **Hooshgar:** مستند رسمی `GET https://api.hooshgar.ir/v1/models` دارد.

این نام‌ها در این نسخه به‌عنوان Provider فعال یا گزینهٔ قابل‌اجرا نشان داده نمی‌شوند. اضافه‌کردن آن‌ها نیازمند Secret مستقل، قرارداد خطا/streaming/tool calling، تست مدل‌ها و تنظیمات Cloudflare جداگانه است. هیچ کلیدی در این نسخه درخواست یا ذخیره نشده است.

## منابع عمومی بررسی

- GapGPT: https://gapgpt.app/ و https://status.gapgpt.app/ . اطلاعیه‌های رسمی کانال GapGPT خانواده‌هایی مانند GPT، Claude، Gemini، Grok و Qwen را معرفی می‌کنند؛ این اطلاعیه‌ها به‌تنهایی شناسهٔ API یا دسترسی فعلی حساب را اثبات نمی‌کنند.
- AvalAI Models API: https://docs.avalai.ir/en/quickstart
- Hooshgar Models API: https://hooshgar.ir/docs/models
- مقایسهٔ سرویس‌های ایرانی و ارجاع به وب‌سایت‌های رسمی: https://1xai.ir/providers

## کنترل انتشار

این نسخه هیچ Secret یا Binding جدیدی نمی‌خواهد. `GAPGPT_API_KEY` و `GAPGPT_DEFAULT_MODEL` قبلی باید در محیط واقعی معتبر باشند. پس از Deploy، `/api/models` را بررسی و حداقل یک مدل متنی را با یک پیام واقعی آزمایش کنید. سپس مدل دارای ابزار را جداگانه با Agent/Function Calling و مدل دارای تصویر را با ورودی تصویر آزمایش کنید؛ وجود نام در `/models` به‌تنهایی پشتیبانی ابزار یا تصویر را تضمین نمی‌کند.
