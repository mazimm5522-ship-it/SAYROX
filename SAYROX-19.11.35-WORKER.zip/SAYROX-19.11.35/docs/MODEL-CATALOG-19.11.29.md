# SAYROX 19.11.29 — چنددرگاهی مدل‌های هوش مصنوعی

## درگاه‌های چت موجود در این نسخه

| درگاه | نشان رابط | Base URL پیش‌فرض | نام متغیر Secret | مدل پیش‌فرض |
|---|---|---|---|---|
| GapGPT | 🇮🇷 | `https://api.gapgpt.app/v1` | `GAPGPT_API_KEY` | `GAPGPT_DEFAULT_MODEL` |
| AvalAI | 🟣 | `https://api.avalai.ir/v1` | `AVALAI_API_KEY` | `AVALAI_DEFAULT_MODEL` |
| Hooshgar | 🧠 | `https://api.hooshgar.ir/v1` | `HOOSHGAR_API_KEY` | `HOOSHGAR_DEFAULT_MODEL` |

نشان‌های رابط glyphهای نمایشی هستند، نه لوگوهای رسمی. عنوان درگاه از نام برند سرویس گرفته می‌شود و سازندهٔ مدل (مانند OpenAI، Anthropic، Google، DeepSeek و Qwen) جداگانه بر اساس metadata/شناسهٔ مدل نمایش داده می‌شود.

## قرارداد API

هر سه Provider در این نسخه از قرارداد سازگار با OpenAI استفاده می‌کنند:

- کشف مدل‌ها: `GET {BASE_URL}/models`
- گفتگو: `POST {BASE_URL}/chat/completions`
- احراز هویت: `Authorization: Bearer <server secret>`
- استریم: `stream: true` با پاسخ Server-Sent Events (SSE)
- ابزارها: ارسال `tools` و `tool_choice` از مسیر مشترک؛ پشتیبانی واقعی به مدل و Provider انتخاب‌شده وابسته است.

دسترسی هر حساب به مدل‌ها بر اساس پاسخ زندهٔ endpoint خودش تعیین می‌شود. فهرست ثابت و سراسری از همهٔ مدل‌های قابل‌دسترسی وجود ندارد؛ ممکن است مدل یکسان برای دو حساب یا دو درگاه دسترسی متفاوتی داشته باشد.

## شناسهٔ مدل و مسیریابی

برای جلوگیری از تصادم نام‌های یکسان در دو API، ID انتخاب داخل رابط scoped است:

- GapGPT: شناسهٔ upstream عیناً حفظ می‌شود تا انتخاب‌های نسخهٔ قبلی سازگار بمانند.
- AvalAI: `avalai::<upstream-model-id>`
- Hooshgar: `hooshgar::<upstream-model-id>`

این پیشوند فقط شناسهٔ انتخاب کلاینت و allowlist سرور است. Worker قبل از ارسال، selection را resolve می‌کند و فقط شناسهٔ خام upstream را در فیلد `model` درخواست Provider می‌فرستد. مدل ارسالی از کلاینت تا زمانی که در کاتالوگ پیکربندی‌شده یا پاسخ زندهٔ Provider نباشد رد می‌شود.

## تنظیم اولویت و fallback

- `AI_PROVIDER=gapgpt|avalai|hooshgar` درگاه اصلی را مشخص می‌کند.
- در حالت خودکار، درگاه‌های دیگر فقط وقتی به‌عنوان fallback وارد می‌شوند که Secret آن‌ها موجود باشد.
- انتخاب دستی مدل به همان درگاه pin می‌شود؛ مدل یک درگاه با شناسهٔ مشابه درگاه دیگر جابه‌جا نمی‌شود.
- در حالت تصویر، فقط Provider/modelهایی قابل انتخاب‌اند که metadata ورودی تصویر را صریحاً اعلام کرده‌اند یا اپراتور با `*_VISION_MODEL` آن را صریحاً تنظیم کرده باشد.

## متغیرهای سرور

برای هر Provider می‌توان این متغیرها را استفاده کرد (ستاره با پیشوند درگاه جایگزین می‌شود):

- `*_API_KEY` — Secret الزامی برای discovery و chat
- `*_BASE_URL` — متغیر غیرمحرمانهٔ اختیاری؛ فقط HTTPS با hostname و بدون userinfo/query/fragment پذیرفته می‌شود
- `*_DEFAULT_MODEL` — شناسهٔ upstream مدل پیش‌فرض؛ برای آماده بودن خودکار Provider لازم است
- `*_MODEL_LABEL` — برچسب اختیاری مدل پیش‌فرض
- `*_VISION_MODEL` و `*_VISION_MODEL_LABEL` — فقط پس از تأیید قابلیت تصویر همان مدل

کلیدهای API در مرورگر خوانده یا ارسال نمی‌شوند. هیچ مقدار Secret داخل Wrangler، ZIP، Preview یا مستندات این نسخه قرار ندارد.

## محدودیت‌های کشف و قابلیت

- cache کشف ۹۰ ثانیه است؛ timeout برابر ۳٫۵ ثانیه، سقف body برابر ۹۶KB و حداکثر ۱۲۰ مدل بررسی می‌شوند.
- مدل‌های شناخته‌شدهٔ embedding، image، video، speech، audio، transcription، moderation و rerank از کاتالوگ چت کنار گذاشته می‌شوند.
- پشتیبانی tool calling یا vision صرفاً از وجود مدل در `/models` نتیجه‌گیری نمی‌شود؛ metadata صریح و تست عملی همان مدل ملاک فعال‌سازی قابلیت است.
- اگر درگاه کلید نداشته باشد، هیچ درخواست شبکه به endpoint مدل‌ها فرستاده نمی‌شود. اگر discovery شکست بخورد، مدل‌های پیش‌فرض/اپراتوری قابل‌اتکا حفظ می‌شوند و مدل‌های کشف‌نشده به‌صورت حدسی اضافه نمی‌شوند.

## وضعیت آزمون انتشار

تست‌های mock مسیر کشف و ارسال چت AvalAI/Hooshgar را بررسی می‌کنند؛ آن‌ها ثابت نمی‌کنند کلید واقعی، اعتبار حساب، موجود بودن یک مدل خاص، Function Calling یا vision در حساب کاربر فعال است. Smoke Test با Secret واقعی پس از تنظیم Worker لازم است.
