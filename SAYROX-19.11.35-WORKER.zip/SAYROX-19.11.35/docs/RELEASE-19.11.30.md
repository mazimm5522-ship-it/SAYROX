# SAYROX 19.11.30 — Security Hardening & Release Hygiene

## دامنهٔ تغییر

این به‌روزرسانی روی دفاع در عمقِ مرز RPC داخلی و کاهش سطح دسترسی عمومی سرویس‌های زیرساختی تمرکز دارد. مسیرهای اصلی چت، Agent، پرداخت، سهمیه، حافظه و زمان‌بندی بازنویسی نشده‌اند.

## ۱) RPC داخلی Worker حساب

- `auth-worker/src/request.js` یک خوانندهٔ مشترک JSON برای درخواست‌های داخلی Durable Object فراهم می‌کند.
- سقف بدنه ۱۶ KiB است؛ هم `Content-Length` و هم تعداد بایت واقعی stream بررسی می‌شود تا نبودن/دروغ‌بودن header محدودیت را دور نزند.
- فقط `application/json` و انواع `+json` پذیرفته می‌شوند.
- decode UTF-8 با حالت fatal انجام می‌شود؛ JSON خراب، بدنهٔ خالی، آرایه، `null` و مقادیر غیرآبجکت رد می‌شوند.
- `AccountObject` و `AuthRateLimiter` در صورت بدنهٔ نامعتبر، `400 INVALID_REQUEST_BODY` برمی‌گردانند؛ ورودی نامعتبر دیگر به `{}` تبدیل نمی‌شود.
- درخواست‌های داخلی موجود با `content-type: application/json` و payloadهای بسیار کوچک‌تر از سقف ادامه می‌یابند.

## ۲) کاهش سطح دسترسی Workerهای داخلی

در `auth-worker`، `billing-worker`، `usage-worker`، `tasks-worker` و `sandbox-worker` مقدار `workers_dev` برابر `false` است. این Workerها از طریق Durable Object binding / service binding موجود مصرف می‌شوند و برای عملکرد به URL عمومی `workers.dev` احتیاج ندارند. Worker اصلی `sayrox` همچنان `workers_dev: true` است تا رابط و API عمومی در دسترس بمانند.

## ۳) نظم فایل و انتشار

- helper ورودی RPC و تست مستقل آن در پوشهٔ مالکیت صحیح `auth-worker/` قرار گرفت.
- تست زیرساخت حالا غیرفعال بودن endpoint عمومی Workerهای داخلی را نیز کنترل می‌کند.
- `package.json`، `docs/quota-policy.json`، README، CHANGELOG، راهنمای زیرساخت، صفحهٔ «درباره»، و Service Worker با نسخهٔ `19.11.30` هماهنگ شدند.
- خروجی‌های تولیدی `site/src/app.js` و `site/_worker.js` باید فقط از سورس مرجع Build شوند؛ ویرایش دستی همچنان ممنوع است.

## ۴) سازگاری و داده

هیچ Durable Object class، Namespace، Binding، Secret، جدول، migration، دادهٔ حساب، رمز نشست، schema پرداخت یا D1 جدیدی اضافه نشده است. تغییر `workers_dev` فقط URL عمومی سرویس‌های داخلی را می‌بندد؛ اتصال داخلی از طریق bindingها حفظ می‌شود.

## ۵) اعتبارسنجی

تست محلی نهایی: **۲۰۰/۲۰۰ موفق**. این مجموعه شامل پذیرش JSON معتبر، رد JSON خراب، آرایه، null، body خالی، Content-Type نامعتبر، بدنهٔ بزرگ‌تر از سقف با و بدون Content-Length، UTF-8 نامعتبر و پیکربندی Workerهای خصوصی هستند. Build و تست کامل باید پیش از انتشار اجرا شوند.

Deploy واقعی، دسترسی Cloudflare و Smoke Test با Secrets واقعی در این محیط انجام نشده‌اند. SDK صوتی محلی نیز همچنان خروجی زمان Build است و نبود فایل آن در ZIP سورس به‌معنی فعال‌بودن Live Voice در Preview نیست.

## Rollback

برای Rollback کامل، بستهٔ `SAYROX-19.11.29-WORKER.zip` را به‌صورت یک مجموعه بازیابی کن. کدهای اصلی چت/Agent و داده‌های Durable Object بدون تغییر schema هستند. اگر Workerهای ذخیره‌سازی نسخهٔ 19.11.30 منتشر شده‌اند، می‌توانند با حفظ DO class و Namespace موجود بمانند؛ خاموش‌بودن `workers.dev` را برای آن‌ها نگه دار، مگر آنکه نیاز معماری مستند و مشخصی برای URL عمومی وجود داشته باشد. هیچ Durable Object، Namespace، SQLite یا داده‌ای را حذف نکن.
