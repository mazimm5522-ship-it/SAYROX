# SAYROX 19.11.34 — Pre-Deploy Stabilization

## هدف

این انتشار مرحلهٔ تثبیت پایه‌ها پیش از Deploy است. هیچ قابلیت محصولی یا سرویس موازی اضافه نمی‌کند؛ تمرکز روی باگ‌هایی است که تست‌های قبلی پوشش نمی‌دادند، صحت بستهٔ انتشار و وابستگی‌های مستقیمِ زنجیرهٔ ساخت.

## باگ‌ها و اصلاحات

### ۱) جلوگیری از خراب‌شدن App Shell آفلاین

- Service Worker قبلاً هر پاسخ موفق‌شده از `fetch()` را بدون بررسی status یا Content-Type در کلید `/` ذخیره می‌کرد؛ بنابراین پاسخ HTTP 404/500 یا محتوای غیر HTML می‌توانست آخرین نسخهٔ سالم آفلاین را جایگزین کند.
- اکنون فقط پاسخ دقیقاً `200` با Content-Type از نوع `text/html` جایگزین App Shell می‌شود.
- نوشتن Cache داخل Promise وابسته به `waitUntil` قرار گرفته تا عمر Fetch Event تا پایان عملیات حفظ شود.
- شکست Cache نباید پاسخ آنلاین کاربر را خراب کند؛ خطای شبکه همچنان به آخرین Shell cache‌شده fallback می‌کند.

### ۲) کامل‌کردن بررسی Assetهای محلی

- `verify-site.mjs` قبلاً همهٔ مسیرهای `/vendor/` را از بررسی وجود فایل معاف می‌کرد.
- اکنون فقط `vendor/elevenlabs-client.mjs` و فقط با پرچم توسعهٔ `--allow-missing-sdk` می‌تواند غایب باشد.
- هر Asset دیگر در `vendor/` مانند سایر فایل‌های محلی بررسی می‌شود؛ مسیر گم‌شده باید Verify را متوقف کند.

### ۳) سخت‌گیری در Origin زمان‌بندی

- `check-tasks-deploy.mjs` دقیقاً یک مقدار `APP_ORIGIN` می‌پذیرد.
- whitespace ابتدا/انتها، origin غیر canonical، پورت پیش‌فرض صریح، query، fragment، path، credentials و URL غیر HTTPS رد می‌شوند.
- تست‌های ورودی معتبر، HTTP، اسلش انتهایی، whitespace، پورت غیر canonical، query و کلید تکراری افزوده شدند.

## اصلاح وابستگی‌های امنیتی

- Deploy Kit: `fflate` از `0.8.2` به `0.8.3` ارتقا یافت. نسخه‌های تا قبل از 0.8.3 تحت CVE-2026-45820 در `unzipSync()` ممکن است با ZIP64 ناقص وارد حلقهٔ بی‌نهایت و DoS شوند. این مسیر در `deploy.mjs` برای استخراج آرشیو استفاده می‌شود.
- پروژهٔ اصلی: `esbuild` از `0.24.2` به `0.28.2` ارتقا یافت. GHSA-67mh-4wv8-2f99 نسخه‌های تا 0.24.2 را در dev server تحت تأثیر قرار می‌دهد و از 0.25.0 رفع شده؛ نسخهٔ 0.28.1 نیز اصلاحیهٔ امنیتی Windows dev server و integrity هنگام دریافت binary را دارد.
- `wrangler` روی نسخهٔ دقیق `4.158.0` باقی ماند؛ در بررسی نسخهٔ منتشرشدهٔ جاری، مورد مستقیم شناخته‌شده‌ای برای همین نسخه در گزارش بررسی‌شده دیده نشد. این گزاره اسکن زنجیرهٔ وابستگی‌های انتقالی نیست.
- SDK `@elevenlabs/client` بدون تغییر باقی ماند تا به‌روزرسانی غیرضروری و تأییدنشدهٔ قرارداد صوتی وارد این انتشار نشود.

## معماری، سازگاری و داده

هیچ Worker، Agent، Provider، Tool Loop، API، Durable Object، Binding، Secret، Namespace، جدول، schema، migration یا D1 تازه‌ای اضافه نشده است. SQLite، نشست‌ها، حساب‌ها، سهمیه، چت‌ها و داده‌های پایدار تغییر schema نداشته‌اند. Rollback کد به 19.11.33 نیازی به حذف یا تبدیل داده ندارد؛ اصلاح نسخه‌های امن `fflate` و `esbuild` را در Deploy Kit نگه دار.

## اعتبارسنجی

- تست‌های رگرسیون جدید برای چهار حالت Service Worker (HTML موفق، پاسخ خطا، محتوای غیر HTML/partial و fallback آفلاین) و اعتبارسنجی دقیق Origin اضافه شدند.
- اجرای تازهٔ `npm test`: **۲۱۹/۲۱۹ موفق**؛ `npm run build:code` و `npm run verify:dev` نیز موفق شدند و ۶۲ فایل سایت تأیید شدند.
- `esbuild` و `fflate` به نسخهٔ patch‌شده در manifestها pin شده‌اند؛ اما رجیستری npm در محیط این ساخت DNS failure داد، بنابراین نصب واقعی پکیج‌های جدید، Build SDK صوتی و npm audit کامل قابل اجرا نبود و lockfile تولید نشد.
- Deploy واقعی Cloudflare، Dry Runهای Wrangler و Smoke Test با Secretهای حساب کاربر در این محیط انجام نشده‌اند.

## محدودیت‌های باقی‌مانده پیش از Deploy

1. اتصال رجیستری npm و تولید lockfile یکپارچه برای دو manifest.
2. اجرای Build کامل شامل `build:voice-sdk` در محیط دارای registry.
3. اجرای `npm audit`/اسکن انتقالی روی lockfile تولیدشده.
4. اجرای Deploy Dry Run تمام شش Worker و سپس Smoke Test حساب، مدل، SSE، زمان‌بندی و مسیرهای امنیتی در Cloudflare Preview.
5. بررسی بصری Android/Chrome، حالت آفلاین واقعی و screen reader.
