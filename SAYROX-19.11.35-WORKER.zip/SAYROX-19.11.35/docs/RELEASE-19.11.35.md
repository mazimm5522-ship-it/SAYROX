# SAYROX 19.11.35 — Cloudflare Container Deploy Fix

## علت خطای Deploy

لاگ Workers Builds نشان می‌داد Wrangler در حال پردازش `sandbox-worker/wrangler.jsonc` فیلد `max_instances` را در بخش `containers` رد می‌کند. بررسی تنظیمات نشان داد Container موجود از `scheduling_policy: "durable_object"` استفاده می‌کند. بر اساس مستندات Cloudflare، این سیاست فقط فیلدهای محدود شامل `name`، `class_name`، `scheduling_policy`، `images`، `observability`، `ssh`، `authorized_keys` و تنظیمات محدود `unsafe` را می‌پذیرد؛ `max_instances` جزو این فهرست نیست.

## اصلاح انجام‌شده

- `max_instances: 10` از `sandbox-worker/wrangler.jsonc` حذف شد.
- سیاست `durable_object`، نام Worker `sayrox-code-sandbox-preview`، کلاس `CodeSandbox`، binding `CODE_SANDBOX`، export با SQLite، named image `python`، Dockerfile و build context حفظ شدند.
- هیچ Container application جدیدی ساخته نشده و سیاست زمان‌بندی تغییر نکرده است. این مهم است چون scheduling policy برای Container application موجود immutable است.
- `scripts/check-sandbox-deploy.mjs` به‌عنوان کنترل مشترک اضافه شد. این اسکریپت هم ساختار config و هم مسیر Dockerfile/context و تطابق Binding/SQLite را قبل از Deploy بررسی می‌کند.
- فرمان `predeploy:sandbox` اضافه شد تا Deploy مستقیم Sandbox نیز همین Preflight را اجرا کند.
- Deploy Kit اکنون همین اسکریپت مشترک را اجرا می‌کند و از تکرار منطق اعتبارسنجی در دو محل جلوگیری می‌شود.
- تست رگرسیون، config سالم را می‌پذیرد و fixture دارای `max_instances` را با پیام مشخص رد می‌کند.

## محدودیت ظرفیت

Cloudflare `max_instances` را برای `durable_object` scheduling policy پشتیبانی نمی‌کند؛ instanceهای فعال تابع محدودیت‌های حساب هستند. این نسخه سقف اختصاصی ۱۰ instance را حفظ یا تضمین نمی‌کند. اگر سقف اختصاصی محصول لازم باشد، باید کنترل concurrency برنامه‌ای با مدل هماهنگی و تست بار طراحی شود. تغییر Container به `default` scheduling policy یک مهاجرت مستقل است و در این hotfix انجام نشده است.

## اعتبارسنجی

در این محیط، Preflight Sandbox موفق است؛ تست مثبت/منفی config پوشش داده شد؛ **۲۲۰ تست از ۲۲۰ تست** موفق شدند؛ `npm run build:code` موفق شد و `npm run verify:dev` تعداد ۶۲ فایل را با نسخهٔ 19.11.35 تأیید کرد. اجرای واقعی `wrangler deploy --dry-run` در این نشست ممکن نشد، چون Wrangler در بستهٔ ورودی نصب نبود و DNS دسترسی به `registry.npmjs.org` خطای `EAI_AGAIN` داد. بنابراین این سند ادعای Dry Run واقعی یا Deploy موفق نمی‌کند. Workers Builds پس از نصب پکیج pin‌شدهٔ Wrangler باید Dry Run شش Worker را اجرا کند؛ در صورت خطای بعدی باید لاگ تازه را بررسی کرد.

## Rollback

برای بازگشت کد محصول به 19.11.34، فایل‌های برنامه و Worker را از بستهٔ قبلی برگردانید، اما در `sandbox-worker/wrangler.jsonc`، Preflight و Deploy Kit فیلد `max_instances` را نگه ندارید. تغییر سیاست زمان‌بندی یا حذف/ساخت مجدد Container، Namespace یا Durable Object بخشی از Rollback این نسخه نیست.
