# SAYROX 19.11.27 — Agent Response Craft & Visual Quality

## خلاصه

این Update 8 موتور پاسخ‌گویی یا Renderer جدید نمی‌سازد؛ راهنمای نگارش Provider موجود، parser مشترک Markdown، renderer فعلی، CSS تم‌محور و مصرف‌کنندهٔ DOCX/HTML را تقویت می‌کند.

## تغییرات

- راهنمای پاسخ در `worker/providers/chat.js` دقیق‌تر شد: انتخاب قالب متناسب با نوع درخواست، استفادهٔ درست از تیتر/فهرست/جدول/فرمول، محدودکردن emoji، بازبینی پیش از ارسال و گزارش صادقانهٔ موفقیت/شکست.
- `site/src/features/files/markdown.js` calloutهای معنایی، نشان وضعیت درون‌خطی، task-list و metadata هم‌ترازی ستون‌های جدول را به parser مشترک موجود افزود.
- `site/src/core/response-renderer.js` همان metadata را به DOM امن و قابل‌دسترس تبدیل می‌کند؛ کلاس‌ها و رنگ‌ها فقط از مقادیر ثابت انتخاب می‌شوند.
- `site/src/styles/response-rendering.css` badgeها، calloutها، نمادها، جدول راه‌راه/قابل‌پیمایش و چک‌لیست را با tokenهای تم تیره/روشن نمایش می‌دهد.
- خروجی HTML و DOCX از parser مشترک، محتوا را بدون syntax خام و بدون از دست‌دادن وضعیت چک‌لیست/callout حفظ می‌کند.

## Syntax برای مدل و تست‌کننده

```markdown
✅ بررسی نهایی انجام شد.

[[status:success|تأییدشده]] [[status:warning|نیازمند بررسی]]

> [!WARNING] پیش از انتشار
> Origin واقعی را در Cloudflare تنظیم کن.

- [x] تست‌ها موفق شدند
- [ ] Preview زنده بررسی شود

| مورد | وضعیت | توضیح |
| :--- | :---: | ---: |
| رندر | آماده | ۱۰۰٪ |
```

## معنای رنگ‌ها

- سبز: موفقیت واقعی/تأییدشده یا کار تکمیل‌شده.
- زرد: هشدار، نیاز به بررسی یا پیش‌نیاز.
- قرمز: شکست، خطر یا مورد مسدودکننده.
- آبی/بنفش: اطلاعات، نکتهٔ مهم یا تأکید.
- خنثی: وضعیت نامشخص یا غیرقطعی.

رنگ badge فقط یک نشانهٔ بصری است؛ خودش وضعیت عملیات را اثبات نمی‌کند. Prompt نیز مدل را از گزارش موفقیت بدون شاهد منع می‌کند.

## فایل‌های تغییرکردهٔ اصلی

- `worker/providers/chat.js`
- `site/src/features/files/markdown.js`
- `site/src/core/response-renderer.js`
- `site/src/styles/response-rendering.css`
- `site/src/features/files/documents.js`
- `tests/response-rendering.test.mjs`
- `tests/document-management.test.mjs`
- `tests/infrastructure.test.mjs`

## معماری و rollback

هیچ D1، ذخیره‌ساز، API، Worker، Binding، Secret، DO class یا migration جدیدی وجود ندارد. برای بازگشت، Worker اصلی و Static Assets را با نسخهٔ 19.11.26 به‌صورت هماهنگ جایگزین کن؛ `site/sw.js` نیز باید از همان نسخه بازگردد تا cache قدیمی بازسازی شود. هیچ داده یا Durable Object را حذف نکن.

## تأیید

تست‌های محلی و `verify:dev` باید پیش از انتشار اجرا شوند. Preview بصری Android/Chrome و screen-reader هنوز آزمون دستی لازم دارد؛ Deploy واقعی با این بسته انجام نشده است.
