import { DurableObject } from "cloudflare:workers";
import {
  readBoundedText,
  verifyInternalSignature,
  validateExecutionPayload,
  readProcessStreamLimited
} from "./security.mjs";

const INACTIVITY_TIMEOUT_MS = 60_000;
const JOB_REPLAY_WINDOW_MS = 120_000;
const PYTHON_TIMEOUT_SECONDS = 8;
const PYTHON_RUNNER = [
  "import json, os, pathlib, resource, shutil, sys",
  "limits = ((resource.RLIMIT_CPU, 7, 8), (resource.RLIMIT_AS, 268435456, 268435456), (resource.RLIMIT_FSIZE, 1048576, 1048576), (resource.RLIMIT_NOFILE, 32, 32), (resource.RLIMIT_NPROC, 16, 16), (resource.RLIMIT_CORE, 0, 0))",
  "[resource.setrlimit(kind, (soft, hard)) for kind, soft, hard in limits]",
  "os.umask(0o077)",
  "request = json.loads(sys.stdin.read())",
  "input_dir = '/workspace/input'",
  "shutil.rmtree(input_dir, ignore_errors=True)",
  "os.makedirs(input_dir, mode=0o700, exist_ok=True)",
  "[pathlib.Path(os.path.join(input_dir, 'document_%d.txt' % (index + 1))).write_text(item['text'], encoding='utf-8') for index, item in enumerate(request.get('files', []))]",
  "source = request['code']",
  "scope = {'__name__': '__main__', '__file__': '<sayrox-user-code>'}",
  "exec(compile(source, '<sayrox-user-code>', 'exec'), scope, scope)"
].join('; ');

function json(body, status = 200) {
  return Response.json(body, {
    status,
    headers: { "cache-control": "no-store", "x-content-type-options": "nosniff" }
  });
}

export class CodeSandbox extends DurableObject {
  async runPython(code, files = []) {
    const claimed = await this.ctx.storage.transaction(async transaction => {
      if (await transaction.get("job-consumed")) return false;
      await transaction.put("job-consumed", Date.now());
      return true;
    });
    if (!claimed) throw new Error("SANDBOX_JOB_REPLAYED");
    try { await this.ctx.storage.setAlarm(Date.now() + JOB_REPLAY_WINDOW_MS); } catch { }

    const container = this.ctx.container;
    if (!container) throw new Error("SANDBOX_CONTAINER_UNAVAILABLE");
    if (!container.running) {
      container.start({
        image: container.images.python,
        instance: "lite",
        entrypoint: ["sleep", "infinity"],
        enableInternet: false
      });
      await container.setInactivityTimeout(INACTIVITY_TIMEOUT_MS);
    }

    const requestBody = JSON.stringify({ code, files: Array.isArray(files) ? files : [] });
    const process = await container.exec([
      "timeout", "--signal=TERM", "--kill-after=2", String(PYTHON_TIMEOUT_SECONDS),
      "python3", "-I", "-B", "-c", PYTHON_RUNNER
    ], {
      stdin: new Response(requestBody).body,
      cwd: "/workspace"
    });

    const state = { total: 0, truncated: false };
    const kill = () => { try { process.kill(); } catch { } };
    const [stdout, stderr, exitCode] = await Promise.all([
      readProcessStreamLimited(process.stdout, state, kill),
      readProcessStreamLimited(process.stderr, state, kill),
      process.exitCode
    ]);
    return {
      stdout, stderr, exitCode,
      outputTruncated: state.truncated,
      timedOut: exitCode === 124 || exitCode === 137,
      runtime: "python-3.13"
    };
  }

  async alarm() {
    await this.ctx.storage.delete("job-consumed");
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname !== "/internal/execute" || request.method !== "POST") return new Response("Not found", { status: 404 });
    if (typeof env.SAYROX_INTERNAL_SECRET !== "string" || env.SAYROX_INTERNAL_SECRET.length < 32) {
      return json({ ok: false, code: "SANDBOX_NOT_CONFIGURED", message: "سرویس Sandbox پیکربندی نشده است." }, 503);
    }
    const timestamp = request.headers.get("x-sayrox-timestamp") || "";
    const signature = request.headers.get("x-sayrox-signature") || "";
    let rawBody;
    try { rawBody = await readBoundedText(request); }
    catch (error) {
      const tooLarge = error?.message === "REQUEST_TOO_LARGE";
      return json({ ok: false, code: tooLarge ? "REQUEST_TOO_LARGE" : "INVALID_REQUEST" }, tooLarge ? 413 : 400);
    }
    if (!await verifyInternalSignature(env.SAYROX_INTERNAL_SECRET, timestamp, rawBody, signature)) {
      return json({ ok: false, code: "INTERNAL_AUTH_FAILED", message: "درخواست داخلی معتبر نیست." }, 401);
    }
    let parsed;
    try { parsed = JSON.parse(rawBody); }
    catch { return json({ ok: false, code: "INVALID_JSON" }, 400); }
    const validated = validateExecutionPayload(parsed);
    if (!validated.ok) return json({ ok: false, code: validated.code }, 400);
    if (!env.CODE_SANDBOX || typeof env.CODE_SANDBOX.getByName !== "function") {
      return json({ ok: false, code: "SANDBOX_BINDING_UNAVAILABLE" }, 503);
    }
    try {
      const sandbox = env.CODE_SANDBOX.getByName(validated.payload.jobId);
      const result = await sandbox.runPython(validated.payload.code, validated.payload.files || []);
      return json({ ok: true, result });
    } catch (error) {
      const code = error?.message === "SANDBOX_JOB_REPLAYED" ? "SANDBOX_JOB_REPLAYED" : "SANDBOX_EXECUTION_FAILED";
      const status = code === "SANDBOX_JOB_REPLAYED" ? 409 : 502;
      return json({ ok: false, code, message: code === "SANDBOX_JOB_REPLAYED" ? "این اجرای Sandbox قبلاً مصرف شده است." : "اجرای کد در محیط ایزوله ناموفق بود." }, status);
    }
  }
};
