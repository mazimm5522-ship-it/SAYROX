export const MAX_REQUEST_BYTES = 360_000;
export const MAX_CODE_CHARS = 8_000;
export const MAX_DOCUMENTS = 2;
export const MAX_DOCUMENT_CHARS = 60_000;
export const MAX_TOTAL_DOCUMENT_CHARS = 100_000;
export const MAX_DOCUMENT_BYTES = 300_000;
export const MAX_OUTPUT_BYTES = 24_000;
export const MAX_CLOCK_SKEW_MS = 60_000;

const encoder = new TextEncoder();

export async function readBoundedText(request, maxBytes = MAX_REQUEST_BYTES) {
  if (!request.body) return "";
  const reader = request.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maxBytes) {
        await reader.cancel("body_too_large").catch(() => {});
        throw new Error("REQUEST_TOO_LARGE");
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const combined = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { combined.set(chunk, offset); offset += chunk.byteLength; }
  return new TextDecoder("utf-8", { fatal: true }).decode(combined);
}

function decodeBase64Url(value) {
  if (typeof value !== "string" || !/^[A-Za-z0-9_-]{43}$/.test(value)) return null;
  try {
    const base64 = value.replace(/-/g, "+").replace(/_/g, "/") + "=";
    const binary = atob(base64);
    const bytes = Uint8Array.from(binary, char => char.charCodeAt(0));
    return bytes.byteLength === 32 ? bytes : null;
  } catch { return null; }
}

export async function verifyInternalSignature(secret, timestamp, rawBody, signature) {
  if (typeof secret !== "string" || secret.length < 32) return false;
  if (!/^\d{13}$/.test(String(timestamp || ""))) return false;
  const parsedTimestamp = Number(timestamp);
  if (!Number.isSafeInteger(parsedTimestamp) || Math.abs(Date.now() - parsedTimestamp) > MAX_CLOCK_SKEW_MS) return false;
  const signatureBytes = decodeBase64Url(signature);
  if (!signatureBytes) return false;
  try {
    const key = await crypto.subtle.importKey("raw", encoder.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["verify"]);
    return await crypto.subtle.verify("HMAC", key, signatureBytes, encoder.encode(`${timestamp}.${rawBody}`));
  } catch { return false; }
}

export function validateExecutionPayload(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return { ok: false, code: "INVALID_PAYLOAD" };
  const keys = Object.keys(value);
  if (keys.some(key => !["version", "jobId", "language", "code", "files"].includes(key))) return { ok: false, code: "INVALID_PAYLOAD" };
  if (value.version !== 1 || value.language !== "python") return { ok: false, code: "UNSUPPORTED_RUNTIME" };
  if (typeof value.jobId !== "string" || !/^[a-f0-9]{64}$/.test(value.jobId)) return { ok: false, code: "INVALID_JOB_ID" };
  if (typeof value.code !== "string" || !value.code.trim() || value.code.length > MAX_CODE_CHARS || encoder.encode(value.code).byteLength > 12_000) return { ok: false, code: "INVALID_CODE" };
  const files = [];
  if (value.files !== undefined) {
    if (!Array.isArray(value.files) || value.files.length < 1 || value.files.length > MAX_DOCUMENTS) return { ok: false, code: "INVALID_FILES" };
    let totalChars = 0;
    let totalBytes = 0;
    for (const file of value.files) {
      if (!file || typeof file !== "object" || Array.isArray(file)
          || Object.keys(file).some(key => !["name", "text"].includes(key))
          || typeof file.name !== "string" || !file.name.trim() || file.name.length > 180
          || /[\\/\u0000-\u001f\u007f]/.test(file.name)
          || typeof file.text !== "string" || !file.text.trim() || file.text.length > MAX_DOCUMENT_CHARS) {
        return { ok: false, code: "INVALID_FILES" };
      }
      const byteLength = encoder.encode(file.text).byteLength;
      totalChars += file.text.length;
      totalBytes += byteLength;
      if (totalChars > MAX_TOTAL_DOCUMENT_CHARS || totalBytes > MAX_DOCUMENT_BYTES) return { ok: false, code: "FILES_TOO_LARGE" };
      files.push({ name: file.name, text: file.text });
    }
  }
  return { ok: true, payload: { version: 1, jobId: value.jobId, language: "python", code: value.code, ...(files.length ? { files } : {}) } };
}

export async function readProcessStreamLimited(stream, sharedState, killProcess) {
  if (!stream || typeof stream.getReader !== "function") return "";
  const reader = stream.getReader();
  const chunks = [];
  let length = 0;
  try {
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      const remaining = Math.max(0, MAX_OUTPUT_BYTES - sharedState.total);
      const accepted = value.byteLength > remaining ? value.subarray(0, remaining) : value;
      if (accepted.byteLength) {
        chunks.push(accepted);
        length += accepted.byteLength;
        sharedState.total += accepted.byteLength;
      }
      if (accepted.byteLength < value.byteLength) {
        sharedState.truncated = true;
        try { killProcess?.(); } catch { }
        await reader.cancel("output_limit_reached").catch(() => {});
        break;
      }
    }
  } finally {
    try { reader.releaseLock(); } catch { }
  }
  const combined = new Uint8Array(length);
  let offset = 0;
  for (const chunk of chunks) { combined.set(chunk, offset); offset += chunk.byteLength; }
  return new TextDecoder().decode(combined);
}
