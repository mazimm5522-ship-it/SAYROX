// Validate the existing Python Sandbox Container against Cloudflare's
// Durable Object scheduling-policy schema before any Wrangler dry-run/deploy.
import { readFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const defaultRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const root = path.resolve(process.argv[2] || defaultRoot);
const configDir = path.join(root, 'sandbox-worker');
const configPath = path.join(configDir, 'wrangler.jsonc');

function stop(message) {
  console.error(`sandbox deploy blocked: ${message}`);
  process.exit(1);
}

if (!existsSync(configPath)) stop('sandbox-worker/wrangler.jsonc is missing.');
let config;
try { config = JSON.parse(readFileSync(configPath, 'utf8')); }
catch { stop('sandbox-worker/wrangler.jsonc must be valid JSON (JSONC comments are not used in this file).'); }

if (config.name !== 'sayrox-code-sandbox-preview') stop('Sandbox Worker name must remain sayrox-code-sandbox-preview.');
if (config.workers_dev !== false) stop('Sandbox is internal-only and must keep workers_dev=false.');
if (config.main !== 'src/index.js' || !existsSync(path.join(configDir, config.main))) stop('Sandbox main entrypoint is missing or unexpected.');
if (!Array.isArray(config.containers) || config.containers.length !== 1) stop('Exactly one existing Durable Object-managed Sandbox Container is required.');

const container = config.containers[0];
if (container.class_name !== 'CodeSandbox' || container.scheduling_policy !== 'durable_object') {
  stop('Existing Sandbox must preserve class CodeSandbox with scheduling_policy=durable_object.');
}
const allowedContainerFields = new Set([
  'name', 'class_name', 'scheduling_policy', 'images', 'observability', 'ssh', 'authorized_keys', 'unsafe'
]);
const unsupported = Object.keys(container).filter(key => !allowedContainerFields.has(key));
if (unsupported.length) {
  const hint = unsupported.includes('max_instances')
    ? ' max_instances is unsupported for scheduling_policy=durable_object; it is only available with scheduling_policy=default.'
    : '';
  stop(`Unsupported Container field(s): ${unsupported.join(', ')}.${hint}`);
}

if (!container.images || typeof container.images !== 'object' || Array.isArray(container.images)
    || Object.keys(container.images).length !== 1 || !container.images.python) {
  stop('The existing named image images.python must remain configured.');
}
const image = container.images.python;
if (!image || typeof image !== 'object' || Array.isArray(image)
    || Object.keys(image).some(key => !['dockerfile', 'image', 'build_context', 'build_vars'].includes(key))) {
  stop('images.python contains unsupported fields.');
}
const hasDockerfile = typeof image.dockerfile === 'string' && image.dockerfile.length > 0;
const hasImageRef = typeof image.image === 'string' && image.image.length > 0;
if (hasDockerfile === hasImageRef) stop('images.python must declare exactly one of dockerfile or image.');
if (hasDockerfile) {
  const dockerfile = path.resolve(configDir, image.dockerfile);
  const context = path.resolve(configDir, image.build_context ?? path.dirname(image.dockerfile));
  const withinConfigDir = candidate => candidate === configDir || candidate.startsWith(`${configDir}${path.sep}`);
  if (!withinConfigDir(dockerfile) || !withinConfigDir(context)) stop('Dockerfile and build_context must remain inside sandbox-worker/.');
  if (!existsSync(dockerfile) || !existsSync(context)) stop('Sandbox Dockerfile or image build_context does not exist.');
} else if (!/@sha256:[a-f0-9]{64}$/i.test(image.image)) {
  stop('Durable Object-managed registry images must be pinned by sha256 digest.');
}

const binding = config.durable_objects?.bindings?.find(item => item.name === 'CODE_SANDBOX');
if (!binding || binding.class_name !== 'CodeSandbox') stop('CODE_SANDBOX binding must point to CodeSandbox.');
if (config.exports?.CodeSandbox?.type !== 'durable-object' || config.exports.CodeSandbox.storage !== 'sqlite') {
  stop('CodeSandbox must remain exported as a SQLite Durable Object.');
}
if (config.d1_databases !== undefined) stop('D1 is not part of this Sandbox architecture.');

console.log('Sandbox deploy config OK — Durable Object policy, supported fields, Python image, Dockerfile, binding and SQLite export verified.');
