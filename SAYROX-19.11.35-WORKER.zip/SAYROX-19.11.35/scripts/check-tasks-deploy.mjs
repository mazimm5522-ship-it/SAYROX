// Deployment guard: the Scheduler Worker must never be published with its template origin.
// Configure APP_ORIGIN in tasks-worker/wrangler.jsonc before `npm run deploy:tasks`.
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';

const root = fileURLToPath(new URL('..', import.meta.url));
const configPath = join(root, 'tasks-worker/wrangler.jsonc');
const config = await readFile(configPath, 'utf8');
const matches = [...config.matchAll(/"APP_ORIGIN"\s*:\s*"([^"]+)"/g)];

function stop(message) {
  console.error(`tasks deploy blocked: ${message}`);
  process.exit(1);
}

if (matches.length !== 1) stop('tasks-worker/wrangler.jsonc must contain exactly one vars.APP_ORIGIN entry.');
const value = matches[0][1];
if (!value || value.trim() !== value || /REPLACE|YOUR-|example\.com/i.test(value)) {
  stop('replace the APP_ORIGIN template with the exact HTTPS SAYROX Worker origin before deployment.');
}
let origin;
try { origin = new URL(value); }
catch { stop('APP_ORIGIN is not a valid URL.'); }
if (origin.protocol !== 'https:' || origin.username || origin.password || origin.pathname !== '/' || origin.search || origin.hash || value.endsWith('/')) {
  stop('APP_ORIGIN must be an HTTPS origin only (no path, query, fragment, credentials, or trailing slash).');
}
if (origin.origin !== value) stop('APP_ORIGIN must use its canonical origin spelling without whitespace or a non-canonical port.');
console.log(`tasks deploy config OK — APP_ORIGIN=${origin.origin}`);
