// Pre-deploy gate: fails (exit 1) if the deployable folder `site/` is inconsistent or out of sync with its sources
// (app/*.js -> site/src/app.js, worker/**/*.js -> site/_worker.js).
//   node scripts/verify-site.mjs                    -> production gate (local voice SDK bundle required)
//   node scripts/verify-site.mjs --allow-missing-sdk -> development check
import { readFile, readdir, stat } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { join, relative, extname, dirname, resolve, sep, isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('..', import.meta.url));
const site = join(root, 'site');
const allowMissingSdk = process.argv.includes('--allow-missing-sdk');
const errors = [];
const fail = message => errors.push(message);

async function walk(dir) {
  const out = [];
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    const path = join(dir, entry.name);
    if (entry.isDirectory()) out.push(...await walk(path));
    else out.push(path);
  }
  return out;
}

const pkg = JSON.parse(await readFile(join(root, 'package.json'), 'utf8'));
const files = await walk(site);
const rel = file => relative(site, file).split('\\').join('/');
const bundle = join(site, 'vendor/elevenlabs-client.mjs');

// 1) Only deployable assets live in site/ (no docs, tests, worker sources, archives).
const allowedTop = new Set(['.assetsignore', '_headers', '_worker.js', 'icon.svg', 'index.html', 'manifest.json', 'src', 'sw.js', 'vendor']);
for (const entry of await readdir(site)) if (!allowedTop.has(entry)) fail(`site/${entry}: not allowed in the deployable folder`);
for (const file of files) if (/\.(md|zip|test\.mjs|map)$/i.test(file)) fail(`site/${rel(file)}: must not be deployed`);

// 1b) Generated files must match their sources (no hand-edits, no stale builds).
for (const script of ['build-app.mjs', 'build-worker.mjs']) {
  try { execFileSync(process.execPath, [join(root, 'scripts', script), '--check'], { stdio: 'pipe' }); }
  catch (error) { fail(`${script} --check: ${String(error.stderr || error.stdout || error.message).trim()}`); }
}
for (const part of (await readdir(join(root, 'app'))).filter(name => name.endsWith('.js'))) {
  try { execFileSync(process.execPath, ['--check', join(root, 'app', part)], { stdio: 'pipe' }); }
  catch (error) { fail(`app/${part}: syntax error — ${String(error.stderr || error.message).split('\n')[0]}`); }
}

// 2) JavaScript syntax (separate processes so one bad file cannot hide another).
for (const file of files.filter(f => ['.js', '.mjs'].includes(extname(f)) && !rel(f).startsWith('vendor/'))) {
  try { execFileSync(process.execPath, ['--check', file], { stdio: 'pipe' }); }
  catch (error) { fail(`site/${rel(file)}: syntax error — ${String(error.stderr || error.message).split('\n')[0]}`); }
}
// Check source files too, not only generated artifacts. This catches a broken module
// before a bundler or runtime obscures which original file introduced it.
for (const sourceDir of ['worker', 'usage-worker', 'billing-worker', 'tasks-worker', 'voice-sdk', 'scripts']) {
  const sourceFiles = await walk(join(root, sourceDir));
  for (const file of sourceFiles.filter(f => ['.js', '.mjs'].includes(extname(f)))) {
    try { execFileSync(process.execPath, ['--check', file], { stdio: 'pipe' }); }
    catch (error) { fail(`${relative(root, file)}: syntax error — ${String(error.stderr || error.message).split('\n')[0]}`); }
  }
}
const html = await readFile(join(site, 'index.html'), 'utf8');
// index.html is markup only: all logic lives in files (keeps the page cacheable and CSP-ready).
if (/<script(?![^>]*\bsrc=)[^>]*>/.test(html)) fail('index.html contains an inline <script>; put the code in app/*.js');

// 3) Validate the local asset graph: HTML, the service worker, and CSS url()/@import
// references. A broken nested CSS asset is otherwise easy to miss in a successful build.
const refs = new Set();
const htmlRefs = new Set();
for (const match of html.matchAll(/\b(?:src|href)="([^"#?:]+)"/g)) {
  const ref = match[1].startsWith('/') ? match[1] : `/${match[1]}`;
  refs.add(ref);
  htmlRefs.add(ref);
}
const sw = await readFile(join(site, 'sw.js'), 'utf8');
const swRefs = new Set([...sw.matchAll(/'(\/[^'?#]*)'/g)].map(match => match[1]));
for (const ref of swRefs) refs.add(ref);
const isInsideSite = file => {
  const path = relative(site, file);
  return path !== '..' && !path.startsWith(`..${sep}`) && !isAbsolute(path);
};
const checkLocalAsset = (rawReference, fromFile, label) => {
  const value = String(rawReference || '').trim().replace(/^(['"])(.*)\1$/, '$2');
  if (!value || value.startsWith('#') || /^(?:data:|https?:|wss?:|blob:|mailto:|tel:|javascript:|\/\/)/i.test(value)) return;
  const clean = value.split(/[?#]/, 1)[0];
  if (!clean) return;
  let decoded = clean;
  try { decoded = decodeURIComponent(clean); } catch { fail(`${label}: malformed URL encoding: ${value}`); return; }
  const target = decoded.startsWith('/') ? resolve(site, `.${decoded}`) : resolve(dirname(fromFile), decoded);
  if (!isInsideSite(target)) { fail(`${label}: asset escapes site/: ${value}`); return; }
  if (!existsSync(target)) fail(`${label}: missing local asset ${value}`);
};
for (const ref of refs) {
  if (ref === '/' || ref.startsWith('/api/')) continue;
  // Only the voice SDK is an optional build artifact. Other vendor references
  // must resolve like every other first-party asset or a broken deploy can pass.
  if (ref === '/vendor/elevenlabs-client.mjs' && allowMissingSdk && !existsSync(bundle)) continue;
  checkLocalAsset(ref, join(site, 'index.html'), 'HTML/service worker');
}
for (const file of files.filter(file => extname(file).toLowerCase() === '.css')) {
  const css = await readFile(file, 'utf8');
  for (const match of css.matchAll(/url\(\s*(?:"([^"]*)"|'([^']*)'|([^)]*?))\s*\)/gi)) {
    checkLocalAsset(match[1] ?? match[2] ?? match[3], file, `site/${rel(file)} CSS url()`);
  }
  for (const match of css.matchAll(/@import\s+(?:url\(\s*)?(?:"([^"]+)"|'([^']+)')/gi)) {
    checkLocalAsset(match[1] ?? match[2], file, `site/${rel(file)} CSS @import`);
  }
}
// The HTML's first-party scripts and styles must be in the offline shell cache.
for (const ref of htmlRefs) {
  if (/\.(?:js|css)$/i.test(ref) && !swRefs.has(ref)) fail(`service worker does not precache HTML asset: ${ref}`);
}

// 4) One version everywhere.
const cache = sw.match(/sayrox-shell-v([0-9.]+)/)?.[1];
if (cache !== pkg.version) fail(`sw.js cache version ${cache} != package.json ${pkg.version}`);
const about = await readFile(join(site, 'src/features/settings/pages/other.js'), 'utf8');
if (!about.includes(`>${pkg.version}<`)) fail(`settings "about" page does not show version ${pkg.version}`);

const readme = await readFile(join(root, 'README.md'), 'utf8');
if (!readme.split('\n')[0].includes(pkg.version)) fail(`README.md title does not show version ${pkg.version}`);

// 5) Local live-voice SDK bundle.
if (!existsSync(bundle)) {
  (allowMissingSdk ? console.warn : fail)('site/vendor/elevenlabs-client.mjs is missing — run `npm run build:voice-sdk` (Live Voice stays disabled without it)');
} else {
  const text = await readFile(bundle, 'utf8');
  const { size } = await stat(bundle);
  if (size < 50_000 || !text.includes('startSession') || !/export\s*\{[^}]*\bConversation\b/.test(text)) fail('site/vendor/elevenlabs-client.mjs does not look like the official SDK bundle (export Conversation / startSession)');
}

if (errors.length) {
  console.error(`verify FAILED (${errors.length}):\n- ${errors.join('\n- ')}`);
  process.exit(1);
}
console.log(`verify OK — ${files.length} files, version ${pkg.version}${existsSync(bundle) ? ', voice SDK present' : ' (voice SDK not built)'}`);
