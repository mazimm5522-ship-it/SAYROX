// Safe ChatGPT-style response renderer for SAYROX.
// Reuses the shared Markdown block parser and the existing code workspace.
(function installSayroxResponseRenderer(root) {
  'use strict';

  const MATH_NS = 'http://www.w3.org/1998/Math/MathML';
  const GREEK = Object.freeze({
    alpha:'α', beta:'β', gamma:'γ', delta:'δ', epsilon:'ε', theta:'θ', lambda:'λ', mu:'μ',
    pi:'π', sigma:'σ', phi:'φ', omega:'ω', Gamma:'Γ', Delta:'Δ', Theta:'Θ', Lambda:'Λ',
    Pi:'Π', Sigma:'Σ', Phi:'Φ', Omega:'Ω'
  });
  const SYMBOLS = Object.freeze({
    times:'×', cdot:'·', pm:'±', mp:'∓', div:'÷', le:'≤', leq:'≤', ge:'≥', geq:'≥',
    neq:'≠', ne:'≠', approx:'≈', sim:'∼', infty:'∞', partial:'∂', nabla:'∇',
    sum:'∑', prod:'∏', int:'∫', rightarrow:'→', leftarrow:'←', leftrightarrow:'↔',
    to:'→', mapsto:'↦', ell:'ℓ', degree:'°', percent:'%'
  });

  function safeUrl(value) {
    try {
      const url = new URL(String(value), root.location?.href || 'https://sayrox.invalid/');
      return ['http:', 'https:', 'mailto:'].includes(url.protocol) && !url.username && !url.password ? url.href : null;
    } catch { return null; }
  }

  function appendText(parent, value) {
    if (!value) return;
    const source=String(value);
    const tokens=root.SayroxMarkdown?.tokenizeNumbers?.(source);
    if(!Array.isArray(tokens)){parent.appendChild(root.document.createTextNode(source));return;}
    for(const token of tokens){
      if(token.type!=='number'){
        if(token.value)parent.appendChild(root.document.createTextNode(token.value));
        continue;
      }
      const number=root.document.createElement('span');
      number.className=`sayrox-number is-${STATUS_TONES[token.tone]?token.tone:'info'}`;
      number.setAttribute('dir','ltr');
      number.setAttribute('data-number-tone',STATUS_TONES[token.tone]?token.tone:'info');
      number.textContent=token.value;
      parent.appendChild(number);
    }
  }

  function mathNode(tag, text) {
    const node = root.document.createElementNS(MATH_NS, tag);
    if (text !== undefined) node.textContent = String(text);
    node.setAttribute('data-sayrox-math-node', tag);
    return node;
  }

  function renderMath(source, display = false) {
    const input = String(source ?? '').slice(0, 1200);
    const rootMath = mathNode('math');
    rootMath.setAttribute('display', display ? 'block' : 'inline');
    rootMath.setAttribute('role', 'math');
    rootMath.setAttribute('aria-label', input.replace(/\\([A-Za-z]+)/g, '$1').slice(0, 500));
    let index = 0;

    const command = () => {
      if (index >= input.length) return '';
      if (!/[A-Za-z]/.test(input[index])) return input[index++];
      const start = index;
      while (index < input.length && /[A-Za-z]/.test(input[index])) index++;
      return input.slice(start, index);
    };
    const group = () => {
      while (/\s/.test(input[index] || '')) index++;
      if (input[index] === '{') {
        index++;
        const value = sequence('}');
        if (input[index] === '}') index++;
        return value;
      }
      return atom();
    };
    const atom = () => {
      if (index >= input.length) return mathNode('mrow');
      const char = input[index++];
      if (char === '{') {
        const value = sequence('}');
        if (input[index] === '}') index++;
        return value;
      }
      if (char === '\\') {
        const name = command();
        if (name === 'frac') {
          const numerator = group();
          const denominator = group();
          const fraction = mathNode('mfrac');
          fraction.append(numerator, denominator);
          return fraction;
        }
        if (name === 'sqrt') {
          const square = mathNode('msqrt');
          square.appendChild(group());
          return square;
        }
        if (name === 'text' || name === 'mathrm' || name === 'mathbf') {
          const value = group();
          const wrapper = mathNode(name === 'text' ? 'mtext' : 'mi');
          wrapper.textContent = value.textContent || '';
          return wrapper;
        }
        if (name === 'left' || name === 'right' || name === 'displaystyle' || name === 'quad' || name === 'qquad') return mathNode('mspace');
        if (name === ',' || name === ';' || name === ':' || name === '!') return mathNode('mspace');
        if (Object.hasOwn(GREEK, name)) return mathNode('mi', GREEK[name]);
        if (Object.hasOwn(SYMBOLS, name)) return mathNode('mo', SYMBOLS[name]);
        return mathNode('mtext', `\\${name}`);
      }
      if (/\d/.test(char)) {
        let value = char;
        while (index < input.length && /[\d.,]/.test(input[index])) value += input[index++];
        return mathNode('mn', value);
      }
      if (/[A-Za-z]/.test(char)) return mathNode('mi', char);
      if (/\s/.test(char)) return mathNode('mspace');
      return mathNode('mo', char);
    };
    const sequence = (stop = '') => {
      const entries = [];
      while (index < input.length && (!stop || input[index] !== stop)) {
        if (input[index] === '^' || input[index] === '_') {
          const kind = input[index++];
          const value = group();
          const last = entries[entries.length - 1];
          if (last) last[kind === '^' ? 'sup' : 'sub'] = value;
          else entries.push({ node: mathNode('mtext', kind), sub: null, sup: value });
          continue;
        }
        entries.push({ node: atom(), sub: null, sup: null });
      }
      const row = mathNode('mrow');
      for (const entry of entries) {
        let node = entry.node;
        if (entry.sub && entry.sup) {
          const combined = mathNode('msubsup'); combined.append(node, entry.sub, entry.sup); node = combined;
        } else if (entry.sub) {
          const combined = mathNode('msub'); combined.append(node, entry.sub); node = combined;
        } else if (entry.sup) {
          const combined = mathNode('msup'); combined.append(node, entry.sup); node = combined;
        }
        row.appendChild(node);
      }
      return row;
    };

    rootMath.appendChild(sequence());
    rootMath.classList?.add(display ? 'sayrox-math-display' : 'sayrox-math-inline');
    return rootMath;
  }

  const STATUS_TONES = Object.freeze({
    success: 'success', warning: 'warning', danger: 'danger', info: 'info', neutral: 'neutral', accent: 'accent'
  });
  const LEADING_SYMBOL_TONES = Object.freeze({
    '✅':'success', '☑️':'success', '☑':'success', '✔️':'success', '✔':'success',
    '⚠️':'warning', '❗':'warning', '🚨':'danger', '❌':'danger', '⛔':'danger',
    'ℹ️':'info', '💡':'success', '🔒':'info', '📊':'info', '📌':'accent',
    '🎯':'accent', '🚀':'accent', '✨':'accent', '🔧':'accent', '🛠️':'accent'
  });

  function appendInline(parent, value) {
    const source = String(value ?? '');
    let cursor = 0;
    const leading = source.match(/^(\s*)(✅|☑️|☑|✔️|✔|⚠️|❗|🚨|❌|⛔|ℹ️|💡|🔒|📊|📌|🎯|🚀|✨|🔧|🛠️)(\s+)/u);
    if (leading) {
      appendText(parent, leading[1]);
      const symbol = root.document.createElement('span');
      symbol.className = `sayrox-leading-symbol is-${LEADING_SYMBOL_TONES[leading[2]] || 'accent'}`;
      symbol.setAttribute('aria-hidden', 'true');
      symbol.textContent = leading[2];
      parent.appendChild(symbol);
      appendText(parent, leading[3]);
      cursor = leading[0].length;
    }
    const content = source.slice(cursor);
    const pattern = /\[\[number:(success|warning|danger|info|neutral|accent)\|([^\]\n]{1,80})\]\]|\[\[status:(success|warning|danger|info|neutral|accent)\|([^\]\n]{1,80})\]\]|\$\$([\s\S]+?)\$\$|\\\[([\s\S]+?)\\\]|\\\(([\s\S]+?)\\\)|(?<!\\)\$([^$\n]+?)\$|\[([^\]\n]{1,300})\]\((https?:\/\/[^\s)]+|mailto:[^\s)]+)\)|`([^`\n]+)`|\*\*([^*\n]+)\*\*|__([^_\n]+)__|~~([^~\n]+)~~|(?<!\*)\*([^*\n]+)\*(?!\*)|(?<!_)_([^_\n]+)_(?!_)/g;
    let match;
    while ((match = pattern.exec(content))) {
      appendText(parent, content.slice(cursor, match.index));
      if (match[1] !== undefined) {
        const tone=STATUS_TONES[match[1]]||'neutral';
        const number=root.document.createElement('span');
        number.className=`sayrox-number is-${tone}`;
        number.setAttribute('dir','ltr');
        number.setAttribute('data-number-tone',tone);
        number.textContent=match[2];
        parent.appendChild(number);
      } else if (match[3] !== undefined) {
        const tone = STATUS_TONES[match[3]] || 'neutral';
        const badge = root.document.createElement('span');
        badge.className = `sayrox-status-badge is-${tone}`;
        badge.setAttribute('role', 'note');
        badge.textContent = match[4];
        parent.appendChild(badge);
      } else if (match[5] !== undefined || match[6] !== undefined) {
        const expression = match[5] ?? match[6];
        const display = root.document.createElement('span');
        display.className = 'sayrox-math-block';
        display.appendChild(renderMath(expression, true));
        parent.appendChild(display);
      } else if (match[7] !== undefined || match[8] !== undefined) {
        const expression = match[7] ?? match[8];
        parent.appendChild(renderMath(expression, false));
      } else if (match[9] !== undefined) {
        const url = safeUrl(match[10]);
        if (url) {
          const link = root.document.createElement('a');
          link.href = url; link.target = '_blank'; link.rel = 'noopener noreferrer';
          appendInline(link, match[9]); parent.appendChild(link);
        } else appendText(parent, `${match[9]} (${match[10]})`);
      } else if (match[11] !== undefined) {
        const code = root.document.createElement('code');
        code.className = 'sayrox-inline-code'; code.textContent = match[11];
        code.setAttribute('dir', 'ltr'); parent.appendChild(code);
      } else {
        const strong = match[12] ?? match[13];
        const strike = match[14];
        const emphasis = match[15] ?? match[16];
        const node = root.document.createElement(strong !== undefined ? 'strong' : strike !== undefined ? 'del' : 'em');
        appendInline(node,strong ?? strike ?? emphasis);
        parent.appendChild(node);
      }
      cursor = match.index + match[0].length;
    }
    appendText(parent, content.slice(cursor));
  }

  const CALLOUT_META = Object.freeze({
    NOTE: { tone: 'info', label: 'نکته', icon: 'ℹ️' },
    INFO: { tone: 'info', label: 'اطلاعات', icon: 'ℹ️' },
    TIP: { tone: 'success', label: 'پیشنهاد', icon: '💡' },
    SUCCESS: { tone: 'success', label: 'موفقیت', icon: '✅' },
    IMPORTANT: { tone: 'accent', label: 'مهم', icon: '✨' },
    WARNING: { tone: 'warning', label: 'هشدار', icon: '⚠️' },
    CAUTION: { tone: 'danger', label: 'احتیاط', icon: '⛔' },
    DANGER: { tone: 'danger', label: 'خطر', icon: '⛔' },
    ERROR: { tone: 'danger', label: 'خطا', icon: '❌' }
  });

  function renderCallout(parent, block) {
    const meta = CALLOUT_META[block.kind] || CALLOUT_META.NOTE;
    const tone = STATUS_TONES[block.tone] ? block.tone : meta.tone;
    const aside = root.document.createElement('aside');
    aside.className = `sayrox-callout is-${tone}`;
    aside.setAttribute('role', 'note');
    aside.setAttribute('data-tone', tone);
    const heading = root.document.createElement('div');
    heading.className = 'sayrox-callout-header';
    const icon = root.document.createElement('span');
    icon.className = `sayrox-callout-icon is-${tone}`;
    icon.setAttribute('aria-hidden', 'true');
    icon.textContent = meta.icon;
    const title = root.document.createElement('strong');
    appendInline(title, block.title || meta.label);
    heading.append(icon, title);
    const body = root.document.createElement('div');
    body.className = 'sayrox-callout-body';
    for (const line of block.lines || []) {
      const paragraph = root.document.createElement('p');
      paragraph.setAttribute('dir', 'auto');
      appendInline(paragraph, line);
      body.appendChild(paragraph);
    }
    aside.append(heading, body);
    parent.appendChild(aside);
  }

  function renderChart(parent, chart, markdown) {
    const spec=markdown?.chartDrawingSpec?.(chart);
    if(!spec)return false;
    const figure=root.document.createElement('figure');
    figure.className='sayrox-chart-figure';
    figure.setAttribute('dir','auto');
    const caption=root.document.createElement('figcaption');
    caption.textContent=spec.title;
    figure.appendChild(caption);
    const svg=root.document.createElementNS('http://www.w3.org/2000/svg','svg');
    svg.classList?.add('sayrox-chart-svg');
    svg.setAttribute('viewBox',`0 0 ${spec.width} ${spec.height}`);
    svg.setAttribute('role','img');
    svg.setAttribute('aria-label',spec.description);
    for(const [tag,value] of [['title',spec.title],['desc',spec.description]]){
      const node=root.document.createElementNS('http://www.w3.org/2000/svg',tag);
      node.textContent=value;svg.appendChild(node);
    }
    for(const shape of spec.shapes){
      const node=root.document.createElementNS('http://www.w3.org/2000/svg',shape.tag);
      for(const [name,value] of Object.entries(shape.attrs||{}))node.setAttribute(name,String(value));
      if(shape.text)node.textContent=shape.text;
      svg.appendChild(node);
    }
    figure.appendChild(svg);
    const details=root.document.createElement('details');
    details.className='sayrox-chart-data';
    const summary=root.document.createElement('summary');
    summary.textContent='مشاهده داده‌های نمودار';
    details.appendChild(summary);
    const wrap=root.document.createElement('div');
    wrap.className='sayrox-table-wrap';
    wrap.setAttribute('role','region');
    wrap.setAttribute('aria-label','داده‌های عددی نمودار');
    wrap.setAttribute('tabindex','0');
    const table=root.document.createElement('table');
    table.className='sayrox-response-table';
    const thead=root.document.createElement('thead'),headRow=root.document.createElement('tr');
    for(const label of ['دسته',...spec.chart.series.map(item=>item.name)]){
      const th=root.document.createElement('th');th.setAttribute('scope','col');th.setAttribute('dir','auto');th.textContent=label;headRow.appendChild(th);
    }
    thead.appendChild(headRow);table.appendChild(thead);
    const tbody=root.document.createElement('tbody');
    for(const row of spec.rows){
      const tr=root.document.createElement('tr');
      row.forEach((value,index)=>{
        const td=root.document.createElement('td');
        if(index){td.className='is-numeric';td.setAttribute('dir','ltr');td.textContent=String(value);}
        else{td.setAttribute('dir','auto');td.textContent=String(value);}
        tr.appendChild(td);
      });
      tbody.appendChild(tr);
    }
    table.appendChild(tbody);wrap.appendChild(table);details.appendChild(wrap);figure.appendChild(details);
    parent.appendChild(figure);
    return true;
  }

  function renderCodeBlock(parent, block, blockIndex, options) {
    const code = String(block.text ?? '');
    if (!options.streaming && root.SayroxCodeWorkspace?.createBlock) {
      const workspace = root.SayroxCodeWorkspace;
      const editable = workspace.createBlock({
        language: block.language || 'text', source: code,
        onSave: nextCode => typeof options.onCodeSave === 'function' ? options.onCodeSave(blockIndex, nextCode) : false
      });
      parent.appendChild(editable);
      return;
    }
    const details = root.document.createElement('details'); details.className = 'code-disclosure sayrox-code-block';
    const summary = root.document.createElement('summary');
    summary.textContent = `کد · ${String(block.language || 'text').toUpperCase()} — برای مشاهده باز کن`;
    const pre = root.document.createElement('pre');
    const codeNode = root.document.createElement('code');
    codeNode.textContent = code; codeNode.setAttribute('dir', 'ltr');
    if (block.language) codeNode.className = `language-${String(block.language).replace(/[^\w+-]/g, '')}`;
    pre.appendChild(codeNode); details.append(summary, pre);
    const copy = root.document.createElement('button'); copy.type = 'button';
    copy.className = 'code-copy'; copy.textContent = 'کپی کد';
    copy.addEventListener('click', async () => {
      try { await root.navigator.clipboard.writeText(code); copy.textContent = 'کپی شد'; }
      catch { copy.textContent = 'کپی در دسترس نیست'; }
    });
    details.appendChild(copy); parent.appendChild(details);
  }

  function render(container, raw, options = {}) {
    if (!container?.replaceChildren) return false;
    const markdown = root.SayroxMarkdown;
    if (!markdown?.parseBlocks) {
      container.textContent = String(raw ?? '');
      return false;
    }
    const blocks = markdown.parseBlocks(String(raw ?? ''));
    container.replaceChildren();
    let codeIndex = 0;
    for (const block of blocks) {
      let node;
      switch (block.type) {
        case 'heading':
          node = root.document.createElement(`h${Math.min(4, Math.max(2, Number(block.level) || 2))}`);
          node.setAttribute('dir','auto'); appendInline(node, block.text); container.appendChild(node); break;
        case 'paragraph':
          node = root.document.createElement('p'); node.className = 'sayrox-markdown-paragraph';
          node.setAttribute('dir', 'auto'); appendInline(node, block.text); container.appendChild(node); break;
        case 'list': {
          node = root.document.createElement(block.ordered ? 'ol' : 'ul');
          if (block.taskList) node.className = 'sayrox-task-list';
          for (let index = 0; index < (block.items || []).length; index++) {
            const li = root.document.createElement('li');
            const checked = block.checks?.[index];
            if (checked !== null && checked !== undefined) {
              li.className = `sayrox-task-item ${checked ? 'is-checked' : 'is-pending'}`;
              const marker = root.document.createElement('span');
              marker.className = `sayrox-task-marker ${checked ? 'is-success' : 'is-neutral'}`;
              marker.setAttribute('aria-hidden', 'true');
              marker.textContent = checked ? '☑' : '☐';
              li.appendChild(marker);
            }
            const text = root.document.createElement('span');
            text.setAttribute('dir', 'auto');
            appendInline(text, block.items[index]);
            li.appendChild(text);
            node.appendChild(li);
          }
          container.appendChild(node); break;
        }
        case 'quote':
          node = root.document.createElement('blockquote');
          for (const line of block.lines || []) { const p = root.document.createElement('p'); p.setAttribute('dir', 'auto'); appendInline(p, line); node.appendChild(p); }
          container.appendChild(node); break;
        case 'callout': renderCallout(container, block); break;
        case 'chart': renderChart(container,block.chart,markdown); break;
        case 'table': {
          const wrap = root.document.createElement('div');
          wrap.className = 'sayrox-table-wrap';
          wrap.setAttribute('role', 'region');
          wrap.setAttribute('aria-label', 'جدول پاسخ؛ برای دیدن ستون‌های بیشتر به‌صورت افقی پیمایش کنید');
          wrap.setAttribute('tabindex', '0');
          const table = root.document.createElement('table'); table.className = 'sayrox-response-table';
          const rows = block.rows || [];
          if (rows.length) {
            const thead = root.document.createElement('thead'), tr = root.document.createElement('tr');
            for (let column = 0; column < rows[0].length; column++) {
              const th = root.document.createElement('th');
              th.setAttribute('scope', 'col');
              th.setAttribute('dir', 'auto');
              const alignment = block.alignments?.[column];
              const numeric=block.numericColumns?.[column]===true;
              const classes=[];
              if(['left','center','right'].includes(alignment))classes.push(`is-align-${alignment}`);
              else if(numeric)classes.push('is-align-right');
              if(numeric)classes.push('is-numeric');
              if(classes.length)th.className=classes.join(' ');
              appendInline(th, rows[0][column]);
              tr.appendChild(th);
            }
            thead.appendChild(tr); table.appendChild(thead);
            const tbody = root.document.createElement('tbody');
            for (const row of rows.slice(1)) {
              const bodyRow = root.document.createElement('tr');
              for (let column = 0; column < rows[0].length; column++) {
                const td = root.document.createElement('td');
                td.setAttribute('dir', 'auto');
                const alignment = block.alignments?.[column];
                const numeric=block.numericColumns?.[column]===true;
                const classes=[];
                if(['left','center','right'].includes(alignment))classes.push(`is-align-${alignment}`);
                else if(numeric)classes.push('is-align-right');
                if(numeric)classes.push('is-numeric');
                if(classes.length)td.className=classes.join(' ');
                if(numeric)td.setAttribute('dir','ltr');
                appendInline(td, row[column] ?? '');
                bodyRow.appendChild(td);
              }
              tbody.appendChild(bodyRow);
            }
            table.appendChild(tbody);
          }
          wrap.appendChild(table);
          const hint = root.document.createElement('span');
          hint.className = 'sayrox-table-scroll-hint';
          hint.setAttribute('aria-hidden', 'true');
          hint.textContent = 'برای دیدن ستون‌های بیشتر، افقی پیمایش کنید';
          wrap.appendChild(hint);
          container.appendChild(wrap); break;
        }
        case 'code': renderCodeBlock(container, block, codeIndex++, options); break;
        case 'rule': node = root.document.createElement('hr'); container.appendChild(node); break;
        default: node = root.document.createElement('p'); node.textContent = String(block.text ?? ''); container.appendChild(node);
      }
    }
    container.classList?.add('sayrox-response-content');
    container.setAttribute('data-render-mode', options.streaming ? 'streaming' : 'complete');
    return true;
  }

  root.SayroxResponseRenderer = Object.freeze({ render, renderMath, appendInline, safeUrl });
})(globalThis);
