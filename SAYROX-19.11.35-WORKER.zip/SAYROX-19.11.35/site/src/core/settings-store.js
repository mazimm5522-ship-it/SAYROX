(function (global) {
  'use strict';
  const VERSION = 1;
  const DEFAULTS = Object.freeze({
    voicePersona: 'ara', voiceProvider: 'aria', voiceRate: 1, voiceVolume: 1,
    orbReactive: true, autoSpeak: false, deepDefault: false,
    useCustomInstructions: true, useDisplayName: false, storeChat: true,
    autoResume: true, customInstructions: '', language: 'fa', accentMode: 'voice',
    notificationsInApp: true, notificationsSystem: false,
    quickAnswers: false, responseStyle: 'balanced', hapticFeedback: false, displayNameOverride: ''
  });
  const isObject = value => value && typeof value === 'object' && !Array.isArray(value);
  function parse(value) { try { const data = JSON.parse(value || 'null'); return isObject(data) ? data : null; } catch { return null; } }
  class SettingsStore {
    constructor(options = {}) {
      let storage = options.storage || null;
      if (!storage) { try { storage = global.localStorage; } catch { storage = null; } }
      this.storage = storage;
      this.key = options.key || 'xynora:settings:v1';
      this.legacyKey = options.legacyKey || 'xynora-settings';
      this.listeners = new Set();
      this.available = Boolean(this.storage);
      this.initial = isObject(options.initial) ? { ...options.initial } : {};
      this.value = { ...DEFAULTS, ...this.initial };
      this.migrate();
    }
    read(key) { try { return this.storage?.getItem(key) ?? null; } catch { this.available = false; return null; } }
    write(key, value) { try { this.storage?.setItem(key, value); return Boolean(this.storage); } catch { this.available = false; return false; } }
    migrate() {
      const current = parse(this.read(this.key));
      if (current && current.version === VERSION && isObject(current.data)) {
        this.value = { ...DEFAULTS, ...current.data };
        return;
      }
      const legacy = parse(this.read(this.legacyKey)) || {};
      const legacyVoice = this.read('xynora-voice');
      const reverse = { aria: 'ara', nova: 'eve', atlas: 'leo', orion: 'rex', elena: 'sal', kai: 'gork', lyra: 'carina' };
      this.value = { ...DEFAULTS, ...this.initial, ...legacy };
      if (!legacy.voicePersona && legacyVoice) this.value.voicePersona = reverse[legacyVoice] || 'ara';
      if (!legacy.voiceProvider && legacyVoice) this.value.voiceProvider = legacyVoice;
      if (Object.prototype.hasOwnProperty.call(legacy, 'pref:اجرای خودکار آخرین گفتگو')) this.value.autoResume = legacy['pref:اجرای خودکار آخرین گفتگو'] !== false;
      this.save(false);
    }
    get(key) { return this.value[key]; }
    getAll() { return { ...this.value }; }
    set(key, value) {
      if (typeof key !== 'string' || !key || key.length > 80) throw new TypeError('Invalid settings key');
      this.value[key] = value;
      this.save();
      this.emit({ key, value });
      return value;
    }
    replace(next) {
      if (!isObject(next)) throw new TypeError('Settings must be an object');
      this.value = { ...DEFAULTS, ...next };
      this.save();
      this.emit({ key: '*', value: this.getAll() });
    }
    save(mirrorLegacy = true) {
      const envelope = JSON.stringify({ version: VERSION, data: this.value });
      const ok = this.write(this.key, envelope);
      if (mirrorLegacy) this.write(this.legacyKey, JSON.stringify(this.value));
      return ok;
    }
    subscribe(listener) { if (typeof listener !== 'function') return () => {}; this.listeners.add(listener); return () => this.listeners.delete(listener); }
    emit(change) { this.listeners.forEach(listener => { try { listener(change, this.getAll()); } catch {} }); }
    static defaults() { return { ...DEFAULTS }; }
  }
  global.SayroxCore = global.SayroxCore || {};
  global.SayroxCore.SettingsStore = SettingsStore;
})(globalThis);
