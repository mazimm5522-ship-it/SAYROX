(function installSayroxStream(root) {
  'use strict';

  // The largest supported generated-image data URL is 9 MB. Leave room for
  // its JSON envelope while keeping malformed/unbounded SSE responses capped.
  const MAX_STREAM_CHARACTERS = 14_000_000;
  const MAX_EVENT_CHARACTERS = 10_000_000;
  const MAX_ANSWER_CHARACTERS = 500_000;

  function eventError(data, eventName) {
    let parsed;
    try { parsed = JSON.parse(data); } catch { parsed = null; }
    const message = parsed?.error?.message || parsed?.message ||
      (eventName === 'error' ? 'جریان پاسخ از سرویس هوش مصنوعی با خطا متوقف شد.' : 'پاسخ جریانی نامعتبر از سرور دریافت شد.');
    return new Error(String(message).slice(0, 500));
  }

  function textFromContent(value) {
    if (typeof value === 'string') return value;
    if (!Array.isArray(value)) return '';
    return value.map(part => typeof part === 'string' ? part : (typeof part?.text === 'string' ? part.text : '')).join('');
  }

  async function readEventStream(response, onUpdate = () => {}, onEvent = () => {}) {
    if (!response?.body?.getReader) throw new Error('جریان پاسخ در دسترس نیست.');
    const reader = response.body.getReader();
    // Fatal decoding prevents corrupted UTF-8 from being silently replaced in JSON.
    const decoder = new TextDecoder('utf-8', { fatal: true });
    let buffer = '';
    let answer = '';
    let totalCharacters = 0;
    let completionSeen = false;
    let firstChunk = true;
    let pendingCarriageReturn = false;

    function normalizeLineEndings(value, final = false) {
      if (pendingCarriageReturn) {
        value = `\r${value}`;
        pendingCarriageReturn = false;
      }
      if (!final && value.endsWith('\r')) {
        value = value.slice(0, -1);
        pendingCarriageReturn = true;
      }
      return value.replace(/\r\n/g, '\n').replace(/\r/g, '\n');
    }

    async function consume(frame) {
      if (frame.length > MAX_EVENT_CHARACTERS) throw new Error('یک بخش از جریان پاسخ بیش از حد مجاز است.');
      let eventName = 'message';
      const dataLines = [];
      for (const line of frame.split(/\r?\n/)) {
        if (!line || line.startsWith(':')) continue;
        if (line.startsWith('event:')) eventName = line.slice(6).trim();
        else if (line.startsWith('data:')) dataLines.push(line.slice(5).replace(/^ /, ''));
      }
      if (!dataLines.length) return;
      const data = dataLines.join('\n');
      if (eventName === 'error') throw eventError(data, eventName);
      if (data === '[DONE]') {
        completionSeen = true;
        return;
      }
      let payload;
      try { payload = JSON.parse(data); } catch { throw eventError(data, eventName); }
      if (payload?.error) throw eventError(data, eventName);
      if (eventName !== 'message') {
        await onEvent(eventName, payload);
        return;
      }
      const choice = payload?.choices?.[0];
      if (choice?.finish_reason !== undefined && choice.finish_reason !== null) completionSeen = true;
      const delta = textFromContent(choice?.delta?.content ?? choice?.message?.content);
      if (delta) {
        if (answer.length + delta.length > MAX_ANSWER_CHARACTERS) {
          throw new Error('طول پاسخ جریانی از سقف امن SAYROX بیشتر شد.');
        }
        answer += delta;
        onUpdate(delta, answer);
      }
    }

    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        let decoded = decoder.decode(value, { stream: true });
        if (firstChunk) {
          firstChunk = false;
          decoded = decoded.replace(/^\uFEFF/, '');
        }
        totalCharacters += decoded.length;
        if (totalCharacters > MAX_STREAM_CHARACTERS) throw new Error('حجم کل جریان پاسخ از سقف امن SAYROX بیشتر شد.');
        buffer += normalizeLineEndings(decoded);
        if (buffer.length > MAX_EVENT_CHARACTERS && !buffer.includes('\n\n')) {
          throw new Error('جریان پاسخ یک رویداد بیش از حد بزرگ یا ناقص دارد.');
        }
        let boundary;
        while ((boundary = buffer.indexOf('\n\n')) !== -1) {
          const frame = buffer.slice(0, boundary);
          buffer = buffer.slice(boundary + 2);
          await consume(frame);
        }
      }
      const tail = decoder.decode();
      totalCharacters += tail.length;
      if (totalCharacters > MAX_STREAM_CHARACTERS) throw new Error('حجم کل جریان پاسخ از سقف امن SAYROX بیشتر شد.');
      buffer += normalizeLineEndings(tail, true);
      if (buffer.trim()) await consume(buffer);
      if (!completionSeen) {
        throw new Error('اتصال پیش از علامت پایان پاسخ قطع شد؛ متن ناقص به‌عنوان پاسخ نهایی ذخیره نشد. دوباره تلاش کن.');
      }
      return answer;
    } catch (error) {
      try { await reader.cancel(error); } catch {}
      throw error;
    } finally {
      try { reader.releaseLock(); } catch {}
    }
  }

  root.SayroxStream = Object.freeze({ readEventStream });
})(globalThis);
