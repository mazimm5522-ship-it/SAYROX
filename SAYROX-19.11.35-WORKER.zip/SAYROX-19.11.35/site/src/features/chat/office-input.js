(function SayroxChatOfficeInput(){
'use strict';
const FILE_POLICY=window.SayroxFilePolicy?.FILE_POLICY||{};
const POLICY=Object.freeze({maxFileBytes:FILE_POLICY.maxFileBytes||20*1024*1024,maxTextChars:FILE_POLICY.maxChatDocumentTextChars||60000});
const MIME=Object.freeze({
  docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  pptx:'application/vnd.openxmlformats-officedocument.presentationml.presentation'
});
function validateOfficeFile(file){
  if(!file||typeof file!=='object'||typeof file.name!=='string')throw new TypeError('فایل Office معتبر نیست.');
  const policy=window.SayroxFilePolicy;
  if(!policy?.validateFile)throw new Error('سیاست امنیتی فایل‌ها بارگیری نشده است. صفحه را تازه‌سازی کن.');
  const info=policy.validateFile(file);
  if(!['docx','pptx'].includes(info.extension))throw new Error('فقط DOCX و PPTX در این مسیر پشتیبانی می‌شوند.');
  if(!Number.isFinite(file.size)||file.size<=0||file.size>POLICY.maxFileBytes)throw new Error('حجم فایل Office باید بین ۱ بایت تا ۲۰ مگابایت باشد.');
  return info.extension;
}
function trimAtParagraphBoundary(source,limit){
  if(source.length<=limit)return source;
  const cut=source.slice(0,limit),boundary=cut.lastIndexOf('\n\n');
  return (boundary>limit*.65?cut.slice(0,boundary):cut).trimEnd();
}
async function prepareOfficeFile(file,{reader}={}){
  const extension=validateOfficeFile(file),documents=window.SayroxDocuments;
  const read=reader||(extension==='docx'?documents?.readDocx:documents?.readPptx);
  if(typeof read!=='function')throw new Error('موتور خواندن سند Office در دسترس نیست؛ صفحه را تازه‌سازی کن.');
  let raw=String(await read(file)||'').replace(/\u0000/g,'').replace(/\r\n?/g,'\n').replace(/[\u0001-\u0008\u000B\u000C\u000E-\u001F\u007F]/g,'').trim();
  if(!raw)throw new Error('متن قابل تحلیل در فایل Office پیدا نشد.');
  const text=trimAtParagraphBoundary(raw,POLICY.maxTextChars);
  if(!text)throw new Error('متن سند پس از پاک‌سازی خالی شد.');
  return Object.freeze({
    id:globalThis.crypto?.randomUUID?.()||`${Date.now()}-${Math.random().toString(16).slice(2)}`,
    kind:'office',name:String(file.name).slice(0,180),mimeType:MIME[extension],extension,size:file.size,
    text,sourceChars:raw.length,includedChars:text.length,truncated:text.length<raw.length
  });
}
window.SayroxChatOfficeInput=Object.freeze({POLICY,MIME,validateOfficeFile,prepareOfficeFile,trimAtParagraphBoundary});
})();
