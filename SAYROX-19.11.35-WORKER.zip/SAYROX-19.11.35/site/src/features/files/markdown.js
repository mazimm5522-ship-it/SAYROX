(function SayroxMarkdownModule(){
'use strict';

const escapeHtml=value=>String(value??'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
const CALLOUT_TYPES=new Set(['NOTE','TIP','IMPORTANT','WARNING','CAUTION','SUCCESS','DANGER','ERROR','INFO']);
const CALLOUT_TONES=Object.freeze({NOTE:'info',INFO:'info',TIP:'success',SUCCESS:'success',IMPORTANT:'accent',WARNING:'warning',CAUTION:'danger',DANGER:'danger',ERROR:'danger'});

function splitTableRow(line){
  const source=String(line??'').trim();
  let text=source.startsWith('|')?source.slice(1):source;
  if(text.endsWith('|')&&!text.endsWith('\\|'))text=text.slice(0,-1);
  const cells=[];let cell='';
  for(let index=0;index<text.length;index++){
    const char=text[index];
    if(char==='\\'&&index+1<text.length&&(text[index+1]==='|'||text[index+1]==='\\')){cell+=text[++index];continue;}
    if(char==='|'){cells.push(cell.trim());cell='';continue;}
    cell+=char;
  }
  cells.push(cell.trim());
  return cells;
}
function tableAlignment(cell){
  const value=String(cell??'').trim();
  const left=value.startsWith(':'),right=value.endsWith(':');
  return left&&right?'center':left?'left':right?'right':'start';
}

// One shared numeric tokenizer keeps chat and exported HTML visually consistent.
// Persian, Arabic-Indic and ASCII digits are supported; dates/versions remain intact.
const DIGITS='0-9۰-۹٠-٩';
const NUMBER_CORE=`(?:[$€£¥]\\s*)?(?:[${DIGITS}]{1,3}(?:[,٬][${DIGITS}]{3})+|[${DIGITS}]+)(?:[.٫][${DIGITS}]+)?(?:\\s?(?:%|٪|‰))?`;
const DATE_VERSION_CORE=`[${DIGITS}]{1,4}(?:[./-][${DIGITS}]{1,4}){1,2}`;
const NUMBER_VALUE_RE=new RegExp(`^[-+−]?${NUMBER_CORE}$`,'u');
const DATE_VERSION_RE=new RegExp(`^${DATE_VERSION_CORE}$`,'u');
const NUMBER_TOKEN_RE=new RegExp(`(?<![\\p{L}\\p{N}_.+−-])(${DATE_VERSION_CORE}|[-+−]?${NUMBER_CORE})(?![\\p{L}\\p{N}_])`,'gu');
function isNumericValue(value){
  const text=String(value??'').trim();
  return Boolean(text)&&!DATE_VERSION_RE.test(text)&&NUMBER_VALUE_RE.test(text);
}
function tokenizeNumbers(value){
  const source=String(value??''),tokens=[];let cursor=0,match;
  NUMBER_TOKEN_RE.lastIndex=0;
  while((match=NUMBER_TOKEN_RE.exec(source))){
    if(match.index>cursor)tokens.push({type:'text',value:source.slice(cursor,match.index)});
    const token=match[1];
    if(DATE_VERSION_RE.test(token))tokens.push({type:'text',value:token});
    else{
      const sign=token.trimStart()[0];
      const tone=sign==='-'||sign==='−'?'danger':sign==='+'?'success':'info';
      tokens.push({type:'number',value:token,tone});
    }
    cursor=match.index+match[0].length;
  }
  if(cursor<source.length)tokens.push({type:'text',value:source.slice(cursor)});
  return tokens.length?tokens:[{type:'text',value:source}];
}
function isTableSeparator(line){
  const cells=splitTableRow(line);
  return cells.length>1&&cells.every(cell=>/^:?-{3,}:?$/.test(cell));
}
function parseTableAt(lines,index){
  if(index+1>=lines.length||!String(lines[index]).includes('|')||!isTableSeparator(lines[index+1]))return null;
  const header=splitTableRow(lines[index]);
  if(header.length<2)return null;
  const width=header.length;
  const alignments=splitTableRow(lines[index+1]).map(tableAlignment);
  let cursor=index+2;
  const rows=[header];
  while(cursor<lines.length&&String(lines[cursor]).trim()&&String(lines[cursor]).includes('|')){
    const row=splitTableRow(lines[cursor]);
    rows.push(Array.from({length:width},(_,column)=>row[column]??''));
    cursor++;
  }
  const numericColumns=header.map((_,column)=>{
    const values=rows.slice(1).map(row=>String(row[column]??'').trim()).filter(Boolean);
    if(!values.length)return false;
    const numericCount=values.filter(isNumericValue).length;
    return numericCount/values.length>=0.6;
  });
  return {rows,alignments:Array.from({length:width},(_,column)=>alignments[column]||'start'),numericColumns,nextIndex:cursor};
}
function normalizeChart(input){
  if(!input||typeof input!=='object'||Array.isArray(input))return null;
  const type=String(input.type||'').toLowerCase();
  if(!['bar','line','pie'].includes(type))return null;
  if(!Array.isArray(input.labels)||input.labels.length<2||input.labels.length>10)return null;
  if(input.labels.some(value=>typeof value!=='string'&&typeof value!=='number'))return null;
  const labels=input.labels.map(value=>String(value).trim());
  if(labels.some(value=>!value||value.length>56||/[\r\n\u0000-\u001f]/.test(value)))return null;
  if(new Set(labels).size!==labels.length)return null;
  if(!Array.isArray(input.series)||!input.series.length||input.series.length>(type==='pie'?1:3))return null;
  const series=input.series.map((entry,index)=>{
    if(!entry||typeof entry!=='object'||Array.isArray(entry)||!Array.isArray(entry.values)||entry.values.length!==labels.length)return null;
    if(entry.name!==undefined&&typeof entry.name!=='string')return null;
    const name=String(entry.name||`مجموعه ${index+1}`).trim();
    if(!name||name.length>40||/[\r\n\u0000-\u001f]/.test(name))return null;
    const values=entry.values.map(value=>typeof value==='number'?value:NaN);
    if(values.some(value=>!Number.isFinite(value)||Math.abs(value)>1e12))return null;
    return {name,values};
  });
  if(series.some(value=>!value))return null;
  if(type==='pie'&&(series[0].values.some(value=>value<0)||series[0].values.every(value=>value===0)))return null;
  if(input.title!==undefined&&typeof input.title!=='string')return null;
  const title=String(input.title||'نمودار داده‌ها').trim();
  if(title.length>100||/[\r\n\u0000-\u001f]/.test(title))return null;
  return {type,title,labels,series};
}
function chartNumber(value){
  try{return new Intl.NumberFormat('fa-IR',{maximumFractionDigits:2}).format(value)}catch{return String(value)}
}
function chartDrawingSpec(input){
  const chart=normalizeChart(input);
  if(!chart)return null;
  const width=760,shapes=[];
  const add=(tag,attrs={},text='')=>shapes.push({tag,attrs,text:String(text??'')});
  const fmt=value=>Number.isFinite(value)?String(Math.round(value*100)/100):'0';
  const allValues=chart.series.flatMap(item=>item.values);
  if(chart.type==='bar'){
    const rowHeight=Math.max(58,chart.series.length*19+18),top=66,bottom=34,left=220,right=34;
    const height=top+chart.labels.length*rowHeight+bottom,plotWidth=width-left-right;
    let min=Math.min(0,...allValues),max=Math.max(0,...allValues);
    if(min===max){min=0;max=1;}
    else {const pad=(max-min)*.04;min-=pad;max+=pad;}
    const x=value=>left+(value-min)/(max-min)*plotWidth,x0=x(0);
    for(let tick=0;tick<=4;tick++){
      const value=min+(max-min)*tick/4,px=x(value);
      add('line',{x1:fmt(px),y1:String(top-6),x2:fmt(px),y2:String(height-bottom+2),class:'sayrox-chart-grid'});
      add('text',{x:fmt(px),y:String(height-10),'text-anchor':'middle',class:'sayrox-chart-axis'},chartNumber(value));
    }
    chart.labels.forEach((label,index)=>{
      const center=top+index*rowHeight+rowHeight/2;
      add('text',{x:String(left-13),y:fmt(center+4),'text-anchor':'end',class:'sayrox-chart-label'},label);
      const cluster=chart.series.length*14+(chart.series.length-1)*4;
      const firstY=center-cluster/2;
      chart.series.forEach((item,seriesIndex)=>{
        const value=item.values[index],end=x(value),y=firstY+seriesIndex*18;
        add('rect',{x:fmt(Math.min(x0,end)),y:fmt(y),width:fmt(Math.max(1.5,Math.abs(end-x0))),height:'14',rx:'4',class:`sayrox-chart-series-${seriesIndex}`});
      });
    });
    chart.series.forEach((item,index)=>{
      const xPos=left+index*165;
      add('rect',{x:String(xPos),y:'25',width:'10',height:'10',rx:'3',class:`sayrox-chart-series-${index}`});
      add('text',{x:String(xPos+16),y:'34',class:'sayrox-chart-legend'},item.name);
    });
    return {type:chart.type,title:chart.title,width,height,shapes,chart,description:`${chart.title}؛ نمودار میله‌ای شامل ${chart.labels.length} دسته و ${chart.series.length} مجموعه داده.`,rows:chart.labels.map((label,index)=>[label,...chart.series.map(item=>item.values[index])])};
  }
  if(chart.type==='line'){
    const height=370,left=84,right=28,top=62,bottom=72,plotWidth=width-left-right,plotHeight=height-top-bottom;
    let min=Math.min(0,...allValues),max=Math.max(0,...allValues);
    if(min===max){const pad=Math.max(1,Math.abs(max)*.1);min-=pad;max+=pad;}
    else {const pad=(max-min)*.08;min-=pad;max+=pad;}
    const x=index=>left+(chart.labels.length===1?0:index/(chart.labels.length-1))*plotWidth;
    const y=value=>top+(max-value)/(max-min)*plotHeight;
    for(let tick=0;tick<=4;tick++){
      const value=min+(max-min)*tick/4,py=y(value);
      add('line',{x1:String(left),y1:fmt(py),x2:String(width-right),y2:fmt(py),class:'sayrox-chart-grid'});
      add('text',{x:String(left-12),y:fmt(py+4),'text-anchor':'end',class:'sayrox-chart-axis'},chartNumber(value));
    }
    chart.labels.forEach((label,index)=>add('text',{x:fmt(x(index)),y:String(height-30),'text-anchor':'middle',class:'sayrox-chart-label'},label));
    chart.series.forEach((item,seriesIndex)=>{
      const points=item.values.map((value,index)=>`${fmt(x(index))},${fmt(y(value))}`).join(' ');
      add('polyline',{points, class:`sayrox-chart-line sayrox-chart-series-${seriesIndex}`});
      item.values.forEach((value,index)=>add('circle',{cx:fmt(x(index)),cy:fmt(y(value)),r:'5',class:`sayrox-chart-point sayrox-chart-series-${seriesIndex}`}));
      const legendX=left+seriesIndex*190;
      add('line',{x1:String(legendX),y1:'29',x2:String(legendX+22),y2:'29',class:`sayrox-chart-line sayrox-chart-series-${seriesIndex}`});
      add('text',{x:String(legendX+30),y:'34',class:'sayrox-chart-legend'},item.name);
    });
    return {type:chart.type,title:chart.title,width,height,shapes,chart,description:`${chart.title}؛ نمودار خطی شامل ${chart.labels.length} دسته و ${chart.series.length} مجموعه داده.`,rows:chart.labels.map((label,index)=>[label,...chart.series.map(item=>item.values[index])])};
  }
  const height=360,cx=230,cy=180,radius=122,total=chart.series[0].values.reduce((sum,value)=>sum+value,0);
  let angle=-Math.PI/2;
  chart.series[0].values.forEach((value,index)=>{
    const next=angle+value/total*Math.PI*2;
    const x1=cx+radius*Math.cos(angle),y1=cy+radius*Math.sin(angle),x2=cx+radius*Math.cos(next),y2=cy+radius*Math.sin(next);
    if(value>0){
      const large=next-angle>Math.PI?1:0;
      const d=`M ${fmt(cx)} ${fmt(cy)} L ${fmt(x1)} ${fmt(y1)} A ${radius} ${radius} 0 ${large} 1 ${fmt(x2)} ${fmt(y2)} Z`;
      add('path',{d,class:`sayrox-chart-slice sayrox-chart-series-${index}`});
    }
    const percent=chartNumber(value/total*100);
    const y=74+index*29;
    add('rect',{x:'430',y:String(y-11),width:'12',height:'12',rx:'3',class:`sayrox-chart-series-${index}`});
    add('text',{x:'452',y:String(y),class:'sayrox-chart-legend'},`${chart.labels[index]} · ${chartNumber(value)} (${percent}٪)`);
    angle=next;
  });
  return {type:chart.type,title:chart.title,width,height,shapes,chart,description:`${chart.title}؛ نمودار دایره‌ای با ${chart.labels.length} بخش.`,rows:chart.labels.map((label,index)=>[label,chart.series[0].values[index]])};
}
function parseChartCode(language,text){
  if(!['chart','chart-json','sayrox-chart'].includes(String(language||'').toLowerCase()))return null;
  const source=String(text||'');
  if(source.length>16000)return null;
  try{
    const input=JSON.parse(source);
    const chart=normalizeChart(input);
    return chart?{type:'chart',chart}:null;
  }catch{return null;}
}
function chartSvgHtml(spec){
  if(!spec)return '';
  const shapes=spec.shapes.map(shape=>{
    const attrs=Object.entries(shape.attrs).map(([key,value])=>`${key}="${escapeHtml(value)}"`).join(' ');
    return `<${shape.tag}${attrs?` ${attrs}`:''}>${shape.text?escapeHtml(shape.text):''}</${shape.tag}>`;
  }).join('');
  return `<svg class="sayrox-chart-svg" viewBox="0 0 ${spec.width} ${spec.height}" role="img" aria-label="${escapeHtml(spec.description)}"><title>${escapeHtml(spec.title)}</title><desc>${escapeHtml(spec.description)}</desc>${shapes}</svg>`;
}
function renderChartHtml(input){
  const spec=chartDrawingSpec(input);
  if(!spec)return '';
  const headers=['دسته',...spec.chart.series.map(item=>item.name)];
  const rows=spec.rows.map(row=>`<tr>${row.map((value,index)=>`<td${index?' class="is-numeric" dir="ltr"':''}>${escapeHtml(index?chartNumber(value):value)}</td>`).join('')}</tr>`).join('');
  const table=`<details class="sayrox-chart-data"><summary>مشاهده داده‌های نمودار</summary><div class="table-wrap"><table><thead><tr>${headers.map(value=>`<th>${escapeHtml(value)}</th>`).join('')}</tr></thead><tbody>${rows}</tbody></table></div></details>`;
  return `<figure class="sayrox-chart-figure"><figcaption>${escapeHtml(spec.title)}</figcaption>${chartSvgHtml(spec)}${table}</figure>`;
}

function parseCallout(lines){
  if(!Array.isArray(lines)||!lines.length)return null;
  const match=String(lines[0]??'').trim().match(/^\[!(NOTE|TIP|IMPORTANT|WARNING|CAUTION|SUCCESS|DANGER|ERROR|INFO)\]\s*(.*)$/i);
  if(!match)return null;
  const kind=match[1].toUpperCase();
  return {type:'callout',kind,tone:CALLOUT_TONES[kind]||'info',title:String(match[2]??'').trim(),lines:lines.slice(1)};
}
function parseBlocks(source){
  const lines=String(source??'').replace(/\r\n?/g,'\n').split('\n');
  const blocks=[];
  let paragraph=[],list=null,quote=[],code=[],inCode=false,codeLanguage='';
  const flushParagraph=()=>{if(paragraph.length){blocks.push({type:'paragraph',text:paragraph.join(' ')});paragraph=[];}};
  const flushList=()=>{
    if(!list)return;
    blocks.push({type:'list',ordered:list.ordered,items:list.items,checks:list.checks,taskList:list.checks.some(value=>value!==null)});
    list=null;
  };
  const flushQuote=()=>{
    if(!quote.length)return;
    const callout=parseCallout(quote);
    blocks.push(callout||{type:'quote',lines:quote});
    quote=[];
  };
  const flushCode=(closed=false)=>{if(inCode){const text=code.join('\n');const chart=closed?parseChartCode(codeLanguage,text):null;blocks.push(chart||{type:'code',language:codeLanguage,text});code=[];inCode=false;codeLanguage='';}};

  for(let index=0;index<lines.length;index++){
    const line=lines[index];
    const fence=line.match(/^\s*```([a-z0-9_-]{0,24})\s*$/i);
    if(fence){if(inCode)flushCode(true);else{flushParagraph();flushList();flushQuote();inCode=true;codeLanguage=fence[1];}continue;}
    if(inCode){code.push(line);continue;}
    if(!line.trim()){flushParagraph();flushList();flushQuote();continue;}
    const table=parseTableAt(lines,index);
    if(table){flushParagraph();flushList();flushQuote();blocks.push({type:'table',rows:table.rows,alignments:table.alignments,numericColumns:table.numericColumns});index=table.nextIndex-1;continue;}
    const heading=line.match(/^\s{0,3}(#{1,6})\s+(.+?)\s*#*\s*$/);
    if(heading){flushParagraph();flushList();flushQuote();blocks.push({type:'heading',level:heading[1].length,text:heading[2]});continue;}
    if(/^\s{0,3}(?:---+|\*\*\*|___)\s*$/.test(line)){flushParagraph();flushList();flushQuote();blocks.push({type:'rule'});continue;}
    const quoteLine=line.match(/^\s{0,3}>\s?(.*)$/);
    if(quoteLine){flushParagraph();flushList();quote.push(quoteLine[1]);continue;}else flushQuote();
    const item=line.match(/^\s*(?:([-*+])\s+|(\d+)[.)]\s+)(.*)$/);
    if(item){
      flushParagraph();
      const ordered=!!item[2];
      if(list&&list.ordered!==ordered)flushList();
      if(!list)list={ordered,items:[],checks:[]};
      const task=String(item[3]??'').match(/^\[([ xX])\]\s+(.*)$/);
      list.items.push(task?task[2]:item[3]);
      list.checks.push(task?/x/i.test(task[1]):null);
      continue;
    }
    flushList();paragraph.push(line.trim());
  }
  if(inCode)flushCode();
  flushParagraph();flushList();flushQuote();
  return blocks;
}
function numericTextHtml(value){
  return tokenizeNumbers(value).map(token=>token.type==='number'
    ?`<span class="sayrox-number is-${token.tone}" dir="ltr">${escapeHtml(token.value)}</span>`
    :escapeHtml(token.value)).join('');
}
function inlineHtml(value){
  const source=String(value??'');let output='',cursor=0,match;
  const pattern=/\[\[number:(success|warning|danger|info|neutral|accent)\|([^\]\n]{1,80})\]\]|\[\[status:(success|warning|danger|info|neutral|accent)\|([^\]\n]{1,80})\]\]|\[([^\]\n]{1,300})\]\((https?:\/\/[^\s)]+|mailto:[^\s)]+)\)|`([^`\n]+)`|\*\*([^*\n]+)\*\*|(?<!\*)\*([^*\n]+)\*(?!\*)/g;
  while((match=pattern.exec(source))){
    output+=numericTextHtml(source.slice(cursor,match.index));
    if(match[1]!==undefined)output+=`<span class="sayrox-number is-${match[1]}" dir="ltr">${escapeHtml(match[2])}</span>`;
    else if(match[3]!==undefined)output+=`<span class="sayrox-status-badge is-${match[3]}">${escapeHtml(match[4])}</span>`;
    else if(match[5]!==undefined){
      let safe=false;
      try{const url=new URL(match[6]);safe=['http:','https:','mailto:'].includes(url.protocol)&&!url.username&&!url.password;}catch{}
      output+=safe?`<a href="${escapeHtml(match[6])}" rel="noopener noreferrer" target="_blank">${inlineHtml(match[5])}</a>`:`${inlineHtml(match[5])} (${escapeHtml(match[6])})`;
    }
    else if(match[7]!==undefined)output+=`<code>${escapeHtml(match[7])}</code>`;
    else if(match[8]!==undefined)output+=`<strong>${inlineHtml(match[8])}</strong>`;
    else output+=`<em>${inlineHtml(match[9])}</em>`;
    cursor=match.index+match[0].length;
  }
  return output+numericTextHtml(source.slice(cursor));
}
function renderListHtml(block){
  const tag=block.ordered?'ol':'ul';
  const className=block.taskList?' class="sayrox-task-list"':'';
  return `<${tag}${className}>${block.items.map((item,index)=>{
    const checked=block.checks?.[index];
    if(checked===null||checked===undefined)return `<li>${inlineHtml(item)}</li>`;
    const marker=checked?'☑':'☐';
    return `<li class="sayrox-task-item ${checked?'is-checked':'is-pending'}"><span class="sayrox-task-marker ${checked?'is-success':'is-neutral'}" aria-hidden="true">${marker}</span><span>${inlineHtml(item)}</span></li>`;
  }).join('')}</${tag}>`;
}
function renderCalloutHtml(block){
  const title=block.title||({NOTE:'نکته',INFO:'اطلاعات',TIP:'پیشنهاد',IMPORTANT:'مهم',WARNING:'هشدار',CAUTION:'احتیاط',SUCCESS:'موفقیت',DANGER:'خطر',ERROR:'خطا'}[block.kind]||'یادداشت');
  const icon=({info:'ℹ️',success:'✅',accent:'✨',warning:'⚠️',danger:'⛔'}[block.tone]||'ℹ️');
  return `<aside class="sayrox-callout is-${block.tone}" role="note"><div class="sayrox-callout-header"><span class="sayrox-callout-icon" aria-hidden="true">${icon}</span><strong>${inlineHtml(title)}</strong></div><div class="sayrox-callout-body">${(block.lines||[]).map(line=>`<p>${inlineHtml(line)}</p>`).join('')}</div></aside>`;
}
function renderTableHtml(rows,alignments=[],numericColumns=[]){
  if(!Array.isArray(rows)||!rows.length)return '';
  const header=rows[0]||[],body=rows.slice(1);
  const alignClass=column=>{
    const explicit=alignments[column];
    if(['left','center','right'].includes(explicit))return `is-align-${explicit}`;
    return numericColumns[column]?'is-align-right':'';
  };
  const columns=header.map((cell,column)=>{
    const classes=[alignClass(column),numericColumns[column]?'is-numeric':''].filter(Boolean).join(' ');
    return `<th scope="col"${classes?` class="${classes}"`:''}>${inlineHtml(cell)}</th>`;
  }).join('');
  const cells=body.map(row=>`<tr>${header.map((_,column)=>{
    const classes=[alignClass(column),numericColumns[column]?'is-numeric':''].filter(Boolean).join(' ');
    return `<td${classes?` class="${classes}"`:''}${numericColumns[column]?' dir="ltr"':''}>${inlineHtml(row[column]??'')}</td>`;
  }).join('')}</tr>`).join('');
  return `<div class="table-wrap sayrox-table-wrap" role="region" aria-label="جدول پاسخ؛ برای دیدن ستون‌های بیشتر به‌صورت افقی پیمایش کنید" tabindex="0"><table class="sayrox-response-table"><thead><tr>${columns}</tr></thead><tbody>${cells}</tbody></table><span class="sayrox-table-scroll-hint" aria-hidden="true">برای دیدن ستون‌های بیشتر، افقی پیمایش کنید</span></div>`;
}
function renderHtml(source,title='SAYROX'){
  const blocks=parseBlocks(source);
  const content=blocks.map(block=>{
    if(block.type==='heading')return `<h${block.level}>${inlineHtml(block.text)}</h${block.level}>`;
    if(block.type==='paragraph')return `<p>${inlineHtml(block.text)}</p>`;
    if(block.type==='list')return renderListHtml(block);
    if(block.type==='quote')return `<blockquote>${block.lines.map(line=>`<p>${inlineHtml(line)}</p>`).join('')}</blockquote>`;
    if(block.type==='callout')return renderCalloutHtml(block);
    if(block.type==='code')return `<pre><code${block.language?` class="language-${escapeHtml(block.language)}"`:''}>${escapeHtml(block.text)}</code></pre>`;
    if(block.type==='chart')return renderChartHtml(block.chart);
    if(block.type==='table')return renderTableHtml(block.rows,block.alignments,block.numericColumns);
    if(block.type==='rule')return '<hr>';
    return '';
  }).join('\n');
  const safeTitle=escapeHtml(title||'SAYROX');
  return `<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${safeTitle}</title><style>body{font-family:Arial,sans-serif;line-height:1.95;max-width:900px;margin:36px auto;padding:0 20px;color:#172033}h1,h2,h3,h4,h5,h6{line-height:1.5;color:#245b8f}pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f2f5f9;padding:14px;border-radius:10px;direction:ltr;text-align:left}code{font-family:Consolas,monospace;background:#f2f5f9;padding:2px 5px;border-radius:4px}blockquote{margin:16px 0;padding:8px 16px;border-right:3px solid #36a6a0;background:#f5f8fb}.table-wrap{overflow-x:auto}table{border-collapse:collapse;width:100%;margin:18px 0}th,td{border:1px solid #d8e0e8;padding:8px 10px;text-align:right}th{background:#eef3f8}a{color:#245b8f}hr{border:0;border-top:1px solid #d8e0e8;margin:24px 0}.sayrox-callout{margin:16px 0;padding:12px 15px;border-inline-start:4px solid #6b4fd0;background:#f5f2ff;border-radius:12px}.sayrox-callout.is-success{border-color:#168452;background:#eaf7ef}.sayrox-callout.is-warning{border-color:#a86b08;background:#fff5df}.sayrox-callout.is-danger{border-color:#c62845;background:#fff0f2}.sayrox-callout.is-info{border-color:#6550bd;background:#f3f0ff}.sayrox-callout-header{font-weight:700;margin-bottom:6px}.sayrox-status-badge{display:inline-block;padding:1px 8px;border:1px solid #b7dec9;border-radius:999px;background:#e8f7ef;color:#087443;font-weight:700}.sayrox-number{display:inline-block;direction:ltr;unicode-bidi:isolate;font-variant-numeric:tabular-nums;font-weight:700;color:#355fb5}.sayrox-number.is-success{color:#168452}.sayrox-number.is-danger{color:#c62845}.sayrox-number.is-warning{color:#a86b08}.sayrox-number.is-neutral{color:#64748b}.sayrox-task-list{list-style:none;padding:0}.sayrox-task-marker{margin-inline-end:6px;font-weight:700}.sayrox-response-table .is-align-left{text-align:left}.sayrox-response-table .is-align-center{text-align:center}.sayrox-response-table .is-align-right{text-align:right}.sayrox-response-table .is-numeric{font-variant-numeric:tabular-nums;white-space:nowrap}.sayrox-response-table td.is-numeric{direction:ltr;text-align:end}.sayrox-chart-figure{margin:16px 0;padding:13px;border:1px solid #d8e0e8;border-radius:14px;overflow-x:auto}.sayrox-chart-figure figcaption{font-weight:700;margin-bottom:8px}.sayrox-chart-svg{display:block;width:100%;min-width:560px;height:auto;font-family:Arial,sans-serif}.sayrox-chart-grid{stroke:#d8e0e8;stroke-dasharray:3 4}.sayrox-chart-axis{fill:#64748b;font-size:12px}.sayrox-chart-label,.sayrox-chart-legend{fill:#172033;font-size:13px}.sayrox-chart-series-0{color:#6957d5;fill:#6957d5;stroke:#6957d5}.sayrox-chart-series-1{color:#168452;fill:#168452;stroke:#168452}.sayrox-chart-series-2{color:#a86b08;fill:#a86b08;stroke:#a86b08}.sayrox-chart-series-3{color:#c62845;fill:#c62845;stroke:#c62845}.sayrox-chart-series-4{color:#2878b8;fill:#2878b8;stroke:#2878b8}.sayrox-chart-series-5{color:#168c91;fill:#168c91;stroke:#168c91}.sayrox-chart-series-6{color:#8c5bb5;fill:#8c5bb5;stroke:#8c5bb5}.sayrox-chart-series-7{color:#c07824;fill:#c07824;stroke:#c07824}.sayrox-chart-series-8{color:#b64f87;fill:#b64f87;stroke:#b64f87}.sayrox-chart-series-9{color:#718096;fill:#718096;stroke:#718096}.sayrox-chart-line{fill:none;stroke-width:3;stroke-linecap:round;stroke-linejoin:round}.sayrox-chart-point{stroke:#fff;stroke-width:2}.sayrox-chart-slice{stroke:#fff;stroke-width:2}.sayrox-chart-data{margin-top:8px}.sayrox-chart-data summary{font-weight:700;cursor:pointer}.sayrox-chart-data table{min-width:100%}</style></head><body><main><h1>${safeTitle}</h1>${content}</main></body></html>`;
}
function toPlainText(source){
  return parseBlocks(source).map(block=>{
    if(block.type==='heading')return block.text;
    if(block.type==='paragraph')return block.text;
    if(block.type==='list')return block.items.map((item,index)=>`${block.checks?.[index]===true?'☑ ':block.checks?.[index]===false?'☐ ':''}${block.ordered?`${index+1}.`:'•'} ${item}`).join('\n');
    if(block.type==='quote')return block.lines.join('\n');
    if(block.type==='callout')return [block.title||block.kind,...block.lines].filter(Boolean).join('\n');
    if(block.type==='code')return block.text;
    if(block.type==='chart'){const spec=chartDrawingSpec(block.chart);return spec?[spec.title,['دسته',...spec.chart.series.map(item=>item.name)].join('\t'),...spec.rows.map(row=>row.map(value=>String(value)).join('\t'))].join('\n'):'';}
    if(block.type==='table')return block.rows.map(row=>row.join('\t')).join('\n');
    if(block.type==='rule')return '────────────────────────────────';
    return '';
  }).filter(Boolean).join('\n\n').replace(/\[\[(?:number|status):(?:success|warning|danger|info|neutral|accent)\|([^\]]{1,80})\]\]/g,'$1').replace(/\*\*([^*]+)\*\*/g,'$1').replace(/(?<!\*)\*([^*]+)\*(?!\*)/g,'$1').replace(/`([^`]+)`/g,'$1').replace(/\[([^\]]+)\]\((?:https?:\/\/|mailto:)[^\s)]+\)/g,'$1');
}
function tableToMarkdown(rows){
  if(!Array.isArray(rows)||!rows.length)return '';
  const cells=rows.map(row=>row.map(value=>String(value??'').replace(/\\/g,'\\\\').replace(/\|/g,'\\|').replace(/\r?\n/g,' ')));
  const width=Math.max(1,...cells.map(row=>row.length));
  const normalized=cells.map(row=>Array.from({length:width},(_,index)=>row[index]??''));
  return [normalized[0].map(value=>`| ${value} `).join('')+'|',normalized[0].map(()=> '| --- ').join('')+'|',...normalized.slice(1).map(row=>row.map(value=>`| ${value} `).join('')+'|')].join('\n');
}
window.SayroxMarkdown=Object.freeze({parseBlocks,parseTableRow:splitTableRow,tableToMarkdown,toPlainText,renderHtml,escapeHtml,tokenizeNumbers,isNumericValue,normalizeChart,chartDrawingSpec,renderChartHtml});
})();
