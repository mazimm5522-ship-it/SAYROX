(function (P) {
  const section = P.section;
  const status = P.status;
  P.register('apps', ctx => {
    const providerNames = { gapgpt: 'GapGPT', avalai: 'AvalAI', hooshgar: 'Hooshgar' };
    const primaryName = providerNames[ctx.providers.chatPrimary] || 'تنظیم نشده';
    const fallbackName = providerNames[ctx.providers.chatFallback] || 'ندارد';
    const providerRow = (name, state) => {
      if (!state) return status(name, 'وضعیت جزئیات از سرور دریافت نشد.', 'نامشخص', 'neutral');
      const missing = [];
      if (!state.keyConfigured) missing.push('کلید API تنظیم نشده');
      if (!state.baseUrlValid) missing.push('آدرس HTTPS نامعتبر است');
      if (!state.defaultModelConfigured) missing.push('مدل پیش‌فرض تنظیم نشده');
      return status(name, missing.length ? missing.join('؛ ') : 'کلید، آدرس HTTPS و مدل پیش‌فرض آماده‌اند.', state.ready ? 'آماده' : 'نیازمند تنظیم', state.ready ? 'success' : 'warning');
    };
    return `${P.head('apps', 'افزونه‌ها و موتور‌ها', 'وضعیت از Worker خوانده می‌شود؛ کلیدها در مرورگر نگهداری نمی‌شوند.', '#4cc38a')}${section('وضعیت اتصال',
      status('مسیریابی خودکار چت', `درگاه اصلی: ${primaryName} · مسیر جایگزین: ${fallbackName}. انتخاب دستی مدل، همیشه به همان درگاه متصل می‌ماند.`, ctx.providers.chatPrimaryReady ? 'آماده' : 'نیازمند بررسی', ctx.providers.chatPrimaryReady ? 'success' : 'warning') +
      providerRow('GapGPT 🇮🇷', ctx.providers.gapgpt) +
      providerRow('AvalAI 🇮🇷', ctx.providers.avalai) +
      providerRow('Hooshgar 🇮🇷', ctx.providers.hooshgar) +
      status('OpenRouter برای گفتگو', 'در مسیر گفتگو استفاده نمی‌شود؛ فقط Provider تصویری اختیاری است.', 'غیرفعال برای چت', 'neutral') +
      status('جست‌وجوی وب — Tavily', 'جست‌وجوی زنده و دریافت منبع.', ctx.providers.search ? 'متصل' : 'تنظیم نشده', ctx.providers.search ? 'success' : 'warning') +
      status('ورودی گفتار زنده — ElevenLabs Scribe', 'تشخیص بلادرنگ فارسی با توکن یک‌بارمصرف و سقف ۳ دقیقه برای هر نشست.', ctx.providers.voiceInput ? 'کلید API پیکربندی شده' : 'تنظیم نشده', ctx.providers.voiceInput ? 'success' : 'warning') +
      status('مکالمهٔ زنده — ElevenLabs Speech Engine', 'برای این مسیر علاوه بر API Key، شناسهٔ Speech Engine با پیشوند seng_ لازم است.', ctx.providers.voiceLive ? 'کلید و Engine پیکربندی شده' : 'نیازمند تنظیم Engine', ctx.providers.voiceLive ? 'success' : 'warning') +
      status('تبدیل متن به صدا — ElevenLabs', 'Voice ID انتخاب‌شده نیز باید پیکربندی شود.', ctx.providers.tts ? 'کلید/حداقل یک صدا تنظیم شده' : 'تنظیم نشده', ctx.providers.tts ? 'success' : 'warning') +
      status('تولید تصویر — OpenRouter', 'نیازمند کلید OpenRouter و OPENROUTER_IMAGE_MODEL؛ سهمیهٔ جدا برای هر پلن.', ctx.providers.images ? 'متصل' : 'تنظیم نشده', ctx.providers.images ? 'success' : 'warning') +
      status('کارهای زمان‌بندی‌شده — Scheduler', 'اجرای سروری کارها با Durable Object و درخواست امضاشدهٔ داخلی.', ctx.providers.tasks ? 'متصل' : 'تنظیم نشده', ctx.providers.tasks ? 'success' : 'warning') +
      status('پرداخت — زرین‌پال', 'درگاه درخواست پرداخت.', ctx.providers.payments ? 'متصل' : 'تنظیم نشده', ctx.providers.payments ? 'success' : 'warning'))}<p class="sx-footnote">چت با درگاه‌های دارای کلید معتبر در Cloudflare اجرا می‌شود. هرگز کلید API را در این صفحه یا کد مرورگر وارد نکن.</p>`;
  });
})(globalThis.SayroxSettingsPages);
