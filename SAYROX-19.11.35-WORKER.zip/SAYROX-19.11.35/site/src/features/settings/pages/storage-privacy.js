(function (P) {
  const section=P.section,row=P.row,toggle=P.toggle,status=P.status,button=P.button;
  const bytes=value=>{
    const n=Math.max(0,Number(value)||0);
    if(n<1024)return `${Math.round(n)} بایت`;
    if(n<1024*1024)return `${(n/1024).toFixed(1)} کیلوبایت`;
    if(n<1024*1024*1024)return `${(n/1024/1024).toFixed(1)} مگابایت`;
    return `${(n/1024/1024/1024).toFixed(2)} گیگابایت`;
  };
  const count=value=>Math.max(0,Number(value)||0).toLocaleString('fa-IR');
  P.register('storage', ctx => {
    const stats=ctx.storageStats||{};
    const percent=stats.quotaBytes>0?Math.min(100,Math.max(0,Math.round(stats.usageBytes/stats.quotaBytes*100))):0;
    const total=stats.loading?'در حال اندازه‌گیری…':bytes(stats.usageBytes);
    const quota=stats.quotaBytes?bytes(stats.quotaBytes):'نامشخص';
    const files=stats.files||{count:0,bytes:0};
    const images=stats.images||{count:0,bytes:0};
    return `${P.head('storage','فضای ذخیره‌سازی','مصرف فضای همین مرورگر، فایل‌های کتابخانه و گالری محلی را بررسی و مدیریت کن.','#5a8cff')}
      ${section('مصرف دستگاه',`<div class="sx-storage-total"><strong>${total}</strong><span>از ${quota}</span></div><div class="sx-storage-track" role="progressbar" aria-label="مصرف فضای مرورگر" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${percent}"><span style="width:${percent}%"></span></div><div class="sx-storage-meta"><span>مصرف کل مبدأ</span><strong>${stats.loading?'…':`${percent}٪`}</strong></div>` + row('داده‌های گفتگو و تنظیمات','اندازه‌ی تقریبی کلیدهای SAYROX در Local Storage.',`<strong class="sx-value">${bytes(stats.localStorageBytes)}</strong>`) + row('فایل‌های کتابخانه',`${count(files.count)} فایل در IndexedDB.`,`<strong class="sx-value">${bytes(files.bytes)}</strong>`) + row('تصاویر ساخته‌شده',`${count(images.count)} تصویر در گالری محلی.`,`<strong class="sx-value">${bytes(images.bytes)}</strong>`) + row('ماندگاری مرورگر','وضعیت درخواست محافظت از داده‌های سایت در برابر پاک‌سازی خودکار.',P.badge(stats.persisted===true?'محافظت‌شده':stats.persisted===false?'تضمین‌نشده':'نامشخص',stats.persisted===true?'success':'warning')))}
      ${section('مدیریت داده‌ها',row('به‌روزرسانی آمار','مقادیر دوباره از Storage API و کتابخانه‌های محلی خوانده می‌شوند.',button('storage-refresh','به‌روزرسانی','secondary')) + row('درخواست ماندگاری داده‌ها','از مرورگر درخواست کن داده‌های SAYROX را در پاک‌سازی خودکار حذف نکند؛ پذیرش با خود مرورگر است.',button('storage-persist','درخواست محافظت','secondary')) + row('پاک‌کردن تصاویر ساخته‌شده','فقط گالری تصاویر همین مرورگر پاک می‌شود؛ فایل‌های کتابخانه و گفتگوها باقی می‌مانند.',button('storage-clear-images','پاک‌کردن تصاویر','danger')) + row('پاک‌کردن گفتگوها','گفتگوهای محلی حذف می‌شوند؛ فایل‌های کتابخانه و تصاویر پاک نمی‌شوند.',button('clear-local-chats','پاک‌کردن گفتگوها','danger')))}
      <p class="sx-footnote">مصرف کل مرورگر شامل داده‌های این بخش و سایر داده‌های همین مبدأ است؛ اندازه‌ی فایل‌ها و تصاویر زیرمجموعه‌ی همین مقدار است و نباید با آن جمع زده شود. داده‌های این نسخه در دستگاه یا سرویس‌های ذخیره‌سازی متصل نگهداری می‌شوند و وابستگی به D1 وجود ندارد.</p>`;
  });
  P.register('privacy', ctx => {
    const googleLinked=Boolean(ctx.state.user?.googleLinked);
    return `${P.head('privacy','مرکز حریم خصوصی','مدیریت نگهداری داده‌ها، مجوزها، اتصال‌ها و خروجی اطلاعات.','#6a7bff')}
      ${section('ذخیره‌سازی و پردازش',toggle('storeChat','ذخیره‌سازی تاریخچه گفتگو','با خاموش‌کردن این گزینه، گفتگوهای جدید در Local Storage نگهداری نمی‌شوند؛ داده‌های قبلی خودکار حذف نخواهند شد.',ctx.state.settings.storeChat!==false) + status('فایل‌های کتابخانه','فایل‌های اضافه‌شده در IndexedDB همین مرورگر نگهداری می‌شوند.','محلی','success') + status('ارسال به مدل','متن پیام و پیوست‌های انتخاب‌شده هنگام درخواست برای Provider ارسال می‌شوند.','هنگام درخواست','warning') + status('کلیدهای سرویس','کلیدهای Provider فقط باید در Secretهای سمت Worker نگهداری شوند.','سمت سرور','success'))}
      ${section('مجوزها و کنترل استفاده',status('کمک به بهبود مدل برای همه','تنظیم رضایت آموزش در سطح Provider هنوز API تأییدشده‌ای در SAYROX ندارد؛ این گزینه از اینجا قابل تغییر نیست.','قابل تنظیم نیست','warning') + status('خدمات موقعیت مکانی','SAYROX در این نسخه موقعیت مکانی را در پس‌زمینه نمی‌خواند و ذخیره نمی‌کند.','خاموش','success') + status('دسترسی برنامه‌های متصل','وضعیت اتصال Google به حساب فعلی.',googleLinked?'Google متصل':'اتصال ثبت‌شده‌ای نیست',googleLinked?'success':'neutral'))}
      ${section('حقوق داده',row('خروجی داده‌ها','دریافت نسخه JSON از گفتگوها، پروژه‌ها، وظایف و فراداده‌های محلی.',button('export-data','دریافت خروجی','secondary')) + row('حذف تاریخچه','حذف گفتگوهای ذخیره‌شده در این دستگاه با تأیید صریح.',button('delete-all-chats','حذف گفتگوها','danger')) + status('حذف حساب کاربری','حذف حساب و تمام داده‌های سمت سرور تا زمان انتشار API امن در دسترس نیست؛ این صفحه حذف حساب را شبیه‌سازی نمی‌کند.','در دسترس نیست','warning'))}
      <p class="sx-footnote">خاموش‌کردن تاریخچه، فایل‌های کتابخانه، گالری تصاویر یا حافظه حساب را حذف نمی‌کند؛ هرکدام مدیریت جداگانه دارند. پاک‌کردن گفتگوهای محلی، اطلاعات سمت Provider را حذف نمی‌کند.</p>`;
  });
  P.register('history', ctx => {
    const chats=Array.isArray(ctx.state.chats)?ctx.state.chats:[];
    const visible=chats.filter(chat=>chat&&!chat.temp&&!chat.archived);
    const archived=Array.isArray(ctx.archivedChats)?ctx.archivedChats:chats.filter(chat=>chat?.archived&&!chat.temp);
    const archivedList=archived.length?`<div class="sx-archived-list">${archived.map(chat=>{
      const title=P.escape(String(chat.title||'گفتگوی بدون عنوان').slice(0,100));
      const date=Number.isFinite(Number(chat.updated))?new Date(Number(chat.updated)).toLocaleDateString('fa-IR'):'';
      const id=P.escape(String(chat.id||''));
      return `<article class="sx-archived-item"><div><strong>${title}</strong><small>${date} · ${(Array.isArray(chat.messages)?chat.messages.length:0).toLocaleString('fa-IR')} پیام</small></div><div class="sx-archived-actions">${button('restore-chat','بازیابی','secondary',`data-chat-id="${id}"`)}${button('delete-archived-chat','حذف','danger',`data-chat-id="${id}"`)}</div></article>`;
    }).join('')}</div>`:'<p class="sx-empty">گفتگوی بایگانی‌شده‌ای وجود ندارد.</p>';
    return `${P.head('history','تاریخچه و داده‌ها','کنترل تاریخچه، بایگانی گفتگوها، مجوزها و خروجی اطلاعات همین دستگاه.')}
      ${section('کنترل داده و حریم خصوصی',status('کمک به بهبود مدل برای همه','ثبت یا لغو رضایت آموزش در سطح Provider از حساب SAYROX قابل مدیریت نیست.', 'قابل مدیریت نیست','warning') + status('خدمات موقعیت مکانی','در این نسخه دسترسی پس‌زمینه یا ذخیره‌ی موقعیت مکانی فعال نیست.','خاموش','success') + status('برنامه‌های متصل','اتصال Google به حساب فعلی.',ctx.state.user?.googleLinked?'Google متصل':'اتصالی ثبت نشده',ctx.state.user?.googleLinked?'success':'neutral'))}
      ${section('خروجی و حساب',row('خروجی گرفتن از داده‌ها','دریافت نسخه JSON از گفتگوها، پروژه‌ها، وظایف و فراداده‌های محلی.',button('export-data','خروجی گرفتن','secondary')) + status('حذف حساب SAYROX','API حذف حساب و داده‌های سرور هنوز منتشر نشده است؛ حذف حساب از این صفحه انجام نمی‌شود.','در دسترس نیست','warning'))}
      ${section('تاریخچه چت',row('گفتگوهای فعال', 'گفتگوهای عادی و قابل مشاهده در همین مرورگر.',`<strong class="sx-value">${count(visible.length)}</strong>`) + row('گفتگوهای بایگانی‌شده','گفتگوهای بایگانی‌شده از فهرست اخیر پنهان می‌شوند و قابل بازیابی هستند.',`<strong class="sx-value">${count(archived.length)}</strong>`) + row('بایگانی همه گفتگوها','همه‌ی گفتگوهای دائمی و غیرموقت از فهرست اخیر خارج می‌شوند؛ هر مورد بعداً قابل بازیابی است.',button('archive-all-chats','بایگانی همه','secondary')) + row('پاک‌کردن تاریخچه چت','حذف همه گفتگوهای محلی، از جمله گفتگوهای بایگانی‌شده؛ این عملیات قابل بازگشت نیست.',button('delete-all-chats','پاک‌کردن تاریخچه','danger')))}
      ${section('مشاهده گفتگوهای بایگانی‌شده',archivedList)}
      <p class="sx-footnote">بایگانی فقط وضعیت محلی گفتگو را تغییر می‌دهد و پیام‌ها را حذف نمی‌کند. حذف تاریخچه فقط داده‌های همین مرورگر را پاک می‌کند و معادل حذف حساب یا پاک‌کردن داده‌های Provider نیست.</p>`;
  });
})(globalThis.SayroxSettingsPages);
