import { DurableObject } from 'cloudflare:workers';

// ───────────────────────── constants ─────────────────────────
export const MAX_TITLE = 80;
export const MAX_PROMPT = 2000;
export const MAX_OUTPUT = 8000;
const RUN_HISTORY = 60;            // finished runs kept per account
const MAX_PER_ALARM = 3;           // occurrences executed in one alarm wake-up
const MAX_ATTEMPTS = 3;            // initial try + 2 retries for transient failures
const RETRY_DELAY_MS = 10 * 60_000;
const MISSED_GRACE_MS = 6 * 3_600_000; // an occurrence delayed beyond this is skipped, never run late
const DISPATCH_TIMEOUT_MS = 100_000;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const ACCOUNT_KEY = /^[A-Za-z0-9_-]{43}$/;
const TIME = /^([01]\d|2[0-3]):([0-5]\d)$/;
const WEEKDAYS = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };

// ───────────────────────── time-zone aware schedule maths (pure) ─────────────────────────
function validTimeZone(tz) {
  if (typeof tz !== 'string' || !tz || tz.length > 64) return false;
  try { new Intl.DateTimeFormat('en-US', { timeZone: tz }); return true; } catch { return false; }
}
function zonedParts(ms, tz) {
  const parts = {};
  for (const part of new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric', weekday: 'short' }).formatToParts(new Date(ms))) parts[part.type] = part.value;
  return { y: +parts.year, m: +parts.month, d: +parts.day, h: +parts.hour % 24, mi: +parts.minute, s: +parts.second, wd: WEEKDAYS[parts.weekday] };
}
function offsetMs(ms, tz) {
  const p = zonedParts(ms, tz);
  return Date.UTC(p.y, p.m - 1, p.d, p.h, p.mi, p.s) - Math.floor(ms / 1000) * 1000;
}
function zonedToUtc(y, m, d, h, mi, tz) {
  const guess = Date.UTC(y, m - 1, d, h, mi);
  const first = offsetMs(guess, tz);
  let utc = guess - first;
  const second = offsetMs(utc, tz);
  if (second !== first) utc = guess - second;   // crossed a DST boundary
  return utc;
}
export function normalizeSchedule(input) {
  const fail = message => ({ ok: false, code: 'INVALID_SCHEDULE', message });
  if (!input || typeof input !== 'object' || Array.isArray(input)) return fail('زمان‌بندی معتبر نیست.');
  const type = input.type;
  if (!['once', 'daily', 'weekly'].includes(type)) return fail('نوع زمان‌بندی باید یک‌بار، روزانه یا هفتگی باشد.');
  const timezone = input.timezone === undefined ? 'Asia/Tehran' : input.timezone;
  if (!validTimeZone(timezone)) return fail('منطقه‌ی زمانی معتبر نیست.');
  const time = String(input.time || '');
  if (!TIME.test(time)) return fail('ساعت باید به شکل HH:MM باشد.');
  const schedule = { type, time, timezone };
  if (type === 'weekly') {
    const weekday = Number(input.weekday);
    if (!Number.isInteger(weekday) || weekday < 0 || weekday > 6) return fail('روز هفته معتبر نیست.');
    schedule.weekday = weekday;
  }
  if (type === 'once') {
    const date = String(input.date || '');
    const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(date);
    const check = match && new Date(Date.UTC(+match[1], +match[2] - 1, +match[3]));
    if (!match || check.getUTCFullYear() !== +match[1] || check.getUTCMonth() !== +match[2] - 1 || check.getUTCDate() !== +match[3]) return fail('تاریخ معتبر نیست.');
    schedule.date = date;
  }
  return { ok: true, schedule };
}
/** Next occurrence strictly after `after` (epoch ms), or null when a one-time schedule is in the past. */
export function computeNextRun(schedule, after) {
  const [hh, mm] = schedule.time.split(':').map(Number);
  const tz = schedule.timezone;
  const at = (dateMs) => { const d = new Date(dateMs); return zonedToUtc(d.getUTCFullYear(), d.getUTCMonth() + 1, d.getUTCDate(), hh, mm, tz); };
  if (schedule.type === 'once') {
    const [y, m, d] = schedule.date.split('-').map(Number);
    const candidate = zonedToUtc(y, m, d, hh, mm, tz);
    return candidate > after ? candidate : null;
  }
  const now = zonedParts(after, tz);
  const base = Date.UTC(now.y, now.m - 1, now.d);
  for (let day = 0; day <= 8; day++) {
    const dateMs = base + day * 86_400_000;
    if (schedule.type === 'weekly' && new Date(dateMs).getUTCDay() !== schedule.weekday) continue;
    const candidate = at(dateMs);
    if (candidate > after) return candidate;
  }
  return null;
}

// ───────────────────────── request signing (shared contract with the SAYROX Worker) ─────────────────────────
export async function signRequest(secret, timestamp, body) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const mac = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(`${timestamp}.${body}`));
  return [...new Uint8Array(mac)].map(byte => byte.toString(16).padStart(2, '0')).join('');
}

const taskShape = row => ({
  id: row.id, title: row.title, prompt: row.prompt, useSearch: Boolean(row.use_search), schedule: JSON.parse(row.schedule),
  enabled: Boolean(row.enabled), nextRun: row.next_run, createdAt: row.created_at, lastRunAt: row.last_run_at, lastStatus: row.last_status,
});
const runShape = row => ({
  runId: row.run_id, taskId: row.task_id, title: row.title, status: row.status, plannedAt: row.planned_at,
  startedAt: row.started_at, finishedAt: row.finished_at, output: row.output, error: row.error,
  searchUsed: Boolean(row.search_used), seen: Boolean(row.seen),
});

export class TaskAccountObject extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    ctx.blockConcurrencyWhile(async () => {
      this.ctx.storage.sql.exec(`
        CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS tasks (
          id TEXT PRIMARY KEY, title TEXT NOT NULL, prompt TEXT NOT NULL, use_search INTEGER NOT NULL DEFAULT 0,
          schedule TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1, next_run INTEGER, attempt INTEGER NOT NULL DEFAULT 0,
          created_at INTEGER NOT NULL, last_run_at INTEGER, last_status TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_tasks_due ON tasks(enabled, next_run);
        CREATE TABLE IF NOT EXISTS task_runs (
          run_id TEXT PRIMARY KEY, task_id TEXT NOT NULL, title TEXT NOT NULL,
          status TEXT NOT NULL CHECK(status IN ('dispatched','running','ok','failed','quota','missed')),
          planned_at INTEGER NOT NULL, started_at INTEGER NOT NULL, finished_at INTEGER,
          output TEXT, error TEXT, search_used INTEGER NOT NULL DEFAULT 0, seen INTEGER NOT NULL DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_runs_started ON task_runs(started_at);
      `);
    });
  }

  now() { return Date.now(); }
  rows(query, ...args) { return this.ctx.storage.sql.exec(query, ...args).toArray(); }
  run(query, ...args) { this.ctx.storage.sql.exec(query, ...args); }

  // ── public RPC (called only by the SAYROX Worker through its Durable Object binding) ──
  async listTasks() {
    return {
      ok: true,
      tasks: this.rows('SELECT * FROM tasks ORDER BY created_at DESC').map(taskShape),
      runs: this.rows('SELECT * FROM task_runs ORDER BY started_at DESC LIMIT 30').map(runShape),
      unseen: this.rows("SELECT COUNT(*) AS n FROM task_runs WHERE seen = 0 AND status IN ('ok','failed','quota')")[0].n,
    };
  }

  async createTask(input, maxTasks, accountKey) {
    if (!ACCOUNT_KEY.test(String(accountKey || ''))) return { ok: false, code: 'INVALID_ACCOUNT', message: 'حساب معتبر نیست.' };
    const title = String(input?.title || '').replace(/\u0000/g, '').trim().slice(0, MAX_TITLE);
    const prompt = String(input?.prompt || '').replace(/\u0000/g, '').trim().slice(0, MAX_PROMPT);
    if (title.length < 2) return { ok: false, code: 'INVALID_TASK', message: 'عنوان کار حداقل دو نویسه باشد.' };
    if (prompt.length < 5) return { ok: false, code: 'INVALID_TASK', message: 'دستور کار حداقل پنج نویسه باشد.' };
    const normalized = normalizeSchedule(input?.schedule);
    if (!normalized.ok) return normalized;
    const nextRun = computeNextRun(normalized.schedule, this.now());
    if (nextRun === null) return { ok: false, code: 'INVALID_SCHEDULE', message: 'زمان انتخاب‌شده گذشته است.' };
    const limit = Number.isInteger(maxTasks) && maxTasks > 0 ? maxTasks : 0;
    const task = this.ctx.storage.transactionSync(() => {
      const count = this.rows('SELECT COUNT(*) AS n FROM tasks')[0].n;
      if (count >= limit) return null;
      const id = crypto.randomUUID();
      this.run('INSERT OR REPLACE INTO meta (key, value) VALUES (?, ?)', 'account_key', accountKey);
      this.run('INSERT INTO tasks (id, title, prompt, use_search, schedule, enabled, next_run, attempt, created_at) VALUES (?, ?, ?, ?, ?, 1, ?, 0, ?)',
        id, title, prompt, input?.useSearch === true ? 1 : 0, JSON.stringify(normalized.schedule), nextRun, this.now());
      return taskShape(this.rows('SELECT * FROM tasks WHERE id = ?', id)[0]);
    });
    if (!task) return { ok: false, code: 'TASK_LIMIT', limit, message: 'به سقف تعداد کارهای زمان‌بندی‌شده‌ی پلن رسیده‌ای.' };
    await this.rearm();
    return { ok: true, task };
  }

  hasActiveRun(id) {
    return this.rows("SELECT run_id FROM task_runs WHERE task_id = ? AND status IN ('dispatched','running') LIMIT 1", id).length > 0;
  }

  async updateTask(id, changes) {
    if (!UUID.test(String(id || ''))) return { ok: false, code: 'INVALID_TASK', message: 'شناسه‌ی کار معتبر نیست.' };
    if (!changes || typeof changes !== 'object' || Array.isArray(changes)) return { ok: false, code: 'INVALID_TASK', message: 'تغییرات کار معتبر نیست.' };
    const keys = Object.keys(changes);
    if (!keys.length || keys.some(key => !['title', 'prompt', 'useSearch', 'schedule'].includes(key))) return { ok: false, code: 'INVALID_TASK', message: 'فیلدهای تغییر معتبر نیستند.' };
    if ('title' in changes && (typeof changes.title !== 'string' || changes.title.trim().replace(/\u0000/g, '').length < 2 || changes.title.length > MAX_TITLE)) return { ok: false, code: 'INVALID_TASK', message: 'عنوان کار باید بین ۲ تا ۸۰ نویسه باشد.' };
    if ('prompt' in changes && (typeof changes.prompt !== 'string' || changes.prompt.trim().replace(/\u0000/g, '').length < 5 || changes.prompt.length > MAX_PROMPT)) return { ok: false, code: 'INVALID_TASK', message: 'دستور کار باید بین ۵ تا ۲۰۰۰ نویسه باشد.' };
    if ('useSearch' in changes && typeof changes.useSearch !== 'boolean') return { ok: false, code: 'INVALID_TASK', message: 'تنظیم جست‌وجو معتبر نیست.' };
    const title = 'title' in changes ? String(changes.title).replace(/\u0000/g, '').trim().slice(0, MAX_TITLE) : null;
    const prompt = 'prompt' in changes ? String(changes.prompt).replace(/\u0000/g, '').trim().slice(0, MAX_PROMPT) : null;
    const result = this.ctx.storage.transactionSync(() => {
      const row = this.rows('SELECT * FROM tasks WHERE id = ?', id)[0];
      if (!row) return { ok: false, code: 'NOT_FOUND', message: 'کار پیدا نشد.' };
      if (this.hasActiveRun(id)) return { ok: false, code: 'TASK_RUNNING', message: 'این کار در حال اجراست؛ پس از پایان اجرا دوباره تلاش کن.' };
      const schedule = 'schedule' in changes ? normalizeSchedule(changes.schedule) : { ok: true, schedule: JSON.parse(row.schedule) };
      if (!schedule.ok) return schedule;
      const enabled = Boolean(row.enabled);
      const scheduleChanged = 'schedule' in changes;
      const nextRun = !enabled ? null : scheduleChanged ? computeNextRun(schedule.schedule, this.now()) : (row.next_run ?? computeNextRun(schedule.schedule, this.now()));
      if (enabled && nextRun === null) return { ok: false, code: 'INVALID_SCHEDULE', message: 'زمان انتخاب‌شده گذشته است.' };
      this.run('UPDATE tasks SET title = ?, prompt = ?, use_search = ?, schedule = ?, next_run = ?, attempt = 0 WHERE id = ?',
        title ?? row.title, prompt ?? row.prompt, 'useSearch' in changes ? (changes.useSearch ? 1 : 0) : row.use_search,
        JSON.stringify(schedule.schedule), nextRun, id);
      return { ok: true, task: taskShape(this.rows('SELECT * FROM tasks WHERE id = ?', id)[0]) };
    });
    if (!result.ok) return result;
    await this.rearm();
    return result;
  }

  async deleteTask(id) {
    if (!UUID.test(String(id || ''))) return { ok: false, code: 'INVALID_TASK' };
    const result = this.ctx.storage.transactionSync(() => {
      const row = this.rows('SELECT id FROM tasks WHERE id = ?', id)[0];
      if (!row) return { ok: false, code: 'NOT_FOUND', message: 'کار پیدا نشد.' };
      if (this.hasActiveRun(id)) return { ok: false, code: 'TASK_RUNNING', message: 'این کار در حال اجراست؛ پس از پایان اجرا می‌توانی آن را حذف کنی.' };
      this.run('DELETE FROM tasks WHERE id = ?', id);
      return { ok: true, deleted: true };
    });
    if (!result.ok) return result;
    await this.rearm();
    return result;
  }

  async setEnabled(id, enabled) {
    if (!UUID.test(String(id || '')) || typeof enabled !== 'boolean') return { ok: false, code: 'INVALID_TASK' };
    const result = this.ctx.storage.transactionSync(() => {
      const row = this.rows('SELECT * FROM tasks WHERE id = ?', id)[0];
      if (!row) return { ok: false, code: 'NOT_FOUND', message: 'کار پیدا نشد.' };
      if (this.hasActiveRun(id)) return { ok: false, code: 'TASK_RUNNING', message: 'این کار در حال اجراست؛ پس از پایان اجرا دوباره تلاش کن.' };
      if (enabled) {
        const next = computeNextRun(JSON.parse(row.schedule), this.now());
        if (next === null) return { ok: false, code: 'INVALID_SCHEDULE', message: 'زمان این کار گذشته است؛ کار جدید بساز.' };
        this.run('UPDATE tasks SET enabled = 1, next_run = ?, attempt = 0 WHERE id = ?', next, id);
      } else this.run('UPDATE tasks SET enabled = 0, next_run = NULL, attempt = 0 WHERE id = ?', id);
      return { ok: true, enabled };
    });
    if (!result.ok) return result;
    await this.rearm();
    return result;
  }

  async runNow(id) {
    if (!UUID.test(String(id || ''))) return { ok: false, code: 'INVALID_TASK' };
    const now = this.now();
    const result = this.ctx.storage.transactionSync(() => {
      const row = this.rows('SELECT id, next_run FROM tasks WHERE id = ?', id)[0];
      if (!row) return { ok: false, code: 'NOT_FOUND', message: 'کار پیدا نشد.' };
      if (this.hasActiveRun(id)) return { ok: false, code: 'TASK_RUNNING', message: 'این کار در حال اجراست؛ اجرای دوباره در همین زمان مجاز نیست.' };
      if (row.next_run !== null && Number(row.next_run) <= now) return { ok: true, queued: true };
      this.run('UPDATE tasks SET enabled = 1, next_run = ?, attempt = 0 WHERE id = ?', now, id);
      return { ok: true, queued: true };
    });
    if (!result.ok) return result;
    await this.rearm();
    return result;
  }

  async markSeen() { this.run('UPDATE task_runs SET seen = 1 WHERE seen = 0'); return { ok: true }; }

  /** One-time claim of a dispatched run by the SAYROX Worker; replays and unknown run ids are refused. */
  async claimRun(runId) {
    if (!UUID.test(String(runId || ''))) return { ok: false, code: 'RUN_NOT_CLAIMABLE' };
    return this.ctx.storage.transactionSync(() => {
      const run = this.rows("SELECT * FROM task_runs WHERE run_id = ? AND status = 'dispatched'", runId)[0];
      if (!run) return { ok: false, code: 'RUN_NOT_CLAIMABLE' };
      const task = this.rows('SELECT * FROM tasks WHERE id = ?', run.task_id)[0];
      if (!task) return { ok: false, code: 'RUN_NOT_CLAIMABLE' };
      this.run("UPDATE task_runs SET status = 'running' WHERE run_id = ?", runId);
      return { ok: true, task: { title: task.title, prompt: task.prompt, useSearch: Boolean(task.use_search), timezone: JSON.parse(task.schedule).timezone } };
    });
  }

  // ── scheduling ──
  async rearm() {
    const next = this.rows('SELECT MIN(next_run) AS t FROM tasks WHERE enabled = 1 AND next_run IS NOT NULL')[0].t;
    if (next === null || next === undefined) await this.ctx.storage.deleteAlarm();
    else await this.ctx.storage.setAlarm(Math.max(Number(next), this.now() + 1000));
  }

  async alarm() {
    const now = this.now();
    const due = this.rows('SELECT * FROM tasks WHERE enabled = 1 AND next_run IS NOT NULL AND next_run <= ? ORDER BY next_run LIMIT ?', now, MAX_PER_ALARM);
    for (const task of due) {
      try { await this.executeOccurrence(task, now); }
      catch (error) {
        const active = this.rows("SELECT run_id FROM task_runs WHERE task_id = ? AND status IN ('dispatched','running') ORDER BY started_at DESC LIMIT 1", task.id)[0];
        if (active) this.run("UPDATE task_runs SET status = 'failed', finished_at = ?, error = ? WHERE run_id = ?", this.now(), 'اجرای وظیفه به دلیل خطای داخلی کامل نشد.', active.run_id);
        console.error('SAYROX task occurrence failed', task.id, String(error?.message || error).slice(0, 200));
        this.advance(task, task.next_run, now, 'failed');
      }
    }
    this.run('DELETE FROM task_runs WHERE run_id NOT IN (SELECT run_id FROM task_runs ORDER BY started_at DESC LIMIT ?)', RUN_HISTORY);
    await this.rearm();
  }

  advance(task, planned, now, status) {
    const next = computeNextRun(JSON.parse(task.schedule), Math.max(planned, now));
    this.run('UPDATE tasks SET next_run = ?, enabled = ?, attempt = 0, last_run_at = ?, last_status = ? WHERE id = ?', next, next === null ? 0 : 1, now, status, task.id);
  }

  async executeOccurrence(task, now) {
    const planned = task.next_run, runId = crypto.randomUUID();
    if (now - planned > MISSED_GRACE_MS) {
      this.run("INSERT INTO task_runs (run_id, task_id, title, status, planned_at, started_at, finished_at, error) VALUES (?, ?, ?, 'missed', ?, ?, ?, ?)",
        runId, task.id, task.title, planned, now, now, 'این نوبت به دلیل تأخیر طولانی سیستم اجرا نشد.');
      this.advance(task, planned, now, 'missed');
      return;
    }
    this.run("INSERT INTO task_runs (run_id, task_id, title, status, planned_at, started_at) VALUES (?, ?, ?, 'dispatched', ?, ?)", runId, task.id, task.title, planned, now);
    const result = await this.dispatch(runId);
    const finished = this.now();
    if (result.ok) {
      this.run("UPDATE task_runs SET status = 'ok', finished_at = ?, output = ?, search_used = ? WHERE run_id = ?", finished, String(result.content).slice(0, MAX_OUTPUT), result.searchUsed ? 1 : 0, runId);
      this.advance(task, planned, finished, 'ok');
    } else if (result.code === 'QUOTA_EXCEEDED') {
      this.run("UPDATE task_runs SET status = 'quota', finished_at = ?, error = ? WHERE run_id = ?", finished, String(result.message || 'سهمیه تمام شده است.').slice(0, 300), runId);
      this.advance(task, planned, finished, 'quota');
    } else {
      this.run("UPDATE task_runs SET status = 'failed', finished_at = ?, error = ? WHERE run_id = ?", finished, String(result.message || 'اجرای کار ناموفق بود.').slice(0, 300), runId);
      if (result.retryable && task.attempt + 1 < MAX_ATTEMPTS) this.run('UPDATE tasks SET next_run = ?, attempt = ?, last_run_at = ?, last_status = ? WHERE id = ?', finished + RETRY_DELAY_MS, task.attempt + 1, finished, 'failed', task.id);
      else this.advance(task, planned, finished, 'failed');
    }
  }

  async dispatch(runId) {
    const origin = String(this.env.APP_ORIGIN || '').replace(/\/+$/, '');
    const secret = String(this.env.TASKS_INTERNAL_SECRET || '');
    const accountKey = this.rows("SELECT value FROM meta WHERE key = 'account_key'")[0]?.value;
    if (!/^https:\/\/[^/\s]+$/.test(origin) || /REPLACE/i.test(origin) || secret.length < 32 || !accountKey)
      return { ok: false, code: 'TASKS_MISCONFIGURED', message: 'پیکربندی Scheduler کامل نیست (APP_ORIGIN یا TASKS_INTERNAL_SECRET).', retryable: false };
    const body = JSON.stringify({ accountKey, runId });
    const timestamp = String(this.now());
    const abort = new AbortController(), timer = setTimeout(() => abort.abort(), DISPATCH_TIMEOUT_MS);
    try {
      const response = await fetch(`${origin}/api/internal/task-run`, {
        method: 'POST', signal: abort.signal,
        headers: { 'content-type': 'application/json', 'x-xy-timestamp': timestamp, 'x-xy-signature': await signRequest(secret, timestamp, body) },
        body,
      });
      const data = await response.json().catch(() => null);
      if (response.ok && data?.ok && typeof data.content === 'string' && data.content.trim()) return { ok: true, content: data.content, searchUsed: data.searchUsed === true };
      const code = String(data?.code || `HTTP_${response.status}`);
      return { ok: false, code, message: data?.message || `سرور برنامه خطای ${response.status} برگرداند.`, retryable: response.status >= 500 && !['TASKS_MISCONFIGURED', 'RUN_NOT_CLAIMABLE', 'QUOTA_EXCEEDED'].includes(code) };
    } catch (error) {
      return { ok: false, code: 'DISPATCH_FAILED', message: error?.name === 'AbortError' ? 'زمان اجرای کار تمام شد.' : 'ارتباط با سرور برنامه برقرار نشد.', retryable: true };
    } finally { clearTimeout(timer); }
  }
}

export default { async fetch() { return new Response('Not found', { status: 404, headers: { 'cache-control': 'no-store' } }); } };
