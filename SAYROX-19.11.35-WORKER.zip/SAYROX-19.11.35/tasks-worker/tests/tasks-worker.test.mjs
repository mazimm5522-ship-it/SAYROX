import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { DatabaseSync } from 'node:sqlite';

let source = await readFile(new URL('../src/index.js', import.meta.url), 'utf8');
source = source.replace("import { DurableObject } from 'cloudflare:workers';", 'class DurableObject { constructor(ctx, env) { this.ctx = ctx; this.env = env; } }');
const { TaskAccountObject, computeNextRun, normalizeSchedule, signRequest } = await import(`data:text/javascript;base64,${Buffer.from(source).toString('base64')}`);

const iso = value => Date.parse(value);
const ACCOUNT = 'A'.repeat(43);
const SECRET = 's'.repeat(40);

// ── schedule maths ──────────────────────────────────────────────
{
  const tehran = { type: 'daily', time: '09:00', timezone: 'Asia/Tehran' };            // UTC+03:30, no DST
  assert.equal(computeNextRun(tehran, iso('2026-11-04T05:00:00Z')), iso('2026-11-04T05:30:00Z'));
  assert.equal(computeNextRun(tehran, iso('2026-11-04T06:00:00Z')), iso('2026-11-05T05:30:00Z'));
  assert.equal(computeNextRun(tehran, iso('2026-11-04T05:30:00Z')), iso('2026-11-05T05:30:00Z'), 'strictly after');
  const weekly = { type: 'weekly', weekday: 1, time: '08:00', timezone: 'Asia/Tehran' };  // Monday
  assert.equal(computeNextRun(weekly, iso('2026-11-04T10:00:00Z')), iso('2026-11-09T04:30:00Z'));
  const once = { type: 'once', date: '2026-12-01', time: '10:15', timezone: 'Asia/Tehran' };
  assert.equal(computeNextRun(once, iso('2026-11-04T00:00:00Z')), iso('2026-12-01T06:45:00Z'));
  assert.equal(computeNextRun(once, iso('2026-12-02T00:00:00Z')), null, 'past one-time schedule');
  // DST: local 09:00 stays 09:00 across both transitions
  const ny = { type: 'daily', time: '09:00', timezone: 'America/New_York' };
  assert.equal(computeNextRun(ny, iso('2026-10-31T13:30:00Z')), iso('2026-11-01T14:00:00Z'), 'fall back (EDT→EST)');
  assert.equal(computeNextRun(ny, iso('2026-03-07T15:00:00Z')), iso('2026-03-08T13:00:00Z'), 'spring forward (EST→EDT)');
}
{
  assert.equal(normalizeSchedule({ type: 'daily', time: '9:00' }).ok, false);
  assert.equal(normalizeSchedule({ type: 'hourly', time: '09:00' }).ok, false);
  assert.equal(normalizeSchedule({ type: 'daily', time: '09:00', timezone: 'Mars/Base' }).ok, false);
  assert.equal(normalizeSchedule({ type: 'weekly', time: '09:00', weekday: 7 }).ok, false);
  assert.equal(normalizeSchedule({ type: 'once', time: '09:00', date: '2026-02-30' }).ok, false);
  assert.equal(normalizeSchedule({ type: 'daily', time: '09:00' }).schedule.timezone, 'Asia/Tehran');
}

// ── Durable Object behaviour (real SQLite via node:sqlite) ──────────────
function createObject(env = { APP_ORIGIN: 'https://xynora.test', TASKS_INTERNAL_SECRET: SECRET }, start = iso('2026-11-04T05:00:00Z')) {
  const db = new DatabaseSync(':memory:');
  const alarms = { at: null, history: [] };
  const sql = {
    exec(query, ...args) {
      if (!args.length && /;\s*(CREATE|INSERT|UPDATE|DELETE|ALTER)/i.test(query)) { db.exec(query); return { toArray: () => [], one: () => null }; }
      const statement = db.prepare(query);
      if (/^\s*(SELECT|WITH)\b/i.test(query)) { const rows = statement.all(...args); return { toArray: () => rows, one: () => rows[0] ?? null }; }
      statement.run(...args); return { toArray: () => [], one: () => null };
    }
  };
  const storage = {
    sql,
    transactionSync(callback) { db.exec('BEGIN IMMEDIATE'); try { const r = callback(); db.exec('COMMIT'); return r; } catch (e) { db.exec('ROLLBACK'); throw e; } },
    async setAlarm(at) { alarms.at = at; alarms.history.push(at); },
    async deleteAlarm() { alarms.at = null; alarms.history.push(null); }
  };
  const ctx = { storage, blockConcurrencyWhile(cb) { this.init = Promise.resolve().then(cb); return this.init; } };
  const instance = new TaskAccountObject(ctx, env);
  const clock = { now: start };
  instance.now = () => clock.now;
  return { instance, clock, alarms, db, ready: ctx.init };
}
const daily = { type: 'daily', time: '09:00', timezone: 'Asia/Tehran' };
const input = (extra = {}) => ({ title: 'خلاصه خبر', prompt: 'اخبار مهم امروز را خلاصه کن', schedule: daily, ...extra });

// create → alarm armed at the next occurrence; plan limit enforced atomically
{
  const { instance, alarms, ready } = createObject();
  await ready;
  const created = await instance.createTask(input(), 2, ACCOUNT);
  assert.equal(created.ok, true);
  assert.equal(created.task.nextRun, iso('2026-11-04T05:30:00Z'));
  assert.equal(alarms.at, iso('2026-11-04T05:30:00Z'));
  assert.equal((await instance.createTask(input({ title: 'دوم' }), 2, ACCOUNT)).ok, true);
  const third = await instance.createTask(input({ title: 'سوم' }), 2, ACCOUNT);
  assert.equal(third.code, 'TASK_LIMIT');
  assert.equal((await instance.createTask(input({ title: 'x' }), 5, ACCOUNT)).code, 'INVALID_TASK');
  assert.equal((await instance.createTask(input({ schedule: { type: 'once', date: '2026-11-01', time: '09:00' } }), 5, ACCOUNT)).code, 'INVALID_SCHEDULE');
  assert.equal((await instance.createTask(input(), 5, 'bad-key')).code, 'INVALID_ACCOUNT');
}

// successful run: signed dispatch, one-time claim, result stored, next day armed
{
  const { instance, clock, alarms, ready } = createObject();
  await ready;
  const { task } = await instance.createTask(input({ useSearch: true }), 3, ACCOUNT);
  clock.now = iso('2026-11-04T05:30:05Z');
  const calls = [];
  globalThis.fetch = async (url, init) => {
    const body = JSON.parse(init.body);
    calls.push({ url, init, body });
    assert.equal(init.headers['x-xy-signature'], await signRequest(SECRET, init.headers['x-xy-timestamp'], init.body), 'signature must match the shared contract');
    const claim = await instance.claimRun(body.runId);
    assert.equal(claim.ok, true);
    assert.equal(claim.task.useSearch, true);
    assert.equal((await instance.claimRun(body.runId)).ok, false, 'replayed run is refused');
    return new Response(JSON.stringify({ ok: true, content: 'خلاصهٔ امروز', searchUsed: true }), { status: 200, headers: { 'content-type': 'application/json' } });
  };
  await instance.alarm();
  assert.equal(calls.length, 1);
  assert.equal(calls[0].url, 'https://xynora.test/api/internal/task-run');
  assert.equal(calls[0].body.accountKey, ACCOUNT);
  assert.equal(Object.keys(calls[0].body).sort().join(), 'accountKey,runId', 'prompt never travels in the signed request');
  const listed = await instance.listTasks();
  assert.equal(listed.runs[0].status, 'ok');
  assert.equal(listed.runs[0].output, 'خلاصهٔ امروز');
  assert.equal(listed.runs[0].searchUsed, true);
  assert.equal(listed.unseen, 1);
  assert.equal(listed.tasks[0].nextRun, iso('2026-11-05T05:30:00Z'));
  assert.equal(alarms.at, iso('2026-11-05T05:30:00Z'));
  await instance.markSeen();
  assert.equal((await instance.listTasks()).unseen, 0);
  assert.equal(task.id, listed.tasks[0].id);
}

// transient failure: retried after 10 minutes, then gives up and moves to the next occurrence
{
  const { instance, clock, ready } = createObject();
  await ready;
  await instance.createTask(input(), 3, ACCOUNT);
  let hits = 0;
  globalThis.fetch = async () => { hits++; return new Response(JSON.stringify({ ok: false, code: 'CHAT_FAILED', message: 'down' }), { status: 503 }); };
  clock.now = iso('2026-11-04T05:30:01Z');
  await instance.alarm();
  let t = (await instance.listTasks()).tasks[0];
  assert.equal(t.nextRun, clock.now + 10 * 60_000, 'first retry in 10 minutes');
  clock.now = t.nextRun; await instance.alarm();
  t = (await instance.listTasks()).tasks[0];
  assert.equal(t.nextRun, clock.now + 10 * 60_000, 'second retry');
  clock.now = t.nextRun; await instance.alarm();
  t = (await instance.listTasks()).tasks[0];
  assert.equal(hits, 3);
  assert.equal(t.nextRun, iso('2026-11-05T05:30:00Z'), 'after 3 attempts the next day is scheduled');
  assert.equal((await instance.listTasks()).runs.filter(r => r.status === 'failed').length, 3);
}

// quota exceeded is not retried; one-time tasks switch themselves off
{
  const { instance, clock, alarms, ready } = createObject();
  await ready;
  await instance.createTask(input(), 3, ACCOUNT);
  await instance.createTask(input({ title: 'یک‌بار', schedule: { type: 'once', date: '2026-11-04', time: '09:05', timezone: 'Asia/Tehran' } }), 3, ACCOUNT);
  let n = 0;
  globalThis.fetch = async (url, init) => {
    n++;
    const { runId } = JSON.parse(init.body); await instance.claimRun(runId);
    return n === 1 ? new Response(JSON.stringify({ ok: false, code: 'QUOTA_EXCEEDED', message: 'سقف گفتگو' }), { status: 429 })
                   : new Response(JSON.stringify({ ok: true, content: 'انجام شد' }), { status: 200 });
  };
  clock.now = iso('2026-11-04T05:36:00Z');            // both occurrences due (05:30 and 05:35)
  await instance.alarm();
  const state = await instance.listTasks();
  assert.equal(state.runs.find(r => r.status === 'quota').title, 'خلاصه خبر');
  const once = state.tasks.find(t => t.title === 'یک‌بار');
  assert.equal(once.enabled, false);
  assert.equal(once.nextRun, null);
  assert.equal(alarms.at, iso('2026-11-05T05:30:00Z'));
  assert.equal(n, 2, 'no retry after quota');
}

// an occurrence delayed by more than 6h is skipped, never executed late
{
  const { instance, clock, ready } = createObject();
  await ready;
  await instance.createTask(input(), 3, ACCOUNT);
  let called = false; globalThis.fetch = async () => { called = true; return new Response('{}'); };
  clock.now = iso('2026-11-04T13:00:00Z');
  await instance.alarm();
  assert.equal(called, false);
  const state = await instance.listTasks();
  assert.equal(state.runs[0].status, 'missed');
  assert.equal(state.tasks[0].nextRun, iso('2026-11-05T05:30:00Z'));
}

// misconfiguration fails closed and is not retried; pause / resume / run-now / delete
{
  const { instance, clock, alarms, ready } = createObject({ APP_ORIGIN: 'https://REPLACE-WITH-YOUR-WORKER-ORIGIN', TASKS_INTERNAL_SECRET: SECRET });
  await ready;
  const { task } = await instance.createTask(input(), 3, ACCOUNT);
  let called = false; globalThis.fetch = async () => { called = true; return new Response('{}'); };
  clock.now = iso('2026-11-04T05:30:01Z');
  await instance.alarm();
  assert.equal(called, false);
  assert.equal((await instance.listTasks()).runs[0].error.includes('Scheduler'), true);
  assert.equal((await instance.setEnabled(task.id, false)).ok, true);
  assert.equal(alarms.at, null, 'no alarm while every task is paused');
  assert.equal((await instance.setEnabled(task.id, true)).ok, true);
  assert.notEqual(alarms.at, null);
  clock.now = iso('2026-11-04T07:00:00Z');
  await instance.runNow(task.id);
  assert.equal(alarms.at, clock.now + 1000);
  assert.equal((await instance.deleteTask(task.id)).ok, true);
  assert.equal(alarms.at, null);
  assert.equal((await instance.setEnabled('not-a-uuid', true)).ok, false);
  assert.equal((await instance.claimRun(crypto.randomUUID())).ok, false);
}
// task management updates validate atomically, preserve paused state and refuse mutation during execution
{
  const { instance, clock, alarms, ready } = createObject();
  await ready;
  const { task } = await instance.createTask(input(), 3, ACCOUNT);
  const updated = await instance.updateTask(task.id, {
    title: 'خلاصه خبر جدید', prompt: 'اخبار مهم فناوری امروز را خلاصه کن', useSearch: true,
    schedule: { type: 'daily', time: '10:00', timezone: 'Asia/Tehran' }
  });
  assert.equal(updated.ok, true);
  assert.equal(updated.task.title, 'خلاصه خبر جدید');
  assert.equal(updated.task.useSearch, true);
  assert.deepEqual(updated.task.schedule, { type: 'daily', time: '10:00', timezone: 'Asia/Tehran' });
  assert.equal(updated.task.nextRun, iso('2026-11-04T06:30:00Z'));
  clock.now = iso('2026-11-04T06:00:00Z');
  const dueSoon = await instance.updateTask(task.id, { title: 'عنوان بدون تغییر زمان' });
  assert.equal(dueSoon.task.nextRun, updated.task.nextRun, 'metadata-only edit must preserve the scheduled occurrence');
  const titleBeforeInvalidEdit = dueSoon.task.title;
  assert.equal((await instance.updateTask(task.id, { title: 'x' })).code, 'INVALID_TASK');
  assert.equal((await instance.listTasks()).tasks[0].title, titleBeforeInvalidEdit, 'invalid updates do not partially modify task state');

  assert.equal((await instance.setEnabled(task.id, false)).ok, true);
  const pausedUpdate = await instance.updateTask(task.id, { schedule: { type: 'daily', time: '11:00', timezone: 'Asia/Tehran' } });
  assert.equal(pausedUpdate.ok, true);
  assert.equal(pausedUpdate.task.enabled, false);
  assert.equal(pausedUpdate.task.nextRun, null, 'editing a paused task must not silently resume it');
  assert.equal(alarms.at, null);
  assert.equal((await instance.setEnabled(task.id, true)).ok, true);
  clock.now += 1000;
  const nowResult = await instance.runNow(task.id);
  assert.equal(nowResult.queued, true);
  assert.equal((await instance.runNow(task.id)).queued, true, 'repeated run-now requests reuse the queued occurrence');
  assert.equal(alarms.at, clock.now + 1000);
}
{
  const { instance, ready } = createObject();
  await ready;
  const { task } = await instance.createTask(input(), 3, ACCOUNT);
  const runId = crypto.randomUUID();
  instance.run("INSERT INTO task_runs (run_id, task_id, title, status, planned_at, started_at) VALUES (?, ?, ?, 'running', ?, ?)", runId, task.id, task.title, instance.now(), instance.now());
  assert.equal((await instance.updateTask(task.id, { title: 'تغییر هم‌زمان' })).code, 'TASK_RUNNING');
  assert.equal((await instance.setEnabled(task.id, false)).code, 'TASK_RUNNING');
  assert.equal((await instance.runNow(task.id)).code, 'TASK_RUNNING');
  assert.equal((await instance.deleteTask(task.id)).code, 'TASK_RUNNING');
  assert.equal((await instance.listTasks()).tasks.length, 1, 'running task cannot be removed');
}
{
  const { instance, ready } = createObject();
  await ready;
  assert.equal((await instance.deleteTask(crypto.randomUUID())).code, 'NOT_FOUND', 'deleting an unknown task is not reported as success');
  assert.equal((await instance.updateTask(crypto.randomUUID(), { title: 'نام جدید' })).code, 'NOT_FOUND');
}
console.log('Tasks worker tests passed: schedule maths (Tehran, DST), limits, signed dispatch, one-time claim, retries, quota, missed-run policy');
