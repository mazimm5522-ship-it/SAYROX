import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';
import { webcrypto } from 'node:crypto';

const source = await readFile(new URL('../site/_worker.js', import.meta.url), 'utf8');
const sandbox = vm.createContext({
  crypto: webcrypto, Request, Response, Headers, URL, URLSearchParams,
  AbortController, AbortSignal, ReadableStream, TextEncoder, TextDecoder,
  Uint8Array, ArrayBuffer, Blob, setTimeout, clearTimeout, console,
  atob, btoa, Date, Math, JSON, Number, String, Boolean, Object, Array,
  Map, Set, RegExp, Error, TypeError, Promise, Intl
});
vm.runInContext(source.replace('export default __worker;', 'globalThis.__sayrox = { __worker, __load };'), sandbox, { filename: 'site/_worker.js' });
const load = sandbox.__sayrox.__load;
const tickets = load('worker/agent/approval-tickets.js');
const registry = load('worker/agent/tool-registry.js');
const approvalApi = load('worker/features/agent-approval.js');
const secret = 'test-secret-that-is-long-enough-for-sayrox-auth';
const accountKey = 'a'.repeat(43);
const runId = webcrypto.randomUUID();

{
  const args = { prompt: 'a precise image description', ratio: '16:9' };
  const sealed = await tickets.sealAgentApprovalTicket({ AUTH_SESSION_SECRET: secret }, {
    accountKey, runId, toolId: 'generate_image', callId: 'call_image_0001', args,
    risk: 'create', description: 'Generate a picture', specialist: 'creative'
  });
  assert.match(sealed.token, /^v1\./);
  assert.equal(sealed.title, undefined, 'sealed ticket payload does not contain a UI-generated title');
  assert.doesNotMatch(sealed.token, /precise image description/, 'ticket is encrypted, not merely signed');
  const opened = await tickets.openAgentApprovalTicket({ AUTH_SESSION_SECRET: secret }, sealed.token);
  assert.equal(opened.accountKey, accountKey);
  assert.equal(opened.toolId, 'generate_image');
  assert.deepEqual(JSON.parse(JSON.stringify(opened.args)), args);
  assert.equal(await tickets.openAgentApprovalTicket({ AUTH_SESSION_SECRET: 'different-secret-which-is-long-enough' }, sealed.token), null);
  const tampered = sealed.token.slice(0, -1) + (sealed.token.endsWith('A') ? 'B' : 'A');
  assert.equal(await tickets.openAgentApprovalTicket({ AUTH_SESSION_SECRET: secret }, tampered), null);
}

{
  assert.equal(await registry.approvalArgsHash({ a: 1, b: 2 }), await registry.approvalArgsHash({ b: 2, a: 1 }));
  assert.notEqual(await registry.approvalArgsHash({ a: 1, b: 2 }), await registry.approvalArgsHash({ a: 1, b: 3 }));
}

{
  const sealed = await tickets.sealAgentApprovalTicket({ AUTH_SESSION_SECRET: secret }, {
    accountKey, runId: webcrypto.randomUUID(), toolId: 'generate_image', callId: 'call_image_deny_01',
    args: { prompt: 'create a mountain image', ratio: '1:1' }, risk: 'create', description: 'Generate image', specialist: 'creative'
  });
  const consumed = new Set();
  const stub = {
    async consumeAgentApproval(id, account, expires, decision) {
      if (consumed.has(id)) return { ok: false, code: 'AGENT_APPROVAL_REPLAYED' };
      consumed.add(id); return { ok: true, decision };
    },
    async recordAgentRun(record) { this.lastRun = record; return { ok: true }; }
  };
  const env = { AUTH_SESSION_SECRET: secret, USAGE_ACCOUNT: { idFromName: () => 'account', get: () => stub } };
  const makeRequest = () => new Request('https://sayrox.test/api/agent/approval', {
    method: 'POST', headers: { 'content-type': 'application/json', origin: 'https://sayrox.test', 'sec-fetch-site': 'same-origin' },
    body: JSON.stringify({ ticket: sealed.token, decision: 'deny' })
  });
  const first = await approvalApi.agentApprovalApi(makeRequest(), env, { accountKey });
  assert.equal(first.status, 200);
  assert.equal((await first.json()).approved, false);
  assert.equal(stub.lastRun.state, 'cancelled');
  assert.equal(stub.lastRun.toolEvents[0].status, 'cancelled', 'user denial is recorded as cancellation, not tool failure');
  const replay = await approvalApi.agentApprovalApi(makeRequest(), env, { accountKey });
  assert.equal(replay.status, 409, 'denied ticket is consumed and cannot be replayed');
  const wrongAccount = await approvalApi.agentApprovalApi(makeRequest(), env, { accountKey: 'b'.repeat(43) });
  assert.equal(wrongAccount.status, 403, 'a ticket cannot be used from another account');
}

console.log('agent approval tests: encrypted/expiring account-bound tickets, exact argument binding, one-use denial and handler isolation passed');

{
  const taskArgs = {
    title: 'ارسال گزارش روزانه',
    prompt: 'گزارش وضعیت کارهای روزانه را آماده کن.',
    schedule: { type: 'once', date: '2099-12-30', time: '09:00', timezone: 'Europe/Berlin' },
    useSearch: false
  };
  const sealed = await tickets.sealAgentApprovalTicket({ AUTH_SESSION_SECRET: secret }, {
    accountKey, runId: webcrypto.randomUUID(), toolId: 'create_scheduled_task',
    callId: 'call_task_approved_01', args: taskArgs, risk: 'create',
    description: 'Create a scheduled task', specialist: 'main'
  });
  const consumed = new Set();
  let taskCalls = 0;
  const usageStub = {
    async consumeAgentApproval(id, account, expires, decision) {
      if (account !== accountKey || expires <= Date.now() || consumed.has(id)) return { ok: false, code: 'AGENT_APPROVAL_REPLAYED' };
      consumed.add(id); return { ok: true, decision };
    },
    async recordAgentRun(record) { this.lastRun = record; return { ok: true }; }
  };
  const env = {
    AUTH_SESSION_SECRET: secret,
    TASKS_INTERNAL_SECRET: 'task-internal-secret-long-enough-for-testing',
    USAGE_ACCOUNT: { idFromName: () => 'usage', get: () => usageStub },
    BILLING_ACCOUNT: { idFromName: () => 'billing', get: () => ({ async getSubscriptionSnapshot() { return { current: null }; } }) },
    TASKS_ACCOUNT: { idFromName: () => 'tasks', get: () => ({
      async createTask(input, limit, account) {
        taskCalls++;
        assert.equal(account, accountKey);
        assert.ok(limit > 0);
        if (input.title === 'failure test') return { ok: false, code: 'TASK_CREATE_FAILED', message: 'mock task storage failure' };
        return { ok: true, task: { id: 'task-0001', title: input.title, schedule: input.schedule, nextRun: '2099-12-30T08:00:00.000Z', enabled: true } };
      }
    }) }
  };
  const makeRequest = () => new Request('https://sayrox.test/api/agent/approval', {
    method: 'POST', headers: { 'content-type': 'application/json', origin: 'https://sayrox.test', 'sec-fetch-site': 'same-origin' },
    body: JSON.stringify({ ticket: sealed.token, decision: 'approve' })
  });
  const approved = await approvalApi.agentApprovalApi(makeRequest(), env, { accountKey });
  const body = await approved.json();
  assert.equal(approved.status, 200);
  assert.equal(body.ok, true);
  assert.equal(body.approved, true);
  assert.equal(body.toolId, 'create_scheduled_task');
  assert.equal(taskCalls, 1, 'the approved action runs exactly once');
  assert.equal(usageStub.lastRun.state, 'completed', 'approval result is persisted as a completed Agent run');
  const replay = await approvalApi.agentApprovalApi(makeRequest(), env, { accountKey });
  assert.equal(replay.status, 409, 'an approved ticket cannot execute twice');
  assert.equal(taskCalls, 1, 'replaying the same ticket never repeats the side effect');

  const failedArgs = { ...taskArgs, title: 'failure test' };
  const failedTicket = await tickets.sealAgentApprovalTicket({ AUTH_SESSION_SECRET: secret }, {
    accountKey, runId: webcrypto.randomUUID(), toolId: 'create_scheduled_task',
    callId: 'call_task_approved_fail_01', args: failedArgs, risk: 'create', specialist: 'main'
  });
  const failedRequest = () => new Request('https://sayrox.test/api/agent/approval', {
    method: 'POST', headers: { 'content-type': 'application/json', origin: 'https://sayrox.test', 'sec-fetch-site': 'same-origin' },
    body: JSON.stringify({ ticket: failedTicket.token, decision: 'approve' })
  });
  const failed = await approvalApi.agentApprovalApi(failedRequest(), env, { accountKey });
  const failedBody = await failed.json();
  assert.equal(failed.status, 502);
  assert.equal(failedBody.ok, false, 'a nested handler failure must never be reported as success');
  assert.equal(failedBody.code, 'TASK_CREATE_FAILED');
  assert.equal(usageStub.lastRun.state, 'failed', 'failed handlers are persisted as failed Agent runs');
  const failedReplay = await approvalApi.agentApprovalApi(failedRequest(), env, { accountKey });
  assert.equal(failedReplay.status, 409, 'a consumed ticket cannot be retried after a side-effect failure');
  assert.equal(taskCalls, 2);
}

console.log('agent approval integration: explicit approval executes once, persists completion, and never masks nested handler failure');

{
  const taskId = webcrypto.randomUUID();
  const consumed = new Set();
  const taskCalls = [];
  const usageStub = {
    async consumeAgentApproval(id, account, expiresAt, decision) {
      if (account !== accountKey || expiresAt <= Date.now() || consumed.has(id)) return { ok: false, code: 'AGENT_APPROVAL_REPLAYED' };
      consumed.add(id); return { ok: true, decision };
    },
    async recordAgentRun(record) { this.lastRun = record; return { ok: true }; }
  };
  const taskStub = {
    async setEnabled(id, enabled) { taskCalls.push(['setEnabled', id, enabled]); return { ok: true, enabled }; },
    async runNow(id) { taskCalls.push(['runNow', id]); return { ok: true, queued: true }; },
    async updateTask(id, changes) { taskCalls.push(['updateTask', id, changes]); return { ok: true, task: { id, title: changes.title || 'کار موجود', schedule: changes.schedule || { type: 'daily', time: '09:00', timezone: 'Asia/Tehran' }, enabled: true, nextRun: Date.now() + 60000 } }; },
    async deleteTask(id) { taskCalls.push(['deleteTask', id]); return { ok: true, deleted: true }; }
  };
  const env = {
    AUTH_SESSION_SECRET: secret,
    TASKS_INTERNAL_SECRET: 'tasks-secret-long-enough-to-pass-validation',
    USAGE_ACCOUNT: { idFromName: () => 'usage', get: () => usageStub },
    TASKS_ACCOUNT: { idFromName: name => name, get: name => { assert.equal(name, `xynora-account:${accountKey}`); return taskStub; } }
  };
  async function approve(toolId, args, risk, callId) {
    const sealed = await tickets.sealAgentApprovalTicket({ AUTH_SESSION_SECRET: secret }, {
      accountKey, runId: webcrypto.randomUUID(), toolId, callId, args, risk, description: 'Manage task', specialist: 'main'
    });
    const request = () => new Request('https://sayrox.test/api/agent/approval', {
      method: 'POST', headers: { 'content-type': 'application/json', origin: 'https://sayrox.test', 'sec-fetch-site': 'same-origin' },
      body: JSON.stringify({ ticket: sealed.token, decision: 'approve' })
    });
    const response = await approvalApi.agentApprovalApi(request(), env, { accountKey });
    return { response, replay: () => approvalApi.agentApprovalApi(request(), env, { accountKey }) };
  }
  const pause = await approve('manage_scheduled_task', { taskId, action: 'pause' }, 'modify', 'call_task_pause_01');
  assert.equal(pause.response.status, 200);
  assert.equal((await pause.response.json()).toolId, 'manage_scheduled_task');
  assert.deepEqual(taskCalls[0], ['setEnabled', taskId, false]);
  assert.equal((await pause.replay()).status, 409, 'a management approval cannot be replayed');

  const updateChanges = { schedule: { type: 'daily', time: '10:30', timezone: 'Europe/Berlin' }, title: 'جلسه جدید' };
  const update = await approve('manage_scheduled_task', { taskId, action: 'update', changes: updateChanges }, 'modify', 'call_task_update_01');
  assert.equal(update.response.status, 200);
  assert.deepEqual(taskCalls.find(call => call[0] === 'updateTask'), ['updateTask', taskId, updateChanges]);

  const deletion = await approve('delete_scheduled_task', { taskId }, 'delete', 'call_task_delete_01');
  assert.equal(deletion.response.status, 200);
  assert.deepEqual(taskCalls.at(-1), ['deleteTask', taskId]);
  assert.equal((await deletion.replay()).status, 409, 'delete approval is one-time');
}

console.log('agent task approval: account-bound, exact-args, one-use pause/update/delete adapters passed');
