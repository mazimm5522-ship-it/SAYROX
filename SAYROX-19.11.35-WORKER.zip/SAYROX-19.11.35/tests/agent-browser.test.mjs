import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

const source = await readFile(new URL('../site/_worker.js', import.meta.url), 'utf8');
const sandbox = vm.createContext({
  crypto: webcrypto, Request, Response, Headers, URL, URLSearchParams,
  AbortController, AbortSignal, ReadableStream, TextEncoder, TextDecoder,
  Uint8Array, ArrayBuffer, Blob, setTimeout, clearTimeout, console,
  atob, btoa, Date, Math, JSON, Number, String, Boolean, Object, Array,
  Map, Set, RegExp, Error, TypeError, Promise, Intl
});
vm.runInContext(source.replace('export default __worker;', 'globalThis.__sayrox = { __worker, __load };'), sandbox, { filename: 'site/_worker.js' });
const browser = sandbox.__sayrox.__load('worker/agent/browser-tools.js');
const registryModule = sandbox.__sayrox.__load('worker/agent/tool-registry.js');
const runtime = sandbox.__sayrox.__load('worker/agent/runtime.js');
const tickets = sandbox.__sayrox.__load('worker/agent/approval-tickets.js');
const approvalApi = sandbox.__sayrox.__load('worker/features/agent-approval.js');
const plain = value => JSON.parse(JSON.stringify(value));

class FakeSocket {
  constructor(targetId, state) { this.targetId = targetId; this.state = state; this.listeners = new Map(); this.closed = false; }
  addEventListener(type, fn) { const set = this.listeners.get(type) || new Set(); set.add(fn); this.listeners.set(type, set); }
  removeEventListener(type, fn) { this.listeners.get(type)?.delete(fn); }
  emit(type, value) { for (const fn of Array.from(this.listeners.get(type) || [])) fn(value); }
  accept() {}
  send(raw) {
    const request = JSON.parse(raw);
    const respond = result => setTimeout(() => this.emit('message', { data: JSON.stringify({ id: request.id, result }) }), 0);
    if (request.method === 'Page.navigate') {
      this.state.urls.set(this.targetId, request.params.url);
      respond({ frameId: 'frame-1' });
      setTimeout(() => this.emit('message', { data: JSON.stringify({ method: 'Page.loadEventFired', params: { timestamp: 1 } }) }), 1);
      return;
    }
    if (request.method === 'Runtime.evaluate') {
      if (this.state.failUnknownAction && request.params.expression.includes('document.querySelector(')) {
        this.state.failUnknownAction = false;
        this.close();
        return;
      }
      if (request.params.expression.includes('document.activeElement')) {
        respond({ result: { type: 'boolean', value: this.state.activeActionable } });
      } else if (request.params.expression.includes('document.querySelectorAll')) {
        respond({ result: { type: 'object', value: {
          title: 'Example Domain', url: this.state.redirectUrl || this.state.urls.get(this.targetId) || 'https://example.com/',
          text: 'Rendered page text', links: [{ text: 'More', url: 'https://example.com/more' }]
        } } });
      } else if (request.params.expression.includes('document.querySelector')) {
        respond({ result: { type: 'object', value: { ok: true } } });
      } else respond({ result: { type: 'undefined' } });
      return;
    }
    if (request.method === 'Input.dispatchKeyEvent') { this.state.keyEvents.push(request.params); respond({}); return; }
    if (request.method === 'Page.captureScreenshot') { respond({ data: 'aGVsbG8=' }); return; }
    respond({});
  }
  close() { this.closed = true; this.emit('close', {}); }
}
function makeEnv() {
  const state = { acquireOptions: null, closedSessions: 0, sessionsCreated: 0, activeSessions: new Set(), targetSessions: new Map(), browserRows: new Map(), reserved: 0, committed: 0, released: 0, urls: new Map(), targets: 0, sockets: [], keyEvents: [], activeActionable: false, failUnknownAction: false, consumedApprovals: new Set(), lastRun: null, redirectUrl: '' };
  const usage = {
    async reserveUsageBatch(id, items) { state.reserved++; assert.equal(items[0].feature, 'search'); return { ok: true }; },
    async commitUsage() { state.committed++; return { ok: true }; },
    async releaseUsage() { state.released++; return { ok: true }; },
    async claimAgentBrowserSession(conversationId, leaseToken, now = Date.now()) {
      const row = state.browserRows.get(conversationId);
      if (row && row.leaseUntil > now) return { ok: false, code: 'BROWSER_SESSION_BUSY' };
      if (!row) {
        state.browserRows.set(conversationId, { state: 'opening', payload: '', expiresAt: now + 900_000, leaseToken, leaseUntil: now + 55_000 });
        return { ok: true, found: false, payload: '', leaseToken };
      }
      row.leaseToken = leaseToken; row.leaseUntil = now + 55_000;
      return { ok: true, found: row.state === 'active' && Boolean(row.payload), payload: row.payload, leaseToken };
    },
    async saveAgentBrowserSession(conversationId, payload, leaseToken, expiresAt, now = Date.now()) {
      const row = state.browserRows.get(conversationId);
      if (!row || row.leaseToken !== leaseToken || row.leaseUntil <= now) return { ok: false, code: 'BROWSER_SESSION_LEASE_LOST' };
      Object.assign(row, { state: 'active', payload, expiresAt, leaseUntil: now + 55_000 });
      return { ok: true };
    },
    async releaseAgentBrowserSession(conversationId, leaseToken, keep = true) {
      const row = state.browserRows.get(conversationId);
      if (!row || row.leaseToken !== leaseToken) return { ok: false, code: 'BROWSER_SESSION_LEASE_LOST' };
      if (!keep || row.state !== 'active' || !row.payload) state.browserRows.delete(conversationId);
      else { row.leaseToken = null; row.leaseUntil = 0; }
      return { ok: true };
    },
    async deleteAgentBrowserSession(conversationId, leaseToken) {
      const row = state.browserRows.get(conversationId);
      if (!row || row.leaseToken !== leaseToken) return { ok: false, code: 'BROWSER_SESSION_LEASE_LOST' };
      state.browserRows.delete(conversationId); return { ok: true };
    },
    async consumeAgentApproval(id, account, expiresAt, decision) {
      if (account !== 'a'.repeat(43) || expiresAt <= Date.now() || state.consumedApprovals.has(id)) return { ok: false, code: 'AGENT_APPROVAL_REPLAYED' };
      state.consumedApprovals.add(id); return { ok: true, decision };
    },
    async recordAgentRun(record) { state.lastRun = record; return { ok: true }; }
  };
  const browserBinding = {
    async acquire(options) {
      state.acquireOptions = options;
      const sessionId = `browser-session-${++state.sessionsCreated}`;
      state.activeSessions.add(sessionId);
      return { sessionId };
    },
    async getSession(sessionId) { return state.activeSessions.has(sessionId) ? { sessionId } : null; },
    async connectSession(sessionId, { targetId }) {
      if (!state.activeSessions.has(sessionId)) throw new Error('session-not-found');
      const socket = new FakeSocket(targetId, state); state.sockets.push(socket);
      return { webSocket: { async fetch() { return { webSocket: socket }; } } };
    },
    async closeSession(sessionId) { state.closedSessions++; state.activeSessions.delete(sessionId); return { status: 'closed' }; },
    devtools: {
      async newTarget(sessionId, url = 'about:blank') { const id = `target-${++state.targets}`; state.urls.set(id, url); state.targetSessions.set(id, sessionId); return { id, type: 'page', url }; },
      async listTargets(sessionId) { return Array.from(state.targetSessions, ([id, owner]) => owner === sessionId ? ({ id, type: 'page', url: state.urls.get(id) || 'about:blank' }) : null).filter(Boolean); },
      async activateTarget() { return { ok: true }; },
      async closeTarget(_sessionId, targetId) { state.targetSessions.delete(targetId); return { ok: true }; }
    }
  };
  return {
    state,
    env: {
      AUTH_SESSION_SECRET: 'browser-approval-secret-long-enough-for-tests',
      BROWSER: browserBinding,
      BILLING_ACCOUNT: { idFromName: () => 'billing', get: () => ({ async getSubscriptionSnapshot() { return { current: null }; } }) },
      USAGE_ACCOUNT: { idFromName: () => 'usage', get: () => usage }
    }
  };
}

// URL boundary: only ordinary public HTTP(S) hostnames can enter Browser Run.
{
  for (const url of [
    'file:///etc/passwd', 'javascript:alert(1)', 'https://user:pass@example.com',
    'http://localhost', 'http://foo.local', 'http://127.0.0.1', 'http://10.0.0.1',
    'http://192.168.1.1', 'http://169.254.169.254', 'http://[::1]',
    'http://2130706433', 'https://example.com:8443', 'https://singlelabel'
  ]) assert.equal(browser.normalizeBrowserUrl(url), null, `${url} must be rejected`);
  assert.equal(browser.normalizeBrowserUrl('https://Example.com/path#section'), 'https://example.com/path#section');
}

// Contract separation: inspect cannot click or fill; interact can only request a fixed action vocabulary.
{
  assert.equal(browser.validateBrowserArgs({ url: 'https://example.com', actions: [{ type: 'extract' }] }, false), true);
  assert.equal(browser.validateBrowserArgs({ url: 'https://example.com', actions: [{ type: 'click', selector: '#ok' }] }, false), false);
  assert.equal(browser.validateBrowserArgs({ url: 'https://example.com', actions: [{ type: 'click', selector: '#ok' }] }, true), true);
  assert.equal(browser.validateBrowserArgs({ url: 'https://example.com', actions: [{ type: 'extract' }] }, true), false, 'interactive tool must contain a state-changing action');
  assert.equal(browser.validateBrowserArgs({ url: 'https://example.com' }, true), false, 'interactive tool cannot be used as an unapproved read-only alias');
  assert.equal(browser.validateBrowserArgs({ url: 'https://example.com', actions: [{ type: 'evaluate', expression: 'alert(1)' }] }, true), false);
  assert.equal(browser.validateBrowserArgs({ url: 'https://example.com', actions: [{ type: 'fill', selector: '#x', value: 'x', extra: true }] }, true), false);
  assert.equal(browser.validateBrowserArgs({ url: 'https://example.com', actions: [{ type: 'navigate', url: 'http://127.0.0.1' }] }, true), false);
  assert.equal(browser.validateBrowserArgs({ url: 'https://example.com', actions: [{ type: 'new_tab' }, { type: 'switch_tab', tab: 'tab-2' }, { type: 'click', selector: '#ok' }] }, true), true);
  assert.equal(browser.validateBrowserArgs({ url: 'https://example.com', actions: [{ type: 'new_tab' }, { type: 'close_tab', tab: 'tab-2' }, { type: 'new_tab' }, { type: 'switch_tab', tab: 'tab-2' }, { type: 'click', selector: '#ok' }] }, true), false, 'closed tab ids are not reused');
}

// Real tool flow is exercised through a fake Cloudflare Browser binding and a CDP-compatible socket.
{
  const { env, state } = makeEnv();
  const screenshots = [];
  const tool = browser.createBrowserInspectTool({ env, accountKey: 'a'.repeat(43), onScreenshot: value => screenshots.push(value) });
  assert.equal(tool.id, 'browser_inspect');
  assert.equal(tool.risk, 'read');
  assert.equal(tool.requiresApproval, false);
  const result = await tool.handler({ url: 'https://example.com', actions: [{ type: 'screenshot' }, { type: 'extract' }] });
  assert.equal(result.ok, true);
  assert.equal(result.pages.at(-1).title, 'Example Domain');
  assert.equal(result.pages.at(-1).text, 'Rendered page text');
  assert.equal(result.pages.at(-1).untrustedContent, true);
  assert.equal(result.screenshotCaptured, true);
  assert.equal(screenshots.length, 1);
  assert.match(screenshots[0].image.dataUrl, /^data:image\/jpeg;base64,/);
  assert.deepEqual(plain(state.acquireOptions.guardrails.allowedDomains), ['example.com']);
  assert.equal(state.acquireOptions.keepAlive, 20 * 60_000);
  assert.equal(state.reserved, 1);
  assert.equal(state.committed, 1);
  assert.equal(state.released, 0);
  assert.equal(state.closedSessions, 1, 'ephemeral Browser Run session is closed on success');
  assert.ok(state.sockets.every(socket => socket.closed), 'all CDP sockets are closed');
}

// Space cannot activate a focused action control (for example, a purchase or submit button).
{
  const { env, state } = makeEnv();
  state.activeActionable = true;
  const tool = browser.createBrowserInteractTool({ env, accountKey: 'a'.repeat(43) });
  const result = await tool.handler({ url: 'https://example.com', actions: [{ type: 'press', key: 'SPACE' }] });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'BROWSER_ACTION_BLOCKED');
  assert.equal(state.keyEvents.length, 0, 'the key event is not dispatched to an actionable control');
  assert.equal(state.closedSessions, 1, 'the browser session closes after blocked interaction');
}

// Navigation domains are constrained per session; cleanup and reservation rollback happen on pre-session failure.
{
  const { env, state } = makeEnv();
  const tool = browser.createBrowserInspectTool({ env, accountKey: 'a'.repeat(43) });
  const result = await tool.handler({ url: 'https://example.com', actions: [{ type: 'navigate', url: 'https://docs.example.org/page' }] });
  assert.equal(result.ok, true);
  assert.deepEqual(plain(state.acquireOptions.guardrails.allowedDomains), ['example.com', 'docs.example.org']);
  assert.equal(state.closedSessions, 1);
}

// A final navigation outside the exact per-session allowlist is rejected even if Browser Run returned a page.
{
  const { env, state } = makeEnv();
  state.redirectUrl = 'https://unlisted.example.net/private';
  const tool = browser.createBrowserInspectTool({ env, accountKey: 'a'.repeat(43) });
  const result = await tool.handler({ url: 'https://example.com' });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'BROWSER_REDIRECT_BLOCKED');
  assert.equal(state.closedSessions, 1, 'a redirected session is still cleaned up');
}

// Risk classification ensures the existing registry pauses before any interaction handler runs.
{
  const { env, state } = makeEnv();
  const tool = browser.createBrowserInteractTool({ env, accountKey: 'a'.repeat(43) });
  assert.equal(tool.id, 'browser_interact');
  assert.equal(tool.risk, 'modify');
  assert.equal(tool.requiresApproval, true);
  const registry = registryModule.createToolRegistry([tool]);
  const run = runtime.createAgentRun('browser-run-0001');
  runtime.transitionAgentRun(run, 'understanding');
  runtime.transitionAgentRun(run, 'planning');
  const result = await registryModule.executeAgentTool(registry, run, 'browser_interact', { url: 'https://example.com', actions: [{ type: 'click', selector: '#continue' }] }, { userInitiated: true });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'APPROVAL_REQUIRED');
  assert.equal(state.reserved, 0, 'no browser session or quota is used before approval');
  assert.equal(state.closedSessions, 0);
}

// The encrypted one-use approval card is the only route that can execute browser interaction.
{
  const { env, state } = makeEnv();
  const accountKey = 'a'.repeat(43);
  const args = { url: 'https://example.com', actions: [{ type: 'screenshot' }, { type: 'click', selector: '#continue' }] };
  const conversationId = webcrypto.randomUUID();
  const sealed = await tickets.sealAgentApprovalTicket(env, {
    accountKey, runId: webcrypto.randomUUID(), toolId: 'browser_interact', callId: 'browser_approve_01',
    args, risk: 'modify', description: 'Interact with the public page', specialist: 'main', conversationId
  });
  const openedTicket = await tickets.openAgentApprovalTicket(env, sealed.token);
  assert.equal(openedTicket.conversationId, conversationId, 'approval ticket retains the originating chat id under encryption');
  assert.equal(state.reserved, 0, 'issuing an approval ticket does not start a browser or charge usage');
  const makeRequest = () => new Request('https://sayrox.test/api/agent/approval', {
    method: 'POST',
    headers: { 'content-type': 'application/json', origin: 'https://sayrox.test', 'sec-fetch-site': 'same-origin' },
    body: JSON.stringify({ ticket: sealed.token, decision: 'approve' })
  });
  const approved = await approvalApi.agentApprovalApi(makeRequest(), env, { accountKey });
  const body = await approved.json();
  assert.equal(approved.status, 200);
  assert.equal(body.ok, true);
  assert.equal(body.toolId, 'browser_interact');
  assert.equal(body.result.ok, true);
  assert.equal(body.image.image.mimeType, 'image/jpeg');
  assert.equal(state.reserved, 1);
  assert.equal(state.committed, 1);
  assert.equal(state.closedSessions, 0, 'approved interaction continues the same conversation-bound persistent session');
  assert.ok(state.browserRows.has(conversationId));
  assert.equal(state.lastRun.state, 'completed');
  const replay = await approvalApi.agentApprovalApi(makeRequest(), env, { accountKey });
  assert.equal(replay.status, 409, 'approved interaction ticket cannot be replayed');
  assert.equal(state.reserved, 1, 'replay does not start another browser session');
  const closedSession = await browser.createBrowserCloseSessionTool({ env, accountKey, conversationId }).handler({});
  assert.equal(closedSession.ok, true);
  assert.equal(state.closedSessions, 1);
}

// Intent detection only exposes browsing tools for explicit requests tied to a supplied URL.
{
  assert.deepEqual(plain(browser.detectBrowserIntent([{ role: 'user', content: 'لطفاً این سایت را باز کن https://example.com' }])), { inspect: true, interact: false, close: false });
  assert.deepEqual(plain(browser.detectBrowserIntent([{ role: 'user', content: 'روی دکمه ادامه کلیک کن https://example.com' }])), { inspect: true, interact: true, close: false });
  assert.deepEqual(plain(browser.detectBrowserIntent([{ role: 'user', content: 'برو به این سایت https://example.com' }])), { inspect: true, interact: false, close: false });
  assert.match(source, /confirm order|cc-|one-time-code/);
  assert.match(source, /BROWSER_FORM_SUBMIT_BLOCKED/);
  assert.deepEqual(plain(browser.detectBrowserIntent([{ role: 'user', content: 'سلام، حالت چطوره؟' }])), { inspect: false, interact: false, close: false });
}

// A browser session is encrypted and scoped to one account+conversation; later turns reconnect without a new acquire.
{
  const { env, state } = makeEnv();
  const accountKey = 'a'.repeat(43), conversationId = webcrypto.randomUUID();
  const inspect = browser.createBrowserInspectTool({ env, accountKey, conversationId, defaultUrl: 'https://example.com/start' });
  assert.deepEqual(plain(inspect.providerSchema.function.parameters.required), [], 'the URL is optional when the same conversation already supplied one');
  const first = await inspect.handler({ actions: [{ type: 'extract' }] });
  assert.equal(first.ok, true);
  assert.equal(first.sessionMode, 'conversation-persistent');
  assert.equal(state.sessionsCreated, 1);
  assert.equal(state.closedSessions, 0, 'persistent sessions are not closed at end of a tool call');
  const row = state.browserRows.get(conversationId);
  assert.ok(row?.payload);
  assert.equal(row.payload.includes('browser-session-1'), false, 'the session identifier is encrypted at rest');
  assert.equal(row.leaseToken, null, 'the conversation lease is released after the operation');

  const second = await inspect.handler({ actions: [{ type: 'extract' }] });
  assert.equal(second.ok, true);
  assert.equal(second.sessionMode, 'conversation-persistent');
  assert.equal(state.sessionsCreated, 1, 'the second turn reuses the existing Browser Run session');
  assert.equal(state.closedSessions, 0);
  assert.equal(state.committed, 2, 'each invocation commits its reserved usage once');

  const close = browser.createBrowserCloseSessionTool({ env, accountKey, conversationId });
  assert.equal(close.id, 'browser_close_session');
  const closed = await close.handler({});
  assert.equal(closed.ok, true);
  assert.equal(closed.closed, true);
  assert.equal(state.closedSessions, 1);
  assert.equal(state.browserRows.has(conversationId), false, 'closing the session removes encrypted session state');
}

// A session cannot silently expand its hostname allowlist; an explicit fresh session is required.
{
  const { env, state } = makeEnv();
  const accountKey = 'a'.repeat(43), conversationId = webcrypto.randomUUID();
  const inspect = browser.createBrowserInspectTool({ env, accountKey, conversationId, defaultUrl: 'https://example.com' });
  assert.equal((await inspect.handler({ actions: [{ type: 'extract' }] })).ok, true);
  const blocked = await inspect.handler({ url: 'https://other.example.org', actions: [{ type: 'extract' }] });
  assert.equal(blocked.ok, false);
  assert.equal(blocked.code, 'BROWSER_SESSION_DOMAIN_BLOCKED');
  assert.equal(state.sessionsCreated, 1);
  const fresh = await inspect.handler({ url: 'https://other.example.org', sessionMode: 'new', actions: [{ type: 'extract' }] });
  assert.equal(fresh.ok, true);
  assert.equal(state.sessionsCreated, 2);
  assert.equal(state.closedSessions, 1, 'the previous session is closed before replacing it');
  assert.deepEqual(plain(state.acquireOptions.guardrails.allowedDomains), ['other.example.org']);
}

// Unknown outcomes of a state-changing CDP command are never replayed automatically.
{
  const { env, state } = makeEnv();
  const accountKey = 'a'.repeat(43), conversationId = webcrypto.randomUUID();
  const inspect = browser.createBrowserInspectTool({ env, accountKey, conversationId, defaultUrl: 'https://example.com' });
  assert.equal((await inspect.handler({ actions: [{ type: 'extract' }] })).ok, true);
  const interact = browser.createBrowserInteractTool({ env, accountKey, conversationId, defaultUrl: 'https://example.com' });
  assert.equal(interact.requiresApproval, true);
  state.failUnknownAction = true;
  const uncertain = await interact.handler({ actions: [{ type: 'click', selector: '#continue' }] });
  assert.equal(uncertain.ok, false);
  assert.equal(uncertain.code, 'BROWSER_CONNECTION_CLOSED');
  const savedPayload = state.browserRows.get(conversationId).payload;
  assert.ok(savedPayload, 'the session checkpoint remains available after an uncertain operation');
  const nextAttempt = await interact.handler({ actions: [{ type: 'click', selector: '#continue' }] });
  assert.equal(nextAttempt.ok, false);
  assert.equal(nextAttempt.code, 'BROWSER_ACTION_OUTCOME_UNKNOWN', 'a possibly dispatched action is never re-run');
  const safeInspect = await inspect.handler({ actions: [{ type: 'extract' }] });
  assert.equal(safeInspect.ok, true, 'read-only inspection remains available for recovery');
  assert.equal(safeInspect.previousActionOutcomeUnknown, true);
  assert.match(safeInspect.recoveryWarning, /تکرار/);
}

// Browser intent follows a URL already supplied earlier in the same conversation and supports explicit close.
{
  const conversation = [
    { role: 'user', content: 'این سایت را باز کن https://example.com' },
    { role: 'assistant', content: 'صفحه باز شد.' },
    { role: 'user', content: 'صفحه فعلی را فقط بررسی کن' }
  ];
  assert.deepEqual(plain(browser.detectBrowserIntent(conversation)), { inspect: true, interact: false, close: false });
  assert.equal(browser.extractLastUserUrl(conversation), 'https://example.com/');
  assert.deepEqual(plain(browser.detectBrowserIntent([{ role: 'user', content: 'نشست مرورگر را ببند' }])), { inspect: false, interact: false, close: true });
}

console.log('agent browser tests: URL policy, read-only/interactive approvals, Browser Run guardrails, encrypted conversation sessions, reconnect, host isolation, recovery locks, close and ephemeral cleanup passed');
