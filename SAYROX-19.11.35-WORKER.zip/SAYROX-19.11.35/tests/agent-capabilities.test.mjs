import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');
const accountKey = 'a'.repeat(43);
const plain = value => JSON.parse(JSON.stringify(value));

async function loadModule(path, imports = {}) {
  const exports = {};
  const source = await read(path);
  const context = vm.createContext({
    exports, __load: id => imports[id], crypto: webcrypto,
    TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, Blob, URL,
    Date, Math, JSON, Number, String, Boolean, Object, Array, Map, Set,
    RegExp, Error, TypeError, Promise, Intl, AbortController, AbortSignal,
    setTimeout, clearTimeout, console
  });
  vm.runInContext(source, context, { filename: path });
  return exports;
}

test('capability intent is explicit and avoids generic file discussion', async () => {
  const intent = await loadModule('worker/agent/capability-intent.js');
  const detect = text => plain(intent.detectCapabilityIntent([{ role: 'user', content: text }]));
  assert.equal(detect('برای من یک تصویر بساز').generateImage, true);
  assert.equal(detect('یک فایل Word بساز').createFile, true);
  assert.equal(detect('برای گزارش یک PDF تولید کن').createFile, true);
  assert.equal(detect('یک فایل Excel بساز').createFile, true);
  assert.equal(detect('یک فایل پاورپوینت بساز').createFile, true);
  assert.equal(detect('Create a PowerPoint presentation').createFile, true);
  assert.equal(detect('این فایل PPTX را تحلیل کن').createFile, false);
  assert.equal(detect('چی از من یادت مونده؟').searchMemory, true);
  assert.equal(detect('هر روز ساعت ۹ صبح یادآوری کن آب بخورم').scheduleTask, true);
  assert.equal(detect('لطفا درباره PDF توضیح بده').createFile, false);
  assert.equal(detect('چطور فایل PDF را بخوانم؟').createFile, false);
  assert.equal(detect('این فایل Excel را تحلیل کن').createFile, false);
  assert.equal(detect('این کد پایتون را اجرا کن').executeCode, true);
  assert.equal(detect('Run this Python code').executeCode, true);
  assert.equal(detect('برایم کد Python بنویس').executeCode, false);
  assert.equal(detect('این کد را توضیح بده').executeCode, false);
  assert.deepEqual(detect('سلام، خوبی؟'), { generateImage: false, createFile: false, scheduleTask: false, listScheduledTasks: false, manageScheduledTasks: false, deleteScheduledTask: false, searchMemory: false, executeCode: false });
});

test('attached-file tool lists, searches and reads only bounded untrusted document text', async () => {
  const fileTools = await loadModule('worker/agent/file-tools.js');
  const docs = fileTools.normalizeAgentDocuments([
    { name: 'old.pdf', text: 'old document' },
    { name: 'report.pdf', text: 'عنوان گزارش\nاین سند شامل اطلاعات مالی و گزارش فروش است.' },
    { name: 'data.xlsx', kind: 'spreadsheet', extension: 'xlsx', text: 'نام,مبلغ\nسارا,120' }
  ]);
  assert.deepEqual(plain(docs.map(doc => doc.name)), ['report.pdf', 'data.xlsx']);

  const tool = fileTools.createInspectFilesTool(docs);
  assert.equal(tool.id, 'inspect_attached_files');
  assert.equal(tool.risk, 'read');
  assert.equal(tool.validateArgs({ action: 'list' }), true);
  assert.equal(tool.validateArgs({ action: 'search', query: 'فروش' }), true);
  assert.equal(tool.validateArgs({ action: 'read', documentIndex: 0, offset: 0, limit: 300 }), true);
  assert.equal(tool.validateArgs({ action: 'read' }), false);
  assert.equal(tool.validateArgs({ action: 'list', extra: 'unexpected' }), false);

  const listed = plain(await tool.handler({ action: 'list' }));
  assert.deepEqual(listed.files.map(item => item.name), ['report.pdf', 'data.xlsx']);
  const searched = plain(await tool.handler({ action: 'search', query: 'فروش' }));
  assert.equal(searched.matchCount, 1);
  assert.match(searched.matches[0].snippet, /گزارش فروش/);
  assert.equal(searched.matches[0].offset, 0);
  const extracted = plain(await tool.handler({ action: 'read', documentIndex: 1, offset: 0, limit: 300 }));
  assert.equal(extracted.document, 'data.xlsx');
  assert.match(extracted.text, /سارا,120/);

  const bounded = fileTools.normalizeAgentDocuments([{ name: 'huge.txt', text: 'x'.repeat(120_000) }]);
  assert.equal(bounded[0].text.length, 100_000);
  assert.equal(bounded[0].truncated, true);
  assert.equal(fileTools.normalizeAgentDocuments([]).length, 0);
  assert.equal(fileTools.createInspectFilesTool([]), null);
});

test('file artifact tool validates Word/PDF/Excel/PowerPoint and keeps generated content bounded', async () => {
  const fileTools = await loadModule('worker/agent/file-tools.js');
  const delivered = [];
  const tool = fileTools.createFileArtifactTool({ onArtifact: artifact => delivered.push(artifact) });
  assert.equal(tool.id, 'create_file');
  assert.equal(tool.risk, 'create');
  const docx = { format: 'docx', filename: '../گزارش نهایی.docx', title: 'گزارش نهایی', content: '# نتیجه\n\nمتن فارسی قابل دانلود است.' };
  assert.equal(tool.validateArgs(docx), true);
  const result = plain(await tool.handler(docx));
  assert.equal(result.created, true);
  assert.equal(result.filename, '-گزارش نهایی.docx');
  assert.equal(delivered.length, 1);
  assert.equal(delivered[0].content, docx.content);
  assert.equal(delivered[0].filename.includes('/'), false);

  const xlsx = { format: 'xlsx', filename: 'sales.xlsx', title: 'فروش', rows: [['نام', 'مبلغ'], ['سارا', 120], ['علی', 95]] };
  assert.equal(tool.validateArgs(xlsx), true);
  const sheet = plain(await tool.handler(xlsx));
  assert.equal(sheet.format, 'xlsx');
  assert.equal(sheet.rowCount, 3);
  assert.equal(delivered.length, 2);

  const pptx = { format: 'pptx', filename: 'roadmap.pptx', title: 'نقشه راه', content: `# شروع\n\nهدف نسخه\n\n# برنامه\n\nمرحله اول` };
  assert.equal(tool.validateArgs(pptx), true);
  const presentation = plain(await tool.handler(pptx));
  assert.equal(presentation.created, true);
  assert.equal(presentation.format, 'pptx');
  assert.equal(presentation.filename, 'roadmap.pptx');
  assert.equal(delivered.length, 3);
  assert.equal(delivered[2].format, 'pptx');
  assert.equal(delivered[2].content, pptx.content);
  assert.equal(tool.validateArgs({ ...pptx, rows: [['unexpected']] }), false);

  assert.equal(tool.validateArgs({ ...xlsx, rows: [['=SUM(A1:A2)']] }), false, 'formula-like user strings must not be emitted as executable spreadsheet formulas');
  assert.equal(tool.validateArgs({ ...xlsx, rows: [['+cmd|/C calc']] }), false);
  assert.equal(tool.validateArgs({ ...xlsx, rows: Array.from({ length: 1201 }, () => ['x']) }), false);
  assert.equal(tool.validateArgs({ ...docx, format: 'pdf', rows: [] }), false);
  assert.equal(tool.validateArgs({ ...docx, format: 'exe' }), false);
  assert.equal(tool.validateArgs({ ...docx, unexpected: true }), false, 'runtime must enforce the no-extra-properties schema');

  const persianLong = { format: 'pdf', filename: 'بلند.pdf', title: 'متن فارسی', content: 'م'.repeat(80_000) };
  assert.equal(tool.validateArgs(persianLong), true);
  const longResult = plain(await tool.handler(persianLong));
  assert.equal(longResult.created, true, 'bounded UTF-8 Persian content should fit the artifact transport envelope');
  assert.equal(delivered.length, 4);
});

test('memory search is read-only, account-scoped, strict and reuses the existing memory service', async () => {
  const calls = [];
  const memory = { searchMemoryForAgent: async (key, env, query) => { calls.push({ key, env, query }); return { ok: true, count: 1, memories: [{ category: 'project', content: 'SAYROX' }] }; } };
  const toolModule = await loadModule('worker/agent/memory-tools.js', { 'worker/features/memory.js': memory });
  assert.equal(toolModule.createMemorySearchTool({ env: {}, accountKey: '' }), null);
  const env = { memoryStore: true };
  const tool = toolModule.createMemorySearchTool({ env, accountKey });
  assert.equal(tool.id, 'search_memory');
  assert.equal(tool.risk, 'read');
  assert.equal(tool.validateArgs({ query: 'SAYROX' }), true);
  assert.equal(tool.validateArgs({ query: 'x' }), false);
  assert.equal(tool.validateArgs({ query: 'SAYROX', scope: 'all' }), false);
  const result = plain(await tool.handler({ query: 'پروژهٔ SAYROX' }));
  assert.equal(result.ok, true);
  assert.equal(calls.length, 1);
  assert.equal(calls[0].key, accountKey);
  assert.equal(calls[0].env, env);
});

test('scheduled-task tool validates calendar dates and routes creation through the existing account Durable Object', async () => {
  const calls = [];
  const stub = {
    async createTask(input, limit, key) {
      calls.push({ input, limit, key });
      return { ok: true, task: { id: 'task-1', title: input.title, schedule: input.schedule, nextRun: 4070908800000, enabled: true } };
    }
  };
  const env = {
    TASKS_INTERNAL_SECRET: 's'.repeat(40),
    TASKS_ACCOUNT: { idFromName: name => name, get: name => { calls.push({ durableObjectName: name }); return stub; } }
  };
  const imports = {
    'worker/shared/constants.js': { TASK_LIMITS: { free: 1, start: 3, advanced: 10, pro: 30, ultra: 80 } },
    'worker/shared/http.js': { text: (value, max) => String(value ?? '').replace(/\u0000/g, '').slice(0, max) },
    'worker/features/quotas.js': { currentTier: async () => 'free' }
  };
  const tasks = await loadModule('worker/agent/scheduled-task-tools.js', imports);
  assert.equal(tasks.createScheduledTaskTool({ env: {}, accountKey }), null);
  const tool = tasks.createScheduledTaskTool({ env, accountKey, timezone: 'Europe/Berlin' });
  assert.equal(tool.id, 'create_scheduled_task');
  assert.equal(tool.risk, 'create');
  const once = { title: 'یادآوری جلسه', prompt: 'یادآوری جلسه را برای من اجرا کن.', schedule: { type: 'once', date: '2099-02-28', time: '09:30', timezone: 'Europe/Berlin' } };
  assert.equal(tool.validateArgs(once), true);
  assert.equal(tool.validateArgs({ ...once, schedule: { ...once.schedule, date: '2099-02-30' } }), false);
  assert.equal(tool.validateArgs({ ...once, schedule: { ...once.schedule, timezone: 'Mars/Base' } }), false);
  assert.equal(tool.validateArgs({ ...once, schedule: { ...once.schedule, extra: 'nope' } }), false);
  assert.equal(tool.validateArgs({ ...once, extra: 'nope' }), false);
  assert.equal(tool.validateArgs({ ...once, schedule: { type: 'weekly', weekday: 1, time: '09:30', timezone: 'Europe/Berlin' } }), true);
  assert.equal(tool.validateArgs({ ...once, schedule: { type: 'daily', weekday: 1, time: '09:30', timezone: 'Europe/Berlin' } }), false);
  const result = plain(await tool.handler(once));
  assert.equal(result.ok, true);
  assert.equal(result.task.id, 'task-1');
  assert.equal(calls.find(call => call.durableObjectName)?.durableObjectName, `xynora-account:${accountKey}`);
  assert.equal(calls.find(call => call.input)?.limit, 1);
  assert.equal(calls.find(call => call.input)?.key, accountKey);
});

test('image generation tool is explicit, quota-backed by existing image service and fails closed when unavailable', async () => {
  const calls = [];
  const images = {
    imageConfig: env => ({ ready: env.imageReady === true }),
    generateImageData: async (...args) => { calls.push(args); return { ok: true, prompt: args[2], ratio: args[3] || '1:1', model: 'configured-image-model', image: { mimeType: 'image/png', dataUrl: 'data:image/png;base64,AQID', bytes: 3 } }; }
  };
  const imageModule = await loadModule('worker/agent/image-tools.js', { 'worker/features/images.js': images });
  assert.equal(imageModule.createImageGenerationTool({ env: {}, accountKey }), null);
  const env = { imageReady: true };
  const generated = [];
  const tool = imageModule.createImageGenerationTool({ env, accountKey, origin: 'https://sayrox.example', onGenerated: value => generated.push(value) });
  assert.equal(tool.id, 'generate_image');
  assert.equal(tool.risk, 'create');
  assert.equal(tool.validateArgs({ prompt: 'A clean blue abstract logo', ratio: '1:1' }), true);
  assert.equal(tool.validateArgs({ prompt: 'x', ratio: 'unknown' }), false);
  assert.equal(tool.validateArgs({ prompt: 'A good image', extra: true }), false);
  const result = plain(await tool.handler({ prompt: 'A clean blue abstract logo', ratio: '4:3' }, { signal: null }));
  assert.equal(result.generated, true);
  assert.equal(generated.length, 1);
  assert.equal(calls[0][0], env);
  assert.equal(calls[0][1], accountKey);
  assert.equal(calls[0][3], '4:3');
  assert.equal(calls[0][4].origin, 'https://sayrox.example');
});

test('custom Agent SSE events deliver images/files before final text and browser uses existing local file engines', async () => {
  const streamSource = await read('site/src/core/stream.js');
  const context = vm.createContext({ TextDecoder, Response, ReadableStream, Uint8Array, JSON, Error, String, Promise });
  vm.runInContext(streamSource, context);
  const encoder = new TextEncoder();
  const body = new ReadableStream({ start(controller) {
    controller.enqueue(encoder.encode('event: sayrox_agent\ndata: {"runId":"agent-1","sequence":1,"type":"tool_started","tool":"web_research"}\n\n'));
    controller.enqueue(encoder.encode('event: sayrox_image\ndata: {"image":{"dataUrl":"data:image/png;base64,AQID"}}\n\n'));
    controller.enqueue(encoder.encode('event: sayrox_file\ndata: {"artifact":{"format":"pdf"}}\n\n'));
    controller.enqueue(encoder.encode('event: sayrox_agent\ndata: {"runId":"agent-1","sequence":2,"type":"summary","research":{"status":"completed"},"sources":[]}\n\n'));
    controller.enqueue(encoder.encode('data: {"choices":[{"delta":{"content":"تمام شد"}}]}\n\n'));
    controller.enqueue(encoder.encode('data: [DONE]\n\n'));
    controller.close();
  } });
  const events = [];
  const updates = [];
  const answer = await context.SayroxStream.readEventStream(new Response(body), (delta, full) => updates.push({ delta, full }), async (name, payload) => events.push({ name, payload }));
  assert.equal(answer, 'تمام شد');
  assert.deepEqual(events.map(item => item.name), ['sayrox_agent', 'sayrox_image', 'sayrox_file', 'sayrox_agent']);
  assert.equal(events[0].payload.type, 'tool_started');
  assert.equal(events[3].payload.type, 'summary');
  assert.equal(updates[0].delta, 'تمام شد');

  const [worker, app, renderer, studio, stream, index, sw] = await Promise.all([
    read('worker/providers/chat.js'), read('app/05-send-message.js'), read('app/04-message-rendering.js'),
    read('site/src/features/files/studio.js'), read('site/src/core/stream.js'), read('site/index.html'), read('site/sw.js')
  ]);
  assert.match(worker, /event: sayrox_image/);
  assert.match(worker, /event: sayrox_file/);
  assert.match(worker, /createAgentProgressResponse/);
  assert.match(worker, /event: sayrox_agent/);
  assert.match(app, /applyAgentProgress/);
  assert.match(app, /tool_started/);
  assert.match(app, /handleAgentOutputEvent/);
  assert.match(app, /deliverAgentFileArtifact/);
  assert.match(app, /tools\.createDocx/);
  assert.match(app, /tools\.createTextPdf/);
  assert.match(app, /tools\.createXlsx/);
  assert.match(app, /tools\.createPptx/);
  assert.match(renderer, /message\.attachments/);
  assert.match(studio, /createDocx/);
  assert.match(studio, /createTextPdf/);
  assert.match(studio, /createXlsx/);
  assert.match(studio, /createPptx/);
  assert.match(index, /src="src\/core\/stream\.js"/);
  assert.match(sw, /\/src\/core\/stream\.js/);
  assert.match(stream, /onEvent\(eventName, payload\)/);
});

test('new capabilities are registered only for explicit intent and never introduce D1', async () => {
  const [chat, workerConfig, tasksConfig, agentCore] = await Promise.all([
    read('worker/providers/chat.js'), read('site/_worker.js'), read('tasks-worker/wrangler.jsonc'), read('docs/AGENT-CORE.md')
  ]);
  assert.match(chat, /if \(capabilityIntent\.createFile\).*createFileArtifactTool/);
  assert.match(chat, /if \(capabilityIntent\.searchMemory && trustedOptions\.accountKey && data\.temporary !== true\)/);
  assert.match(chat, /if \(capabilityIntent\.generateImage\)/);
  assert.match(chat, /if \(capabilityIntent\.scheduleTask && trustedOptions\.accountKey && data\.temporary !== true\)/);
  assert.match(chat, /createListScheduledTasksTool/);
  assert.match(chat, /createManageScheduledTaskTool/);
  assert.match(chat, /createDeleteScheduledTaskTool/);
  assert.match(chat, /if \(capabilityIntent\.executeCode && trustedOptions\.accountKey && data\.temporary !== true\)/);
  assert.match(chat, /createPythonExecutionTool/);
  assert.match(chat, /if \(agentDocuments\.length\).*createInspectFilesTool/);
  assert.doesNotMatch(workerConfig, /d1_databases|D1Database|env\.DB\b/i);
  assert.doesNotMatch(tasksConfig, /d1_databases/i);
  assert.match(agentCore, /بدون ساخت ذخیره‌ساز دوم/);
});
