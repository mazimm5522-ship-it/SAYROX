import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

const source = await readFile(new URL('../site/_worker.js', import.meta.url), 'utf8');
const bundled = source.replace('export default __worker;', 'globalThis.__sayrox = { __worker, __load };');
const sandbox = vm.createContext({
  crypto: webcrypto, Request, Response, Headers, URL, URLSearchParams,
  AbortController, AbortSignal, ReadableStream, TextEncoder, TextDecoder,
  Uint8Array, ArrayBuffer, Blob, setTimeout, clearTimeout, console,
  atob, btoa, Date, Math, JSON, Number, String, Boolean, Object, Array,
  Map, Set, RegExp, Error, TypeError, Promise, Intl
});
vm.runInContext(bundled, sandbox, { filename: 'site/_worker.js' });
const load = sandbox.__sayrox.__load;
const sessions = load('worker/security/sessions.js');
const history = load('worker/features/agent-history.js');
const chat = load('worker/providers/chat.js');
const api = load('worker/routes/api.js').api;
const runId = '123e4567-e89b-42d3-a456-426614174000';
const accountKey = 'a'.repeat(43);

function makeRequest(body = { runId }, origin = 'https://sayrox.test') {
  return new Request('https://sayrox.test/api/agent/resume', {
    method: 'POST', headers: { origin, 'content-type': 'application/json' }, body: JSON.stringify(body)
  });
}

function setup({ claim = { ok: true, snapshot: { runId, input: { messages: [{ role: 'user', content: 'resume me' }] }, provider: 'gapgpt', model: 'test' }, leaseToken: '123e4567-e89b-42d3-a456-426614174001' }, responseStatus = 200 } = {}) {
  const calls = [];
  sessions.enforceApiRateLimit = async () => null;
  sessions.sameOriginRequest = request => request.headers.get('origin') === 'https://sayrox.test';
  sessions.authReady = () => true;
  sessions.authenticatedSession = async () => ({ accountKey });
  history.claimAgentCheckpoint = async (env, key, id) => { calls.push(['claim', key, id]); return claim; };
  history.releaseAgentCheckpoint = async (env, key, id, token) => { calls.push(['release', key, id, token]); return { ok: true }; };
  chat.chat = async (request, env, options) => {
    calls.push(['chat', request.url, options.accountKey, options.agentResumeCheckpoint.snapshot.runId, options.agentResumeCheckpoint.leaseToken]);
    return Response.json({ ok: responseStatus < 400, message: 'result' }, { status: responseStatus });
  };
  return calls;
}

test('resume endpoint requires a same-origin authenticated POST before claiming', async () => {
  const calls = setup();
  const cross = await api(makeRequest({ runId }, 'https://evil.test'), {});
  assert.equal(cross.status, 403);
  assert.equal(calls.length, 0);
  const method = await api(new Request('https://sayrox.test/api/agent/resume', { method: 'GET', headers: { origin: 'https://sayrox.test' } }), {});
  assert.equal(method.status, 405);
});

test('resume endpoint claims an account-scoped checkpoint and passes only trusted state to chat', async () => {
  const calls = setup();
  const response = await api(makeRequest(), {});
  assert.equal(response.status, 200);
  assert.deepEqual(calls, [
    ['claim', accountKey, runId],
    ['chat', 'https://sayrox.test/api/chat', accountKey, runId, '123e4567-e89b-42d3-a456-426614174001']
  ]);
});

test('resume endpoint refuses unsafe in-flight checkpoints and releases a failed pre-loop attempt', async () => {
  const unsafeCalls = setup({ claim: { ok: false, code: 'CHECKPOINT_UNSAFE' } });
  const unsafe = await api(makeRequest(), {});
  assert.equal(unsafe.status, 409);
  assert.equal(unsafeCalls.some(call => call[0] === 'chat'), false);

  const failedCalls = setup({ responseStatus: 503 });
  const failed = await api(makeRequest(), {});
  assert.equal(failed.status, 503);
  assert.deepEqual(failedCalls.at(-1), ['release', accountKey, runId, '123e4567-e89b-42d3-a456-426614174001']);
});
