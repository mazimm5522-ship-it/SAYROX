import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

let source = await readFile(new URL('../site/_worker.js', import.meta.url), 'utf8');
source = source.replace('export default __worker;', 'globalThis.__sayrox = { __worker, __load };');
const sandbox = vm.createContext({
  crypto: webcrypto, Request, Response, Headers, URL, URLSearchParams,
  AbortController, AbortSignal, ReadableStream, TextEncoder, TextDecoder,
  Uint8Array, ArrayBuffer, Blob, setTimeout, clearTimeout, console,
  atob, btoa, Date, Math, JSON, Number, String, Boolean, Object, Array,
  Map, Set, RegExp, Error, TypeError, Promise, Intl
});
vm.runInContext(source, sandbox, { filename: 'site/_worker.js' });
const load = sandbox.__sayrox.__load;
const runtime = load('worker/agent/runtime.js');
const registryModule = load('worker/agent/tool-registry.js');
const loopModule = load('worker/agent/tool-loop.js');

function makeRun(id) {
  const run = runtime.createAgentRun(id);
  runtime.transitionAgentRun(run, 'understanding');
  runtime.transitionAgentRun(run, 'planning');
  runtime.transitionAgentRun(run, 'responding');
  return run;
}
function schema(name = 'safe_lookup') {
  return {
    type: 'function',
    function: {
      name,
      description: 'A bounded read-only test tool.',
      parameters: { type: 'object', additionalProperties: false, properties: { query: { type: 'string', maxLength: 40 } }, required: ['query'] }
    }
  };
}
function definition(overrides = {}) {
  return {
    id: 'safe_lookup', risk: 'read', timeoutMs: 1000,
    providerSchema: schema(),
    validateArgs: args => Object.keys(args).length === 1 && typeof args.query === 'string',
    handler: async args => ({ answer: args.query }),
    ...overrides
  };
}

test('registry rejects mismatched or permissive provider schemas before exposing tools to the model', () => {
  assert.throws(() => registryModule.createToolRegistry([definition({ providerSchema: schema('different_tool') })]), /invalid_tool_provider_schema/);
  const permissive = schema();
  permissive.function.parameters.additionalProperties = true;
  assert.throws(() => registryModule.createToolRegistry([definition({ providerSchema: permissive })]), /invalid_tool_provider_schema/);
  const missingRequiredProperty = schema();
  missingRequiredProperty.function.parameters.required = ['not_declared'];
  assert.throws(() => registryModule.createToolRegistry([definition({ providerSchema: missingRequiredProperty })]), /invalid_tool_provider_schema/);
});

test('registry snapshots and deeply freezes provider schemas so callers cannot mutate the model contract', () => {
  const original = schema();
  const registry = registryModule.createToolRegistry([definition({ providerSchema: original })]);
  original.function.name = 'attacker_replacement';
  original.function.parameters.properties.query.maxLength = 99999;
  const exposed = registry.get('safe_lookup').providerSchema;
  assert.equal(exposed.function.name, 'safe_lookup');
  assert.equal(exposed.function.parameters.properties.query.maxLength, 40);
  assert.equal(Object.isFrozen(exposed), true);
  assert.equal(Object.isFrozen(exposed.function), true);
  assert.equal(Object.isFrozen(exposed.function.parameters.properties.query), true);
});

test('handler-level failures become real tool failures instead of false successes', async () => {
  const registry = registryModule.createToolRegistry([definition({
    handler: async () => ({ ok: false, code: 'lookup_offline', message: '  Service unavailable  ' })
  })]);
  const run = makeRun('agent-hardening-001');
  const result = await registryModule.executeAgentTool(registry, run, 'safe_lookup', { query: 'x' }, { userInitiated: true });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'LOOKUP_OFFLINE');
  assert.equal(result.message, 'Service unavailable');
  assert.equal(run.stepCount, 1, 'an attempted but failed tool still consumes one bounded step');
});

test('tool loop reports handler failures to the model and event observers as failures', async () => {
  const registry = registryModule.createToolRegistry([definition({
    handler: async () => ({ ok: false, code: 'REMOTE_UNAVAILABLE', message: 'Lookup service is unavailable.' })
  })]);
  const run = makeRun('agent-hardening-002');
  const results = [];
  const events = [];
  let modelCalls = 0;
  const result = await loopModule.runAgentToolLoop({
    registry,
    run,
    messages: [{ role: 'user', content: 'Look this up.' }],
    async callModel(messages) {
      modelCalls++;
      if (modelCalls === 1) return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
        { id: 'call_failed_lookup_01', type: 'function', function: { name: 'safe_lookup', arguments: JSON.stringify({ query: 'test' }) } }
      ] } }] } };
      const toolMessage = messages.find(message => message.role === 'tool');
      assert.match(toolMessage.content, /REMOTE_UNAVAILABLE/);
      return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'The lookup could not be completed.' } }] } };
    },
    onToolResult: entry => results.push(entry),
    onEvent: event => events.push(event)
  });
  assert.equal(result.ok, true);
  assert.equal(results.length, 1);
  assert.equal(results[0].outcome.ok, false);
  assert.equal(results[0].outcome.code, 'REMOTE_UNAVAILABLE');
  assert.ok(events.some(event => event.type === 'tool_failed'));
  assert.equal(events.some(event => event.type === 'tool_completed'), false);
});
