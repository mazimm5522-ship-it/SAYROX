import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

let source = await readFile(new URL('../site/_worker.js', import.meta.url), 'utf8');
source = source.replace('export default __worker;', 'globalThis.__sayrox = { __worker, __load };');
const context = vm.createContext({ crypto: webcrypto, Request, Response, Headers, URL, URLSearchParams, AbortController, AbortSignal, ReadableStream, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, Blob, setTimeout, clearTimeout, console, atob, btoa, Date, Math, JSON, Number, String, Boolean, Object, Array, Map, Set, RegExp, Error, TypeError, Promise, Intl });
vm.runInContext(source, context, { filename: 'site/_worker.js' });
const history = context.__sayrox.__load('worker/features/agent-history.js');
const runId = '123e4567-e89b-42d3-a456-426614174000';

{
  let saved;
  const env = { USAGE_ACCOUNT: { idFromName: name => name, get: () => ({ recordAgentRun: async record => { saved = record; return { ok: true }; } }) } };
  const result = await history.persistAgentRun(env, 'account-key', {
    runId, specialist: 'research', state: 'completed', createdAt: 100, updatedAt: 200,
    toolEvents: [{ tool: 'web_research', status: 'success' }, { tool: 'unexpected tool', status: 'failed', code: 'tool_error' }],
    durationMs: 150, stepCount: 2, researchMode: 'deep', researchStatus: 'completed', sourceCount: 4,
    prompt: 'MUST NOT BE PERSISTED', answer: 'MUST NOT BE PERSISTED', toolArguments: { secret: 'MUST NOT BE PERSISTED' }
  });
  assert.equal(result.ok, true);
  assert.equal(saved.runId, runId);
  assert.equal(saved.toolEvents.length, 2);
  assert.equal(saved.toolEvents[0].tool, 'web_research');
  assert.equal(saved.toolEvents[1].tool, 'unexpected tool');
  assert.equal('prompt' in saved, false);
  assert.equal('answer' in saved, false);
  assert.equal('toolArguments' in saved, false);
}

{
  const calls = [];
  const stub = {
    listAgentRuns: async (limit, offset) => { calls.push(['list', limit, offset]); return { ok: true, hasMore: offset < 100, runs: [{ runId, state: 'completed' }] }; },
    getAgentRun: async id => ({ ok: true, run: { runId: id, state: 'completed' } }),
    deleteAgentRun: async id => { calls.push(['delete', id]); return { ok: true }; },
    clearAgentRuns: async () => { calls.push(['clear']); return { ok: true }; }
  };
  const env = { USAGE_ACCOUNT: { idFromName: name => name, get: () => stub } };
  const session = { accountKey: 'account-key' };
  let response = await history.agentHistoryApi(new Request('https://sayrox.test/api/agent/runs?limit=20&offset=40', { headers: { origin: 'https://sayrox.test' } }), env, session, '/api/agent/runs');
  let body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.runs.length, 1);
  assert.deepEqual(calls[0], ['list', 20, 40]);
  assert.equal(body.hasMore, true);
  assert.equal(body.nextOffset, 41);

  response = await history.agentHistoryApi(new Request('https://sayrox.test/api/agent/runs', { method: 'POST', headers: { origin: 'https://sayrox.test', 'content-type': 'application/json' }, body: JSON.stringify({ action: 'delete', runId }) }), env, session, '/api/agent/runs');
  assert.equal(response.status, 200);
  assert.deepEqual(calls[1], ['delete', runId]);

  response = await history.agentHistoryApi(new Request('https://sayrox.test/api/agent/runs', { method: 'POST', headers: { origin: 'https://sayrox.test', 'content-type': 'application/json' }, body: JSON.stringify({ action: 'clear' }) }), env, session, '/api/agent/runs');
  assert.equal(response.status, 200);
  assert.deepEqual(calls[2], ['clear']);

  response = await history.agentHistoryApi(new Request('https://sayrox.test/api/agent/runs?limit=999&offset=9999', { headers: { origin: 'https://sayrox.test' } }), env, session, '/api/agent/runs');
  assert.equal(response.status, 200);
  assert.deepEqual(calls[3], ['list', 50, 100]);
}

{
  const env = { USAGE_ACCOUNT: { idFromName: name => name, get: () => ({}) } };
  const cross = await history.agentHistoryApi(new Request('https://sayrox.test/api/agent/runs', { headers: { origin: 'https://evil.test' } }), env, { accountKey: 'account-key' }, '/api/agent/runs');
  assert.equal(cross.status, 403);
  const missing = await history.agentHistoryApi(new Request('https://sayrox.test/api/agent/runs'), env, null, '/api/agent/runs');
  assert.equal(missing.status, 401);
}

console.log('agent history API tests: privacy-minimal records, authenticated access, same-origin guard and deletion passed');

// Agent checkpoints are encrypted at rest and bound cryptographically to the account and run.
{
  const accountKey = 'a'.repeat(43);
  let storedPayload = '';
  let deleteCalls = 0;
  const stub = {
    async saveAgentCheckpoint(id, payload, expiresAt, leaseToken, state) { storedPayload = payload; return { ok: true, state, expiresAt }; },
    async claimAgentCheckpoint() { return { ok: true, payload: storedPayload, leaseToken: '123e4567-e89b-42d3-a456-426614174001' }; },
    async releaseAgentCheckpoint() { return { ok: true }; },
    async deleteAgentCheckpoint() { deleteCalls++; return { ok: true }; }
  };
  const env = { AUTH_SESSION_SECRET: 'checkpoint-test-secret-value-that-is-long-enough-123', USAGE_ACCOUNT: { idFromName: value => value, get: () => stub } };
  const now = Date.now();
  const snapshot = {
    v: 1, runId, createdAt: now, expiresAt: now + 60_000,
    input: { messages: [{ role: 'user', content: 'private prompt text' }], stream: false },
    provider: 'gapgpt', model: 'safe-test-model',
    loop: { conversation: [{ role: 'user', content: 'private prompt text' }], results: [], pendingCalls: [], pendingIndex: 0, rounds: 0, calls: 0, choice: 'auto', stepCount: 0 },
    toolEvents: [], researchSummary: null, researchEvidence: null
  };
  const saved = await history.saveAgentCheckpoint(env, accountKey, runId, snapshot, '123e4567-e89b-42d3-a456-426614174002', 'leased');
  assert.equal(saved.ok, true);
  assert.ok(storedPayload);
  assert.equal(storedPayload.includes('private prompt text'), false, 'checkpoint plaintext must not be stored in the DO row');
  const claimed = await history.claimAgentCheckpoint(env, accountKey, runId);
  assert.equal(claimed.ok, true);
  assert.equal(claimed.snapshot.input.messages[0].content, 'private prompt text');
  assert.equal(claimed.snapshot.accountKey, accountKey);
  const wrongAccount = await history.claimAgentCheckpoint(env, 'b'.repeat(43), runId);
  assert.equal(wrongAccount.ok, false, 'AES-GCM additional data binds ciphertext to the account');
  assert.equal(wrongAccount.code, 'CHECKPOINT_INVALID');
  assert.equal(deleteCalls, 1, 'invalid ciphertext is removed instead of retried');
}

{
  const chatSource = await readFile(new URL('../worker/providers/chat.js', import.meta.url), 'utf8');
  assert.match(chatSource, /if \(resumeCheckpoint\?\.model\) providerPayload\.model = resumeCheckpoint\.model/, 'resume pins the provider model saved in the checkpoint');
  assert.match(chatSource, /onCheckpoint: \(checkpointStorageReady && !payload\.stream && !requiresVision\)/, 'vision/image payloads are not copied into Agent checkpoints');
  assert.match(chatSource, /results: loopState\.results\.slice\(-20\)\.map/, 'checkpoint stores only minimal tool outcomes, not full raw tool results');
}
