import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');
const accountKey = 'a'.repeat(43);
const plain = value => JSON.parse(JSON.stringify(value));
async function loadModule(path, imports = {}) {
  const exports = {};
  const source = await read(path);
  const context = vm.createContext({
    exports, __load: id => imports[id], crypto: webcrypto,
    TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, Blob, URL,
    Date, Math, JSON, Number, String, Boolean, Object, Array, Map, Set,
    RegExp, Error, TypeError, Promise, Intl, AbortController, AbortSignal,
    setTimeout, clearTimeout, console
  });
  vm.runInContext(source, context, { filename: path });
  return exports;
}

test('scheduled task intent separates listing, reversible management and deletion', async () => {
  const intent = await loadModule('worker/agent/capability-intent.js');
  const detect = text => plain(intent.detectCapabilityIntent([{ role: 'user', content: text }]));
  assert.equal(detect('فهرست یادآورهای من را نشان بده').listScheduledTasks, true);
  assert.equal(detect('یادآوری‌های ثبت‌شده‌ام را نمایش بده').listScheduledTasks, true);
  assert.equal(detect('یادآور جلسه را متوقف کن').manageScheduledTasks, true);
  assert.equal(detect('زمان یادآور روزانه را تغییر بده').manageScheduledTasks, true);
  assert.equal(detect('این یادآور را همین الان اجرا کن').manageScheduledTasks, true);
  assert.equal(detect('یادآور قدیمی را حذف کن').deleteScheduledTask, true);
  assert.equal(detect('pause my daily reminder').manageScheduledTasks, true);
  assert.equal(detect('pause my daily reminder').scheduleTask, false, 'managing a daily reminder must not expose the create-task tool');
  assert.equal(detect('دربارهٔ یادآوری‌ها توضیح بده').listScheduledTasks, false);
});

test('Agent task management tools reuse the account-scoped existing Tasks Durable Object', async () => {
  const calls = [];
  const existingTask = { id: '1d0a80b4-6b27-4bc5-bc83-3e8b13a908e1', title: 'جلسه', prompt: 'prompt-private', schedule: { type: 'daily', time: '09:00', timezone: 'Europe/Berlin' }, enabled: true, nextRun: 1234, createdAt: 100, lastRunAt: 110, lastStatus: 'ok' };
  const stub = {
    async listTasks() { calls.push(['list']); return { ok: true, tasks: [existingTask], runs: [{ runId: 'run-1', taskId: existingTask.id, title: 'جلسه', status: 'ok', output: 'private output', error: 'private error', searchUsed: true }], unseen: 1 }; },
    async setEnabled(id, enabled) { calls.push(['enabled', id, enabled]); return { ok: true, enabled }; },
    async runNow(id) { calls.push(['runNow', id]); return { ok: true, queued: true }; },
    async updateTask(id, changes) { calls.push(['update', id, changes]); return { ok: true, task: { ...existingTask, ...changes, id } }; },
    async deleteTask(id) { calls.push(['delete', id]); return { ok: true, deleted: true }; }
  };
  const env = {
    TASKS_INTERNAL_SECRET: 's'.repeat(40),
    TASKS_ACCOUNT: { idFromName: name => name, get: name => { calls.push(['namespace', name]); return stub; } }
  };
  const module = await loadModule('worker/agent/scheduled-task-tools.js', {
    'worker/shared/constants.js': { TASK_LIMITS: { free: 1 } },
    'worker/shared/http.js': { text: (value, max) => String(value ?? '').replace(/\u0000/g, '').slice(0, max) },
    'worker/features/quotas.js': { currentTier: async () => 'free' }
  });
  assert.equal(module.createListScheduledTasksTool({ env: {}, accountKey }), null);
  const list = module.createListScheduledTasksTool({ env, accountKey });
  const manage = module.createManageScheduledTaskTool({ env, accountKey });
  const remove = module.createDeleteScheduledTaskTool({ env, accountKey });
  assert.equal(list.risk, 'read');
  assert.equal(list.requiresApproval, false);
  assert.equal(manage.risk, 'modify');
  assert.equal(manage.requiresApproval, true);
  assert.equal(remove.risk, 'delete');
  assert.equal(remove.requiresApproval, true);
  assert.equal(list.validateArgs({}), true);
  assert.equal(list.validateArgs({ extra: true }), false);
  const listed = plain(await list.handler({}));
  assert.equal(listed.tasks[0].id, existingTask.id);
  assert.equal('prompt' in listed.tasks[0], false, 'private task prompts are not exposed during ordinary listing');
  assert.equal('output' in listed.recentRuns[0], false, 'private task result bodies are omitted from status summaries');
  assert.equal('error' in listed.recentRuns[0], false);
  assert.equal(calls[0][1], `xynora-account:${accountKey}`);

  for (const action of ['pause', 'resume', 'run_now']) assert.equal(manage.validateArgs({ taskId: existingTask.id, action }), true);
  assert.equal(manage.validateArgs({ taskId: existingTask.id, action: 'update', changes: { schedule: { type: 'daily', time: '10:00', timezone: 'Europe/Berlin' } } }), true);
  assert.equal(manage.validateArgs({ taskId: existingTask.id, action: 'update', changes: {} }), false);
  assert.equal(manage.validateArgs({ taskId: existingTask.id, action: 'pause', changes: { title: 'x' } }), false);
  assert.equal(manage.validateArgs({ taskId: 'not-a-uuid', action: 'pause' }), false);
  assert.equal(manage.validateArgs({ taskId: existingTask.id, action: 'update', changes: { unknown: true } }), false);
  assert.equal(manage.validateArgs({ taskId: existingTask.id, action: 'update', changes: { schedule: { type: 'once', date: '2099-02-30', time: '09:00', timezone: 'Europe/Berlin' } } }), false);

  assert.equal((await manage.handler({ taskId: existingTask.id, action: 'pause' })).ok, true);
  assert.equal((await manage.handler({ taskId: existingTask.id, action: 'resume' })).ok, true);
  assert.equal((await manage.handler({ taskId: existingTask.id, action: 'run_now' })).queued, true);
  const update = await manage.handler({ taskId: existingTask.id, action: 'update', changes: { title: 'جلسه جدید', schedule: { type: 'daily', time: '10:00', timezone: 'Europe/Berlin' } } });
  assert.equal(update.ok, true);
  assert.deepEqual(calls.filter(call => ['enabled', 'runNow', 'update'].includes(call[0])).map(call => call[0]), ['enabled', 'enabled', 'runNow', 'update']);
  assert.equal(calls.find(call => call[0] === 'update')[1], existingTask.id);
  assert.equal(calls.find(call => call[0] === 'update')[2].title, 'جلسه جدید');
  assert.equal(remove.validateArgs({ taskId: existingTask.id }), true);
  assert.equal(remove.validateArgs({ taskId: existingTask.id, extra: true }), false);
  assert.equal((await remove.handler({ taskId: existingTask.id })).deleted, true);
  assert.equal(calls.at(-1)[0], 'delete');
});

test('task API exposes authenticated schedule update via the existing account Durable Object', async () => {
  const { readFile } = await import('node:fs/promises');
  const source = await read('worker/features/tasks.js');
  assert.match(source, /pathname === '\/api\/tasks\/update'/);
  assert.match(source, /stub\.updateTask\(id, data\.changes\)/);
  const wrangler = await read('tasks-worker/wrangler.jsonc');
  assert.match(wrangler, /TaskAccountObject/);
  assert.doesNotMatch(wrangler, /d1_databases/i);
});
