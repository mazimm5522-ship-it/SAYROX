import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { webcrypto } from 'node:crypto';

let source = await readFile(new URL('../site/_worker.js', import.meta.url), 'utf8');
source = source.replace('export default __worker;', 'globalThis.__sayrox = { __worker, __load };');
const sandbox = vm.createContext({
  crypto: webcrypto, Request, Response, Headers, URL, URLSearchParams,
  AbortController, AbortSignal, ReadableStream, TextEncoder, TextDecoder,
  Uint8Array, ArrayBuffer, Blob, setTimeout, clearTimeout, console,
  atob, btoa, Date, Math, JSON, Number, String, Boolean, Object, Array,
  Map, Set, RegExp, Error, TypeError, Promise, Intl
});
vm.runInContext(source, sandbox, { filename: 'site/_worker.js' });
const load = sandbox.__sayrox.__load;
const runtime = load('worker/agent/runtime.js');
const registryModule = load('worker/agent/tool-registry.js');
const loopModule = load('worker/agent/tool-loop.js');
const plain = value => JSON.parse(JSON.stringify(value));

function makeRun(id = 'agent-loop-test-001') {
  const run = runtime.createAgentRun(id);
  runtime.transitionAgentRun(run, 'understanding');
  runtime.transitionAgentRun(run, 'planning');
  runtime.transitionAgentRun(run, 'responding');
  return run;
}

function toolDefinition(overrides = {}) {
  return {
    id: 'lookup_info',
    specialist: 'research',
    description: 'Read-only test lookup',
    risk: 'read',
    timeoutMs: 1000,
    providerSchema: {
      type: 'function',
      function: {
        name: 'lookup_info',
        description: 'Lookup trusted test data',
        parameters: {
          type: 'object', additionalProperties: false,
          properties: { query: { type: 'string', minLength: 1, maxLength: 80 } },
          required: ['query']
        }
      }
    },
    validateArgs: args => Object.keys(args).length === 1 && typeof args.query === 'string' && args.query.length > 0,
    handler: async args => ({ found: true, query: args.query }),
    ...overrides
  };
}

// The model may perform a true multi-round tool loop: request a function, receive the result, then request another.
{
  const run = makeRun();
  const registry = registryModule.createToolRegistry([toolDefinition()]);
  const modelCalls = [];
  const toolResults = [];
  const agentEvents = [];
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Compare two independent facts.' }],
    async callModel(messages, toolChoice, tools) {
      modelCalls.push({ messages, toolChoice, tools });
      const count = messages.filter(message => message.role === 'tool').length;
      if (count === 0) return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
        { id: 'call_lookup_0001', type: 'function', function: { name: 'lookup_info', arguments: JSON.stringify({ query: 'first' }) } }
      ] } }] } };
      if (count === 1) return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
        { id: 'call_lookup_0002', type: 'function', function: { name: 'lookup_info', arguments: JSON.stringify({ query: 'second' }) } }
      ] } }] } };
      return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'Both checks completed.' } }] } };
    },
    onToolResult: value => toolResults.push(value),
    onEvent: value => agentEvents.push(value)
  });
  assert.equal(result.ok, true);
  assert.equal(result.rounds, 2);
  assert.equal(result.calls, 2);
  assert.equal(run.stepCount, 2);
  assert.equal(run.state, 'responding');
  assert.equal(modelCalls.length, 3);
  assert.equal(modelCalls[0].tools[0].function.name, 'lookup_info');
  assert.equal(modelCalls[0].toolChoice, 'auto');
  assert.deepEqual(toolResults.map(item => item.outcome.result.query), ['first', 'second']);
  assert.equal(result.providerResult.data.choices[0].message.content, 'Both checks completed.');
  assert.deepEqual(agentEvents.map(item => item.type), [
    'thinking', 'tool_requested', 'tool_started', 'tool_completed', 'verifying',
    'thinking', 'tool_requested', 'tool_started', 'tool_completed', 'verifying',
    'thinking', 'responding'
  ], 'lifecycle notifications must reflect actual model/tool execution order');
  assert.equal(agentEvents.filter(item => item.type === 'tool_started').length, 2);
  assert.ok(agentEvents.filter(item => item.type === 'tool_started').every(item => item.tool === 'lookup_info'));
}

// Invalid function arguments are returned to the model as a tool error and never reach the handler.
{
  let handlerCalls = 0;
  const run = makeRun('agent-loop-test-002');
  const registry = registryModule.createToolRegistry([toolDefinition({ handler: async () => { handlerCalls++; return { ok: true }; } })]);
  let secondMessage;
  let modelCallCount = 0;
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Use a lookup tool.' }],
    async callModel(messages) {
      modelCallCount++;
      if (modelCallCount === 1) return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
        { id: 'call_bad_args_0001', type: 'function', function: { name: 'lookup_info', arguments: '{invalid-json' } }
      ] } }] } };
      secondMessage = messages.at(-1);
      return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'The tool arguments were invalid.' } }] } };
    }
  });
  assert.equal(result.ok, true);
  assert.equal(handlerCalls, 0);
  assert.match(secondMessage.content, /INVALID_TOOL_ARGUMENTS/);
  assert.equal(run.stepCount, 0);
}

// Required search fails closed when the model does not return a function call.
{
  const run = makeRun('agent-loop-test-003');
  const registry = registryModule.createToolRegistry([toolDefinition()]);
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Search this.' }], toolChoice: 'required',
    async callModel() { return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'Here is an unsupported answer.' } }] } }; }
  });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'REQUIRED_TOOL_NOT_CALLED');
}

// A required tool that was actually invoked may fail; the model receives that failure and can give an honest degraded answer.
{
  const run = makeRun('agent-loop-test-required-failure');
  const registry = registryModule.createToolRegistry([toolDefinition({
    handler: async () => ({ ok: false, code: 'LOOKUP_UNAVAILABLE', message: 'Lookup service unavailable.' })
  })]);
  const choices = [];
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Always look this up.' }], toolChoice: 'required', requiredToolId: 'lookup_info',
    async callModel(messages, toolChoice) {
      choices.push(toolChoice);
      if (!messages.some(message => message.role === 'tool')) {
        return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
          { id: 'call_required_failure_0001', type: 'function', function: { name: 'lookup_info', arguments: JSON.stringify({ query: 'required' }) } }
        ] } }] } };
      }
      assert.match(messages.at(-1).content, /LOOKUP_UNAVAILABLE/);
      return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'The required lookup was attempted but unavailable; I cannot verify the result.' } }] } };
    }
  });
  assert.equal(result.ok, true, 'attempting the required tool satisfies invocation enforcement even when the handler fails');
  assert.deepEqual(choices, ['required', 'auto']);
  assert.equal(result.results[0].outcome.ok, false, 'the actual tool failure remains visible to the model and history');
}

// Provider tool schemas are exposed only for enabled tools with a declared schema.
{
  const disabled = toolDefinition({ id: 'disabled_tool', enabled: false, providerSchema: undefined });
  const plain = toolDefinition({ id: 'plain_tool', providerSchema: undefined });
  const registry = registryModule.createToolRegistry([toolDefinition(), disabled, plain]);
  const schemas = loopModule.providerTools(registry);
  assert.equal(schemas.length, 1);
  assert.equal(schemas[0].function.name, 'lookup_info');
  assert.equal(registry.list().length, 3);
}

// Specialist filtering exposes only the coordinated team tools plus shared Main Agent tools.
{
  const namedTool = (id, specialist) => toolDefinition({
    id, specialist,
    providerSchema: { ...toolDefinition().providerSchema, function: { ...toolDefinition().providerSchema.function, name: id } }
  });
  const registry = registryModule.createToolRegistry([
    namedTool('research_lookup', 'research'),
    namedTool('coding_lookup', 'coding'),
    namedTool('main_lookup', 'main')
  ]);
  assert.deepEqual(loopModule.providerTools(registry, ['coding']).map(item => item.function.name), ['coding_lookup', 'main_lookup']);
  assert.deepEqual(loopModule.providerTools(registry, ['coding'], 'research_lookup').map(item => item.function.name), ['research_lookup', 'coding_lookup', 'main_lookup'], 'required tools are retained even when they belong to a collaborating role');
  assert.deepEqual(loopModule.providerTools(registry, ['main'], '', ['research']).map(item => item.function.name), ['research_lookup', 'main_lookup'], 'explicitly registered tool roles are available without misreporting them as active collaborators');
}

// A model cannot call a registered tool outside the planned team or request-scoped tool-role allowlist.
{
  let hiddenHandlerCalls = 0;
  const hidden = toolDefinition({
    id: 'coding_only_tool', specialist: 'coding',
    providerSchema: { ...toolDefinition().providerSchema, function: { ...toolDefinition().providerSchema.function, name: 'coding_only_tool' } },
    handler: async () => { hiddenHandlerCalls++; return { secret: 'not exposed' }; }
  });
  const allowed = toolDefinition({ id: 'research_only_tool', specialist: 'research', providerSchema: { ...toolDefinition().providerSchema, function: { ...toolDefinition().providerSchema.function, name: 'research_only_tool' } } });
  const registry = registryModule.createToolRegistry([hidden, allowed]);
  const run = makeRun('agent-loop-team-guard-001');
  let toolList = [];
  const result = await loopModule.runAgentToolLoop({
    registry, run, specialists: ['main'], toolSpecialists: ['research'], messages: [{ role: 'user', content: 'Research only.' }],
    async callModel(_messages, _choice, tools) {
      toolList = tools;
      if (!toolList.some(item => item.function.name === 'coding_only_tool')) {
        return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
          { id: 'call_hidden_tool_0001', type: 'function', function: { name: 'coding_only_tool', arguments: JSON.stringify({ query: 'not allowed' }) } }
        ] } }] } };
      }
      return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'Tool exposed.' } }] } };
    }
  });
  assert.equal(result.ok, true);
  assert.equal(hiddenHandlerCalls, 0, 'registry presence alone must not bypass per-run team membership');
  assert.equal(result.results[0].outcome.code, 'TOOL_SPECIALIST_NOT_IN_TEAM');
  assert.equal(toolList.some(item => item.function.name === 'coding_only_tool'), false);
}

// The same side-effecting tool+arguments cannot execute twice in a single coordinated run.
{
  let sideEffects = 0;
  let modelCalls = 0;
  const sideEffectTool = toolDefinition({
    id: 'create_record', specialist: 'data', risk: 'create',
    providerSchema: { type: 'function', function: { name: 'create_record', description: 'Create one test record', parameters: { type: 'object', additionalProperties: false, properties: { query: { type: 'string' } }, required: ['query'] } } },
    handler: async args => { sideEffects++; return { created: true, query: args.query }; }
  });
  const registry = registryModule.createToolRegistry([sideEffectTool]);
  const run = makeRun('agent-loop-dedupe-001');
  let duplicateResult;
  const result = await loopModule.runAgentToolLoop({
    registry, run, specialists: ['data'], messages: [{ role: 'user', content: 'Create one record once.' }],
    async callModel(messages) {
      modelCalls++;
      const tools = messages.filter(item => item.role === 'tool').length;
      if (tools < 2) return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
        { id: `call_create_record_${tools + 1}`, type: 'function', function: { name: 'create_record', arguments: JSON.stringify({ query: 'same payload' }) } }
      ] } }] } };
      duplicateResult = JSON.parse(messages.at(-1).content);
      return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'The repeated action was blocked.' } }] } };
    }
  });
  assert.equal(result.ok, true);
  assert.equal(sideEffects, 1);
  assert.equal(result.calls, 2);
  assert.equal(result.results[1].outcome.code, 'DUPLICATE_SIDE_EFFECT_BLOCKED');
  assert.equal(result.results[1].specialist, 'data');
  assert.equal(result.results[1].risk, 'create');
  assert.match(duplicateResult.message, /اثر تکراری/);
  assert.equal(modelCalls, 3);
}

// An unrelated tool can never satisfy a required tool: the choice stays "required" until the named tool really ran.
{
  const other = toolDefinition({ id: 'other_tool', providerSchema: { type: 'function', function: { name: 'other_tool', description: 'Other', parameters: { type: 'object', additionalProperties: false, properties: {} } } }, validateArgs: args => Object.keys(args).length === 0, handler: async () => ({ ok: true }) });
  const registry = registryModule.createToolRegistry([toolDefinition(), other]);
  const choices = [];
  const run = makeRun('agent-loop-test-004');
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Always look it up.' }], toolChoice: 'required', requiredToolId: 'lookup_info',
    async callModel(messages, toolChoice) {
      choices.push(toolChoice);
      const count = messages.filter(message => message.role === 'tool').length;
      if (count === 0) return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [{ id: 'call_other_0001', type: 'function', function: { name: 'other_tool', arguments: '{}' } }] } }] } };
      if (count === 1) return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [{ id: 'call_lookup_0003', type: 'function', function: { name: 'lookup_info', arguments: JSON.stringify({ query: 'required' }) } }] } }] } };
      return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'Done.' } }] } };
    }
  });
  assert.equal(result.ok, true);
  assert.deepEqual(choices, ['required', 'required', 'auto']);
  assert.equal(result.calls, 2);
}
{
  const other = toolDefinition({ id: 'other_tool', providerSchema: { type: 'function', function: { name: 'other_tool', description: 'Other', parameters: { type: 'object', additionalProperties: false, properties: {} } } }, validateArgs: args => Object.keys(args).length === 0, handler: async () => ({ ok: true }) });
  const registry = registryModule.createToolRegistry([toolDefinition(), other]);
  const run = makeRun('agent-loop-test-005');
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Always look it up.' }], toolChoice: 'required', requiredToolId: 'lookup_info',
    async callModel(messages) {
      const count = messages.filter(message => message.role === 'tool').length;
      if (count === 0) return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [{ id: 'call_other_0002', type: 'function', function: { name: 'other_tool', arguments: '{}' } }] } }] } };
      return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'Skipped the required tool.' } }] } };
    }
  });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'REQUIRED_TOOL_NOT_CALLED', 'fail closed instead of reporting an unrelated tool as the required one');
}
// An unknown requiredToolId is ignored (it cannot make a healthy loop fail).
{
  const registry = registryModule.createToolRegistry([toolDefinition()]);
  const run = makeRun('agent-loop-test-006');
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Hi' }], requiredToolId: 'not_registered',
    async callModel() { return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'Hello.' } }] } }; }
  });
  assert.equal(result.ok, true);
}

console.log('Agent tool-loop tests passed: true multi-round function calling, strict argument validation, required-tool enforcement (including unrelated-tool rejection) and allowlisted schemas');

// Sensitive tool calls stop the model loop and return a confirmation payload; handlers remain untouched.
{
  const run = makeRun('agent-loop-approval-001');
  let handlerCalls = 0;
  let modelCalls = 0;
  const registry = registryModule.createToolRegistry([toolDefinition({
    id: 'sensitive_action', providerSchema: { ...toolDefinition().providerSchema, function: { ...toolDefinition().providerSchema.function, name: 'sensitive_action' } }, risk: 'create', requiresApproval: true,
    description: 'Perform a sensitive user-visible action',
    handler: async () => { handlerCalls++; return { changed: true }; }
  })]);
  const events = [];
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Do the action.' }],
    async callModel() {
      modelCalls++;
      return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
        { id: 'call_sensitive_0001', type: 'function', function: { name: 'sensitive_action', arguments: JSON.stringify({ query: 'exact operation' }) } }
      ] } }] } };
    },
    onEvent: event => events.push(event)
  });
  assert.equal(result.ok, true);
  assert.equal(result.pendingApproval.toolId, 'sensitive_action');
  assert.equal(result.pendingApproval.args.query, 'exact operation');
  assert.equal(handlerCalls, 0, 'sensitive handler is never called before user approval');
  assert.equal(modelCalls, 1, 'model loop pauses rather than pretending the tool executed');
  assert.equal(run.state, 'awaiting_approval');
  assert.ok(events.some(event => event.type === 'approval_required'));
  assert.equal(events.some(event => event.type === 'tool_started'), false);
}

// A failed provider turn can resume from the safe boundary after a completed tool without replaying it.
{
  const run = makeRun('agent-loop-resume-001');
  const registry = registryModule.createToolRegistry([toolDefinition({ handler: async args => { handlerCalls++; return { found: true, query: args.query }; } })]);
  const checkpoints = [];
  let handlerCalls = 0;
  let providerCalls = 0;
  const first = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Look up this fact and summarize it.' }],
    async callModel() {
      providerCalls++;
      if (providerCalls === 1) return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
        { id: 'call_resume_0001', type: 'function', function: { name: 'lookup_info', arguments: JSON.stringify({ query: 'once-only' }) } }
      ] } }] } };
      return { ok: false, status: 503, code: 'PROVIDER_FAILED', message: 'temporary provider failure' };
    },
    onCheckpoint: async (snapshot, state) => { checkpoints.push({ snapshot: plain(snapshot), state }); return { ok: true }; }
  });
  assert.equal(first.ok, false);
  assert.equal(first.resumeAvailable, true);
  assert.equal(checkpoints.at(-1).state, 'ready');
  assert.equal(handlerCalls, 1);
  const resumeState = checkpoints.at(-1).snapshot;
  assert.equal(resumeState.pendingCalls.length, 0);
  assert.equal(resumeState.conversation.at(-1).role, 'tool');

  const resumed = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'this must not replace checkpoint conversation' }],
    resumeState,
    async callModel(messages) {
      assert.equal(messages[0].content, 'Look up this fact and summarize it.');
      assert.equal(messages.at(-1).role, 'tool');
      return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'The fact was checked once.' } }] } };
    }
  });
  assert.equal(resumed.ok, true);
  assert.equal(resumed.providerResult.data.choices[0].message.content, 'The fact was checked once.');
  assert.equal(handlerCalls, 1, 'resume must never replay an already completed tool');
  assert.equal(run.stepCount, 1);
}

// Side-effect fingerprints survive a safe checkpoint and block a repeated action after resume.
{
  let effects = 0;
  const definition = toolDefinition({
    id: 'create_record', specialist: 'data', risk: 'create',
    providerSchema: { type: 'function', function: { name: 'create_record', description: 'Create record', parameters: { type: 'object', additionalProperties: false, properties: { query: { type: 'string' } }, required: ['query'] } } },
    handler: async args => { effects++; return { created: args.query }; }
  });
  const registry = registryModule.createToolRegistry([definition]);
  const run = makeRun('agent-loop-dedupe-resume-001');
  const checkpoints = [];
  let modelCalls = 0;
  const first = await loopModule.runAgentToolLoop({
    registry, run, specialists: ['data'], messages: [{ role: 'user', content: 'Create record.' }],
    async callModel() {
      modelCalls++;
      if (modelCalls === 1) return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
        { id: 'call_create_before_resume_1', type: 'function', function: { name: 'create_record', arguments: JSON.stringify({ query: 'only-once' }) } }
      ] } }] } };
      return { ok: false, status: 503, code: 'PROVIDER_FAILED' };
    },
    onCheckpoint: async (snapshot, state) => { checkpoints.push({ snapshot: plain(snapshot), state }); return { ok: true }; }
  });
  assert.equal(first.ok, false);
  assert.equal(effects, 1);
  const safe = checkpoints.at(-1).snapshot;
  assert.equal(safe.results[0].risk, 'create');
  assert.match(safe.results[0].argsHash, /^[a-f0-9]{64}$/);
  const resumed = await loopModule.runAgentToolLoop({
    registry, run, specialists: ['data'], messages: [], resumeState: safe,
    async callModel(messages) {
      if (!messages.some(item => item.role === 'tool' && /DUPLICATE_SIDE_EFFECT_BLOCKED/.test(item.content))) {
        return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
          { id: 'call_create_after_resume_2', type: 'function', function: { name: 'create_record', arguments: JSON.stringify({ query: 'only-once' }) } }
        ] } }] } };
      }
      return { ok: true, data: { choices: [{ message: { role: 'assistant', content: 'The repeated action stayed blocked.' } }] } };
    }
  });
  assert.equal(resumed.ok, true);
  assert.equal(effects, 1, 'safe Resume must retain the side-effect dedupe ledger');
  assert.equal(resumed.results.at(-1).outcome.code, 'DUPLICATE_SIDE_EFFECT_BLOCKED');
}

// A checkpoint captured after entering a tool handler is explicitly unsafe to resume.
{
  const run = makeRun('agent-loop-resume-unsafe-001');
  const registry = registryModule.createToolRegistry([toolDefinition({ handler: async () => ({ ok: true }) })]);
  let inFlightSnapshot;
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Use a tool.' }],
    async callModel() { return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
      { id: 'call_unsafe_0001', type: 'function', function: { name: 'lookup_info', arguments: JSON.stringify({ query: 'test' }) } }
    ] } }] } }; },
    onCheckpoint: async (snapshot, state) => { if (state === 'in_flight') inFlightSnapshot = plain(snapshot); return { ok: true }; }
  });
  assert.equal(result.ok, true);
  assert.ok(inFlightSnapshot, 'the unsafe boundary is persisted before invoking the handler');
  assert.equal(inFlightSnapshot.pendingIndex, 0);
  assert.equal(inFlightSnapshot.pendingCalls.length, 1);
}

// Tool handlers fail closed when the in-flight checkpoint cannot be persisted.
{
  const run = makeRun('agent-loop-checkpoint-write-failed-001');
  let handlerCalls = 0;
  const registry = registryModule.createToolRegistry([toolDefinition({ handler: async () => { handlerCalls++; return { ok: true }; } })]);
  const states = [];
  const result = await loopModule.runAgentToolLoop({
    registry, run, messages: [{ role: 'user', content: 'Use a side-effecting tool.' }],
    async callModel() { return { ok: true, data: { choices: [{ message: { role: 'assistant', content: null, tool_calls: [
      { id: 'call_checkpoint_error_01', type: 'function', function: { name: 'lookup_info', arguments: JSON.stringify({ query: 'safe' }) } }
    ] } }] } }; },
    onCheckpoint: async (_snapshot, state) => { states.push(state); return { ok: state !== 'in_flight' }; }
  });
  assert.equal(result.ok, false);
  assert.equal(result.code, 'CHECKPOINT_WRITE_FAILED');
  assert.equal(handlerCalls, 0, 'a handler must not start if its in-flight guard cannot be made durable');
  assert.equal(states.at(-1), 'ready');
  assert.equal(result.resumeAvailable, true);
}
