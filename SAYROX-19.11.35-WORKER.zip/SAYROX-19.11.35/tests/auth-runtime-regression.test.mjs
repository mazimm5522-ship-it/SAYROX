import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { webcrypto, pbkdf2 as nodePbkdf2 } from 'node:crypto';

const bundle = await readFile(new URL('../site/_worker.js', import.meta.url), 'utf8');
const executable = bundle.replace('export default __worker;', 'globalThis.__sayroxBundle = { __worker, __load };');
const context = vm.createContext({
  crypto: webcrypto, Request, Response, Headers, URL, URLSearchParams,
  AbortController, AbortSignal, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, Blob,
  setTimeout, clearTimeout, console, atob, btoa, Date, Math, JSON, Number, String,
  Boolean, Object, Array, Map, Set, RegExp, Error, TypeError, Promise, Intl,
  ReadableStream, TransformStream, queueMicrotask
});
vm.runInContext(executable, context, {
  filename: 'site/_worker.js',
  importModuleDynamically: vm.constants.USE_MAIN_CONTEXT_DEFAULT_LOADER
});
const { __worker, __load } = context.__sayroxBundle;
const passwords = __load('worker/security/passwords.js');
const constants = __load('worker/shared/constants.js');

function jsonResponse(value, status = 200) {
  return new Response(JSON.stringify(value), {
    status,
    headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' }
  });
}

function makeNamespaces() {
  const accounts = new Map();
  const sessions = new Map();
  const attempts = new Map();
  const accountNamespace = {
    idFromName: name => name,
    get: accountKey => ({
      fetch: async request => {
        const path = new URL(request.url).pathname;
        const body = await request.json();
        const account = accounts.get(accountKey);
        if (path === '/internal/signup') {
          if (account) return jsonResponse({ ok: false, error: 'ACCOUNT_EXISTS' }, 409);
          const row = {
            id: body.userId,
            email: body.email,
            password_hash: body.passwordHash,
            display_name: body.displayName,
            created_at: body.createdAt
          };
          accounts.set(accountKey, row);
          return jsonResponse({ ok: true, user: row }, 201);
        }
        if (path === '/internal/get-user') return account ? jsonResponse({ ok: true, user: account }) : jsonResponse({ ok: false }, 404);
        if (path === '/internal/update-password-hash') {
          if (!account) return jsonResponse({ ok: false }, 404);
          account.password_hash = body.passwordHash;
          return jsonResponse({ ok: true, changes: 1 });
        }
        if (path === '/internal/create-session') {
          if (!account) return jsonResponse({ ok: false }, 404);
          sessions.set(body.tokenHash, body.expiresAt);
          return jsonResponse({ ok: true });
        }
        if (path === '/internal/validate-session') {
          const expiry = sessions.get(body.tokenHash);
          return account && Number(expiry) > Number(body.now)
            ? jsonResponse({ ok: true, user: account })
            : jsonResponse({ ok: false }, 404);
        }
        if (path === '/internal/delete-session') {
          sessions.delete(body.tokenHash);
          return jsonResponse({ ok: true });
        }
        return jsonResponse({ ok: false, error: 'NOT_FOUND' }, 404);
      }
    })
  };
  const rateLimitNamespace = {
    idFromName: name => name,
    get: shard => ({
      fetch: async request => {
        const body = await request.json();
        const bucket = `${shard}:${body.bucketKey}`;
        const count = (attempts.get(bucket) || 0) + 1;
        attempts.set(bucket, count);
        return jsonResponse({ ok: true, allowed: true, attempts: count, retryAfterSeconds: 1 });
      }
    })
  };
  return { accountNamespace, rateLimitNamespace, accounts };
}

test('PBKDF2 password hashes use native node:crypto at 600,000 rounds and remain verifiable', async () => {
  assert.equal(constants.PASSWORD_ITERATIONS, 600_000);
  const password = 'SAYROX-Strong-Test-Password-2026';
  const encoded = await passwords.createPasswordHash(password);
  const [algorithm, rounds, saltText, expected] = encoded.split('$');
  assert.equal(algorithm, 'pbkdf2');
  assert.equal(Number(rounds), 600_000);
  assert.match(saltText, /^[A-Za-z0-9_-]{22}$/);
  assert.match(expected, /^[A-Za-z0-9_-]{43}$/);
  const actual = await passwords.derivePassword(password, passwords.fromBase64url(saltText), Number(rounds));
  assert.equal(actual, expected);
  assert.notEqual(await passwords.derivePassword(`${password}!`, passwords.fromBase64url(saltText), Number(rounds)), expected);
  await assert.rejects(() => passwords.derivePassword(password, new Uint8Array(8), 600_000), /معتبر نیست/);
});

test('signup issues a session, /api/auth/me restores it, and /api/chat passes the authentication gate', async () => {
  const { accountNamespace, rateLimitNamespace } = makeNamespaces();
  const env = {
    AUTH_ACCOUNTS: accountNamespace,
    AUTH_RATE_LIMITER: rateLimitNamespace,
    AUTH_SESSION_SECRET: 'sayrox-unit-test-session-secret-keep-private-and-long',
    AI_PROVIDER: 'gapgpt',
    GAPGPT_BASE_URL: 'https://api.gapgpt.app/v1'
  };
  const signup = await __worker.fetch(new Request('https://sayrox.test/api/auth/signup', {
    method: 'POST',
    headers: { origin: 'https://sayrox.test', 'content-type': 'application/json' },
    body: JSON.stringify({ email: 'test@example.com', password: 'SAYROX-Strong-Test-Password-2026', displayName: 'SAYROX Test' })
  }), env);
  assert.equal(signup.status, 200);
  const signupBody = await signup.json();
  assert.equal(signupBody.ok, true);
  assert.equal(signupBody.user.email, 'test@example.com');
  const setCookie = signup.headers.get('set-cookie') || '';
  assert.match(setCookie, /xynora_session=/);
  assert.match(setCookie, /HttpOnly/);
  assert.match(setCookie, /Secure/);
  const cookie = setCookie.split(';', 1)[0];
  assert.ok(cookie.includes('='));

  const me = await __worker.fetch(new Request('https://sayrox.test/api/auth/me', {
    headers: { cookie, accept: 'application/json' }
  }), env);
  assert.equal(me.status, 200);
  const meBody = await me.json();
  assert.equal(meBody.authenticated, true);
  assert.equal(meBody.user.email, 'test@example.com');

  const login = await __worker.fetch(new Request('https://sayrox.test/api/auth/login', {
    method: 'POST',
    headers: { origin: 'https://sayrox.test', 'content-type': 'application/json' },
    body: JSON.stringify({ email: 'test@example.com', password: 'SAYROX-Strong-Test-Password-2026' })
  }), env);
  assert.equal(login.status, 200, 'login must verify the 600,000-round password hash');
  const loginCookie = (login.headers.get('set-cookie') || '').split(';', 1)[0];
  assert.match(loginCookie, /^xynora_session=/);

  const chat = await __worker.fetch(new Request('https://sayrox.test/api/chat', {
    method: 'POST',
    headers: { origin: 'https://sayrox.test', cookie: loginCookie, 'content-type': 'application/json' },
    body: JSON.stringify({ messages: [{ role: 'user', content: 'سلام' }], context: {}, model: 'auto', stream: false })
  }), env);
  const chatBody = await chat.json();
  assert.notEqual(chat.status, 401, 'a valid session must not be redirected to sign-in');
  assert.notEqual(chatBody.code, 'AUTH_REQUIRED');
  assert.notEqual(chatBody.code, 'AUTH_UNAVAILABLE');
  // With provider credentials intentionally omitted, a provider-readiness error is expected.
  assert.ok(chat.status === 503 || chat.status === 502 || chat.status === 429 || chat.status === 403);
});

test('a legacy 120,000-round password can be checked and upgraded without WebCrypto PBKDF2', async () => {
  const password = 'Legacy-SAYROX-Password-2026';
  const salt = new Uint8Array(16).fill(7);
  const expected = await new Promise((resolve, reject) => nodePbkdf2(password, salt, 120_000, 32, 'sha256', (error, key) => error ? reject(error) : resolve(key)));
  const expectedText = passwords.base64url(new Uint8Array(expected));
  assert.equal(constants.LEGACY_PASSWORD_ITERATIONS.has(120_000), true);
  assert.equal(await passwords.derivePassword(password, salt, 120_000), expectedText);
});

test('successful login upgrades a legacy password hash to the current 600,000-round policy', async () => {
  const { accountNamespace, rateLimitNamespace, accounts } = makeNamespaces();
  const env = {
    AUTH_ACCOUNTS: accountNamespace,
    AUTH_RATE_LIMITER: rateLimitNamespace,
    AUTH_SESSION_SECRET: 'sayrox-unit-test-session-secret-keep-private-and-long'
  };
  const email = 'legacy@example.com';
  const password = 'Legacy-SAYROX-Password-2026';
  const salt = new Uint8Array(16).fill(19);
  const legacyDigest = await new Promise((resolve, reject) => nodePbkdf2(password, salt, 120_000, 32, 'sha256', (error, key) => error ? reject(error) : resolve(key)));
  const accountKey = await passwords.sha256(email);
  accounts.set(accountKey, {
    id: 'legacy-user', email, password_hash: `pbkdf2$120000$${passwords.base64url(salt)}$${passwords.base64url(new Uint8Array(legacyDigest))}`,
    display_name: 'Legacy User', created_at: 1794000000
  });
  const response = await __worker.fetch(new Request('https://sayrox.test/api/auth/login', {
    method: 'POST',
    headers: { origin: 'https://sayrox.test', 'content-type': 'application/json' },
    body: JSON.stringify({ email, password })
  }), env);
  assert.equal(response.status, 200);
  assert.match(response.headers.get('set-cookie') || '', /xynora_session=/);
  assert.match(accounts.get(accountKey).password_hash, /^pbkdf2\$600000\$/);
});
