import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const read = path => readFile(resolve(root, path), 'utf8');

test('email login and registration expand inline on the one approved SAYROX account screen', async () => {
  const html = await read('site/index.html');
  const auth = await read('app/11-auth.js');
  assert.match(html, /id="authLanding"[\s\S]*?id="authGoogle"[\s\S]*?id="authContinueEmail"[\s\S]*?id="authCreateAccount"/);
  assert.match(html, /id="authFormPanel"/);
  assert.match(html, /id="authEmail"[^>]*type="email"/);
  assert.match(html, /id="authPassword"[^>]*type="password"/);
  assert.match(auth, /function showAuthForm\(mode='login'\)[\s\S]*?authEntryButtons'\)\.classList\.add\('hidden'\)/);
  assert.doesNotMatch(auth, /authLanding'\)\.classList\.add\('hidden'\)/);
  assert.doesNotMatch(auth, /authScreen'\)\.classList\.add\('is-form'\)/);
  assert.match(auth, /location\.assign\('\/api\/auth\/google\/start'\)/);
});

test('a guest draft is held before the account gate and resumes after successful login', async () => {
  const send = await read('app/05-send-message.js');
  const auth = await read('app/11-auth.js');
  assert.match(send, /let pendingAuthSend=null/);
  assert.match(send, /pendingAuthSend=\{kind:'draft',text\};\s*if\(!requireAccountForProtectedApis\(\)\)return ''/);
  assert.match(send, /function resumePendingAuthSend\(\)/);
  assert.match(send, /if\(pending\.text&&!\$\('#promptInput'\)\.value\.trim\(\)\)\$\('#promptInput'\)\.value=pending\.text/);
  assert.match(auth, /function enterAccount\(user\)[\s\S]*?resumePendingAuthSend\?\.\(\)/);
  assert.match(auth, /if\(response\.status===401&&data\.code==='AUTH_REQUIRED'\)/);
});

test('an already-created user message is retried by its exact id after re-authentication', async () => {
  const send = await read('app/05-send-message.js');
  assert.match(send, /pendingAuthSend=\{kind:'retry',chatId,messageId:failedUser\.id\}/);
  assert.match(send, /message=chat\?\.messages\.find\(item=>item\.id===pending\.messageId&&item\.role==='user'\)/);
  assert.match(send, /sendMessage\(message\.content,true,\{messageId:message\.id\}\)/);
  assert.match(send, /همین پیام خودکار ادامه پیدا می‌کند/);
});

test('the S monogram is the empty-chat mark and hides as soon as a conversation exists', async () => {
  const html = await read('site/index.html');
  const rendering = await read('app/04-message-rendering.js');
  const css = await read('site/src/styles/branding.css');
  assert.match(html, /<symbol id="sayrox-orbit-mark" viewBox="0 0 128 128">[\s\S]*?sayroxHomeSGradient[\s\S]*?<\/symbol>/);
  assert.match(html, /class="home-brand-mark" viewBox="0 0 128 128"[^>]*aria-label="نشان S سایروکس"/);
  assert.match(rendering, /function syncEmptyChatBrand\(\)/);
  assert.match(rendering, /function syncEmptyChatBrand\(\)/);
  assert.match(rendering, /const hasConversation=Boolean\(chat&&Array\.isArray\(chat\.messages\)&&chat\.messages\.some\(message=>message&&!message\.internal\)\)/);
  assert.match(rendering, /const hasDraft=Boolean\(input\?\.value\?\.trim\(\)\|\|pendingImageAttachments\.length\|\|pendingPdfAttachments\.length\|\|pendingSpreadsheetAttachments\.length\|\|pendingZipAttachments\.length\|\|pendingOfficeAttachments\.length\)/);
  assert.match(rendering, /showBrand=!hasConversation&&!hasDraft/);
  const composer = await read('app/09-composer-menus.js');
  assert.match(composer, /updateComposerButton\(\);syncEmptyChatBrand\(\)/);
  assert.match(css, /\.home-brand-mark\{[^}]*width:min\(44vw,184px\)/);
});

test('mobile composer is compact without removing the writing and voice controls', async () => {
  const html = await read('site/index.html');
  const css = await read('site/src/styles/content.css');
  assert.match(html, /id="promptInput"/);
  assert.match(html, /id="micBtn"/);
  assert.match(css, /\.composer\{min-height:84px/);
  assert.match(css, /\.composer-input\{padding:4px 6px;min-height:38px;height:38px/);
  assert.match(css, /\.composer-icon,\.composer-icon\.voice\{width:36px;height:36px/);
});
