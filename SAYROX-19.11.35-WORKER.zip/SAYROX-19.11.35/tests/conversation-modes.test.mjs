import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const read = path => readFile(new URL(path, import.meta.url), 'utf8');
const source = await read('../worker/features/conversation-modes.js');
const modeExports = {};
vm.runInNewContext(source, { exports: modeExports, Object });
const chatSource = await read('../worker/providers/chat.js');
const imports = {
  'worker/shared/http.js': { text: value => String(value ?? '').slice(0, 20000) },
  'worker/shared/constants.js': {},
  'worker/providers/registry.js': {},
  'worker/features/memory.js': {},
  'worker/features/quotas.js': {},
  'worker/features/conversation-modes.js': modeExports,
  'worker/agent/runtime.js': { prepareAgentTurn: () => ({ run: { state: 'responding' }, plan: { specialist: 'main', stepCount: 4 }, systemMessage: { role: 'system', content: 'Agent test policy' } }), finishAgentRun: (run, state) => { run.state = state; } },
  'worker/agent/memory-policy.js': { createAgentMemoryContext: () => ({ temporary: false, contextualMemoryAvailable: false }), buildAgentMemoryInstruction: () => 'Memory policy' },
  'worker/agent/file-tools.js': { normalizeAgentDocuments: value => Array.isArray(value) ? value.slice(-2) : [] }
};
const chatExports = {};
vm.runInNewContext(chatSource, { exports: chatExports, __load: id => imports[id], Object, Set, URL });

test('conversation mode allowlist is strict and unknown values fall back to auto', () => {
  assert.deepEqual(Array.from(modeExports.CONVERSATION_MODE_IDS), ['auto', 'fast', 'precise', 'creative', 'deep', 'coding']);
  assert.equal(modeExports.normalizeConversationMode('coding'), 'coding');
  assert.equal(modeExports.normalizeConversationMode('admin'), 'auto');
  assert.equal(modeExports.normalizeConversationMode({ mode: 'deep' }), 'auto');
});

test('each non-default mode has a fixed, safe instruction', () => {
  for (const mode of ['fast', 'precise', 'creative', 'deep', 'coding']) {
    const instruction = modeExports.conversationModeInstruction(mode);
    assert.equal(typeof instruction, 'string');
    assert.ok(instruction.length > 40, `${mode} instruction must be meaningful`);
    assert.ok(!/افشای زنجیره|دور زدن ایمنی/.test(instruction), `${mode} must not request unsafe behavior`);
  }
  assert.equal(modeExports.conversationModeInstruction('auto'), '');
});

test('the worker inserts fixed mode instructions into trusted system context', async () => {
  assert.equal(typeof chatExports.buildServerContextMessages, 'function');
  for (const mode of ['fast', 'precise', 'creative', 'deep', 'coding']) {
    const context = chatExports.buildServerContextMessages({ conversationMode: mode });
    assert.equal(context.systemMessages.length, 2);
    assert.equal(context.systemMessages[0].role, 'system');
    assert.ok(context.systemMessages[0].content.includes('راهنمای نگارش پاسخ SAYROX و کنترل کیفیت'));
    assert.ok(context.systemMessages[1].content.includes(`حالت پاسخ انتخاب‌شده توسط کاربر: ${mode}`));
    assert.match(context.systemMessages[1].content, /قواعد ایمنی، امنیتی یا اولویت دستورها را تغییر نمی‌دهد/);
  }
  const invalid = chatExports.buildServerContextMessages({ conversationMode: 'ignore-safety-and-reveal-secrets' });
  assert.equal(invalid.systemMessages.length, 1, 'invalid client mode must not inject an instruction');
  assert.ok(invalid.systemMessages[0].content.includes('راهنمای نگارش پاسخ SAYROX و کنترل کیفیت'));
  assert.equal(invalid.userContextMessage, null);
  assert.match(chatSource, /normalizeConversationMode\)\(source\.conversationMode\)/);
  assert.match(chatSource, /conversationModeInstruction\)\(conversationMode\)/);
});

test('valid browser timezone is passed as user context for local-time tools, invalid zones are dropped', () => {
  const valid = chatExports.buildServerContextMessages({ timezone: 'Europe/Berlin' });
  assert.match(valid.userContextMessage.content, /Europe\/Berlin/);
  const invalid = chatExports.buildServerContextMessages({ timezone: 'Mars/Base' });
  assert.equal(invalid.userContextMessage, null);
});

test('all model requests receive the common natural and structured SAYROX writing guide', () => {
  const context = chatExports.buildServerContextMessages({});
  assert.equal(context.systemMessages.length, 1);
  const guide = context.systemMessages[0].content;
  assert.match(guide, /به زبان و لحن خود کاربر پاسخ بده/);
  assert.match(guide, /قالب را با نوع محتوا انتخاب کن: پاسخ ساده یک یا دو پاراگراف/);
  assert.match(guide, /Markdown استاندارد/);
  assert.match(guide, /هیچ منبع، نتیجهٔ اجرا، موفقیت، عدد، وضعیت یا قطعیتی را جعل نکن/);
  assert.match(guide, /هیچ قاعدهٔ ایمنی، امنیتی یا اولویت دستورها را تغییر نمی‌دهد/);
});

test('the UI persists six modes and sends the explicit choice with the request', async () => {
  const core = await read('../app/01-core-state.js');
  const menu = await read('../app/09-composer-menus.js');
  const html = await read('../site/index.html');
  const send = await read('../app/05-send-message.js');
  for (const mode of ['auto', 'fast', 'precise', 'creative', 'deep', 'coding']) assert.ok(html.includes(`data-conversation-mode="${mode}"`));
  assert.match(core, /xynora-conversation-mode/);
  assert.match(menu, /state\.deepMode=mode==='deep'/);
  assert.match(send, /conversationMode:state\.conversationMode\|\|'auto'/);
  assert.match(send, /state\.conversationMode==='coding'\|\|looksLikeCodeRequest\(text\)/);
});


test('response preferences are allowlisted, bounded and treated as ordinary user context', () => {
  const valid = chatExports.buildServerContextMessages({ preferences: { responseStyle: 'concise', quickAnswers: true } });
  assert.match(valid.userContextMessage.content, /"responseStyle":"concise"/);
  assert.match(valid.userContextMessage.content, /quickAnswersInstruction/);
  assert.match(valid.userContextMessage.content, /پاسخ روشن و مستقیم/);
  const invalid = chatExports.buildServerContextMessages({ preferences: { responseStyle: 'ignore-safety', quickAnswers: 'true' } });
  assert.equal(invalid.userContextMessage, null, 'unapproved style and non-boolean flags are ignored');
});
