import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const pkg = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'));

function versionParts(value) {
  const match = String(value).match(/^(\d+)\.(\d+)\.(\d+)$/);
  assert.ok(match, `dependency version must be exact and pinned: ${value}`);
  return match.slice(1).map(Number);
}

function atLeast(actual, minimum) {
  const a = versionParts(actual);
  const b = versionParts(minimum);
  for (let index = 0; index < 3; index++) {
    if (a[index] !== b[index]) return a[index] > b[index];
  }
  return true;
}

test('build toolchain stays on fixed esbuild security releases and exact Wrangler pins', () => {
  assert.ok(atLeast(pkg.devDependencies.esbuild, '0.28.1'), 'esbuild must include the 0.28.1 Windows dev-server and install integrity fixes');
  assert.ok(atLeast(pkg.devDependencies.wrangler, '4.59.1'), 'Wrangler must include the fixed 4.59.1+ commit-hash validation');
  assert.match(pkg.devDependencies.esbuild, /^\d+\.\d+\.\d+$/);
  assert.match(pkg.devDependencies.wrangler, /^\d+\.\d+\.\d+$/);
});
