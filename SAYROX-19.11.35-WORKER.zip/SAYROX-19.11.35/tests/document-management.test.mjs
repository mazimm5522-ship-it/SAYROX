import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');

async function loadOfficeEngines() {
  const window = { addEventListener() {}, removeEventListener() {} };
  const context = vm.createContext({
    window, Blob, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, DataView,
    Map, Set, Date, Math, Number, String, Array, Object, RegExp, Error, TypeError,
    Promise, JSON, URL, DecompressionStream, crypto: globalThis.crypto,
    setTimeout, clearTimeout, console
  });
  for (const path of [
    'site/src/features/files/policy.js',
    'site/src/features/files/zip.js',
    'site/src/features/files/markdown.js',
    'site/src/features/files/documents.js'
  ]) vm.runInContext(await read(path), context, { filename: path });
  return window;
}


async function loadStudioTools() {
  const window = { addEventListener() {}, removeEventListener() {} };
  const document = { querySelector() { return null; } };
  const context = vm.createContext({
    window, document, Blob, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, DataView,
    Map, Set, Date, Math, Number, String, Array, Object, RegExp, Error, TypeError,
    Promise, JSON, URL, DecompressionStream, crypto: globalThis.crypto,
    setTimeout, clearTimeout, console, navigator: { clipboard: {} }
  });
  for (const path of [
    'site/src/features/files/policy.js',
    'site/src/features/files/zip.js',
    'site/src/features/files/spreadsheet.js',
    'site/src/features/files/pdf.js',
    'site/src/features/files/pdf-text.js',
    'site/src/features/files/ocr.js',
    'site/src/features/files/markdown.js',
    'site/src/features/files/documents.js',
    'site/src/features/files/studio.js'
  ]) vm.runInContext(await read(path), context, { filename: path });
  return window;
}

class TestFile extends Blob {
  constructor(parts, name, type = 'text/plain') { super(Array.isArray(parts) ? parts : [parts], { type }); this.name = name; this.lastModified = 1_700_000_000_000; }
}

async function makeMinimalPptx(window, { slideOrder = ['second.xml', 'first.xml'], targets } = {}) {
  const relationships = (targets || slideOrder).map((name, index) =>
    `<Relationship Id="rId${index + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/${name}"/>`
  ).join('');
  const ids = slideOrder.map((_, index) => `<p:sldId id="${256 + index}" r:id="rId${index + 1}"/>`).join('');
  const entries = [
    { name: 'ppt/presentation.xml', text: `<?xml version="1.0" encoding="UTF-8"?><p:presentation xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><p:sldIdLst>${ids}</p:sldIdLst></p:presentation>` },
    { name: 'ppt/_rels/presentation.xml.rels', text: `<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">${relationships}</Relationships>` },
    { name: 'ppt/slides/first.xml', text: '<p:sld xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:p><a:r><a:t>اسلاید اول</a:t></a:r></a:p></p:sld>' },
    { name: 'ppt/slides/second.xml', text: '<p:sld xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"><a:p><a:r><a:t>اسلاید دوم</a:t></a:r></a:p><a:p><a:r><a:t>متن دوم</a:t></a:r></a:p></p:sld>' }
  ];
  return window.SayroxZip.createZip(entries);
}

test('DOCX creation and extraction round-trip Persian paragraphs, basic Markdown and line breaks', async () => {
  const window = await loadOfficeEngines();
  const source = '# عنوان اصلی\n\nسلام **رفیق**\n\n- مورد اول\n- مورد دوم\n\nستون اول\tستون دوم';
  const blob = await window.SayroxDocuments.createDocx(source, { title: 'گزارش فارسی' });
  const entries = await window.SayroxZip.readZip(blob);
  const names = new Set(entries.map(entry => entry.name));
  assert.ok(names.has('[Content_Types].xml'));
  assert.ok(names.has('word/document.xml'));
  assert.ok(names.has('word/styles.xml'));
  assert.ok(names.has('word/numbering.xml'));
  const extracted = await window.SayroxDocuments.readDocx(blob);
  assert.match(extracted, /^# عنوان اصلی$/m);
  assert.match(extracted, /سلام رفیق/);
  assert.match(extracted, /^- مورد اول$/m);
  assert.match(extracted, /^- مورد دوم$/m);
  assert.match(extracted, /ستون اول\tستون دوم/);
});

test('DOCX converts Markdown pipe tables into real Word tables and preserves their cell text', async () => {
  const window = await loadOfficeEngines();
  const source = '# گزارش\n\n| نام | توضیح |\n| --- | --- |\n| سایروکس | هوش مصنوعی |\n| نسخه | ۱۹.۱۱.۱ |';
  const blob = await window.SayroxDocuments.createDocx(source);
  const entries = await window.SayroxZip.readZip(blob);
  const document = new TextDecoder().decode(entries.find(entry => entry.name === 'word/document.xml').bytes);
  assert.match(document, /<w:tbl>/);
  assert.match(document, /<w:tblBorders>/);
  assert.match(document, /<w:shd w:fill="EAF1F8"\/>/);
  const extracted = await window.SayroxDocuments.readDocx(blob);
  assert.match(extracted, /سایروکس/);
  assert.match(extracted, /هوش مصنوعی/);
  assert.match(extracted, /۱۹\.۱۱\.۱/);
  assert.match(extracted, /\| نام \| توضیح \|/);
});

test('DOCX to HTML renders extracted headings and tables instead of displaying Markdown syntax', async () => {
  const window = await loadStudioTools();
  const file = new TestFile(await window.SayroxDocuments.createDocx('# گزارش\n\n| نام | مقدار |\n| --- | --- |\n| SAYROX | 19.11.1 |').then(blob => blob.arrayBuffer()), 'report.docx', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
  const result = await window.SayroxFileStudio.tools.convertSelectedFile({ file, extension: 'docx' }, 'html');
  const html = await result.blob.text();
  assert.match(html, /<h1>گزارش<\/h1>/);
  assert.match(html, /<table(?:\s|>)/g);
  assert.match(html, /<th[^>]*>نام<\/th>/);
  assert.doesNotMatch(html, /\| نام \| مقدار \|/);
});

test('DOCX reader rejects nested tables rather than silently mis-parsing their content', async () => {
  const window = await loadOfficeEngines();
  const source = '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body><w:tbl><w:tr><w:tc><w:p><w:r><w:t>outer</w:t></w:r></w:p><w:tbl><w:tr><w:tc><w:p><w:r><w:t>inner</w:t></w:r></w:p></w:tc></w:tr></w:tbl></w:tc></w:tr></w:tbl></w:body></w:document>';
  const blob = await window.SayroxZip.createZip([
    { name: '[Content_Types].xml', text: '<Types>wordprocessingml.document.main+xml</Types>' },
    { name: 'word/document.xml', text: source }
  ]);
  await assert.rejects(window.SayroxDocuments.readDocx(blob), /جدول‌های تو‌در‌تو/);
});

test('DOCX reader rejects incomplete packages and invalid UTF-8 XML instead of returning corrupt text', async () => {
  const window = await loadOfficeEngines();
  const missing = await window.SayroxZip.createZip([{ name: 'word/document.xml', text: '<w:document/>' }]);
  await assert.rejects(window.SayroxDocuments.readDocx(missing), /ساختار اصلی فایل Word معتبر نیست/);
  const invalid = await window.SayroxZip.createZip([
    { name: '[Content_Types].xml', text: '<Types>wordprocessingml.document.main+xml</Types>' },
    { name: 'word/document.xml', bytes: new Uint8Array([0xff, 0xfe, 0xfd]) }
  ]);
  await assert.rejects(window.SayroxDocuments.readDocx(invalid), /UTF-8/);
});

test('PPTX creation and extraction preserve slide order and paragraph boundaries', async () => {
  const window = await loadOfficeEngines();
  const blob = await window.SayroxDocuments.createPptx('# اول\n\nمتن اسلاید اول\n\n# دوم\n\nمتن اسلاید دوم');
  const entries = await window.SayroxZip.readZip(blob);
  assert.ok(entries.some(entry => entry.name === 'ppt/presentation.xml'));
  assert.ok(entries.some(entry => entry.name === 'ppt/slides/slide1.xml'));
  assert.ok(entries.some(entry => entry.name === 'ppt/slides/slide2.xml'));
  const extracted = await window.SayroxDocuments.readPptx(blob);
  assert.ok(extracted.indexOf('اول') < extracted.indexOf('دوم'));
  assert.match(extracted, /متن اسلاید اول/);
  assert.match(extracted, /متن اسلاید دوم/);
});

test('PPTX creation splits long presentations without silently dropping lines', async () => {
  const window = await loadOfficeEngines();
  const lines = Array.from({ length: 210 }, (_, index) => `ردیف متنی ${index + 1}`);
  const blob = await window.SayroxDocuments.createPptx(`# گزارش
${lines.join('\n')}`);
  const extracted = await window.SayroxDocuments.readPptx(blob);
  assert.match(extracted, /ردیف متنی 1/);
  assert.match(extracted, /ردیف متنی 210/);
  assert.equal((extracted.match(/ردیف متنی \d+/g) || []).length, 210);
  await assert.rejects(window.SayroxDocuments.createPptx('x'.repeat(500_001)), /سقف مجاز/);
  await assert.rejects(window.SayroxDocuments.createPptx(Array.from({ length: 31 }, (_, index) => `# بخش ${index + 1}\n\nمتن`).join('\n\n')), /حداکثر 30 اسلاید/);
});

test('PPTX reader follows presentation relationship order, not slide filename order', async () => {
  const window = await loadOfficeEngines();
  const blob = await makeMinimalPptx(window);
  const extracted = await window.SayroxDocuments.readPptx(blob);
  assert.ok(extracted.indexOf('اسلاید دوم') < extracted.indexOf('اسلاید اول'));
  assert.match(extracted, /متن دوم/);
});

test('PPTX reader rejects path traversal and external slide relationships', async () => {
  const window = await loadOfficeEngines();
  const traversal = await makeMinimalPptx(window, { targets: ['../../outside.xml', 'first.xml'] });
  await assert.rejects(window.SayroxDocuments.readPptx(traversal), /ارجاع اسلاید خارج از پوشهٔ مجاز/);
  const external = await window.SayroxZip.createZip([
    { name: 'ppt/presentation.xml', text: '<p:presentation xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><p:sldIdLst><p:sldId id="256" r:id="rId1"/></p:sldIdLst></p:presentation>' },
    { name: 'ppt/_rels/presentation.xml.rels', text: '<Relationships><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="https://example.invalid/slide.xml"/></Relationships>' }
  ]);
  await assert.rejects(window.SayroxDocuments.readPptx(external), /مسیر ارجاع‌شده/);
});

test('PPTX reader rejects missing or duplicate relationship identifiers', async () => {
  const window = await loadOfficeEngines();
  const duplicate = await window.SayroxZip.createZip([
    { name: 'ppt/presentation.xml', text: '<p:presentation xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><p:sldIdLst><p:sldId id="256" r:id="rId1"/></p:sldIdLst></p:presentation>' },
    { name: 'ppt/_rels/presentation.xml.rels', text: '<Relationships><Relationship Id="rId1" Type="x/slide" Target="slides/one.xml"/><Relationship Id="rId1" Type="x/slide" Target="slides/two.xml"/></Relationships>' },
    { name: 'ppt/slides/one.xml', text: '<p:sld xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"/>' }
  ]);
  await assert.rejects(window.SayroxDocuments.readPptx(duplicate), /تکراری یا نامعتبر/);
});

test('Markdown converts to safe semantic HTML with headings, lists, inline formatting and safe links', async () => {
  const window = await loadStudioTools();
  const source = new TestFile(['# گزارش', '', 'سلام **مهم** و `code`', '', '- اول', '- دوم', '', '[سایت](https://example.com)', '', '[ناامن](javascript:alert(1))', '', '<script>alert(1)</script>'].join('\n'), 'report.md', 'text/markdown');
  const result = await window.SayroxFileStudio.tools.convertSelectedFile({ id: 'md-1', file: source, extension: 'md' }, 'html');
  const html = await result.blob.text();
  assert.match(html, /<h1>گزارش<\/h1>/);
  assert.match(html, /<strong>مهم<\/strong>/);
  assert.match(html, /<code>code<\/code>/);
  assert.match(html, /<ul><li>اول<\/li><li>دوم<\/li><\/ul>/);
  assert.match(html, /href=\"https:\/\/example\.com\"/);
  assert.doesNotMatch(html, /href=\"javascript:/i);
  assert.doesNotMatch(html, /<script>/i);
  assert.match(html, /&lt;script&gt;/i);
});

test('shared Markdown parser renders pipe tables safely and keeps escaped delimiters', async () => {
  const window = await loadStudioTools();
  const html = window.SayroxMarkdown.renderHtml('| عنوان | مقدار |\n| --- | --- |\n| سایروکس | الف \\| ب |', 'جدول');
  assert.match(html, /<table(?:\s|>)/g);
  assert.match(html, /<th[^>]*>عنوان<\/th>/);
  assert.match(html, /الف \| ب/);
  assert.doesNotMatch(html, /<script/i);
});

test('Markdown table escaping round-trips backslashes and literal pipes', async () => {
  const window = await loadStudioTools();
  const rows = [['عنوان', 'مقدار'], ['مسیر', String.raw`a\|b`]];
  const markdown = window.SayroxMarkdown.tableToMarkdown(rows);
  const table = window.SayroxMarkdown.parseBlocks(markdown).find(block => block.type === 'table');
  assert.deepEqual(JSON.parse(JSON.stringify(table.rows)), rows);
});

test('shared Markdown recognizes semantic callouts, checklist state and explicit table alignment', async () => {
  const window = await loadOfficeEngines();
  const source = [
    '> [!SUCCESS] کار تکمیل شد',
    '> نتیجه بررسی شد.',
    '',
    '- [x] مورد تأییدشده',
    '- [ ] مورد باقی‌مانده',
    '',
    '| راست | وسط | چپ |',
    '| ---: | :---: | :--- |',
    '| ۱ | ۲ | ۳ |'
  ].join('\n');
  const blocks = window.SayroxMarkdown.parseBlocks(source);
  const callout = blocks.find(block => block.type === 'callout');
  const checklist = blocks.find(block => block.type === 'list');
  const table = blocks.find(block => block.type === 'table');
  assert.equal(callout.kind, 'SUCCESS');
  assert.equal(callout.tone, 'success');
  assert.equal(callout.title, 'کار تکمیل شد');
  assert.deepEqual(JSON.parse(JSON.stringify(checklist.checks)), [true, false]);
  assert.equal(checklist.taskList, true);
  assert.deepEqual(JSON.parse(JSON.stringify(table.alignments)), ['right', 'center', 'left']);
  const html = window.SayroxMarkdown.renderHtml(source, 'گزارش');
  assert.match(html, /sayrox-callout is-success/);
  assert.match(html, /sayrox-task-list/);
  assert.match(html, /sayrox-status/);
  assert.match(html, /is-align-right/);
  assert.match(window.SayroxMarkdown.toPlainText(source), /☑/);
  assert.match(window.SayroxMarkdown.toPlainText(source), /☐/);
});

test('Word export preserves semantic callout text and completed/pending checklist markers', async () => {
  const window = await loadOfficeEngines();
  const source = [
    '> [!WARNING] پیش از انتشار',
    '> تنظیم Origin هنوز لازم است.',
    '',
    '- [x] تست‌ها موفق شدند',
    '- [ ] Deploy واقعی انجام شود'
  ].join('\n');
  const blob = await window.SayroxDocuments.createDocx(source);
  const entries = await window.SayroxZip.readZip(blob);
  const document = new TextDecoder().decode(entries.find(entry => entry.name === 'word/document.xml').bytes);
  assert.match(document, /پیش از انتشار/);
  assert.match(document, /تنظیم Origin هنوز لازم است/);
  assert.match(document, /☑ تست‌ها موفق شدند/);
  assert.match(document, /☐ Deploy واقعی انجام شود/);
});

test('PDF generation rejects oversized input instead of clipping the end', async () => {
  const window = await loadStudioTools();
  await assert.rejects(window.SayroxFileStudio.tools.createTextPdf('x'.repeat(500_001)), /سقف مجاز/);
});

test('HTML extraction rejects oversized text in the no-DOMParser fallback', async () => {
  const window = await loadStudioTools();
  await assert.rejects(Promise.resolve().then(() => window.SayroxFileStudio.tools.htmlToPlainText(`<p>${'x'.repeat(500_001)}</p>`)), /سقف ۵۰۰٬۰۰۰ نویسه/);
});

test('CSV converts to Markdown tables with escaped pipes and safe output text', async () => {
  const window = await loadStudioTools();
  const file = new TestFile(['نام,توضیح', 'سایروکس,هوش | مصنوعی', 'فرمول,=SUM(A1:A2)'].join('\n'), 'table.csv', 'text/csv');
  const result = await window.SayroxFileStudio.tools.convertSelectedFile({ file, extension: 'csv' }, 'md');
  const markdown = await result.blob.text();
  assert.equal(result.filename, 'table.md');
  assert.match(markdown, /\| نام \| توضیح \|/);
  assert.match(markdown, /هوش \\| مصنوعی/);
  assert.match(markdown, /=SUM\(A1:A2\)/);
  assert.equal(result.warning.includes('فقط متن'), true);
});

test('batch document conversion emits a machine-readable report and unique output names', async () => {
  const window = await loadStudioTools();
  const items = [
    { id: 'a', file: new TestFile('### اول', 'report.txt'), extension: 'txt' },
    { id: 'b', file: new TestFile('### دوم', 'report.txt'), extension: 'txt' }
  ];
  const result = await window.SayroxFileStudio.tools.convertBatchFiles(items, 'md');
  assert.equal(result.successes.length, 2);
  const entries = await window.SayroxZip.readZip(result.blob);
  const names = entries.map(entry => entry.name);
  assert.ok(names.includes('report.md'));
  assert.ok(names.includes('report-2.md'));
  assert.ok(names.includes('sayrox-conversion-report.json'));
  const reportEntry = entries.find(entry => entry.name === 'sayrox-conversion-report.json');
  const report = JSON.parse(new TextDecoder().decode(reportEntry.bytes));
  assert.equal(report.generatedBy, 'SAYROX 19.11.4');
  assert.deepEqual(report.summary, { requested: 2, succeeded: 2, failed: 0, cancelled: false });
});

test('text conversion rejects oversized documents instead of silently truncating content', async () => {
  const window = await loadStudioTools();
  const oversized = new TestFile('x'.repeat(500_001), 'large.txt');
  await assert.rejects(window.SayroxFileStudio.tools.convertSelectedFile({ file: oversized, extension: 'txt' }, 'md'), /سقف ۵۰۰٬۰۰۰ نویسه/);
});

test('Markdown to TXT removes markup and keeps list/table content readable', async () => {
  const window = await loadStudioTools();
  const file = new TestFile('# گزارش\n\nسلام **رفیق**\n\n- اول\n- دوم\n\n| نام | مقدار |\n| --- | --- |\n| SAYROX | 19.11.1 |', 'report.md', 'text/markdown');
  const result = await window.SayroxFileStudio.tools.convertSelectedFile({ file, extension: 'md' }, 'txt');
  const text = await result.blob.text();
  assert.equal(result.filename, 'report.txt');
  assert.match(text, /گزارش/);
  assert.match(text, /رفیق/);
  assert.match(text, /• اول/);
  assert.match(text, /• دوم/);
  assert.match(text, /نام\tمقدار/);
  assert.doesNotMatch(text, /<|\*\*/);
});

test('Markdown does not offer a redundant Markdown-to-Markdown conversion', async () => {
  const window = await loadStudioTools();
  assert.equal(window.SayroxFileStudio.tools.conversionTargets('md').some(([extension]) => extension === 'md'), false);
  assert.equal(window.SayroxFileStudio.tools.conversionTargets('md').some(([extension]) => extension === 'txt'), true);
  assert.equal(window.SayroxFileStudio.tools.conversionTargets('txt').some(([extension]) => extension === 'md'), true);
});

test('one shared Markdown parser is loaded before Office/Studio and cached offline', async () => {
  const index = await read('site/index.html');
  const serviceWorker = await read('site/sw.js');
  const studio = await read('site/src/features/files/studio.js');
  const documents = await read('site/src/features/files/documents.js');
  assert.ok(index.indexOf('src/features/files/markdown.js') < index.indexOf('src/features/files/documents.js'));
  assert.ok(index.indexOf('src/features/files/markdown.js') < index.indexOf('src/features/files/studio.js'));
  assert.match(serviceWorker, /\/src\/features\/files\/markdown\.js/);
  assert.doesNotMatch(studio, /function\s+markdownInlineHtml|function\s+markdownToHtml|function\s+markdownTable/);
  assert.match(documents, /window\.SayroxMarkdown/);
});
