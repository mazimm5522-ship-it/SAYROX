import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const [accountPage, settingsController, authRoutes, authUi, sessions] = await Promise.all([
  readFile(new URL('../site/src/features/settings/pages/account.js', import.meta.url), 'utf8'),
  readFile(new URL('../site/src/features/settings/controller.js', import.meta.url), 'utf8'),
  readFile(new URL('../worker/routes/auth.js', import.meta.url), 'utf8'),
  readFile(new URL('../app/11-auth.js', import.meta.url), 'utf8'),
  readFile(new URL('../worker/security/sessions.js', import.meta.url), 'utf8')
]);

test('Google linking is exposed only in account settings and uses an authenticated same-origin POST', () => {
  assert.match(accountPage, /user\.googleLinked/);
  assert.match(accountPage, /button\('google-link','اتصال حساب Google'/);
  assert.match(settingsController, /form\.method = 'POST'; form\.action = '\/api\/auth\/google\/link\/start'/);
  assert.match(authRoutes, /googleOAuthLinkStart/);
  assert.match(authUi, /google_link_required/);
  assert.match(sessions, /googleLinked: Boolean\(row\.google_sub\)/);
  assert.doesNotMatch(sessions, /googleSub:\s*row\.google_sub/);
});
