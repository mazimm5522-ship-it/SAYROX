import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';
import { webcrypto, generateKeyPairSync, sign as rsaSign, createHash } from 'node:crypto';

const bundle = await readFile(new URL('../site/_worker.js', import.meta.url), 'utf8');
const executable = bundle.replace('export default __worker;', 'globalThis.__sayroxBundle = { __worker, __load };');
const signing = generateKeyPairSync('rsa', { modulusLength: 2048 });
const jwk = { ...signing.publicKey.export({ format: 'jwk' }), kid: 'sayrox-google-test-key', use: 'sig', alg: 'RS256' };
let activeIdToken = '';
const fetchMock = async (input, init = {}) => {
  const url = String(input);
  if (url === 'https://oauth2.googleapis.com/token') {
    const body = new URLSearchParams(init.body);
    assert.equal(body.get('grant_type'), 'authorization_code');
    assert.ok(body.get('code_verifier'), 'PKCE verifier must be sent to Google');
    return new Response(JSON.stringify({ id_token: activeIdToken, access_token: 'not-stored-test-token' }), {
      status: 200, headers: { 'content-type': 'application/json' }
    });
  }
  if (url === 'https://www.googleapis.com/oauth2/v3/certs') {
    return new Response(JSON.stringify({ keys: [jwk] }), { status: 200, headers: { 'content-type': 'application/json' } });
  }
  throw new Error(`Unexpected outbound request: ${url}`);
};
const context = vm.createContext({
  crypto: webcrypto, fetch: fetchMock, Request, Response, Headers, URL, URLSearchParams,
  AbortController, AbortSignal, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, Blob,
  setTimeout, clearTimeout, console, atob, btoa, Date, Math, JSON, Number, String,
  Boolean, Object, Array, Map, Set, RegExp, Error, TypeError, Promise, Intl,
  ReadableStream, TransformStream, queueMicrotask
});
vm.runInContext(executable, context, { filename: 'site/_worker.js', importModuleDynamically: vm.constants.USE_MAIN_CONTEXT_DEFAULT_LOADER });
const { __worker, __load } = context.__sayroxBundle;
const passwords = __load('worker/security/passwords.js');
const sessionsApi = __load('worker/security/sessions.js');

function jsonResponse(value, status = 200) {
  return new Response(JSON.stringify(value), { status, headers: { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' } });
}
function namespaces() {
  const accounts = new Map();
  const googleIdentities = new Map();
  const sessions = new Map();
  const rate = new Map();
  const AUTH_ACCOUNTS = {
    idFromName: value => value,
    get: key => ({ fetch: async request => {
      const path = new URL(request.url).pathname;
      const body = await request.json();
      let account = accounts.get(key);
      if (path === '/internal/google-identity/get') return jsonResponse({ ok: true, identity: googleIdentities.get(key) || null });
      if (path === '/internal/google-identity/claim') {
        const current = googleIdentities.get(key);
        if (current) return current.account_key === body.accountKey && current.email === body.email
          ? jsonResponse({ ok: true, created: false }) : jsonResponse({ ok: false }, 409);
        googleIdentities.set(key, { account_key: body.accountKey, email: body.email });
        return jsonResponse({ ok: true, created: true });
      }
      if (path === '/internal/google-identity/delete') {
        const current = googleIdentities.get(key);
        if (current?.account_key === body.accountKey) googleIdentities.delete(key);
        return jsonResponse({ ok: true });
      }
      if (path === '/internal/google-link') {
        if (!account || account.id !== body.userId || account.email !== body.email) return jsonResponse({ ok: false, error: 'ACCOUNT_SESSION_MISMATCH' }, 403);
        if (account.google_sub && account.google_sub !== body.googleSub) return jsonResponse({ ok: false, error: 'GOOGLE_IDENTITY_CONFLICT' }, 409);
        account.google_sub = body.googleSub;
        return jsonResponse({ ok: true, user: account });
      }
      if (path === '/internal/google-login') {
        if (account && account.google_sub && account.google_sub !== body.googleSub) return jsonResponse({ ok: false, error: 'GOOGLE_IDENTITY_CONFLICT' }, 409);
        if (account && account.password_hash && !account.google_sub) return jsonResponse({ ok: false, error: 'GOOGLE_LINK_REQUIRED' }, 409);
        if (account) {
          account.google_sub = body.googleSub;
          return jsonResponse({ ok: true, user: account });
        }
        account = { id: body.userId, email: body.email, password_hash: '', display_name: body.displayName, created_at: body.createdAt, google_sub: body.googleSub };
        accounts.set(key, account);
        return jsonResponse({ ok: true, user: account });
      }
      if (path === '/internal/validate-session') return account && Number(sessions.get(body.tokenHash)) > Number(body.now) ? jsonResponse({ ok: true, user: account }) : jsonResponse({ ok: false }, 404);
      if (path === '/internal/create-session') { if (!account) return jsonResponse({ ok: false }, 404); sessions.set(body.tokenHash, body.expiresAt); return jsonResponse({ ok: true }); }
      if (path === '/internal/get-user') return account ? jsonResponse({ ok: true, user: account }) : jsonResponse({ ok: false }, 404);
      if (path === '/internal/delete-session') { sessions.delete(body.tokenHash); return jsonResponse({ ok: true }); }
      return jsonResponse({ ok: false, error: 'NOT_FOUND' }, 404);
    } })
  };
  const AUTH_RATE_LIMITER = {
    idFromName: value => value,
    get: shard => ({ fetch: async request => {
      const body = await request.json();
      const key = `${shard}:${body.bucketKey}`;
      const attempts = (rate.get(key) || 0) + 1;
      rate.set(key, attempts);
      return jsonResponse({ ok: true, allowed: true, attempts, retryAfterSeconds: 1 });
    } })
  };
  return { AUTH_ACCOUNTS, AUTH_RATE_LIMITER, accounts, googleIdentities };
}
function decodeCookiePayload(cookie) {
  const value = cookie.split(';', 1)[0].split('=').slice(1).join('=');
  const encoded = value.split('.')[0];
  return JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8'));
}
function makeIdToken({ nonce, email = 'same.user@gmail.com', sub = 'google-sub-001', emailVerified = true, clientId = 'sayrox-google-client-id.apps.googleusercontent.com' }) {
  const now = Math.floor(Date.now() / 1000);
  const header = Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT', kid: jwk.kid })).toString('base64url');
  const claims = Buffer.from(JSON.stringify({
    iss: 'https://accounts.google.com', aud: clientId, sub, email,
    email_verified: emailVerified, name: 'SAYROX Test User', nonce, iat: now, exp: now + 300
  })).toString('base64url');
  const data = `${header}.${claims}`;
  return `${data}.${rsaSign('RSA-SHA256', Buffer.from(data), signing.privateKey).toString('base64url')}`;
}
function envWith(namespaces) {
  return {
    ...namespaces,
    AUTH_SESSION_SECRET: 'sayrox-test-session-secret-at-least-thirty-two-characters',
    GOOGLE_CLIENT_ID: 'sayrox-google-client-id.apps.googleusercontent.com',
    GOOGLE_CLIENT_SECRET: 'sayrox-google-client-secret-long-enough'
  };
}

test('Google OAuth creates new accounts, requires authenticated explicit linking for existing accounts, and preserves sessions', async () => {
  const store = namespaces();
  const env = envWith(store);
  const email = 'same.user@gmail.com';
  const accountKey = await passwords.sha256(email);
  const originalHash = 'pbkdf2$600000$aaaaaaaaaaaaaaaaaaaaaa$aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';
  store.accounts.set(accountKey, {
    id: 'existing-sayrox-user', email, password_hash: originalHash,
    display_name: 'Existing SAYROX account', created_at: 1794000000, google_sub: null
  });

  // Attempting direct Google sign-in must not silently link an account whose email was never verified by SAYROX.
  let start = await __worker.fetch(new Request('https://sayrox.test/api/auth/google/start'), env);
  assert.equal(start.status, 302);
  let authorization = new URL(start.headers.get('location'));
  assert.equal(authorization.origin, 'https://accounts.google.com');
  assert.equal(authorization.searchParams.get('response_type'), 'code');
  assert.equal(authorization.searchParams.get('scope'), 'openid email profile');
  assert.equal(authorization.searchParams.get('code_challenge_method'), 'S256');
  assert.equal(authorization.searchParams.get('redirect_uri'), 'https://sayrox.test/api/auth/google/callback');
  let stateCookie = start.headers.get('set-cookie');
  assert.match(stateCookie, /HttpOnly/); assert.match(stateCookie, /Secure/); assert.match(stateCookie, /SameSite=Lax/);
  let state = decodeCookiePayload(stateCookie);
  assert.equal(state.purpose, 'signin');
  assert.equal(authorization.searchParams.get('state'), state.state);
  assert.equal(authorization.searchParams.get('nonce'), state.nonce);
  assert.ok(state.verifier.length >= 43);
  assert.equal(createHash('sha256').update(state.verifier).digest('base64url'), authorization.searchParams.get('code_challenge'));
  activeIdToken = makeIdToken({ nonce: state.nonce });
  let callback = await __worker.fetch(new Request(`https://sayrox.test/api/auth/google/callback?code=single-use-code&state=${encodeURIComponent(state.state)}`, {
    headers: { cookie: stateCookie.split(';', 1)[0] }
  }), env);
  assert.equal(callback.status, 303);
  assert.match(callback.headers.get('location'), /auth=google_link_required/);
  assert.equal(store.accounts.get(accountKey).google_sub, null, 'Google must not silently bind to an existing unverified password account');
  assert.equal(store.accounts.get(accountKey).password_hash, originalHash, 'existing password must remain unchanged');
  assert.equal(store.accounts.size, 1);
  assert.equal(store.googleIdentities.size, 0, 'a rejected implicit link must release its temporary identity claim');

  // The user first authenticates with the existing SAYROX password, then explicitly starts linking.
  const issued = await sessionsApi.issueSession(env, accountKey, store.accounts.get(accountKey));
  const issuedCookie = issued.headers.get('set-cookie');
  assert.match(issuedCookie, /HttpOnly/);
  const sessionPair = issuedCookie.split(';', 1)[0];
  const linkStart = await __worker.fetch(new Request('https://sayrox.test/api/auth/google/link/start', {
    method: 'POST', headers: { origin: 'https://sayrox.test', cookie: sessionPair }
  }), env);
  assert.equal(linkStart.status, 302);
  const linkStateCookie = linkStart.headers.get('set-cookie');
  const linkState = decodeCookiePayload(linkStateCookie);
  const linkAuthorization = new URL(linkStart.headers.get('location'));
  assert.equal(linkState.purpose, 'link');
  assert.equal(linkState.accountKey, accountKey);
  assert.equal(linkState.userId, 'existing-sayrox-user');
  assert.equal(linkAuthorization.searchParams.get('state'), linkState.state);
  activeIdToken = makeIdToken({ nonce: linkState.nonce, email, sub: 'google-sub-001' });
  callback = await __worker.fetch(new Request(`https://sayrox.test/api/auth/google/callback?code=explicit-link-code&state=${encodeURIComponent(linkState.state)}`, {
    headers: { cookie: `${sessionPair}; ${linkStateCookie.split(';', 1)[0]}` }
  }), env);
  assert.match(callback.headers.get('location'), /auth=google_linked/);
  assert.equal(store.accounts.get(accountKey).id, 'existing-sayrox-user');
  assert.equal(store.accounts.get(accountKey).google_sub, 'google-sub-001');
  assert.equal(store.accounts.get(accountKey).password_hash, originalHash);
  assert.equal(store.accounts.size, 1);
  assert.equal(store.googleIdentities.size, 1);

  // The linked identity can now use Google sign-in and receives a regular SAYROX session.
  start = await __worker.fetch(new Request('https://sayrox.test/api/auth/google/start'), env);
  stateCookie = start.headers.get('set-cookie');
  state = decodeCookiePayload(stateCookie);
  activeIdToken = makeIdToken({ nonce: state.nonce });
  callback = await __worker.fetch(new Request(`https://sayrox.test/api/auth/google/callback?code=linked-login-code&state=${encodeURIComponent(state.state)}`, {
    headers: { cookie: stateCookie.split(';', 1)[0] }
  }), env);
  assert.match(callback.headers.get('location'), /auth=google_success/);
  const cookieHeaders = callback.headers.getSetCookie ? callback.headers.getSetCookie().join('; ') : callback.headers.get('set-cookie');
  assert.match(cookieHeaders, /xynora_session=/);
  assert.match(cookieHeaders, /sayrox_google_oauth=;.*Max-Age=0/);
  const sessionCookie = cookieHeaders.match(/xynora_session=([^;,]+)/)?.[1];
  const me = await __worker.fetch(new Request('https://sayrox.test/api/auth/me', { headers: { cookie: `xynora_session=${sessionCookie}` } }), env);
  const meBody = await me.json();
  assert.equal(meBody.authenticated, true);
  assert.equal(meBody.user.id, 'existing-sayrox-user');
  assert.equal(meBody.user.email, email);
  assert.equal(meBody.user.googleLinked, true);

  // A changed Google email is rejected rather than silently creating a second SAYROX account.
  const secondStart = await __worker.fetch(new Request('https://sayrox.test/api/auth/google/start'), env);
  const secondStateCookie = secondStart.headers.get('set-cookie');
  const secondState = decodeCookiePayload(secondStateCookie);
  activeIdToken = makeIdToken({ nonce: secondState.nonce, email: 'renamed.user@gmail.com', sub: 'google-sub-001' });
  const changedEmail = await __worker.fetch(new Request(`https://sayrox.test/api/auth/google/callback?code=changed-email&state=${encodeURIComponent(secondState.state)}`, {
    headers: { cookie: secondStateCookie.split(';', 1)[0] }
  }), env);
  assert.match(changedEmail.headers.get('location'), /auth=google_email_changed/);
  assert.equal(store.accounts.size, 1);

  const googleOnlyEmail = 'google.only@gmail.com';
  store.accounts.set(await passwords.sha256(googleOnlyEmail), {
    id: 'google-only-user', email: googleOnlyEmail, password_hash: '', display_name: 'Google Only',
    created_at: 1794000000, google_sub: 'google-sub-only'
  });
  const passwordLogin = await __worker.fetch(new Request('https://sayrox.test/api/auth/login', {
    method: 'POST', headers: { origin: 'https://sayrox.test', 'content-type': 'application/json' },
    body: JSON.stringify({ email: googleOnlyEmail, password: 'A-Test-Password-That-Is-Long' })
  }), env);
  assert.equal(passwordLogin.status, 401);
  assert.match((await passwordLogin.json()).message, /با Google ساخته شده/);
});

test('Google OAuth fails closed when state is missing or Google credentials are absent', async () => {
  const store = namespaces();
  const env = envWith(store);
  const noCredentials = await __worker.fetch(new Request('https://sayrox.test/api/auth/google/start'), {
    ...store, AUTH_SESSION_SECRET: env.AUTH_SESSION_SECRET
  });
  assert.equal(noCredentials.status, 503);
  assert.equal((await noCredentials.json()).code, 'GOOGLE_AUTH_NOT_CONFIGURED');

  const invalid = await __worker.fetch(new Request('https://sayrox.test/api/auth/google/callback?code=stolen&state=wrong', {
    headers: { cookie: 'sayrox_google_oauth=bad.value' }
  }), env);
  assert.equal(invalid.status, 303);
  assert.match(invalid.headers.get('location'), /auth=google_error/);
  assert.match(invalid.headers.get('set-cookie'), /Max-Age=0/);
  assert.equal(store.accounts.size, 0);

  const start = await __worker.fetch(new Request('https://sayrox.test/api/auth/google/start'), env);
  const stateCookie = start.headers.get('set-cookie');
  const state = decodeCookiePayload(stateCookie);
  activeIdToken = makeIdToken({ nonce: 'not-the-issued-nonce', email: 'unverified.flow@gmail.com', sub: 'google-sub-invalid' });
  const badNonce = await __worker.fetch(new Request(`https://sayrox.test/api/auth/google/callback?code=nonce-mismatch&state=${encodeURIComponent(state.state)}`, {
    headers: { cookie: stateCookie.split(';', 1)[0] }
  }), env);
  assert.equal(badNonce.status, 303);
  assert.match(badNonce.headers.get('location'), /auth=google_error/);
  assert.equal(store.accounts.size, 0, 'a mismatched OIDC nonce must never create an account');

  const verifyStart = await __worker.fetch(new Request('https://sayrox.test/api/auth/google/start'), env);
  const verifyCookie = verifyStart.headers.get('set-cookie');
  const verifyState = decodeCookiePayload(verifyCookie);
  activeIdToken = makeIdToken({ nonce: verifyState.nonce, email: 'not.verified@gmail.com', sub: 'google-sub-unverified', emailVerified: false });
  const unverified = await __worker.fetch(new Request(`https://sayrox.test/api/auth/google/callback?code=unverified&state=${encodeURIComponent(verifyState.state)}`, {
    headers: { cookie: verifyCookie.split(';', 1)[0] }
  }), env);
  assert.match(unverified.headers.get('location'), /auth=google_error/);
  assert.equal(store.accounts.size, 0, 'an unverified Google email must never create an account');
});

test('Google account linking rejects cross-origin requests and unauthenticated users', async () => {
  const store = namespaces();
  const env = envWith(store);
  const crossOrigin = await __worker.fetch(new Request('https://sayrox.test/api/auth/google/link/start', {
    method: 'POST', headers: { origin: 'https://attacker.test' }
  }), env);
  assert.equal(crossOrigin.status, 403);
  const unauthenticated = await __worker.fetch(new Request('https://sayrox.test/api/auth/google/link/start', {
    method: 'POST', headers: { origin: 'https://sayrox.test' }
  }), env);
  assert.equal(unauthenticated.status, 401);
});
