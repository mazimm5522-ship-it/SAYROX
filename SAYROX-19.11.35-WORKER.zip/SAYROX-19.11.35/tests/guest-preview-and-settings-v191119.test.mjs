import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const read = path => readFile(new URL(path, import.meta.url), 'utf8');

test('guest composer stores a local preview without calling model or protected Worker APIs', async () => {
  const send = await read('../app/05-send-message.js');
  const branch = send.split("if(!state.user&&state.guest){")[1]?.split("pendingAuthSend={kind:'draft',text};")[0] || '';
  assert.ok(branch, 'guest preview branch exists before the protected account gate');
  assert.match(branch, /addMessage\('user',text/);
  assert.match(branch, /addMessage\('assistant'/);
  assert.match(branch, /localPreview:true/);
  assert.doesNotMatch(branch, /fetch\s*\(/, 'guest preview must not call network APIs');
  assert.match(send, /pendingAuthSend=\{kind:'draft',text\};\s*if\(!requireAccountForProtectedApis\(\)\)return ''/);
});

test('Google button remains visible and starts the existing select-account OAuth flow', async () => {
  const auth = await read('../app/11-auth.js');
  const oauth = await read('../worker/features/google-oauth.js');
  assert.match(auth, /location\.assign\('\/api\/auth\/google\/start'\)/);
  assert.match(auth, /\$\('#authGoogle'\)\.hidden=false/);
  assert.match(auth, /aria-disabled/);
  assert.match(oauth, /prompt:\s*'select_account'/);
});

test('settings archive actions operate on local chats and archived chats stay out of recent list', async () => {
  const controller = await read('../site/src/features/settings/controller.js');
  const history = await read('../site/src/features/settings/pages/storage-privacy.js');
  const recent = await read('../app/04-message-rendering.js');
  const boot = await read('../app/14-boot.js');
  for (const action of ['archive-all-chats', 'restore-chat', 'delete-archived-chat']) assert.match(controller, new RegExp(action));
  assert.match(history, /مشاهده گفتگوهای بایگانی‌شده/);
  assert.match(recent, /state\.chats\.filter\(chat=>chat&&!chat\.archived\)/);
  assert.match(boot, /visibleChats=state\.chats\.filter\(chat=>chat&&!chat\.archived\)/);
});

test('notification settings request the real browser permission and refresh their status', async () => {
  const page = await read('../site/src/features/settings/pages/general.js');
  const controller = await read('../site/src/features/settings/controller.js');
  const app = await read('../app/08-modules-settings.js');
  assert.match(page, /data-setting-action="notification-permission"/);
  assert.doesNotMatch(page, /toggle\('notificationsInApp'/, 'do not expose an inert notification toggle');
  assert.match(app, /Notification\.requestPermission\(\)/);
  assert.match(controller, /result\.finally\(\(\) => renderCurrentDetail\(\)\)/);
});
