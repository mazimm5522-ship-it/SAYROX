import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const app = await readFile(new URL('../app/05-send-message.js', import.meta.url), 'utf8');
const settings = await readFile(new URL('../app/08-modules-settings.js', import.meta.url), 'utf8');
const boot = await readFile(new URL('../app/14-boot.js', import.meta.url), 'utf8');

test('model picker renders searchable accessible cards and uses textContent for provider metadata', () => {
  assert.match(app, /id="modelSearch"/);
  assert.match(app, /id="modelOptions"[^>]*role="radiogroup"/);
  assert.match(app, /button\.setAttribute\('role','radio'\)/);
  assert.match(app, /button\.setAttribute\('aria-checked'/);
  assert.match(app, /title\.textContent=model\.label/);
  assert.match(app, /meta\.textContent=/);
  assert.match(app, /mark\.textContent=model\.brandIcon/);
  assert.match(app, /fetch\('\/api\/models'/);
  assert.match(app, /مدل‌های فعال در درگاه‌های متصل SAYROX/);
  assert.match(app, /avalai::/);
  assert.match(app, /hooshgar::/);
  assert.doesNotMatch(app, /model\.label[^;]*innerHTML|model\.brand[^;]*innerHTML/);
});

test('model branding is restored in composer and settings after page reload', () => {
  assert.match(app, /function formatModelDisplayName\(/);
  assert.match(settings, /formatModelDisplayName\(value\)/);
  assert.match(boot, /formatModelDisplayName\(state\.model\)/);
});
