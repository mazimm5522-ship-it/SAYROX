import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');

function loadPdfInput() {
  const window = {
    SayroxFilePolicy: {
      validateFile(file) {
        const extension = String(file?.name || '').split('.').pop().toLowerCase();
        if (extension !== 'pdf') throw new Error('پسوند پشتیبانی نمی‌شود.');
        if (!Number.isFinite(file.size) || file.size > 20 * 1024 * 1024) throw new Error('حجم فایل نامعتبر است.');
        return { extension };
      }
    }
  };
  const context = vm.createContext({ window, crypto: { randomUUID: () => 'pdf-test-id' }, Math, Date, String, Number, Object, TypeError, Error });
  return { window, context };
}

async function loadWorkerChat() {
  const modeExports = {};
  const modeSource = await read('worker/features/conversation-modes.js');
  vm.runInNewContext(modeSource, { exports: modeExports, Object });
  const chatExports = {};
  const imports = {
    'worker/shared/http.js': {
      text: (value, max = 20000) => typeof value === 'string' ? value.replace(/\u0000/g, '').slice(0, max) : '',
      safeUrl: value => { try { const url = new URL(value); return ['http:', 'https:'].includes(url.protocol) ? url.href : ''; } catch { return ''; } }
    },
    'worker/shared/constants.js': {},
    'worker/providers/registry.js': {},
    'worker/features/memory.js': {},
    'worker/features/quotas.js': {},
    'worker/features/conversation-modes.js': modeExports
  };
  const fileToolExports = {};
  vm.runInNewContext(await read('worker/agent/file-tools.js'), { exports: fileToolExports, Object, Set, TextEncoder, crypto: { randomUUID: () => 'file-test-id' } });
  imports['worker/agent/file-tools.js'] = fileToolExports;
  const chatSource = await read('worker/providers/chat.js');
  vm.runInNewContext(chatSource, { exports: chatExports, __load: id => imports[id], URL });
  return chatExports;
}


test('PDF chat input validates files and extracts bounded text locally', async () => {
  const { window, context } = loadPdfInput();
  vm.runInContext(await read('site/src/features/chat/pdf-input.js'), context);
  const api = window.SayroxChatPdfInput;
  assert.ok(api);
  assert.throws(() => api.validatePdfFile({ name: 'notes.txt', size: 10 }), /پسوند/);
  assert.throws(() => api.validatePdfFile({ name: 'large.pdf', size: 21 * 1024 * 1024 }), /حجم/);

  const pdf = await api.preparePdfFile({ name: 'گزارش.pdf', size: 1024 }, { extractor: async () => 'متن صفحه اول\n\nمتن صفحه دوم\u0000\u0001' });
  assert.equal(pdf.name, 'گزارش.pdf');
  assert.equal(pdf.mimeType, 'application/pdf');
  assert.match(pdf.text, /متن صفحه اول/);
  assert.ok(!pdf.text.includes('\u0000'));
  assert.equal(pdf.truncated, false);
  assert.equal(pdf.id, 'pdf-test-id');
  assert.equal(Object.hasOwn(pdf, 'file'), false, 'the original binary file must not be stored in the payload');
});

test('PDF chat input trims at a page boundary and explains scanned PDFs', async () => {
  const { window, context } = loadPdfInput();
  vm.runInContext(await read('site/src/features/chat/pdf-input.js'), context);
  const api = window.SayroxChatPdfInput;
  const longText = 'A'.repeat(45000) + '\n\n' + 'B'.repeat(20000);
  const pdf = await api.preparePdfFile({ name: 'long.pdf', size: 5000 }, { extractor: async () => longText });
  assert.equal(pdf.truncated, true);
  assert.ok(pdf.text.length <= api.POLICY.maxTextChars);
  assert.equal(pdf.text.endsWith('A'), true, 'truncation should prefer a page boundary');
  await assert.rejects(
    api.preparePdfFile({ name: 'scan.pdf', size: 500 }, { extractor: async () => { throw new Error('متنی از PDF استخراج نشد؛ فایل تصویرمحور است.'); } }),
    /OCR فارسی\/انگلیسی/
  );
});


test('scanned PDF chat attachments use the existing local OCR engine only when text extraction is empty', async () => {
  const { window, context } = loadPdfInput();
  vm.runInContext(await read('site/src/features/chat/pdf-input.js'), context);
  let ocrCalls = 0, progressSeen = false;
  const result = await window.SayroxChatPdfInput.preparePdfFile({ name: 'scan.pdf', size: 1000 }, {
    extractor: async () => '',
    ocr: async (_file, options) => { ocrCalls++; options.onProgress({ stage: 'recognizing', percent: 50 }); return 'متن تشخیص داده‌شده از اسکن'; },
    onProgress: event => { if (event.ocr && event.percent === 50) progressSeen = true; }
  });
  assert.equal(ocrCalls, 1);
  assert.equal(progressSeen, true);
  assert.equal(result.ocr, true);
  assert.match(result.text, /متن تشخیص داده‌شده/);
});

test('Office chat input reuses existing DOCX/PPTX readers and sends bounded extracted text only', async () => {
  const window = {
    SayroxFilePolicy: { FILE_POLICY: { maxFileBytes: 20 * 1024 * 1024, maxChatDocumentTextChars: 60000 }, validateFile(file) {
      const extension = String(file.name).split('.').pop().toLowerCase();
      if (!['docx', 'pptx'].includes(extension)) throw new Error('پسوند پشتیبانی نمی‌شود.');
      return { extension };
    } },
    SayroxDocuments: {
      readDocx: async () => '# گزارش\n\nمحتوای Word',
      readPptx: async () => '# اسلاید ۱\n\nپیش‌بینی فروش'
    }
  };
  const context = vm.createContext({ window, crypto: { randomUUID: () => 'office-test-id' }, globalThis: { crypto: { randomUUID: () => 'office-test-id' } }, Math, Date, String, Number, Object, TypeError, Error });
  vm.runInContext(await read('site/src/features/chat/office-input.js'), context);
  const api = window.SayroxChatOfficeInput;
  const docx = await api.prepareOfficeFile({ name: 'report.docx', size: 120 });
  const pptx = await api.prepareOfficeFile({ name: 'slides.pptx', size: 220 });
  assert.equal(docx.kind, 'office');
  assert.equal(docx.extension, 'docx');
  assert.match(docx.text, /محتوای Word/);
  assert.equal(pptx.extension, 'pptx');
  assert.match(pptx.text, /پیش‌بینی فروش/);
  assert.equal(Object.hasOwn(docx, 'file'), false);
  assert.throws(() => api.validateOfficeFile({ name: 'bad.pdf', size: 1 }), /پسوند پشتیبانی نمی‌شود/);
});

test('the existing PDF text engine can extract a basic real PDF content stream', async () => {
  const pdfSource = await read('site/src/features/files/pdf-text.js');
  const window = { SayroxFilePolicy: { FILE_POLICY: { maxFileBytes: 20 * 1024 * 1024, maxExpandedBytes: 50 * 1024 * 1024, maxTextChars: 500000 } } };
  const context = vm.createContext({ window, TextDecoder, Uint8Array, ArrayBuffer, Blob, DecompressionStream: globalThis.DecompressionStream, Map, Set, Math, Number, String, Array, Object, RegExp, Error, TypeError, parseInt, TextEncoder });
  vm.runInContext(pdfSource, context);
  const source = `%PDF-1.4\n`+
    `1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n`+
    `2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n`+
    `3 0 obj << /Type /Page /Parent 2 0 R /Resources 4 0 R /Contents 5 0 R >> endobj\n`+
    `4 0 obj << /Font << /F1 6 0 R >> >> endobj\n`+
    `5 0 obj << >> stream\nBT /F1 12 Tf (Hello SAYROX PDF) Tj ET\nendstream endobj\n`+
    `6 0 obj << /Type /Font /Subtype /Type1 /BaseFont /Helvetica >> endobj\n`+
    `trailer << /Root 1 0 R >>\n%%EOF`;
  const bytes = new TextEncoder().encode(source);
  const file = { size: bytes.byteLength, arrayBuffer: async () => bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) };
  const result = await context.window.SayroxPdfText.extractPdfText(file);
  assert.match(result, /Hello SAYROX PDF/);
});

test('document context includes only recent in-memory documents and reports unavailable history', async () => {
  const window = {};
  const context = vm.createContext({ window, TextEncoder, Map, Set, String, Array, Object, Number });
  vm.runInContext(await read('site/src/features/chat/message-payload.js'), context);
  const api = window.SayroxChatPayload;
  const messages = [
    { id: 'one', role: 'user', content: 'summarize', documents: [{ name: 'old.pdf' }] },
    { id: 'two', role: 'user', content: 'compare', documents: [{ name: 'new.pdf' }] },
    { id: 'three', role: 'user', content: 'also this', documents: [{ name: 'missing.pdf' }] }
  ];
  const map = new Map([
    ['one', [{ name: 'old.pdf', text: 'OLD DOCUMENT TEXT', truncated: false }]],
    ['two', [{ name: 'new.pdf', text: 'NEW DOCUMENT TEXT', truncated: false }]]
  ]);
  const result = api.buildDocumentContext(messages, map);
  assert.deepEqual(Array.from(result.documents, item => item.name), ['old.pdf', 'new.pdf']);
  assert.equal(result.unavailableCount, 1);
  assert.equal(result.omittedCount, 0);
  const limited = api.buildDocumentContext(messages, map, 1, 5);
  assert.equal(limited.documents.length, 1);
  assert.equal(limited.documents[0].text.length, 5);
  assert.equal(limited.omittedCount, 2);
});

test('Worker treats attached PDF and spreadsheet text as untrusted data and bounds the accepted context', async () => {
  const api = await loadWorkerChat();
  const context = api.buildServerContextMessages({
    documents: [
      { name: 'first.pdf', text: 'oldest document should be dropped', truncated: false },
      { name: 'second.pdf', text: 'B'.repeat(70000), truncated: false },
      { kind: 'spreadsheet', extension: 'xlsx', name: 'third.xlsx', text: 'third document should remain in the newest-two allowlist' }
    ],
    documentsUnavailable: 1,
    documentsOmitted: 2
  });
  const safety = context.systemMessages.find(item => /متن اسناد PDF، Word/.test(item.content));
  assert.ok(safety);
  assert.match(safety.content, /غیرقابل‌اعتماد/);
  assert.match(safety.content, /PowerPoint/);
  assert.match(safety.content, /نباید اجرا شود/);
  assert.ok(!context.userContextMessage.content.includes('first.pdf'), 'Worker keeps only the two newest documents');
  assert.match(context.userContextMessage.content, /second\.pdf/);
  assert.match(context.userContextMessage.content, /third\.xlsx/);
  assert.match(context.userContextMessage.content, /سند قبلی در حافظه/);
  assert.match(context.userContextMessage.content, /سقف زمینه/);
  const marker = 'فهرست فایل‌های پیوست‌شده برای بررسی در صورت نیاز: ';
  const markerIndex = context.userContextMessage.content.indexOf(marker);
  assert.notEqual(markerIndex, -1);
  const serializedDocuments = context.userContextMessage.content.slice(markerIndex + marker.length).split('\n\n')[0];
  const manifest = JSON.parse(serializedDocuments);
  const docs = manifest.documents;
  assert.equal(docs.length, 2);
  assert.equal(docs[0].name, 'second.pdf');
  assert.equal(docs[0].characters, 70000);
  assert.equal(docs[1].kind, 'spreadsheet');
  assert.equal(docs[1].extension, 'xlsx');
  assert.equal(docs[1].name, 'third.xlsx');
  assert.ok(!context.userContextMessage.content.includes('third document should remain'), 'document body text is not injected into the model context');
  assert.match(context.systemMessages.map(item => item.content).join('\n'), /فایل.*غیرقابل‌اعتماد/);
});

test('chat composer exposes PDF and spreadsheet documents through one volatile context path', async () => {
  const html = await read('site/index.html');
  const sw = await read('site/sw.js');
  const menu = await read('app/09-composer-menus.js');
  const send = await read('app/05-send-message.js');
  const state = await read('app/01-core-state.js');
  const render = await read('app/04-message-rendering.js');
  assert.match(html, /id="chatFileInput"[^>]*\.pdf/);
  assert.match(html, /id="chatFileInput"[^>]*\.xlsx/);
  assert.match(html, /id="chatFileInput"[^>]*\.docx/);
  assert.match(html, /id="chatFileInput"[^>]*\.pptx/);
  assert.match(html, /src="src\/features\/chat\/pdf-input\.js"/);
  assert.match(html, /src="src\/features\/chat\/office-input\.js"/);
  assert.match(sw, /\/src\/features\/chat\/pdf-input\.js/);
  assert.match(sw, /\/src\/features\/chat\/office-input\.js/);
  assert.match(html, /src="src\/features\/chat\/spreadsheet-input\.js"/);
  assert.match(sw, /\/src\/features\/chat\/spreadsheet-input\.js/);
  assert.match(menu, /SayroxChatPdfInput\.preparePdfFile/);
  assert.match(menu, /SayroxChatOfficeInput\.prepareOfficeFile/);
  assert.match(menu, /متن PDF، Office، Excel یا ZIP روی دستگاه استخراج شد/);
  assert.equal((menu.match(/SayroxChatPdfInput\.preparePdfFile\(file,/g)||[]).length, 1, 'there must be exactly one PDF attachment path');
  assert.match(send, /buildDocumentContext\(chat\.messages,documentTextPayloadsByMessage\)/);
  assert.match(send, /documents:documentContext\.documents/);
  assert.match(state, /const pendingOfficeAttachments=\[\]/);
  assert.match(state, /const documentTextPayloadsByMessage=new Map\(\)/);
  assert.match(state, /JSON\.stringify\(state\.chats/);
  assert.match(render, /message-attachment-document/);
  assert.match(render, /pendingOfficeAttachments/);
  assert.match(render, /composer-document-privacy/);
  assert.match(render, /message-document-privacy/);
  assert.equal((render.match(/documents\.forEach\(documentMeta=>/g)||[]).length, 1, 'each PDF attachment is rendered exactly once');
  assert.equal((await read('site/src/styles/chat-image-input.css')).match(/(?:^|\n)\.composer-document-attachment\{/g)?.length, 1, 'PDF card styles must have one canonical base definition; responsive overrides are allowed');
  assert.doesNotMatch(send, /text:document\.text/, 'extracted document text must not be copied into persistent message metadata');
});
