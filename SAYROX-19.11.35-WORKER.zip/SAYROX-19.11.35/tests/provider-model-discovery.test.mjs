import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

async function loadRegistry(fetchImpl) {
  const constants = { MAX_CHAT_BODY_BYTES: 1_048_576, JSON_HEADERS: { 'content-type': 'application/json' }, MAX_BODY: 1_048_576 };
  const httpExports = {};
  const httpContext = { exports: httpExports, __load: () => constants, Object, Array, String, Number, Boolean, URL, Response };
  vm.runInNewContext(await readFile(new URL('../worker/shared/http.js', import.meta.url), 'utf8'), httpContext, { filename: 'http.js' });
  const registryExports = {};
  const context = {
    exports: registryExports,
    __load: () => httpExports,
    fetch: fetchImpl,
    AbortController,
    setTimeout,
    clearTimeout,
    Date,
    URL,
    Object,
    Array,
    String,
    Number,
    Boolean,
    Map,
    Set,
    JSON,
    RegExp,
    Promise,
    Response
  };
  vm.runInNewContext(await readFile(new URL('../worker/providers/registry.js', import.meta.url), 'utf8'), context, { filename: 'registry.js' });
  return registryExports;
}

test('GapGPT live model discovery is authenticated, bounded, branded and filters non-chat models', async () => {
  let calls = 0;
  let requestUrl = '';
  let authorization = '';
  const registry = await loadRegistry(async (url, init) => {
    calls++;
    requestUrl = String(url);
    authorization = init.headers.authorization;
    return new Response(JSON.stringify({ data: [
      { id: 'gpt-5.5', name: 'GPT 5.5', owned_by: 'openai' },
      { id: 'claude-sonnet-4-6', name: 'Claude Sonnet 4.6', owned_by: 'anthropic' },
      { id: 'gemini-3-flash', name: 'Gemini 3 Flash', owned_by: 'google' },
      { id: 'deepseek-chat', owned_by: 'deepseek' },
      { id: 'gemini-3.1-pro', owned_by: 'google', modalities: ['text', 'image'] },
      { id: 'gpt-image-1', owned_by: 'openai' },
      { id: 'text-embedding-3-small', owned_by: 'openai' },
      { id: 'bad model id', owned_by: 'unknown' },
      { id: 'speech-tts', owned_by: 'openai' }
    ] }), { status: 200, headers: { 'content-type': 'application/json' } });
  });
  const env = { GAPGPT_API_KEY: 'secret-gap-key', GAPGPT_BASE_URL: 'https://gap-discovery.example/v1', GAPGPT_DEFAULT_MODEL: 'gpt-5.5' };
  const models = await registry.modelCatalogAsync(env);
  assert.equal(requestUrl, 'https://gap-discovery.example/v1/models');
  assert.equal(authorization, 'Bearer secret-gap-key');
  assert.deepEqual(Array.from(models, item => item.id), ['auto', 'gpt-5.5', 'claude-sonnet-4-6', 'gemini-3-flash', 'deepseek-chat', 'gemini-3.1-pro']);
  const claude = models.find(item => item.id === 'claude-sonnet-4-6');
  assert.equal(claude.brand, 'Anthropic');
  assert.equal(claude.brandIcon, '◈');
  assert.equal(claude.providerName, 'گپ‌جی‌پی‌تی');
  assert.equal(claude.providerIcon, '🇮🇷');
  assert.equal(models.find(item => item.id === 'gemini-3-flash').brand, 'Google');
  assert.equal(models.find(item => item.id === 'deepseek-chat').brand, 'DeepSeek');
  assert.equal(models.find(item => item.id === 'gemini-3.1-pro').supportsVision, true);
  assert.equal(calls, 1);
  assert.doesNotMatch(JSON.stringify(models), /secret-gap-key/);
  assert.doesNotMatch(JSON.stringify(models), /gap-discovery\.example/);
  await registry.resolveModelSelectionAsync(env, 'claude-sonnet-4-6');
  assert.equal(calls, 1, 'recent model discovery should be cached');
});

test('only a model returned by the configured GapGPT API can be selected dynamically', async () => {
  const registry = await loadRegistry(async () => new Response(JSON.stringify({ data: [{ id: 'qwen3-235b-a22b', owned_by: 'qwen' }] }), { status: 200 }));
  const env = { GAPGPT_API_KEY: 'secret', GAPGPT_BASE_URL: 'https://gap-allowlist.example/v1', GAPGPT_DEFAULT_MODEL: 'default-model' };
  const selected = await registry.resolveModelSelectionAsync(env, 'qwen3-235b-a22b');
  assert.equal(selected.ok, true);
  assert.equal(selected.provider, 'gapgpt');
  assert.equal(selected.model, 'qwen3-235b-a22b');
  const unknown = await registry.resolveModelSelectionAsync(env, 'client-invented-model');
  assert.equal(unknown.ok, false);
  assert.equal(unknown.reason, 'model-not-configured');
});

test('live model discovery fails closed and never calls a provider without its API key', async () => {
  let calls = 0;
  const registry = await loadRegistry(async () => { calls++; throw new Error('must not call'); });
  const models = await registry.modelCatalogAsync({ GAPGPT_DEFAULT_MODEL: 'orphaned-model' });
  assert.deepEqual(Array.from(models, item => item.id), ['auto']);
  assert.equal(calls, 0);
});

test('automatic vision selection may use a live model only when the provider explicitly declares image support', async () => {
  const registry = await loadRegistry(async () => new Response(JSON.stringify({ data: [
    { id: 'gemini-3.1-pro', owned_by: 'google', modalities: ['text', 'image'] },
    { id: 'gpt-5.5', owned_by: 'openai', modalities: ['text'] }
  ] }), { status: 200 }));
  const env = { GAPGPT_API_KEY: 'secret', GAPGPT_BASE_URL: 'https://gap-vision.example/v1', GAPGPT_DEFAULT_MODEL: 'gpt-5.5' };
  const selected = await registry.resolveModelSelectionAsync(env, 'auto', { requiresVision: true });
  assert.equal(selected.ok, true);
  assert.equal(selected.model, 'gemini-3.1-pro');
  assert.equal(selected.requiresVision, true);
});

test('AvalAI and Hooshgar discover live models independently and route duplicate model IDs to the selected gateway', async () => {
  const requests = [];
  const registry = await loadRegistry(async (url, init) => {
    requests.push({ url: String(url), authorization: init.headers.authorization });
    const isAvalai = String(url).startsWith('https://api.avalai.ir/v1/');
    const providerModels = isAvalai
      ? [
          { id: 'openai/gpt-4o', name: 'GPT-4o via AvalAI', owned_by: 'openai', modalities: ['text', 'image'] },
          { id: 'text-embedding-3-small', owned_by: 'openai' }
        ]
      : [
          { id: 'openai/gpt-4o', name: 'GPT-4o via Hooshgar', owned_by: 'openai', modalities: ['text'] },
          { id: 'deepseek-chat', owned_by: 'deepseek' }
        ];
    return new Response(JSON.stringify({ data: providerModels }), { status: 200, headers: { 'content-type': 'application/json' } });
  });
  const env = {
    AI_PROVIDER: 'hooshgar',
    AVALAI_API_KEY: 'secret-avalai', AVALAI_DEFAULT_MODEL: 'openai/gpt-4o',
    HOOSHGAR_API_KEY: 'secret-hooshgar', HOOSHGAR_DEFAULT_MODEL: 'openai/gpt-4o'
  };
  const models = await registry.modelCatalogAsync(env);
  assert.equal(requests.length, 2);
  assert.deepEqual(requests.map(item => item.url).sort(), [
    'https://api.avalai.ir/v1/models', 'https://api.hooshgar.ir/v1/models'
  ]);
  assert.equal(requests.find(item => item.url.includes('avalai')).authorization, 'Bearer secret-avalai');
  assert.equal(requests.find(item => item.url.includes('hooshgar')).authorization, 'Bearer secret-hooshgar');
  const avalai = models.find(item => item.id === 'avalai::openai/gpt-4o');
  const hooshgar = models.find(item => item.id === 'hooshgar::openai/gpt-4o');
  assert.ok(avalai && hooshgar, 'same upstream model ID must have two provider-specific selection IDs');
  assert.equal(avalai.modelId, 'openai/gpt-4o');
  assert.equal(avalai.providerName, 'اَوَل‌ای (AvalAI)');
  assert.equal(hooshgar.providerName, 'هوشگر (Hooshgar)');
  assert.equal(avalai.supportsVision, true);
  assert.equal(hooshgar.supportsVision, false);
  const selectedAval = await registry.resolveModelSelectionAsync(env, avalai.id);
  const selectedHooshgar = await registry.resolveModelSelectionAsync(env, hooshgar.id);
  assert.deepEqual({ ok: selectedAval.ok, provider: selectedAval.provider, model: selectedAval.model }, { ok: true, provider: 'avalai', model: 'openai/gpt-4o' });
  assert.deepEqual({ ok: selectedHooshgar.ok, provider: selectedHooshgar.provider, model: selectedHooshgar.model }, { ok: true, provider: 'hooshgar', model: 'openai/gpt-4o' });
  const automaticVision = await registry.resolveModelSelectionAsync(env, 'auto', { requiresVision: true });
  assert.equal(automaticVision.ok, true);
  assert.equal(automaticVision.provider, 'avalai', 'provider priority is respected only among declared vision-capable models');
  const diagnostics = registry.providerDiagnostics(env);
  assert.equal(diagnostics.primary, 'hooshgar');
  assert.equal(diagnostics.fallback, 'avalai');
  assert.equal(diagnostics.hooshgar.ready, true);
  assert.doesNotMatch(JSON.stringify(models), /secret-(?:avalai|hooshgar)|api\.avalai\.ir|api\.hooshgar\.ir/);
});

test('provider model discovery never calls AvalAI or Hooshgar without their server API keys', async () => {
  let calls = 0;
  const registry = await loadRegistry(async () => { calls++; throw new Error('must not call'); });
  const result = await registry.modelCatalogAsync({
    AVALAI_DEFAULT_MODEL: 'openai/gpt-4o',
    HOOSHGAR_DEFAULT_MODEL: 'openai/gpt-4o'
  });
  assert.deepEqual(Array.from(result, item => item.id), ['auto']);
  assert.equal(calls, 0);
  assert.equal(registry.providerOrder({ OPENROUTER_API_KEY: 'router-only' }).length, 0);
});


test('provider gateways reject unsafe custom base URLs instead of sending credentials to them', async () => {
  let calls = 0;
  const registry = await loadRegistry(async () => { calls++; throw new Error('unsafe base must never be contacted'); });
  for (const base of [
    'http://avalai.example/v1',
    'https://user:pass@avalai.example/v1',
    'https://avalai.example/v1?token=unsafe',
    'https://avalai.example/v1#fragment'
  ]) {
    const cfg = registry.providerConfig('avalai', { AVALAI_API_KEY: 'secret', AVALAI_BASE_URL: base });
    assert.equal(cfg.base, '', `base URL should be rejected: ${base}`);
    const result = await registry.discoverProviderModels('avalai', { AVALAI_API_KEY: 'secret', AVALAI_BASE_URL: base });
    assert.deepEqual(Array.from(result), []);
  }
  assert.equal(calls, 0);
});
