import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

async function loadExports(path, load, fetchImpl = globalThis.fetch) {
  const exports = {};
  const context = {
    exports, __load: load, URL, URLSearchParams, Request, Response, Headers,
    AbortController, AbortSignal, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer,
    Blob, ReadableStream, setTimeout, clearTimeout, Date, Math, JSON, Number,
    String, Boolean, Object, Array, Map, Set, RegExp, Error, TypeError, Promise,
    fetch: fetchImpl, console
  };
  const vm = await import('node:vm');
  vm.runInNewContext(await readFile(new URL(path, import.meta.url), 'utf8'), context, { filename: path });
  return exports;
}

const http = await loadExports('../worker/shared/http.js', () => ({}));
const registry = await loadExports('../worker/providers/registry.js', () => http);

for (const item of [
  { provider: 'avalai', key: 'aval-secret', base: 'https://api.avalai.ir/v1', envKey: 'AVALAI_API_KEY', envBase: 'AVALAI_BASE_URL' },
  { provider: 'hooshgar', key: 'hoosh-secret', base: 'https://api.hooshgar.ir/v1', envKey: 'HOOSHGAR_API_KEY', envBase: 'HOOSHGAR_BASE_URL' }
]) {
  test(`${item.provider} uses the existing OpenAI-compatible chat endpoint and keeps credentials server-side`, async () => {
    let captured;
    const modelListUrl = `${item.base}/models`;
    const fakeFetch = async (url, init) => {
      if (String(url) === modelListUrl) return new Response(JSON.stringify({ data: [{ id: 'openai/gpt-4o', owned_by: 'openai', modalities: ['text'] }] }), { status: 200, headers: { 'content-type': 'application/json' } });
      captured = { url: String(url), headers: init.headers, body: JSON.parse(init.body) };
      if (captured.body.stream === true) return new Response('data: {\"choices\":[{\"delta\":{\"content\":\"سلام\"}}]}\n\ndata: [DONE]\n\n', { status: 200, headers: { 'content-type': 'text/event-stream' } });
      return new Response(JSON.stringify({ choices: [{ message: { role: 'assistant', content: 'سلام' } }] }), {
        status: 200, headers: { 'content-type': 'application/json' }
      });
    };
    const registry = await loadExports('../worker/providers/registry.js', () => http, fakeFetch);
    // callChatProvider closes over the VM global fetch; install a one-shot replacement.
    const source = await readFile(new URL('../worker/providers/chat.js', import.meta.url), 'utf8');
    const vm = await import('node:vm');
    const chatExports = {};
    const context = {
      exports: chatExports,
      __load: id => id === 'worker/shared/http.js' ? http : id === 'worker/providers/registry.js' ? registry : {},
      fetch: fakeFetch, URL, URLSearchParams, Request, Response, Headers, AbortController,
      AbortSignal, TextEncoder, TextDecoder, Uint8Array, ArrayBuffer, Blob, ReadableStream,
      setTimeout, clearTimeout, Date, Math, JSON, Number, String, Boolean, Object, Array,
      Map, Set, RegExp, Error, TypeError, Promise, console
    };
    vm.runInNewContext(source, context, { filename: 'worker/providers/chat.js' });
    const env = { [item.envKey]: item.key, [item.envBase]: item.base, [`${item.provider.toUpperCase()}_DEFAULT_MODEL`]: 'openai/gpt-4o' };
    const uiSelectionId = `${item.provider}::openai/gpt-4o`;
    const selection = await registry.resolveModelSelectionAsync(env, uiSelectionId);
    assert.equal(selection.ok, true);
    assert.equal(selection.provider, item.provider);
    assert.equal(selection.model, 'openai/gpt-4o');
    const request = new Request('https://sayrox.example/api/chat', { method: 'POST' });
    const result = await chatExports.callChatProvider(selection.provider, env, {
      model: selection.model, messages: [{ role: 'user', content: 'سلام' }],
      tools: [{ type: 'function', function: { name: 'sample', parameters: { type: 'object', properties: {}, additionalProperties: false } } }],
      tool_choice: 'auto', stream: false
    }, request);
    assert.equal(result.ok, true);
    assert.equal(captured.url, `${item.base}/chat/completions`);
    assert.equal(captured.headers.authorization, `Bearer ${item.key}`);
    assert.equal(captured.body.model, 'openai/gpt-4o', 'wire model ID, not provider-scoped UI ID, is sent upstream');
    assert.equal(captured.body.tool_choice, 'auto');
    assert.equal(result.data.choices[0].message.content, 'سلام');
    const streamed = await chatExports.callChatProvider(selection.provider, env, {
      model: selection.model, messages: [{ role: 'user', content: 'سلام' }], stream: true
    }, request);
    assert.equal(streamed.ok, true, 'the same provider adapter must support SSE');
    assert.equal(streamed.provider, item.provider);
    assert.match(await streamed.response.text(), /سلام/);
    assert.doesNotMatch(JSON.stringify(result), /aval-secret|hoosh-secret/);
  });
}
