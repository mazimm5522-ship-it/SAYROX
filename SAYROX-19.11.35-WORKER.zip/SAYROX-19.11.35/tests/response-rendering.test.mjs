import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');

class FakeElement {
  constructor(tag, namespace = null) {
    this.tagName = tag; this.localName = tag; this.namespaceURI = namespace;
    this.children = []; this.attributes = {}; this.listeners = {}; this.parentNode = null;
    this.className = ''; this.hidden = false; this.href = ''; this.target = ''; this.rel = '';
    this._text = '';
    this.classList = { add: (...names) => { const all = new Set(String(this.className).split(/\s+/).filter(Boolean)); names.forEach(name => all.add(name)); this.className = [...all].join(' '); } };
  }
  appendChild(child) { this.children.push(child); child.parentNode = this; return child; }
  append(...children) { children.forEach(child => this.appendChild(child)); }
  replaceChildren(...children) { this.children = []; this._text = ''; this.append(...children); }
  setAttribute(name, value) { this.attributes[name] = String(value); }
  getAttribute(name) { return this.attributes[name] ?? null; }
  addEventListener(name, callback) { this.listeners[name] = callback; }
  set textContent(value) { this._text = String(value ?? ''); this.children = []; }
  get textContent() { return this._text + this.children.map(child => child.textContent ?? '').join(''); }
  click() { return this.listeners.click?.({ preventDefault() {} }); }
}
class FakeDocument {
  createElement(tag) { return new FakeElement(tag); }
  createElementNS(namespace, tag) { return new FakeElement(tag, namespace); }
  createTextNode(value) { const node = new FakeElement('#text'); node.textContent = String(value); return node; }
}

async function loadRenderer({ workspace = null } = {}) {
  const document = new FakeDocument();
  const sandbox = { document, URL, URLSearchParams, console, navigator: { clipboard: { writeText: async () => {} } }, location: { href: 'https://sayrox.test/' } };
  sandbox.window = sandbox;
  sandbox.SayroxCodeWorkspace = workspace;
  const context = vm.createContext(sandbox);
  vm.runInContext(await read('site/src/features/files/markdown.js'), context, { filename: 'markdown.js' });
  vm.runInContext(await read('site/src/core/response-renderer.js'), context, { filename: 'response-renderer.js' });
  return { api: sandbox.SayroxResponseRenderer, document, markdown: sandbox.SayroxMarkdown };
}
function walk(node, predicate, found = []) {
  if (predicate(node)) found.push(node);
  for (const child of node.children || []) walk(child, predicate, found);
  return found;
}

 test('renders headings, inline formatting, lists, quotes, separators and responsive tables as real nodes', async () => {
  const { api, document } = await loadRenderer();
  const host = document.createElement('div');
  const source = [
    '## عنوان اصلی',
    'متن **مهم** و *تأکیدی* و ~~حذف‌شده~~ و `inline()`.',
    '',
    '- گزینه اول',
    '- گزینه دوم',
    '',
    '> یک نقل‌قول',
    '',
    '| نام | وضعیت |',
    '| --- | --- |',
    '| SAYROX | آماده |',
    '',
    '---'
  ].join('\n');
  assert.equal(api.render(host, source), true);
  assert.equal(walk(host, node => node.tagName === 'h2').length, 1);
  assert.equal(walk(host, node => node.tagName === 'strong').length, 1);
  assert.equal(walk(host, node => node.tagName === 'em').length, 1);
  assert.equal(walk(host, node => node.tagName === 'del').length, 1);
  assert.equal(walk(host, node => node.tagName === 'code').length, 1);
  assert.equal(walk(host, node => node.tagName === 'ul').length, 1);
  assert.equal(walk(host, node => node.tagName === 'li').length, 2);
  assert.equal(walk(host, node => node.tagName === 'blockquote').length, 1);
  assert.equal(walk(host, node => node.tagName === 'table').length, 1);
  assert.equal(walk(host, node => node.tagName === 'th').length, 2);
  assert.equal(walk(host, node => node.tagName === 'td').length, 2);
  assert.equal(walk(host, node => node.tagName === 'hr').length, 1);
  assert.equal(host.getAttribute('data-render-mode'), 'complete');
});

test('untrusted message HTML remains literal text and unsafe URL schemes are not linked', async () => {
  const { api, document } = await loadRenderer();
  const host = document.createElement('div');
  api.render(host, '<img src=x onerror=alert(1)> [خطر](javascript:alert(1)) [منبع](https://example.com/report)');
  assert.equal(walk(host, node => node.tagName === 'img').length, 0);
  assert.equal(walk(host, node => node.tagName === 'a').length, 1);
  const link = walk(host, node => node.tagName === 'a')[0];
  assert.equal(link.href, 'https://example.com/report');
  assert.ok(host.textContent.includes('<img src=x onerror=alert(1)>'));
  assert.ok(host.textContent.includes('javascript:alert(1)'));
  assert.equal(api.safeUrl('data:text/html,boom'), null);
  assert.equal(api.safeUrl('https://user:pass@example.com'), null);
});

test('renders common LaTeX with MathML fractions, roots, superscripts, subscripts and Greek symbols', async () => {
  const { api, document } = await loadRenderer();
  const host = document.createElement('div');
  api.render(host, 'فرمول inline: \\(x_1^2 + \\frac{\\alpha}{\\sqrt{y}}\\)\n\n$$E = mc^2$$');
  const math = walk(host, node => node.localName === 'math');
  assert.equal(math.length, 2);
  assert.equal(walk(host, node => node.localName === 'mfrac').length, 1);
  assert.equal(walk(host, node => node.localName === 'msqrt').length, 1);
  assert.equal(walk(host, node => node.localName === 'msubsup').length, 1);
  assert.ok(host.textContent.includes('α'));
  assert.equal(math[0].getAttribute('display'), 'inline');
  assert.equal(math[1].getAttribute('display'), 'block');
});

test('reuses the existing code workspace for completed fenced blocks and preserves the save callback', async () => {
  let captured = null;
  const workspace = { createBlock(options) { captured = options; const node = new FakeElement('section'); node.className = 'cw-block'; return node; } };
  const { api, document } = await loadRenderer({ workspace });
  const host = document.createElement('div');
  let saved = null;
  api.render(host, 'نمونه:\n```js\nconst x = 1;\n```', { onCodeSave: (index, value) => { saved = { index, value }; return true; } });
  assert.equal(walk(host, node => node.className === 'cw-block').length, 1);
  assert.equal(captured.language, 'js');
  assert.equal(captured.source, 'const x = 1;');
  assert.equal(captured.onSave('const x = 2;'), true);
  assert.deepEqual(saved, { index: 0, value: 'const x = 2;' });
});

test('streaming mode renders unfinished code fences without creating editable workspace widgets', async () => {
  let workspaceCalls = 0;
  const { api, document } = await loadRenderer({ workspace: { createBlock() { workspaceCalls++; return new FakeElement('section'); } } });
  const host = document.createElement('div');
  api.render(host, 'در حال نوشتن\n```python\nprint("hello")', { streaming: true });
  assert.equal(workspaceCalls, 0);
  assert.equal(walk(host, node => node.tagName === 'details').length, 1);
  assert.equal(walk(host, node => node.tagName === 'code')[0].textContent, 'print("hello")');
  assert.equal(host.getAttribute('data-render-mode'), 'streaming');
});


test('renders semantic callouts, status badges and leading symbols with fixed visual tones', async () => {
  const { api, document } = await loadRenderer();
  const host = document.createElement('div');
  const source = [
    '✅ همه تست‌ها با موفقیت تمام شدند.',
    '',
    'وضعیت: [[status:success|تأییدشده]] و [[status:warning|نیازمند بررسی]] و [[status:danger|ناموفق]].',
    '',
    '> [!WARNING]',
    '> این عملیات هنوز در محیط واقعی تأیید نشده است.',
    '> نتیجه را قطعی اعلام نکن.',
    '',
    '> [!SUCCESS] نتیجهٔ بررسی',
    '> هر ۱۷۵ تست محلی پاس شدند.'
  ].join('\n');
  api.render(host, source);
  const symbols = walk(host, node => String(node.className).includes('sayrox-leading-symbol'));
  assert.equal(symbols.length, 1);
  assert.match(symbols[0].className, /is-success/);
  const badges = walk(host, node => String(node.className).includes('sayrox-status-badge'));
  assert.equal(badges.length, 3);
  assert.ok(badges.some(node => node.className.includes('is-success')));
  assert.ok(badges.some(node => node.className.includes('is-warning')));
  assert.ok(badges.some(node => node.className.includes('is-danger')));
  const callouts = walk(host, node => node.tagName === 'aside' && String(node.className).includes('sayrox-callout'));
  assert.equal(callouts.length, 2);
  assert.match(callouts[0].className, /is-warning/);
  assert.match(callouts[1].className, /is-success/);
  assert.equal(callouts[1].getAttribute('role'), 'note');
  assert.ok(host.textContent.includes('نتیجهٔ بررسی'));
});

test('status badges keep untrusted text literal and unknown badge syntax is not interpreted', async () => {
  const { api, document } = await loadRenderer();
  const host = document.createElement('div');
  api.render(host, '[[status:success|<img src=x onerror=alert(1)>]] [[status:unknown|plain]]');
  assert.equal(walk(host, node => node.tagName === 'img').length, 0);
  assert.equal(walk(host, node => String(node.className).includes('sayrox-status-badge')).length, 1);
  assert.ok(host.textContent.includes('<img src=x onerror=alert(1)>'));
  assert.ok(host.textContent.includes('[[status:unknown|plain]]'));
});

test('renders read-only checklist markers and aligned keyboard-scrollable tables', async () => {
  const { api, document } = await loadRenderer();
  const host = document.createElement('div');
  api.render(host, [
    '- [x] بررسی شد',
    '- [ ] نیازمند اقدام',
    '',
    '| مورد | مقدار | توضیح |',
    '| :--- | :---: | ---: |',
    '| اول | وسط | راست |'
  ].join('\n'));
  const taskItems = walk(host, node => String(node.className).includes('sayrox-task-item'));
  assert.equal(taskItems.length, 2);
  assert.match(taskItems[0].className, /is-checked/);
  assert.match(taskItems[1].className, /is-pending/);
  const markers = walk(host, node => String(node.className).includes('sayrox-task-marker'));
  assert.equal(markers[0].textContent, '☑');
  assert.equal(markers[1].textContent, '☐');
  const tableWrap = walk(host, node => String(node.className).includes('sayrox-table-wrap'))[0];
  assert.equal(tableWrap.getAttribute('role'), 'region');
  assert.equal(tableWrap.getAttribute('tabindex'), '0');
  const headers = walk(host, node => node.tagName === 'th');
  assert.match(headers[0].className, /is-align-left/);
  assert.match(headers[1].className, /is-align-center/);
  assert.match(headers[2].className, /is-align-right/);
  assert.equal(walk(host, node => String(node.className).includes('sayrox-table-scroll-hint')).length, 1);
});


test('highlights Persian, Arabic and Latin numbers semantically while preserving dates and version identifiers', async () => {
  const { api, document, markdown } = await loadRenderer();
  const host = document.createElement('div');
  api.render(host, 'افزایش +۱۲٪، افت −۵٫۵٪، مقدار 1,250 و رقم ٣٤؛ تاریخ ۲۰۲۶-۱۱-۰۸ و نسخهٔ 19.11.32 و tag v19.11.32 و شناسه X123 و کد `A123` و شناسه ID-777 و **رشد +۲٪**.');
  const numbers = walk(host, node => String(node.className).includes('sayrox-number'));
  assert.deepEqual(numbers.map(node => node.textContent), ['+۱۲٪', '−۵٫۵٪', '1,250', '٣٤', '+۲٪']);
  assert.match(numbers[0].className, /is-success/);
  assert.match(numbers[1].className, /is-danger/);
  assert.match(numbers[2].className, /is-info/);
  assert.match(numbers[3].className, /is-info/);
  assert.match(numbers[4].className, /is-success/);
  assert.equal(walk(host, node => node.tagName === 'code').length, 1);
  assert.ok(host.textContent.includes('۲۰۲۶-۱۱-۰۸'));
  assert.ok(host.textContent.includes('19.11.32'));
  assert.ok(host.textContent.includes('X123'));
  assert.ok(host.textContent.includes('v19.11.32'));
  assert.ok(host.textContent.includes('ID-777'));
  assert.equal(markdown.isNumericValue('۱٬۲۳۴٫۵۶'), true);
  assert.equal(markdown.isNumericValue('۲۰۲۶-۱۱-۰۸'), false);
  assert.equal(markdown.isNumericValue('19.11.32'), false);
  assert.equal(markdown.isNumericValue('۱۲۳ نسخه'), false);
});

test('explicit number tones render as safe colored values and plain-text export strips only their wrapper', async () => {
  const { api, document, markdown } = await loadRenderer();
  const host = document.createElement('div');
  api.render(host, 'نتیجه [[number:success|۹۸٪]] و هشدار [[number:warning|۷۰٪]] و متن [[number:danger|<img src=x onerror=alert(1)>]].');
  const numbers = walk(host, node => String(node.className).includes('sayrox-number'));
  assert.equal(numbers.length, 3);
  assert.match(numbers[0].className, /is-success/);
  assert.match(numbers[1].className, /is-warning/);
  assert.equal(numbers[2].textContent, '<img src=x onerror=alert(1)>');
  assert.equal(walk(host, node => node.tagName === 'img').length, 0);
  assert.equal(markdown.toPlainText('[[number:success|۹۸٪]]'), '۹۸٪');
  const html = markdown.renderHtml('[[number:danger|−۷٪]]');
  assert.match(html, /sayrox-number is-danger/);
  assert.match(html, /−۷٪/);
  assert.match(html, /sayrox-number\.is-danger/);
});

test('tables automatically right-align numeric columns without overriding explicit column alignment', async () => {
  const { api, document, markdown } = await loadRenderer();
  const host = document.createElement('div');
  api.render(host, [
    '| نام | فروش | تغییر | تاریخ |',
    '| --- | --- | :---: | --- |',
    '| الف | ۱٬۲۳۴ | +۲٪ | ۲۰۲۶-۱۱-۰۸ |',
    '| ب | ۲٬۳۴۵ | −۱٪ | ۲۰۲۶-۱۱-۰۹ |'
  ].join('\n'));
  const table = markdown.parseBlocks('| نام | فروش | تاریخ |\n| --- | --- | --- |\n| الف | ۱۲۳ | ۲۰۲۶-۱۱-۰۸ |\n| ب | ۴۵۶ | ۲۰۲۶-۱۱-۰۹ |').find(block => block.type === 'table');
  assert.deepEqual(Array.from(table.numericColumns), [false, true, false]);
  const headers = walk(host, node => node.tagName === 'th');
  assert.match(headers[1].className, /is-align-right/);
  assert.match(headers[2].className, /is-align-center/);
  assert.doesNotMatch(headers[3].className, /is-numeric/);
  const cells = walk(host, node => node.tagName === 'td');
  assert.match(cells[1].className, /is-numeric/);
  assert.equal(cells[1].getAttribute('dir'), 'ltr');
  assert.match(cells[2].className, /is-align-center/);
  const exported = markdown.renderHtml('| نام | فروش |\n| --- | --- |\n| الف | ۱۲۳ |');
  assert.match(exported, /class="is-align-right is-numeric"/);
});



test('valid chart fences are parsed once and render as accessible SVG with an optional data table', async () => {
  const { api, document, markdown } = await loadRenderer();
  const source = [
    '## فروش ماهانه',
    '',
    '```chart',
    JSON.stringify({ type: 'bar', title: 'فروش فصل', labels: ['مهر', 'آبان', 'آذر'], series: [{ name: 'فروش', values: [120, 180, 220] }, { name: 'هدف', values: [100, 160, 200] }] }),
    '```'
  ].join('\n');
  const blocks = markdown.parseBlocks(source);
  assert.deepEqual(Array.from(blocks, block => block.type), ['heading', 'chart']);
  assert.equal(blocks[1].chart.type, 'bar');
  const host = document.createElement('div');
  api.render(host, source);
  const figure = walk(host, node => node.tagName === 'figure' && String(node.className).includes('sayrox-chart-figure'))[0];
  assert.ok(figure);
  const svg = walk(figure, node => node.tagName === 'svg')[0];
  assert.equal(svg.getAttribute('role'), 'img');
  assert.match(svg.getAttribute('aria-label'), /3 دسته/);
  assert.ok(walk(svg, node => node.tagName === 'rect' && /sayrox-chart-series-0/.test(node.getAttribute('class') || '')).length > 0);
  assert.equal(walk(figure, node => node.tagName === 'details' && node.className === 'sayrox-chart-data').length, 1);
  assert.equal(walk(figure, node => node.tagName === 'td').length, 9);
  assert.match(markdown.toPlainText(source), /فروش فصل[\s\S]*مهر\s+120/);
});


test('unfinished chart fences remain code during streaming and are promoted only after the closing fence', async () => {
  const { api, document, markdown } = await loadRenderer();
  const raw = '```chart\n{"type":"bar","labels":["A","B"],"series":[{"name":"S","values":[1,2]}]}';
  assert.equal(markdown.parseBlocks(raw)[0].type, 'code');
  const host = document.createElement('div');
  api.render(host, raw, { streaming: true });
  assert.equal(walk(host, node => node.tagName === 'figure').length, 0);
  assert.ok(walk(host, node => node.tagName === 'code').length > 0);
  assert.equal(markdown.parseBlocks(`${raw}\n\`\`\``)[0].type, 'chart');
});

test('line and pie chart drawing models validate their geometry and category bounds', async () => {
  const { markdown } = await loadRenderer();
  const line = markdown.chartDrawingSpec({ type: 'line', title: 'روند', labels: ['A', 'B', 'C'], series: [{ name: 'Series', values: [3, 8, 5] }] });
  assert.ok(line);
  assert.ok(line.shapes.some(shape => shape.tag === 'polyline'));
  assert.equal(line.rows.length, 3);
  const pie = markdown.chartDrawingSpec({ type: 'pie', title: 'سهم‌ها', labels: ['الف', 'ب'], series: [{ name: 'سهم', values: [2, 3] }] });
  assert.ok(pie);
  assert.equal(pie.shapes.filter(shape => shape.tag === 'path').length, 2);
  const tenSlices = markdown.chartDrawingSpec({ type: 'pie', labels: Array.from({ length: 10 }, (_, i) => `بخش ${i + 1}`), series: [{ values: Array.from({ length: 10 }, (_, i) => i + 1) }] });
  assert.ok(tenSlices.shapes.some(shape => (shape.attrs.class || '').includes('sayrox-chart-series-9')));
  assert.equal(markdown.chartDrawingSpec({ type: 'pie', labels: ['الف', 'ب'], series: [{ values: [-1, 2] }] }), null);
  assert.equal(markdown.chartDrawingSpec({ type: 'bar', labels: ['الف'], series: [{ values: [1] }] }), null);
  assert.equal(markdown.chartDrawingSpec({ type: 'bar', labels: Array.from({ length: 11 }, (_, i) => `L${i}`), series: [{ values: Array(11).fill(1) }] }), null);
});

test('invalid chart payloads remain escaped code and chart exports reuse the safe drawing model', async () => {
  const { api, document, markdown } = await loadRenderer();
  const malicious = { type: 'bar', title: '<script>alert(1)</script>', labels: ['<img src=x onerror=alert(1)>', 'دوم'], series: [{ name: 'مقدار', values: [1, 2] }] };
  const source = `\`\`\`chart\n${JSON.stringify(malicious)}\n\`\`\``;
  const html = markdown.renderHtml(source);
  assert.match(html, /&lt;script&gt;/);
  assert.match(html, /&lt;img src=x onerror=alert\(1\)&gt;/);
  assert.doesNotMatch(html, /<script>alert/);
  assert.doesNotMatch(html, /<img src=x/);
  assert.match(html, /<svg class="sayrox-chart-svg"/);
  assert.match(html, /sayrox-chart-series-0/);
  const host = document.createElement('div');
  api.render(host, source);
  assert.equal(walk(host, node => node.tagName === 'img').length, 0);
  assert.ok(host.textContent.includes('<img src=x onerror=alert(1)>'));
  const invalid = markdown.parseBlocks('```chart\n{"type":"scatter","labels":["A","B"],"series":[{"values":[1,2]}]}\n```');
  assert.equal(invalid[0].type, 'code');
  const oversized = markdown.parseBlocks(`\`\`\`chart\n${JSON.stringify({ type: 'bar', title: 'x'.repeat(20000), labels: ['A', 'B'], series: [{ values: [1, 2] }] })}\n\`\`\``);
  assert.equal(oversized[0].type, 'code');
});

test('mixed Persian and Latin headings and chart labels retain automatic text direction', async () => {
  const { api, document } = await loadRenderer();
  const host = document.createElement('div');
  api.render(host, '## گزارش API و فروش\n\n```chart\n{"type":"bar","labels":["API","فروش"],"series":[{"name":"Q4","values":[4,8]}]}\n```');
  const heading = walk(host, node => node.tagName === 'h2')[0];
  const figure = walk(host, node => node.tagName === 'figure')[0];
  assert.equal(heading.getAttribute('dir'), 'auto');
  assert.equal(figure.getAttribute('dir'), 'auto');
  const categoryLabels = walk(figure, node => node.tagName === 'text' && (node.getAttribute('class') || '').includes('sayrox-chart-label'));
  assert.deepEqual(categoryLabels.map(node => node.textContent), ['API', 'فروش']);
});

test('writing guide chooses structure by need and only emits chart JSON for grounded numeric data', async () => {
  const source = await read('worker/providers/chat.js');
  assert.match(source, /از بلوک fenced با زبان chart استفاده کن/);
  assert.match(source, /داده، واحد، روند یا برآورد ساختگی نساز/);
  assert.match(source, /"type":"bar\|line\|pie"/);
  assert.match(source, /نمودار جای جدول و منبع اعداد را نمی‌گیرد/);
});

test('response styling uses design tokens for dark/light themes and includes mobile and accessibility states', async () => {
  const css = await read('site/src/styles/response-rendering.css');
  assert.match(css, /--success/);
  assert.match(css, /--warning/);
  assert.match(css, /--danger/);
  assert.match(css, /--accent-2/);
  assert.match(css, /sayrox-number\.is-success/);
  assert.match(css, /sayrox-number\.is-danger/);
  assert.match(css, /font-variant-numeric:tabular-nums/);
  assert.match(css, /is-numeric/);
  assert.match(css, /is-align-center/);
  assert.doesNotMatch(css, /td\.is-numeric\{[^}]*text-align/);
  assert.match(css, /@media\(max-width:600px\)/);
  assert.match(css, /@media\(forced-colors:active\)/);
  assert.match(css, /:focus-visible/);
  assert.match(css, /prefers-reduced-motion/);
});

test('server writing guide teaches restrained structured formatting and truthful status semantics', async () => {
  const source = await read('worker/providers/chat.js');
  assert.match(source, /\[!SUCCESS\]/);
  assert.match(source, /\[\[status:success\|متن\]\]/);
  assert.match(source, /\[\[number:success\|عدد\]\]/);
  assert.match(source, /\[ \]/);
  assert.match(source, /پیش از ارسال، یک بازبینی کوتاه انجام بده/);
  assert.match(source, /نشان سبز هرگز جای تأیید واقعی را نگیرد/);
});

console.log('Response rendering tests passed: Markdown structure, safe URLs, MathML, code workspace and streamed rendering');
