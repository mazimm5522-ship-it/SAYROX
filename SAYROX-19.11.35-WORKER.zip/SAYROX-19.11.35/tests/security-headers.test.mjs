import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const bundle = await readFile(new URL('../site/_worker.js', import.meta.url), 'utf8');
const executable = bundle.replace('export default __worker;', 'globalThis.__sayroxBundle = { __load };');
const context = vm.createContext({
  Request, Response, Headers, URL, URLSearchParams, TextEncoder, TextDecoder,
  Uint8Array, ArrayBuffer, Blob, AbortController, AbortSignal,
  setTimeout, clearTimeout, console, atob, btoa, Date, Math, JSON, Number,
  String, Boolean, Object, Array, Map, Set, RegExp, Error, TypeError, Promise,
  Intl, ReadableStream, TransformStream, queueMicrotask
});
vm.runInContext(executable, context, { filename: 'site/_worker.js' });
const http = context.__sayroxBundle.__load('worker/shared/http.js');

test('HTTPS responses keep the full baseline security-header contract', () => {
  const request = new Request('https://sayrox.test/api/health');
  const response = http.securityHeaders(new Response('ok'), request);
  assert.equal(response.headers.get('x-content-type-options'), 'nosniff');
  assert.equal(response.headers.get('x-frame-options'), 'DENY');
  assert.equal(response.headers.get('referrer-policy'), 'strict-origin-when-cross-origin');
  assert.equal(response.headers.get('permissions-policy'), 'camera=(), microphone=(self), geolocation=(), payment=()');
  assert.equal(response.headers.get('cross-origin-opener-policy'), 'same-origin');
  assert.equal(response.headers.get('strict-transport-security'), 'max-age=31536000; includeSubDomains');
});

test('HSTS is only emitted for HTTPS and app shell/service worker cache controls remain strict', () => {
  const httpResponse = http.securityHeaders(new Response('ok'), new Request('http://sayrox.test/api/health'));
  assert.equal(httpResponse.headers.has('strict-transport-security'), false);
  const shell = http.securityHeaders(new Response('shell'), new Request('https://sayrox.test/'));
  assert.equal(shell.headers.get('cache-control'), 'no-store');
  const serviceWorker = http.securityHeaders(new Response('sw'), new Request('https://sayrox.test/sw.js'));
  assert.equal(serviceWorker.headers.get('cache-control'), 'no-cache');
});

console.log('Security header tests passed: HTTPS HSTS, framing, MIME, referrer, permissions, opener isolation and shell cache controls');
