import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
const read = path => readFile(new URL(path, import.meta.url), 'utf8');

test('SAYROX sign-in uses its own S mark and only exposes working account methods', async () => {
  const html = await read('../site/index.html');
  const auth = await read('../app/11-auth.js');
  const css = await read('../site/src/styles/branding.css');
  assert.match(html, /class="auth-s-mark"/);
  assert.match(html, /id="authContinueEmail"/);
  assert.match(html, /id="authCreateAccount"/);
  assert.match(html, /id="authGuest"/);
  assert.match(auth, /showAuthForm\('login'\)/);
  assert.match(auth, /showAuthForm\('signup'\)/);
  assert.match(css, /\.auth-s-mark/);
  assert.doesNotMatch(html, /Continue with Google|ورود با Google/);
});

test('general settings are connected to persisted preferences and safe defaults', async () => {
  const page = await read('../site/src/features/settings/pages/general.js');
  const controller = await read('../site/src/features/settings/controller.js');
  const store = await read('../site/src/core/settings-store.js');
  const send = await read('../app/05-send-message.js');
  for (const key of ['hapticFeedback', 'quickAnswers', 'webSearchEnabled', 'librarySearchEnabled']) assert.match(page, new RegExp(key));
  for (const key of ['quickAnswers', 'responseStyle', 'hapticFeedback', 'displayNameOverride']) assert.match(store, new RegExp(key));
  assert.match(controller, /setSetting\('responseStyle'/);
  assert.match(controller, /setSetting\('displayNameOverride'/);
  assert.match(send, /responseStyle:/);
  assert.match(send, /quickAnswers:/);
});

test('storage page reports live browser usage and can clear only the local image gallery', async () => {
  const page = await read('../site/src/features/settings/pages/storage-privacy.js');
  const controller = await read('../site/src/features/settings/controller.js');
  const images = await read('../app/12-images-studio.js');
  assert.match(page, /storageStats/);
  assert.match(page, /storage-clear-images/);
  assert.match(page, /کمک به بهبود مدل برای همه/);
  assert.match(page, /خدمات موقعیت مکانی/);
  assert.match(page, /حذف حساب کاربری/);
  assert.match(controller, /navigator\?\.storage/);
  assert.match(controller, /SayroxImageGallery\.clear/);
  assert.match(images, /SayroxImageGallery=Object\.freeze/);
  assert.match(images, /async function imageGalleryStats/);
});

test('security settings never imply unsupported MFA, passkeys, biometric lock or all-device session controls are active', async () => {
  const page = await read('../site/src/features/settings/pages/safety-security.js');
  assert.match(page, /Passkey/);
  assert.match(page, /کد TOTP/);
  assert.match(page, /قفل مستقل برای هر گفتگو/);
  assert.match(page, /مدیریت نشست‌های چنددستگاهی/);
  assert.match(page, /قفل زیستی دستگاه/);
  assert.match(page, /غیرفعال|فعال نیست|در دست توسعه/);
});

test('composer is compact on mobile and optional haptics are gated', async () => {
  const css = await read('../site/src/styles/shell.css');
  const module = await read('../app/08-modules-settings.js');
  assert.match(css, /min-height: 108px/);
  assert.match(css, /min-height: 54px/);
  const mobile = await read('../site/src/styles/content.css');
  assert.match(mobile, /\.composer\{min-height:84px/);
  assert.match(mobile, /min-height:38px;height:38px/);
  assert.match(module, /hapticFeedback!==true/);
  assert.match(module, /navigator\.vibrate\(8\)/);
});

test('provider settings expose health for all configured Iranian chat gateways', async () => {
  const page = await read('../site/src/features/settings/pages/integrations.js');
  const controller = await read('../site/src/features/settings/controller.js');
  const api = await read('../worker/routes/api.js');
  for (const gateway of ['gapgpt', 'avalai', 'hooshgar']) {
    assert.match(page, new RegExp(`ctx\\.providers\\.${gateway}`));
    assert.match(controller, new RegExp(`${gateway}:data\\.providers`));
    assert.match(api, new RegExp(`${gateway}: chatDiagnostics\\.${gateway}`));
  }
});
