import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { readFile } from 'node:fs/promises';

// Development gate: syntax, referenced assets, single version, no stray files in site/.
const run = spawnSync(process.execPath, [new URL('../scripts/verify-site.mjs', import.meta.url).pathname, '--allow-missing-sdk'], { encoding: 'utf8' });
assert.equal(run.status, 0, `site verification failed:\n${run.stdout}${run.stderr}`);
assert.match(run.stdout, /verify OK/);

const verifier = await readFile(new URL('../scripts/verify-site.mjs', import.meta.url), 'utf8');
assert.doesNotMatch(verifier, /ref\.startsWith\('\/vendor\/'\)/, 'the verifier must not exempt the entire vendor directory from asset checks');
assert.match(verifier, /ref === '\/vendor\/elevenlabs-client\.mjs'[\s\S]*allowMissingSdk/, 'only the optional voice SDK may be absent in development verification');
console.log('Site integrity test passed:', run.stdout.trim());
