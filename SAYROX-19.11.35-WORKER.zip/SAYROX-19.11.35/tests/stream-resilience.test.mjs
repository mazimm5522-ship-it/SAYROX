import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const source = await readFile(new URL('../site/src/core/stream.js', import.meta.url), 'utf8');
function createReader() {
  const context = vm.createContext({ TextDecoder, Response, ReadableStream, Uint8Array, JSON, Error, String, Promise });
  vm.runInContext(source, context);
  return context.SayroxStream.readEventStream;
}
function streamFrom(chunks) {
  const encoder = new TextEncoder();
  return new Response(new ReadableStream({
    start(controller) {
      for (const chunk of chunks) controller.enqueue(typeof chunk === 'string' ? encoder.encode(chunk) : chunk);
      controller.close();
    }
  }));
}

test('SSE reader handles BOM, CRLF split across chunks, custom events and a terminal marker', async () => {
  const readEventStream = createReader();
  const events = [];
  const updates = [];
  const response = streamFrom([
    '\uFEFFevent: sayrox_agent\r',
    '\ndata: {"type":"thinking"}\r\n\r\n',
    'data: {"choices":[{"delta":{"content":"سلام"},"finish_reason":null}]}\r\n\r\n',
    'data: {"choices":[{"delta":{},"finish_reason":"stop"}]}\r\n\r\n'
  ]);
  const answer = await readEventStream(response, (delta, all) => updates.push({ delta, all }), async (name, payload) => events.push({ name, payload }));
  assert.equal(answer, 'سلام');
  assert.equal(updates[0].all, 'سلام');
  assert.deepEqual(events.map(event => event.name), ['sayrox_agent']);
});

test('SSE reader refuses a clean socket close before a completion marker', async () => {
  const readEventStream = createReader();
  let displayed = '';
  await assert.rejects(
    readEventStream(streamFrom(['data: {"choices":[{"delta":{"content":"نیمه پاسخ"}}]}\n\n']), delta => { displayed += delta; }),
    /پیش از علامت پایان پاسخ قطع شد/
  );
  assert.equal(displayed, 'نیمه پاسخ', 'partial text may be shown while streaming but must never be returned as a completed answer');
});

test('SSE reader rejects invalid UTF-8 and malformed event JSON', async () => {
  const readEventStream = createReader();
  await assert.rejects(readEventStream(streamFrom([new Uint8Array([0x64, 0x61, 0x74, 0x61, 0x3a, 0x20, 0xff, 0x0a, 0x0a])]), () => {}));
  await assert.rejects(readEventStream(streamFrom(['data: {not-json}\n\n']), () => {}), /نامعتبر/);
});

test('SSE reader caps an unterminated oversized event before buffering without bound', async () => {
  const readEventStream = createReader();
  const oversized = 'x'.repeat(10_000_001);
  await assert.rejects(readEventStream(streamFrom([oversized]), () => {}), /بیش از حد بزرگ یا ناقص/);
});

test('SSE reader enforces a bounded accumulated answer', async () => {
  const readEventStream = createReader();
  const text = 'x'.repeat(500_001);
  const frame = `data: ${JSON.stringify({ choices: [{ delta: { content: text }, finish_reason: 'stop' }] })}\n\n`;
  await assert.rejects(readEventStream(streamFrom([frame]), () => {}), /طول پاسخ جریانی از سقف امن/);
});
