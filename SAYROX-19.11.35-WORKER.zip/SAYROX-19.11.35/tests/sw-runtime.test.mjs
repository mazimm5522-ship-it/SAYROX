import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import vm from 'node:vm';

const source = await readFile(new URL('../site/sw.js', import.meta.url), 'utf8');

function createRuntime({ fetchImpl, cachedShell = '<html>cached shell</html>' }) {
  const listeners = new Map();
  const writes = [];
  const cache = {
    async put(key, response) {
      writes.push({ key, response: response.clone() });
    }
  };
  const caches = {
    async open() { return cache; },
    async match(key) {
      if (key !== '/') return undefined;
      return new Response(cachedShell, { headers: { 'content-type': 'text/html' } });
    }
  };
  const self = {
    location: { origin: 'https://sayrox.test' },
    clients: { claim: async () => undefined },
    addEventListener(type, handler) { listeners.set(type, handler); },
    skipWaiting: async () => undefined
  };
  vm.runInNewContext(source, { self, caches, fetch: fetchImpl, URL, Request, Response, Headers, Promise });

  async function navigate() {
    const event = {
      request: { method: 'GET', mode: 'navigate', url: 'https://sayrox.test/some-route' },
      responsePromise: null,
      lifetimePromise: null,
      respondWith(promise) { this.responsePromise = promise; },
      waitUntil(promise) { this.lifetimePromise = promise; }
    };
    listeners.get('fetch')(event);
    assert.ok(event.responsePromise, 'navigation handler must provide a response');
    assert.ok(event.lifetimePromise, 'navigation cache work must extend the fetch event lifetime');
    const [response] = await Promise.all([event.responsePromise, event.lifetimePromise]);
    return response;
  }

  return { navigate, writes };
}

test('service worker caches only successful HTML navigations and awaits the cache write', async () => {
  const runtime = createRuntime({
    fetchImpl: async () => new Response('<html>fresh</html>', { status: 200, headers: { 'content-type': 'text/html; charset=utf-8' } })
  });
  const response = await runtime.navigate();
  assert.equal(response.status, 200);
  assert.equal(await response.text(), '<html>fresh</html>');
  assert.equal(runtime.writes.length, 1);
  assert.equal(runtime.writes[0].key, '/');
  assert.equal(await runtime.writes[0].response.text(), '<html>fresh</html>');
});

test('service worker never replaces the offline shell with an HTTP error page', async () => {
  const runtime = createRuntime({
    fetchImpl: async () => new Response('<html>upstream error</html>', { status: 503, headers: { 'content-type': 'text/html' } })
  });
  const response = await runtime.navigate();
  assert.equal(response.status, 503);
  assert.equal(runtime.writes.length, 0);
});

test('service worker does not cache non-HTML or partial navigation responses', async () => {
  const json = createRuntime({
    fetchImpl: async () => new Response('{"error":true}', { status: 200, headers: { 'content-type': 'application/json' } })
  });
  assert.equal((await json.navigate()).status, 200);
  assert.equal(json.writes.length, 0);

  const partial = createRuntime({
    fetchImpl: async () => new Response('<html>partial</html>', { status: 206, headers: { 'content-type': 'text/html' } })
  });
  assert.equal((await partial.navigate()).status, 206);
  assert.equal(partial.writes.length, 0);
});

test('service worker falls back to the last cached shell when navigation fetch fails', async () => {
  const runtime = createRuntime({ fetchImpl: async () => { throw new Error('network unavailable'); } });
  const response = await runtime.navigate();
  assert.equal(response.status, 200);
  assert.equal(await response.text(), '<html>cached shell</html>');
  assert.equal(runtime.writes.length, 0);
});
