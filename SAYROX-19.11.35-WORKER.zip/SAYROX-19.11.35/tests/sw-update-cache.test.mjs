import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const read = path => readFile(new URL(`../${path}`, import.meta.url), 'utf8');

test('service worker and app shell force fresh versioned UI assets on update', async () => {
  const [boot, sw, headers, workerHttp] = await Promise.all([
    read('app/14-boot.js'), read('site/sw.js'), read('site/_headers'), read('worker/shared/http.js')
  ]);
  assert.match(boot, /serviceWorker\.register\('\/sw\.js',\{updateViaCache:'none'\}\)/);
  assert.match(sw, /new Request\(path, \{ cache: 'reload' \}\)/);
  assert.match(sw, /new Request\('\/vendor\/elevenlabs-client\.mjs', \{ cache: 'reload' \}\)/);
  assert.match(sw, /keys\.filter\(key => \(key\.startsWith\('sayrox-shell-'\) \|\| key\.startsWith\('xynora-next-shell-'\)\) \&\& key !== CACHE\)/);
  assert.match(headers, /\/sw\.js\s+Cache-Control: no-cache/);
  assert.match(workerHttp, /url\.pathname === '\/sw\.js'[\s\S]*?headers\.set\('cache-control', 'no-cache'\)/);
});
