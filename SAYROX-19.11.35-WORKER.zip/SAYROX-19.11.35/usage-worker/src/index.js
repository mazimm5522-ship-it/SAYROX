import { DurableObject } from 'cloudflare:workers';

const LIMITS = Object.freeze({
  free: { chat: 30, search: 5, tts: 3, live_voice: 0, voice_input: 10, images: 2, image_generation: 1 },
  start: { chat: 150, search: 25, tts: 20, live_voice: 3, voice_input: 60, images: 15, image_generation: 8 },
  advanced: { chat: 450, search: 90, tts: 75, live_voice: 12, voice_input: 180, images: 60, image_generation: 30 },
  pro: { chat: 1500, search: 350, tts: 250, live_voice: 40, voice_input: 600, images: 200, image_generation: 100 },
  ultra: { chat: 3000, search: 750, tts: 500, live_voice: 90, voice_input: 1200, images: 450, image_generation: 250 },
});
const FEATURES = new Set(['chat', 'search', 'tts', 'live_voice', 'voice_input', 'images', 'image_generation']);
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const CHECKPOINT_TTL_MS = 30 * 60_000;
const CHECKPOINT_LEASE_MS = 3 * 60_000;
const MAX_CHECKPOINT_CIPHER_BYTES = 700_000;
const BROWSER_SESSION_TTL_MS = 15 * 60_000;
const BROWSER_SESSION_LEASE_MS = 55_000;
const MAX_BROWSER_SESSIONS_PER_ACCOUNT = 10;
const MAX_BROWSER_SESSION_CIPHER_BYTES = 32_000;

function monthAt(timestamp, offset) {
  const start = new Date(timestamp), day = start.getUTCDate();
  const result = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + offset, 1,
    start.getUTCHours(), start.getUTCMinutes(), start.getUTCSeconds(), start.getUTCMilliseconds()));
  const lastDay = new Date(Date.UTC(result.getUTCFullYear(), result.getUTCMonth() + 1, 0)).getUTCDate();
  result.setUTCDate(Math.min(day, lastDay));
  return result.getTime();
}
function safeSubscription(subscription, now) {
  if (!subscription || typeof subscription !== 'object' || subscription.status !== 'active') return null;
  const tier = String(subscription.tier || '');
  const startsAt = Number(subscription.startsAt), expiresAt = Number(subscription.expiresAt);
  const months = Number(subscription.months), subscriptionId = String(subscription.subscriptionId || '');
  if (!Object.hasOwn(LIMITS, tier) || tier === 'free' || !UUID.test(subscriptionId) ||
      !Number.isSafeInteger(startsAt) || !Number.isSafeInteger(expiresAt) ||
      !Number.isInteger(months) || months < 1 || months > 24 || startsAt > now || expiresAt <= now) return null;
  return { subscriptionId, tier, startsAt, expiresAt, months, planId: String(subscription.planId || '') };
}
function contextFor(subscriptionInput, now) {
  const subscription = safeSubscription(subscriptionInput, now);
  if (subscription) {
    let monthIndex = 0;
    while (monthIndex < subscription.months && monthAt(subscription.startsAt, monthIndex + 1) <= now) monthIndex++;
    return { scopeKey: subscription.subscriptionId, tier: subscription.tier, planId: subscription.planId,
      limits: LIMITS[subscription.tier], periodStart: monthAt(subscription.startsAt, monthIndex),
      resetAt: Math.min(subscription.expiresAt, monthAt(subscription.startsAt, monthIndex + 1)), isPlus: true };
  }
  const date = new Date(now), year = date.getUTCFullYear(), month = date.getUTCMonth();
  const key = `${year}-${String(month + 1).padStart(2, '0')}`;
  return { scopeKey: `free:${key}`, tier: 'free', planId: null, limits: LIMITS.free,
    periodStart: Date.UTC(year, month, 1), resetAt: Date.UTC(year, month + 1, 1), isPlus: false };
}

export class UsageAccountObject extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);
    ctx.blockConcurrencyWhile(async () => {
      this.ctx.storage.sql.exec(`
        CREATE TABLE IF NOT EXISTS usage_counters (
          scope_key TEXT NOT NULL, feature TEXT NOT NULL, period_start INTEGER NOT NULL,
          used INTEGER NOT NULL DEFAULT 0, reserved INTEGER NOT NULL DEFAULT 0, limit_value INTEGER NOT NULL,
          PRIMARY KEY (scope_key, feature, period_start)
        );
        CREATE TABLE IF NOT EXISTS usage_reservations (
          request_id TEXT NOT NULL, feature TEXT NOT NULL, scope_key TEXT NOT NULL, period_start INTEGER NOT NULL,
          amount INTEGER NOT NULL, status TEXT NOT NULL CHECK(status IN ('reserved','committed','released')),
          created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL,
          PRIMARY KEY (request_id, feature)
        );
        CREATE INDEX IF NOT EXISTS idx_usage_reservations_expiry ON usage_reservations(status, expires_at);
        CREATE TABLE IF NOT EXISTS agent_run_history (
          run_id TEXT PRIMARY KEY, specialist TEXT NOT NULL, state TEXT NOT NULL,
          created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL, duration_ms INTEGER NOT NULL DEFAULT 0,
          step_count INTEGER NOT NULL DEFAULT 0, tool_events_json TEXT NOT NULL DEFAULT '[]',
          research_status TEXT NOT NULL DEFAULT 'not_used', research_mode TEXT NOT NULL DEFAULT 'none',
          source_count INTEGER NOT NULL DEFAULT 0, provider TEXT NOT NULL DEFAULT '', model TEXT NOT NULL DEFAULT '',
          failure_code TEXT NOT NULL DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_agent_run_history_updated ON agent_run_history(updated_at DESC);
        CREATE TABLE IF NOT EXISTS agent_approval_tickets (
          ticket_id TEXT PRIMARY KEY, account_key TEXT NOT NULL, expires_at INTEGER NOT NULL,
          consumed_at INTEGER NOT NULL, decision TEXT NOT NULL CHECK(decision IN ('approved','denied'))
        );
        CREATE INDEX IF NOT EXISTS idx_agent_approval_tickets_expiry ON agent_approval_tickets(expires_at);
        CREATE TABLE IF NOT EXISTS agent_run_checkpoints (
          run_id TEXT PRIMARY KEY, state TEXT NOT NULL CHECK(state IN ('leased','in_flight','ready')),
          payload TEXT NOT NULL, expires_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
          lease_token TEXT, lease_until INTEGER
        );
        CREATE INDEX IF NOT EXISTS idx_agent_run_checkpoints_expiry ON agent_run_checkpoints(expires_at);
        CREATE TABLE IF NOT EXISTS agent_browser_sessions (
          conversation_id TEXT PRIMARY KEY, state TEXT NOT NULL CHECK(state IN ('opening','active')),
          payload TEXT NOT NULL DEFAULT '', expires_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
          lease_token TEXT, lease_until INTEGER
        );
        CREATE INDEX IF NOT EXISTS idx_agent_browser_sessions_expiry ON agent_browser_sessions(expires_at);
      `);
    });
  }

  async reserveUsageBatch(requestId, items, subscription) {
    if (!UUID.test(String(requestId || '')) || !Array.isArray(items) || !items.length || items.length > 4)
      return { ok: false, code: 'INVALID_USAGE_RESERVATION' };
    const normalized = [], seen = new Set();
    for (const item of items) {
      const feature = String(item?.feature || ''), amount = Number(item?.amount ?? 1);
      if (!FEATURES.has(feature) || !Number.isSafeInteger(amount) || amount < 1 || amount > 10 || seen.has(feature))
        return { ok: false, code: 'INVALID_USAGE_ITEM' };
      seen.add(feature); normalized.push({ feature, amount });
    }
    const now = Date.now(), context = contextFor(subscription, now);
    return this.ctx.storage.transactionSync(() => {
      const expired = this.ctx.storage.sql.exec(
        "SELECT request_id,feature,scope_key,period_start,amount FROM usage_reservations WHERE status='reserved' AND expires_at<=?", now
      ).toArray();
      for (const row of expired) this.ctx.storage.sql.exec(
        'UPDATE usage_counters SET reserved=MAX(0,reserved-?) WHERE scope_key=? AND feature=? AND period_start=?',
        row.amount, row.scope_key, row.feature, row.period_start);
      this.ctx.storage.sql.exec("UPDATE usage_reservations SET status='released' WHERE status='reserved' AND expires_at<=?", now);

      const existing = this.ctx.storage.sql.exec(
        'SELECT feature,amount,status FROM usage_reservations WHERE request_id=?', requestId
      ).toArray();
      if (existing.length) {
        const same = existing.length === normalized.length && normalized.every(item => {
          const row = existing.find(entry => entry.feature === item.feature);
          return row && row.amount === item.amount;
        });
        if (!same) return { ok: false, code: 'USAGE_IDEMPOTENCY_CONFLICT' };
        if (existing.some(row => row.status === 'released')) return { ok: false, code: 'USAGE_RESERVATION_RELEASED' };
        return { ok: true, duplicate: true, status: existing[0].status };
      }

      const checks = [];
      for (const item of normalized) {
        const limit = Math.max(0, Math.trunc(Number(context.limits[item.feature]) || 0));
        this.ctx.storage.sql.exec(
          'INSERT OR IGNORE INTO usage_counters(scope_key,feature,period_start,used,reserved,limit_value) VALUES(?,?,?,0,0,?)',
          context.scopeKey, item.feature, context.periodStart, limit);
        const counter = this.ctx.storage.sql.exec(
          'SELECT used,reserved FROM usage_counters WHERE scope_key=? AND feature=? AND period_start=?',
          context.scopeKey, item.feature, context.periodStart).toArray()[0];
        if (!counter || limit <= 0 || counter.used + counter.reserved + item.amount > limit)
          return { ok: false, code: 'QUOTA_EXCEEDED', feature: item.feature, used: Number(counter?.used || 0),
            reserved: Number(counter?.reserved || 0), limit,
            remaining: Math.max(0, limit - Number(counter?.used || 0) - Number(counter?.reserved || 0)),
            resetAt: context.resetAt, tier: context.tier, isPlus: context.isPlus };
        checks.push({ ...item, limit });
      }
      for (const item of checks) {
        this.ctx.storage.sql.exec(
          "INSERT INTO usage_reservations(request_id,feature,scope_key,period_start,amount,status,created_at,expires_at) VALUES(?,?,?,?,?,'reserved',?,?)",
          requestId, item.feature, context.scopeKey, context.periodStart, item.amount, now, now + 86400000);
        this.ctx.storage.sql.exec(
          'UPDATE usage_counters SET reserved=reserved+?,limit_value=? WHERE scope_key=? AND feature=? AND period_start=?',
          item.amount, item.limit, context.scopeKey, item.feature, context.periodStart);
      }
      return { ok: true, duplicate: false, tier: context.tier, resetAt: context.resetAt };
    });
  }

  async commitUsage(requestId) {
    if (!UUID.test(String(requestId || ''))) return { ok: false, code: 'INVALID_USAGE_RESERVATION' };
    return this.ctx.storage.transactionSync(() => {
      const rows = this.ctx.storage.sql.exec('SELECT * FROM usage_reservations WHERE request_id=?', requestId).toArray();
      if (!rows.length) return { ok: false, code: 'RESERVATION_NOT_FOUND' };
      if (rows.every(row => row.status === 'committed')) return { ok: true, duplicate: true };
      if (rows.some(row => row.status !== 'reserved' || row.expires_at <= Date.now())) return { ok: false, code: 'RESERVATION_EXPIRED' };
      for (const row of rows) {
        this.ctx.storage.sql.exec(
          'UPDATE usage_counters SET used=used+?,reserved=MAX(0,reserved-?) WHERE scope_key=? AND feature=? AND period_start=?',
          row.amount, row.amount, row.scope_key, row.feature, row.period_start);
        this.ctx.storage.sql.exec("UPDATE usage_reservations SET status='committed' WHERE request_id=? AND feature=? AND status='reserved'", requestId, row.feature);
      }
      return { ok: true, duplicate: false };
    });
  }

  async releaseUsage(requestId) {
    if (!UUID.test(String(requestId || ''))) return { ok: false, code: 'INVALID_USAGE_RESERVATION' };
    return this.ctx.storage.transactionSync(() => {
      const rows = this.ctx.storage.sql.exec("SELECT * FROM usage_reservations WHERE request_id=? AND status='reserved'", requestId).toArray();
      for (const row of rows) {
        this.ctx.storage.sql.exec('UPDATE usage_counters SET reserved=MAX(0,reserved-?) WHERE scope_key=? AND feature=? AND period_start=?',
          row.amount, row.scope_key, row.feature, row.period_start);
        this.ctx.storage.sql.exec("UPDATE usage_reservations SET status='released' WHERE request_id=? AND feature=? AND status='reserved'", requestId, row.feature);
      }
      return { ok: true, released: rows.length };
    });
  }

  async getUsageSnapshot(subscription) {
    const now = Date.now(), context = contextFor(subscription, now), features = {};
    for (const [feature, limitValue] of Object.entries(context.limits)) {
      const row = this.ctx.storage.sql.exec('SELECT used,reserved FROM usage_counters WHERE scope_key=? AND feature=? AND period_start=?',
        context.scopeKey, feature, context.periodStart).toArray()[0];
      const used = Number(row?.used || 0), reserved = Number(row?.reserved || 0), limit = Math.max(0, Math.trunc(Number(limitValue) || 0));
      features[feature] = { used, reserved, limit, remaining: Math.max(0, limit - used - reserved), resetAt: context.resetAt };
    }
    return { tier: context.tier, planId: context.planId, isPlus: context.isPlus,
      cycleStart: context.periodStart, resetAt: context.resetAt, features };
  }

  async recordAgentRun(record) {
    const runId = String(record?.runId || '');
    const state = String(record?.state || '');
    const specialist = String(record?.specialist || 'main');
    if (!UUID.test(runId) || !['running', 'streaming', 'awaiting_approval', 'completed', 'failed', 'cancelled'].includes(state) ||
        !['main', 'research', 'coding', 'documents', 'data', 'creative', 'verification'].includes(specialist))
      return { ok: false, code: 'INVALID_AGENT_RUN' };
    const now = Date.now();
    const createdAt = Number(record.createdAt), updatedAt = Number(record.updatedAt);
    const durationMs = Number(record.durationMs), stepCount = Number(record.stepCount), sourceCount = Number(record.sourceCount);
    const events = Array.isArray(record.toolEvents) ? record.toolEvents.slice(0, 20).map(event => ({
      tool: /^[a-z][a-z0-9_]{1,63}$/.test(String(event?.tool || '')) ? String(event.tool) : 'unknown_tool',
      specialist: ['main', 'research', 'coding', 'documents', 'data', 'creative'].includes(String(event?.specialist || '')) ? String(event.specialist) : 'main',
      status: event?.status === 'success' ? 'success' : event?.status === 'pending' ? 'pending' : event?.status === 'cancelled' ? 'cancelled' : 'failed',
      code: /^[A-Z0-9_]{1,64}$/.test(String(event?.code || '')) ? String(event.code) : ''
    })) : [];
    const researchStatus = ['not_used', 'completed', 'unavailable'].includes(String(record.researchStatus)) ? String(record.researchStatus) : 'not_used';
    const researchMode = ['none', 'quick', 'deep'].includes(String(record.researchMode)) ? String(record.researchMode) : 'none';
    const provider = ['gapgpt', 'openrouter'].includes(String(record.provider)) ? String(record.provider) : '';
    const model = String(record.model || '').slice(0, 120).replace(/[\u0000-\u001F\u007F]/g, '');
    const failureCode = /^[A-Z0-9_]{1,64}$/.test(String(record.failureCode || '')) ? String(record.failureCode) : '';
    const safeCreated = Number.isSafeInteger(createdAt) && createdAt > 0 ? createdAt : now;
    const safeUpdated = Number.isSafeInteger(updatedAt) && updatedAt >= safeCreated ? updatedAt : now;
    const safeDuration = Number.isSafeInteger(durationMs) ? Math.max(0, Math.min(600_000, durationMs)) : 0;
    const safeSteps = Number.isSafeInteger(stepCount) ? Math.max(0, Math.min(20, stepCount)) : 0;
    const safeSources = Number.isSafeInteger(sourceCount) ? Math.max(0, Math.min(20, sourceCount)) : 0;
    return this.ctx.storage.transactionSync(() => {
      this.ctx.storage.sql.exec(`
        INSERT INTO agent_run_history(run_id,specialist,state,created_at,updated_at,duration_ms,step_count,tool_events_json,research_status,research_mode,source_count,provider,model,failure_code)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        ON CONFLICT(run_id) DO UPDATE SET specialist=excluded.specialist,state=excluded.state,updated_at=excluded.updated_at,
          duration_ms=excluded.duration_ms,step_count=excluded.step_count,tool_events_json=excluded.tool_events_json,
          research_status=excluded.research_status,research_mode=excluded.research_mode,source_count=excluded.source_count,
          provider=excluded.provider,model=excluded.model,failure_code=excluded.failure_code
      `, runId, specialist, state, safeCreated, safeUpdated, safeDuration, safeSteps, JSON.stringify(events), researchStatus, researchMode, safeSources, provider, model, failureCode);
      this.ctx.storage.sql.exec('DELETE FROM agent_run_history WHERE updated_at<?', now - 90 * 86400_000);
      this.ctx.storage.sql.exec('DELETE FROM agent_run_history WHERE run_id IN (SELECT run_id FROM agent_run_history ORDER BY updated_at DESC LIMIT -1 OFFSET 100)');
      return { ok: true };
    });
  }

  async consumeAgentApproval(ticketId, accountKey, expiresAt, decision, now = Date.now()) {
    if (!UUID.test(String(ticketId || '')) || !/^[A-Za-z0-9_-]{43}$/.test(String(accountKey || '')) ||
        !Number.isSafeInteger(Number(expiresAt)) || Number(expiresAt) <= now || Number(expiresAt) > now + 5 * 60 * 1000 ||
        !['approved', 'denied'].includes(String(decision || '')) || !Number.isSafeInteger(now))
      return { ok: false, code: 'INVALID_AGENT_APPROVAL' };
    return this.ctx.storage.transactionSync(() => {
      this.ctx.storage.sql.exec('DELETE FROM agent_approval_tickets WHERE expires_at<=?', now - 86400_000);
      const existing = this.ctx.storage.sql.exec('SELECT ticket_id FROM agent_approval_tickets WHERE ticket_id=?', String(ticketId)).toArray()[0];
      if (existing) return { ok: false, code: 'AGENT_APPROVAL_REPLAYED' };
      this.ctx.storage.sql.exec(
        'INSERT INTO agent_approval_tickets(ticket_id,account_key,expires_at,consumed_at,decision) VALUES(?,?,?,?,?)',
        String(ticketId), String(accountKey), Number(expiresAt), now, String(decision));
      return { ok: true, decision: String(decision) };
    });
  }

  async saveAgentCheckpoint(runId, payload, expiresAt, leaseToken, state = 'leased', now = Date.now()) {
    if (!UUID.test(String(runId || '')) || typeof payload !== 'string' || !payload.length || payload.length > MAX_CHECKPOINT_CIPHER_BYTES ||
        !UUID.test(String(leaseToken || '')) || !['leased', 'in_flight', 'ready'].includes(String(state)) ||
        !Number.isSafeInteger(Number(expiresAt)) || Number(expiresAt) <= now || Number(expiresAt) > now + CHECKPOINT_TTL_MS + 60_000 ||
        !Number.isSafeInteger(now)) return { ok: false, code: 'INVALID_AGENT_CHECKPOINT' };
    return this.ctx.storage.transactionSync(() => {
      this.ctx.storage.sql.exec('DELETE FROM agent_run_checkpoints WHERE expires_at<=?', now);
      const row = this.ctx.storage.sql.exec('SELECT * FROM agent_run_checkpoints WHERE run_id=?', String(runId)).toArray()[0];
      if (row) {
        if (row.lease_token !== leaseToken || Number(row.expires_at) <= now) return { ok: false, code: 'CHECKPOINT_LEASE_LOST' };
        this.ctx.storage.sql.exec(
          'UPDATE agent_run_checkpoints SET state=?,payload=?,expires_at=?,updated_at=?,lease_until=? WHERE run_id=? AND lease_token=?',
          state, payload, Number(expiresAt), now, state === 'ready' ? null : now + CHECKPOINT_LEASE_MS, String(runId), leaseToken);
      } else {
        this.ctx.storage.sql.exec(
          'INSERT INTO agent_run_checkpoints(run_id,state,payload,expires_at,updated_at,lease_token,lease_until) VALUES(?,?,?,?,?,?,?)',
          String(runId), state, payload, Number(expiresAt), now, state === 'ready' ? null : leaseToken,
          state === 'ready' ? null : now + CHECKPOINT_LEASE_MS);
      }
      return { ok: true, state, expiresAt: Number(expiresAt) };
    });
  }

  async claimAgentCheckpoint(runId, now = Date.now()) {
    if (!UUID.test(String(runId || '')) || !Number.isSafeInteger(now)) return { ok: false, code: 'INVALID_AGENT_CHECKPOINT' };
    return this.ctx.storage.transactionSync(() => {
      this.ctx.storage.sql.exec('DELETE FROM agent_run_checkpoints WHERE expires_at<=?', now);
      const row = this.ctx.storage.sql.exec('SELECT * FROM agent_run_checkpoints WHERE run_id=?', String(runId)).toArray()[0];
      if (!row) return { ok: false, code: 'CHECKPOINT_NOT_FOUND' };
      if (row.state === 'in_flight') return { ok: false, code: 'CHECKPOINT_UNSAFE' };
      if (row.state === 'leased' && Number(row.lease_until || 0) > now) return { ok: false, code: 'CHECKPOINT_BUSY' };
      const leaseToken = crypto.randomUUID();
      this.ctx.storage.sql.exec("UPDATE agent_run_checkpoints SET state='leased',lease_token=?,lease_until=?,updated_at=? WHERE run_id=?",
        leaseToken, now + CHECKPOINT_LEASE_MS, now, String(runId));
      return { ok: true, payload: String(row.payload), leaseToken, expiresAt: Number(row.expires_at) };
    });
  }

  async releaseAgentCheckpoint(runId, leaseToken, now = Date.now()) {
    if (!UUID.test(String(runId || '')) || !UUID.test(String(leaseToken || ''))) return { ok: false, code: 'INVALID_AGENT_CHECKPOINT' };
    return this.ctx.storage.transactionSync(() => {
      const row = this.ctx.storage.sql.exec('SELECT state,lease_token FROM agent_run_checkpoints WHERE run_id=?', String(runId)).toArray()[0];
      if (!row || row.lease_token !== leaseToken) return { ok: false, code: 'CHECKPOINT_LEASE_LOST' };
      if (row.state === 'in_flight') return { ok: false, code: 'CHECKPOINT_UNSAFE' };
      this.ctx.storage.sql.exec("UPDATE agent_run_checkpoints SET state='ready',lease_token=NULL,lease_until=NULL,updated_at=? WHERE run_id=?", now, String(runId));
      return { ok: true };
    });
  }

  async deleteAgentCheckpoint(runId, leaseToken = '') {
    if (!UUID.test(String(runId || ''))) return { ok: false, code: 'INVALID_AGENT_CHECKPOINT' };
    if (leaseToken && !UUID.test(String(leaseToken))) return { ok: false, code: 'INVALID_AGENT_CHECKPOINT' };
    return this.ctx.storage.transactionSync(() => {
      if (leaseToken) this.ctx.storage.sql.exec('DELETE FROM agent_run_checkpoints WHERE run_id=? AND lease_token=?', String(runId), leaseToken);
      else this.ctx.storage.sql.exec('DELETE FROM agent_run_checkpoints WHERE run_id=?', String(runId));
      return { ok: true };
    });
  }

  async claimAgentBrowserSession(conversationId, leaseToken, now = Date.now()) {
    if (!UUID.test(String(conversationId || '')) || !UUID.test(String(leaseToken || '')) || !Number.isSafeInteger(now))
      return { ok: false, code: 'INVALID_AGENT_BROWSER_SESSION' };
    return this.ctx.storage.transactionSync(() => {
      this.ctx.storage.sql.exec('DELETE FROM agent_browser_sessions WHERE expires_at<=?', now);
      const row = this.ctx.storage.sql.exec('SELECT * FROM agent_browser_sessions WHERE conversation_id=?', String(conversationId)).toArray()[0];
      if (row && Number(row.lease_until || 0) > now) return { ok: false, code: 'BROWSER_SESSION_BUSY' };
      if (!row) {
        const activeCount = Number(this.ctx.storage.sql.exec('SELECT COUNT(*) AS total FROM agent_browser_sessions WHERE expires_at>?', now).toArray()[0]?.total || 0);
        if (activeCount >= MAX_BROWSER_SESSIONS_PER_ACCOUNT) return { ok: false, code: 'BROWSER_SESSION_LIMIT' };
      }
      const leaseUntil = now + BROWSER_SESSION_LEASE_MS;
      if (row) {
        this.ctx.storage.sql.exec('UPDATE agent_browser_sessions SET lease_token=?,lease_until=?,updated_at=? WHERE conversation_id=?',
          String(leaseToken), leaseUntil, now, String(conversationId));
        return { ok: true, found: row.state === 'active' && Boolean(row.payload), payload: String(row.payload || ''), expiresAt: Number(row.expires_at), leaseToken: String(leaseToken) };
      }
      const expiresAt = now + BROWSER_SESSION_TTL_MS;
      this.ctx.storage.sql.exec(
        'INSERT INTO agent_browser_sessions(conversation_id,state,payload,expires_at,updated_at,lease_token,lease_until) VALUES(?,?,?,?,?,?,?)',
        String(conversationId), 'opening', '', expiresAt, now, String(leaseToken), leaseUntil);
      return { ok: true, found: false, payload: '', expiresAt, leaseToken: String(leaseToken) };
    });
  }

  async saveAgentBrowserSession(conversationId, payload, leaseToken, expiresAt, now = Date.now()) {
    if (!UUID.test(String(conversationId || '')) || !UUID.test(String(leaseToken || '')) ||
        typeof payload !== 'string' || !payload.length || payload.length > MAX_BROWSER_SESSION_CIPHER_BYTES ||
        !Number.isSafeInteger(Number(expiresAt)) || Number(expiresAt) <= now ||
        Number(expiresAt) > now + BROWSER_SESSION_TTL_MS + 60_000 || !Number.isSafeInteger(now))
      return { ok: false, code: 'INVALID_AGENT_BROWSER_SESSION' };
    return this.ctx.storage.transactionSync(() => {
      const row = this.ctx.storage.sql.exec('SELECT state,lease_token,lease_until FROM agent_browser_sessions WHERE conversation_id=?', String(conversationId)).toArray()[0];
      if (!row || row.lease_token !== leaseToken || Number(row.lease_until || 0) <= now) return { ok: false, code: 'BROWSER_SESSION_LEASE_LOST' };
      this.ctx.storage.sql.exec(
        "UPDATE agent_browser_sessions SET state='active',payload=?,expires_at=?,updated_at=?,lease_until=? WHERE conversation_id=? AND lease_token=?",
        payload, Number(expiresAt), now, now + BROWSER_SESSION_LEASE_MS, String(conversationId), String(leaseToken));
      return { ok: true, expiresAt: Number(expiresAt) };
    });
  }

  async releaseAgentBrowserSession(conversationId, leaseToken, keep = true, now = Date.now()) {
    if (!UUID.test(String(conversationId || '')) || !UUID.test(String(leaseToken || '')) || typeof keep !== 'boolean' || !Number.isSafeInteger(now))
      return { ok: false, code: 'INVALID_AGENT_BROWSER_SESSION' };
    return this.ctx.storage.transactionSync(() => {
      const row = this.ctx.storage.sql.exec('SELECT state,lease_token,payload FROM agent_browser_sessions WHERE conversation_id=?', String(conversationId)).toArray()[0];
      if (!row || row.lease_token !== leaseToken) return { ok: false, code: 'BROWSER_SESSION_LEASE_LOST' };
      if (!keep || row.state !== 'active' || !row.payload) {
        this.ctx.storage.sql.exec('DELETE FROM agent_browser_sessions WHERE conversation_id=? AND lease_token=?', String(conversationId), String(leaseToken));
      } else {
        this.ctx.storage.sql.exec('UPDATE agent_browser_sessions SET lease_token=NULL,lease_until=NULL,updated_at=? WHERE conversation_id=? AND lease_token=?', now, String(conversationId), String(leaseToken));
      }
      return { ok: true, kept: keep && row.state === 'active' && Boolean(row.payload) };
    });
  }

  async deleteAgentBrowserSession(conversationId, leaseToken) {
    if (!UUID.test(String(conversationId || '')) || !UUID.test(String(leaseToken || '')))
      return { ok: false, code: 'INVALID_AGENT_BROWSER_SESSION' };
    return this.ctx.storage.transactionSync(() => {
      const row = this.ctx.storage.sql.exec('SELECT lease_token FROM agent_browser_sessions WHERE conversation_id=?', String(conversationId)).toArray()[0];
      if (!row || row.lease_token !== leaseToken) return { ok: false, code: 'BROWSER_SESSION_LEASE_LOST' };
      this.ctx.storage.sql.exec('DELETE FROM agent_browser_sessions WHERE conversation_id=? AND lease_token=?', String(conversationId), String(leaseToken));
      return { ok: true };
    });
  }

  async listAgentRuns(limit = 30, offset = 0) {
    const take = Number.isSafeInteger(Number(limit)) ? Math.max(1, Math.min(50, Number(limit))) : 30;
    const skip = Number.isSafeInteger(Number(offset)) ? Math.max(0, Math.min(100, Number(offset))) : 0;
    const now = Date.now();
    const rows = this.ctx.storage.sql.exec(`SELECT h.*, CASE WHEN c.run_id IS NOT NULL AND c.state!='in_flight' AND (c.state='ready' OR COALESCE(c.lease_until,0)<=?) THEN 1 ELSE 0 END AS resume_available
      FROM agent_run_history h LEFT JOIN agent_run_checkpoints c ON c.run_id=h.run_id AND c.expires_at>?
      ORDER BY h.updated_at DESC, h.run_id DESC LIMIT ? OFFSET ?`, now, now, take + 1, skip).toArray();
    const hasMore = rows.length > take;
    return { ok: true, hasMore, runs: rows.slice(0, take).map(row => this.normalizeAgentRunRow(row)) };
  }

  async getAgentRun(runId) {
    if (!UUID.test(String(runId || ''))) return { ok: false, code: 'INVALID_AGENT_RUN' };
    const row = this.ctx.storage.sql.exec(`SELECT h.*, CASE WHEN c.run_id IS NOT NULL AND c.state!='in_flight' AND (c.state='ready' OR COALESCE(c.lease_until,0)<=?) THEN 1 ELSE 0 END AS resume_available
      FROM agent_run_history h LEFT JOIN agent_run_checkpoints c ON c.run_id=h.run_id AND c.expires_at>? WHERE h.run_id=?`, Date.now(), Date.now(), String(runId)).toArray()[0];
    return row ? { ok: true, run: this.normalizeAgentRunRow(row) } : { ok: false, code: 'AGENT_RUN_NOT_FOUND' };
  }

  async deleteAgentRun(runId) {
    if (!UUID.test(String(runId || ''))) return { ok: false, code: 'INVALID_AGENT_RUN' };
    this.ctx.storage.sql.exec('DELETE FROM agent_run_checkpoints WHERE run_id=?', String(runId));
    this.ctx.storage.sql.exec('DELETE FROM agent_run_history WHERE run_id=?', String(runId));
    return { ok: true };
  }

  async clearAgentRuns() {
    this.ctx.storage.sql.exec('DELETE FROM agent_run_checkpoints');
    this.ctx.storage.sql.exec('DELETE FROM agent_run_history');
    return { ok: true };
  }

  normalizeAgentRunRow(row) {
    let toolEvents = [];
    try { const parsed = JSON.parse(String(row.tool_events_json || '[]')); if (Array.isArray(parsed)) toolEvents = parsed.slice(0, 20); } catch { }
    return {
      runId: String(row.run_id), specialist: String(row.specialist), state: String(row.state),
      createdAt: Number(row.created_at), updatedAt: Number(row.updated_at), durationMs: Number(row.duration_ms),
      stepCount: Number(row.step_count), toolEvents, researchStatus: String(row.research_status),
      researchMode: String(row.research_mode), sourceCount: Number(row.source_count),
      provider: String(row.provider), model: String(row.model), failureCode: String(row.failure_code),
      resumeAvailable: Number(row.resume_available || 0) === 1
    };
  }
}

export default { async fetch() { return new Response('Not found', { status: 404, headers: { 'cache-control': 'no-store' } }); } };
