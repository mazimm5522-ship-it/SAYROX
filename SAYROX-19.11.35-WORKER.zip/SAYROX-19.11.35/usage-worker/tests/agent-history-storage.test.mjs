import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { DatabaseSync } from 'node:sqlite';

let source = await readFile(new URL('../src/index.js', import.meta.url), 'utf8');
source = source.replace("import { DurableObject } from 'cloudflare:workers';", 'class DurableObject { constructor(ctx, env) { this.ctx = ctx; this.env = env; } }');
const sourceUrl = `data:text/javascript;base64,${Buffer.from(source).toString('base64')}`;
const { UsageAccountObject } = await import(sourceUrl);

function createObject() {
  const db = new DatabaseSync(':memory:');
  const sql = {
    exec(query, ...args) {
      if (!args.length && /;\s*(CREATE|INSERT|UPDATE|DELETE|ALTER)/i.test(query)) {
        db.exec(query);
        return { toArray: () => [], one: () => null };
      }
      const statement = db.prepare(query);
      if (/^\s*(SELECT|WITH)\b/i.test(query)) {
        const rows = statement.all(...args);
        return { toArray: () => rows, one: () => rows[0] ?? null };
      }
      statement.run(...args);
      return { toArray: () => [], one: () => null };
    }
  };
  const storage = { sql, transactionSync(callback) { db.exec('BEGIN IMMEDIATE'); try { const value = callback(); db.exec('COMMIT'); return value; } catch (error) { db.exec('ROLLBACK'); throw error; } } };
  const ctx = { storage, blockConcurrencyWhile(callback) { this.initialization = Promise.resolve().then(callback); return this.initialization; } };
  const instance = new UsageAccountObject(ctx, {});
  return { instance, db, ready: ctx.initialization };
}
const uuid = () => crypto.randomUUID();

{
  const { instance, db, ready } = createObject();
  await ready;
  const id = uuid(), now = Date.now();
  const record = {
    runId: id, specialist: 'research', state: 'running', createdAt: now, updatedAt: now,
    durationMs: 12, stepCount: 1,
    toolEvents: [{ tool: 'web_research', specialist: 'research', status: 'success' }, { tool: 'dangerous_tool!', specialist: 'coding', status: 'failed', code: 'TOOL_NOT_FOUND' }, { tool: 'create_scheduled_task', specialist: 'main', status: 'cancelled' }],
    researchStatus: 'completed', researchMode: 'deep', sourceCount: 4, provider: 'gapgpt', model: 'test-model'
  };
  assert.equal((await instance.recordAgentRun(record)).ok, true);
  const listed = await instance.listAgentRuns(10);
  assert.equal(listed.runs.length, 1);
  assert.equal(listed.runs[0].runId, id);
  assert.equal(listed.runs[0].toolEvents[0].tool, 'web_research');
  assert.equal(listed.runs[0].toolEvents[0].specialist, 'research');
  assert.equal(listed.runs[0].toolEvents[1].specialist, 'coding');
  assert.equal(listed.runs[0].toolEvents[1].tool, 'unknown_tool');
  assert.equal(listed.runs[0].toolEvents[2].status, 'cancelled');
  assert.equal(listed.runs[0].researchMode, 'deep');

  assert.equal((await instance.recordAgentRun({ ...record, state: 'completed', updatedAt: now + 50, durationMs: 50, stepCount: 2 })).ok, true);
  const detail = await instance.getAgentRun(id);
  assert.equal(detail.run.state, 'completed');
  assert.equal(detail.run.durationMs, 50);
  assert.equal((await instance.deleteAgentRun(id)).ok, true);
  assert.equal((await instance.getAgentRun(id)).code, 'AGENT_RUN_NOT_FOUND');
  db.close();
}

{
  const { instance, db, ready } = createObject();
  await ready;
  assert.equal((await instance.recordAgentRun({ runId: 'bad', state: 'completed', specialist: 'main' })).code, 'INVALID_AGENT_RUN');
  assert.equal((await instance.recordAgentRun({ runId: uuid(), state: 'unknown', specialist: 'main' })).code, 'INVALID_AGENT_RUN');
  for (let i = 0; i < 105; i++) {
    const id = uuid();
    await instance.recordAgentRun({ runId: id, state: 'completed', specialist: 'main', createdAt: Date.now() + i, updatedAt: Date.now() + i });
  }
  const firstPage = await instance.listAgentRuns(50, 0);
  const secondPage = await instance.listAgentRuns(50, 50);
  assert.equal(firstPage.runs.length, 50);
  assert.equal(firstPage.hasMore, true);
  assert.equal(secondPage.runs.length, 50);
  assert.equal(secondPage.hasMore, false);
  assert.equal(new Set([...firstPage.runs, ...secondPage.runs].map(run => run.runId)).size, 100);
  assert.equal(db.prepare('SELECT COUNT(*) AS total FROM agent_run_history').get().total, 100);
  assert.equal((await instance.clearAgentRuns()).ok, true);
  assert.equal((await instance.listAgentRuns()).runs.length, 0);

  const staleId = uuid();
  const staleAt = Date.now() - 91 * 86400_000;
  assert.equal((await instance.recordAgentRun({ runId: staleId, state: 'completed', specialist: 'main', createdAt: staleAt, updatedAt: staleAt })).ok, true);
  assert.equal((await instance.getAgentRun(staleId)).code, 'AGENT_RUN_NOT_FOUND');
  db.close();
}

console.log('agent history storage tests: persistence, upsert, validation, 100-run/90-day retention and deletion passed');

{
  const { instance, db, ready } = createObject();
  await ready;
  const ticketId = uuid(), accountKey = 'x'.repeat(43), now = Date.now();
  const accepted = await instance.consumeAgentApproval(ticketId, accountKey, now + 300_000, 'approved', now);
  assert.equal(accepted.ok, true);
  assert.equal((await instance.consumeAgentApproval(ticketId, accountKey, now + 300_000, 'approved', now + 1)).code, 'AGENT_APPROVAL_REPLAYED');
  const deniedId = uuid();
  assert.equal((await instance.consumeAgentApproval(deniedId, accountKey, now + 300_000, 'denied', now)).decision, 'denied');
  assert.equal((await instance.consumeAgentApproval(uuid(), accountKey, now - 1, 'approved', now)).code, 'INVALID_AGENT_APPROVAL');
  assert.equal((await instance.consumeAgentApproval(uuid(), 'bad', now + 300_000, 'approved', now)).code, 'INVALID_AGENT_APPROVAL');
  assert.equal(db.prepare('SELECT COUNT(*) AS total FROM agent_approval_tickets').get().total, 2);
  db.close();
}

{
  const { instance, db, ready } = createObject();
  await ready;
  const id = uuid(), lease = uuid(), nextLease = uuid(), now = Date.now();
  assert.equal((await instance.saveAgentCheckpoint(id, 'encrypted-payload', now + 60_000, lease, 'leased', now)).ok, true);
  assert.equal((await instance.claimAgentCheckpoint(id, now + 1)).code, 'CHECKPOINT_BUSY', 'a live lease prevents concurrent resume');
  assert.equal((await instance.releaseAgentCheckpoint(id, lease, now + 2)).ok, true);
  const claimed = await instance.claimAgentCheckpoint(id, now + 3);
  assert.equal(claimed.ok, true);
  assert.equal(claimed.payload, 'encrypted-payload');
  assert.notEqual(claimed.leaseToken, lease);
  assert.equal((await instance.claimAgentCheckpoint(id, now + 4)).code, 'CHECKPOINT_BUSY', 'only one resume can own a checkpoint');
  assert.equal((await instance.saveAgentCheckpoint(id, 'safe-after-tool', now + 60_000, claimed.leaseToken, 'leased', now + 5)).ok, true);
  assert.equal((await instance.saveAgentCheckpoint(id, 'unsafe-tool-running', now + 60_000, claimed.leaseToken, 'in_flight', now + 6)).ok, true);
  assert.equal((await instance.claimAgentCheckpoint(id, now + 7)).code, 'CHECKPOINT_UNSAFE');
  assert.equal((await instance.releaseAgentCheckpoint(id, claimed.leaseToken, now + 8)).code, 'CHECKPOINT_UNSAFE');
  assert.equal((await instance.deleteAgentCheckpoint(id, claimed.leaseToken)).ok, true);
  assert.equal((await instance.claimAgentCheckpoint(id, now + 9)).code, 'CHECKPOINT_NOT_FOUND');

  const expiredId = uuid();
  assert.equal((await instance.saveAgentCheckpoint(expiredId, 'expired-payload', now + 20, nextLease, 'leased', now)).ok, true);
  assert.equal((await instance.claimAgentCheckpoint(expiredId, now + 21)).code, 'CHECKPOINT_NOT_FOUND');
  db.close();
}


{
  const { instance, db, ready } = createObject();
  await ready;
  const conversationId = uuid(), lease = uuid(), secondLease = uuid(), now = Date.now();
  const initial = await instance.claimAgentBrowserSession(conversationId, lease, now);
  assert.equal(initial.ok, true);
  assert.equal(initial.found, false);
  assert.equal((await instance.claimAgentBrowserSession(conversationId, secondLease, now + 1)).code, 'BROWSER_SESSION_BUSY', 'only one request may own a conversation browser session');
  assert.equal((await instance.saveAgentBrowserSession(conversationId, 'encrypted-session-payload', lease, now + 15 * 60_000, now + 2)).ok, true);
  assert.equal((await instance.releaseAgentBrowserSession(conversationId, lease, true, now + 3)).ok, true);

  const resumed = await instance.claimAgentBrowserSession(conversationId, secondLease, now + 4);
  assert.equal(resumed.ok, true);
  assert.equal(resumed.found, true);
  assert.equal(resumed.payload, 'encrypted-session-payload');
  assert.equal((await instance.releaseAgentBrowserSession(conversationId, lease, false, now + 5)).code, 'BROWSER_SESSION_LEASE_LOST', 'a stale lease cannot delete a newer session owner');
  assert.equal((await instance.releaseAgentBrowserSession(conversationId, secondLease, false, now + 6)).ok, true);
  assert.equal(db.prepare('SELECT COUNT(*) AS total FROM agent_browser_sessions').get().total, 0);

  const otherConversation = uuid(), shortLease = uuid();
  assert.equal((await instance.claimAgentBrowserSession(otherConversation, shortLease, now)).ok, true);
  assert.equal((await instance.saveAgentBrowserSession(otherConversation, 'encrypted-payload', shortLease, now + 15 * 60_000, now + 1)).ok, true);
  const renewedLease = uuid();
  assert.equal((await instance.claimAgentBrowserSession(otherConversation, renewedLease, now + 15 * 60_000 + 1)).found, false, 'expired browser sessions are purged rather than resumed');
  assert.equal(db.prepare('SELECT COUNT(*) AS total FROM agent_browser_sessions').get().total, 1, 'the expired row is replaced by a fresh opening lease');
  assert.equal((await instance.releaseAgentBrowserSession(otherConversation, shortLease, false, now + 15 * 60_000 + 2)).code, 'BROWSER_SESSION_LEASE_LOST');
  assert.equal((await instance.releaseAgentBrowserSession(otherConversation, renewedLease, false, now + 15 * 60_000 + 2)).ok, true);

  // The existing per-account UsageAccountObject caps outstanding browser session records.
  const opening = [];
  for (let i = 0; i < 10; i++) {
    const chatId = uuid(), token = uuid(); opening.push([chatId, token]);
    assert.equal((await instance.claimAgentBrowserSession(chatId, token, now + 20 * 60_000)).ok, true);
  }
  assert.equal((await instance.claimAgentBrowserSession(uuid(), uuid(), now + 20 * 60_000 + 1)).code, 'BROWSER_SESSION_LIMIT');
  for (const [chatId, token] of opening) assert.equal((await instance.releaseAgentBrowserSession(chatId, token, false, now + 20 * 60_000 + 2)).ok, true);
  db.close();
}

console.log('agent browser storage tests: per-conversation lease ownership, concurrency exclusion, encrypted payload persistence, stale-lease rejection, deletion and expiry passed');
