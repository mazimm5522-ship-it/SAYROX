"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sealAgentApprovalTicket = sealAgentApprovalTicket;
exports.openAgentApprovalTicket = openAgentApprovalTicket;
const passwords_js_1 = __load("worker/security/passwords.js");
const tool_registry_js_1 = __load("worker/agent/tool-registry.js");
const TICKET_TTL_MS = 5 * 60 * 1000;
const MAX_TICKET_BYTES = 24_000;
const AAD = new TextEncoder().encode("SAYROX_AGENT_APPROVAL_V1");

async function approvalKey(env) {
    const secret = typeof env?.AUTH_SESSION_SECRET === "string" ? env.AUTH_SESSION_SECRET : "";
    if (secret.length < 32) throw new Error("APPROVAL_SECRET_UNAVAILABLE");
    const material = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`sayrox-agent-approval:${secret}`));
    return crypto.subtle.importKey("raw", material, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}
function validTicketShape(value, now = Date.now()) {
    return Boolean(value && typeof value === "object" && value.v === 1 &&
        /^[0-9a-f-]{36}$/i.test(String(value.ticketId || "")) &&
        /^[A-Za-z0-9_-]{43}$/.test(String(value.accountKey || "")) &&
        /^[0-9a-f-]{36}$/i.test(String(value.runId || "")) &&
        /^[a-z][a-z0-9_.-]{1,63}$/.test(String(value.toolId || "")) &&
        /^[A-Za-z0-9_-]{1,128}$/.test(String(value.callId || "")) &&
        value.args && typeof value.args === "object" && !Array.isArray(value.args) &&
        typeof value.argsHash === "string" && /^[a-f0-9]{64}$/.test(value.argsHash) &&
        typeof value.risk === "string" && value.risk.length <= 32 &&
        typeof value.description === "string" && value.description.length <= 240 &&
        ['','gapgpt','openrouter'].includes(value.provider) && typeof value.model === 'string' && value.model.length <= 120 &&
        ['not_used','completed','unavailable'].includes(value.researchStatus) && ['none','quick','deep'].includes(value.researchMode) &&
        Number.isSafeInteger(value.sourceCount) && value.sourceCount >= 0 && value.sourceCount <= 20 &&
        Number.isSafeInteger(value.stepCount) && value.stepCount >= 0 && value.stepCount <= 20 &&
        (value.conversationId === undefined || /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(value.conversationId))) &&
        Number.isSafeInteger(value.issuedAt) && Number.isSafeInteger(value.expiresAt) &&
        value.issuedAt <= now + 30_000 && value.expiresAt > now &&
        value.expiresAt <= value.issuedAt + TICKET_TTL_MS &&
        value.expiresAt > value.issuedAt);
}
async function sealAgentApprovalTicket(env, input) {
    if (!input || typeof input !== "object" || !/^[A-Za-z0-9_-]{43}$/.test(String(input.accountKey || "")) ||
        !/^[0-9a-f-]{36}$/i.test(String(input.runId || "")) ||
        !/^[a-z][a-z0-9_.-]{1,63}$/.test(String(input.toolId || "")) ||
        !/^[A-Za-z0-9_-]{1,128}$/.test(String(input.callId || "")) ||
        !input.args || typeof input.args !== "object" || Array.isArray(input.args)) {
        throw new Error("INVALID_APPROVAL_TICKET_INPUT");
    }
    const now = Date.now();
    const ticket = {
        v: 1, ticketId: crypto.randomUUID(), accountKey: input.accountKey,
        runId: input.runId, toolId: input.toolId, callId: input.callId,
        args: input.args, argsHash: await (0, tool_registry_js_1.approvalArgsHash)(input.args),
        risk: String(input.risk || "unclassified").slice(0, 32),
        description: String(input.description || "برای این عملیات تأیید صریح لازم است.").slice(0, 240),
        specialist: String(input.specialist || "main").slice(0, 32),
        provider: ['gapgpt', 'openrouter'].includes(input.provider) ? input.provider : '',
        model: String(input.model || '').slice(0, 120),
        stepCount: Number.isSafeInteger(input.stepCount) ? Math.max(0, Math.min(20, input.stepCount)) : 0,
        researchStatus: ['not_used','completed','unavailable'].includes(input.researchStatus) ? input.researchStatus : 'not_used',
        researchMode: ['none','quick','deep'].includes(input.researchMode) ? input.researchMode : 'none',
        sourceCount: Number.isSafeInteger(input.sourceCount) ? Math.max(0, Math.min(20, input.sourceCount)) : 0,
        ...( /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(String(input.conversationId || '')) ? { conversationId: input.conversationId } : {}),
        issuedAt: now, expiresAt: now + TICKET_TTL_MS
    };
    const plaintext = new TextEncoder().encode(JSON.stringify(ticket));
    if (plaintext.byteLength > MAX_TICKET_BYTES) throw new Error("APPROVAL_TICKET_TOO_LARGE");
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const key = await approvalKey(env);
    const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv, additionalData: AAD, tagLength: 128 }, key, plaintext);
    return {
        token: `v1.${(0, passwords_js_1.base64url)(iv)}.${(0, passwords_js_1.base64url)(new Uint8Array(ciphertext))}`,
        expiresAt: ticket.expiresAt,
        toolId: ticket.toolId,
        risk: ticket.risk,
        description: ticket.description,
        specialist: ticket.specialist
    };
}
async function openAgentApprovalTicket(env, token) {
    if (typeof token !== "string" || token.length > MAX_TICKET_BYTES || !token.startsWith("v1.")) return null;
    const parts = token.split(".");
    if (parts.length !== 3 || parts[0] !== "v1" || !/^[A-Za-z0-9_-]{16}$/.test(parts[1]) || !/^[A-Za-z0-9_-]+$/.test(parts[2])) return null;
    try {
        const iv = (0, passwords_js_1.fromBase64url)(parts[1]);
        const ciphertext = (0, passwords_js_1.fromBase64url)(parts[2]);
        // Require canonical Base64URL so alternate encodings of identical bytes cannot bypass tamper checks.
        if (iv.byteLength !== 12 || ciphertext.byteLength < 16 ||
            (0, passwords_js_1.base64url)(iv) !== parts[1] ||
            (0, passwords_js_1.base64url)(ciphertext) !== parts[2]) return null;
        const key = await approvalKey(env);
        const plaintext = await crypto.subtle.decrypt({
            name: "AES-GCM", iv,
            additionalData: AAD, tagLength: 128
        }, key, ciphertext);
        const ticket = JSON.parse(new TextDecoder().decode(plaintext));
        if (!validTicketShape(ticket)) return null;
        if (await (0, tool_registry_js_1.approvalArgsHash)(ticket.args) !== ticket.argsHash) return null;
        return ticket;
    } catch { return null; }
}
