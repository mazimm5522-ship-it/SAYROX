"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.detectCapabilityIntent = detectCapabilityIntent;
function latestUserText(messages) {
    if (!Array.isArray(messages)) return "";
    for (let index = messages.length - 1; index >= 0; index--) {
        const message = messages[index];
        if (message?.role !== "user") continue;
        if (typeof message.content === "string") return message.content.slice(0, 12_000);
        if (Array.isArray(message.content)) return message.content.filter(part => part?.type === "text" && typeof part.text === "string").map(part => part.text).join(" ").slice(0, 12_000);
    }
    return "";
}
function normalize(value) {
    return String(value || "").toLocaleLowerCase("fa").replace(/[يى]/g, "ی").replace(/ك/g, "ک").replace(/[\u064b-\u065f\u0670\u0640]/g, "").replace(/\s+/g, " ").trim();
}
function detectCapabilityIntent(messages) {
    const text = normalize(latestUserText(messages));
    const imageRequest = /\b(generate|create|make|draw)\s+(?:me\s+)?(?:an?\s+)?(?:image|picture|illustration)\b|تصویر\s*(?:بساز|ایجاد\s*کن|تولید\s*کن)|عکس\s*(?:بساز|ایجاد\s*کن)|تولید\s*تصویر/.test(text);
    const fileType = /\b(word|docx|pdf|excel|xlsx|spreadsheet|powerpoint|pptx|slides?)\b|ورد|پی.?دی.?اف|اکسل|پاورپوینت|پاور\s*پوینت|اسلاید|صفحه.?گسترده|فایل\s*(?:word|pdf|excel|powerpoint)?/.test(text);
    const createVerb = /\b(create|make|generate|export|download|build)\b|بساز|ساخت|ایجاد\s*کن|تولید\s*کن|خروجی\s*بگیر|تبدیل\s*کن/.test(text);
    const createFile = fileType && createVerb && !/\b(read|open|analy[sz]e|summari[sz]e|review)\b|بخوان|باز\s*کن|تحلیل\s*کن|خلاصه\s*کن/.test(text);
    const scheduledTask = /\b(remind\s+me|set\s+(?:a\s+)?reminder|create\s+(?:a\s+)?reminder|schedule\s+(?:this|a\s+task)|every\s+(?:day|week)\s+(?:remind|notify)|daily\s+reminder\s+for|weekly\s+reminder\s+for)\b|یادآوری\s*کن|یادآور\s*(?:بساز|ثبت\s*کن)|یادآوری\s*(?:تنظیم|ثبت)\s*کن|برام\s*یادآور|زمان.?بندی\s*کن|هر\s*(?:روز|هفته).{0,24}یادآوری/.test(text);
    const taskNoun = /\b(reminder|reminders|scheduled\s+tasks?|tasks?)\b|یادآور|یادآوری|کارهای\s*زمان.?بندی|وظیفه|تسک/.test(text);
    const listScheduledTasks = taskNoun && (/\b(list|show|display|view|what are|my)\b|فهرست|لیست|نمایش|نشون\s*بده|نشان\s*بده|کارهای\s*من/.test(text));
    const deleteScheduledTask = taskNoun && (/\b(delete|remove|cancel)\b|حذف|پاک\s*کن|لغو/.test(text));
    const manageScheduledTasks = taskNoun && (/\b(pause|stop|disable|resume|enable|edit|update|change|run\s+now|run\s+immediately)\b|متوقف|توقف|خاموش|غیرفعال|فعال\s*کن|روشن\s*کن|ویرایش|تغییر|اصلاح|الان\s*اجرا|همین\s*الان\s*اجرا/.test(text));
    const memorySearch = /\b(what\s+do\s+you\s+remember|search\s+my\s+memory|what\s+is\s+saved\s+about\s+me)\b|چی\s*(?:از من|درباره.?ی من)\s*(?:یادت|می.?دونی)|چه\s*چیزی\s*(?:از من|درباره.?ی من)\s*(?:یادت|ذخیره)|حافظه.?ات\s*(?:چی|چه)/.test(text);
    const executeCode = /\b(?:run|execute|test)\b.{0,50}\b(?:code|script|python)\b|\b(?:code|script|python)\b.{0,50}\b(?:run|execute|test)\b|کد.{0,45}(?:اجرا|ران|تست)|(?:اجرا|ران|تست).{0,45}کد|پایتون.{0,45}(?:اجرا|تست)|(?:اجرا|تست).{0,45}پایتون/.test(text);
    return Object.freeze({
        generateImage: imageRequest, createFile, scheduleTask: scheduledTask,
        listScheduledTasks, manageScheduledTasks, deleteScheduledTask,
        searchMemory: memorySearch, executeCode
    });
}
