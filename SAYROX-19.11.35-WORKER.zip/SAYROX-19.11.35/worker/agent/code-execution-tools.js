"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPythonExecutionTool = createPythonExecutionTool;

const MAX_CODE_CHARS = 8_000;
const MAX_RESPONSE_BYTES = 36_000;
const MAX_DOCUMENTS = 2;
const MAX_DOCUMENT_CHARS = 60_000;
const MAX_TOTAL_DOCUMENT_CHARS = 100_000;

function toBase64Url(bytes) {
    let binary = "";
    for (const byte of new Uint8Array(bytes)) binary += String.fromCharCode(byte);
    return btoa(binary).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/g, "");
}

async function signRequest(secret, timestamp, body) {
    const key = await crypto.subtle.importKey(
        "raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]
    );
    const signature = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`${timestamp}.${body}`));
    return toBase64Url(signature);
}

async function deriveJobId(accountKey, runId, invocationId) {
    const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`sayrox-code-job-v1\n${accountKey}\n${runId}\n${invocationId}`));
    return Array.from(new Uint8Array(bytes), byte => byte.toString(16).padStart(2, "0")).join("");
}

function createPythonExecutionTool({ env, accountKey, documents = [] } = {}) {
    const availableDocuments = Array.isArray(documents) ? documents.slice(0, MAX_DOCUMENTS).filter(item => item && typeof item.text === "string" && item.text.trim()).map(item => ({
        name: String(item.name || "attached-document").replace(/[\\/\u0000-\u001f]/g, "-").slice(0, 180) || "attached-document",
        text: item.text.replace(/\u0000/g, "").slice(0, MAX_DOCUMENT_CHARS)
    })) : [];
    let totalDocumentChars = 0;
    for (const document of availableDocuments) {
        const remaining = MAX_TOTAL_DOCUMENT_CHARS - totalDocumentChars;
        document.text = document.text.slice(0, Math.max(0, remaining));
        totalDocumentChars += document.text.length;
    }
    const documentIndexesSchema = availableDocuments.length ? {
        documentIndexes: { type: "array", minItems: 1, maxItems: availableDocuments.length, uniqueItems: true,
            items: { type: "integer", minimum: 0, maximum: availableDocuments.length - 1 } }
    } : {};
    const service = env?.CODE_SANDBOX;
    const secret = typeof env?.CODE_SANDBOX_INTERNAL_SECRET === "string" ? env.CODE_SANDBOX_INTERNAL_SECRET : "";
    if (!accountKey || !service || typeof service.fetch !== "function" || secret.length < 32) return null;
    return {
        id: "execute_python",
        specialist: "coding",
        description: "Run user-requested Python code inside a dedicated isolated Linux microVM with outbound Internet disabled. Requires explicit user approval.",
        risk: "sandbox_execution",
        requiresApproval: true,
        timeoutMs: 24_000,
        providerSchema: {
            type: "function",
            function: {
                name: "execute_python",
                description: "Execute Python 3.13 code only when the user explicitly asks to run, execute, test, or calculate by executing code. Do not call this when the user only asks to write or explain code. The isolated environment has Python standard library only, no Internet, no API credentials, and a temporary one-job workspace. The user must approve before execution.",
                parameters: {
                    type: "object", additionalProperties: false,
                    properties: {
                        language: { type: "string", enum: ["python"] },
                        code: { type: "string", minLength: 1, maxLength: MAX_CODE_CHARS },
                        ...documentIndexesSchema
                    }, required: ["language", "code"]
                }
            }
        },
        validateArgs(args) {
            if (!args || typeof args !== "object" || Array.isArray(args)
                || !Object.keys(args).every(key => ["language", "code", "documentIndexes"].includes(key))
                || args.language !== "python" || typeof args.code !== "string" || !args.code.trim()
                || args.code.length > MAX_CODE_CHARS || new TextEncoder().encode(args.code).byteLength > 12_000) return false;
            if (args.documentIndexes === undefined) return true;
            if (!availableDocuments.length || !Array.isArray(args.documentIndexes)
                || args.documentIndexes.length < 1 || args.documentIndexes.length > availableDocuments.length) return false;
            return args.documentIndexes.every((index, position, indexes) => Number.isInteger(index)
                && index >= 0 && index < availableDocuments.length && indexes.indexOf(index) === position);
        },
        async handler(args, context = {}) {
            if (context.signal?.aborted) return { ok: false, code: "EXECUTION_CANCELLED", message: "اجرای کد لغو شد." };
            if (!/^[A-Za-z0-9_-]{8,80}$/.test(context.runId || "")) return { ok: false, code: "INVALID_EXECUTION_CONTEXT", message: "شناسهٔ اجرای امن موجود نیست." };
            // A fresh invocation id permits multiple approved code calls in one Agent run
            // while keeping each signed request one-use and replay-isolated.
            const invocationId = crypto.randomUUID();
            const jobId = await deriveJobId(accountKey, context.runId, invocationId);
            const selectedDocuments = Array.isArray(args.documentIndexes) ? args.documentIndexes.map(index => availableDocuments[index]) : [];
            const files = selectedDocuments.map(document => ({ name: document.name, text: document.text }));
            const payload = { version: 1, jobId, language: "python", code: args.code, ...(files.length ? { files } : {}) };
            const body = JSON.stringify(payload);
            if (new TextEncoder().encode(body).byteLength > 360_000) return { ok: false, code: "CODE_SANDBOX_REQUEST_TOO_LARGE", message: "متن فایل‌های انتخاب‌شده برای سقف امن انتقال بیش از حد بزرگ است؛ محدودهٔ کوچک‌تری را انتخاب کن." };
            const timestamp = String(Date.now());
            let response;
            try {
                const signature = await signRequest(secret, timestamp, body);
                response = await service.fetch(new Request("https://sayrox-code-sandbox.internal/internal/execute", {
                    method: "POST",
                    headers: {
                        "content-type": "application/json",
                        "x-sayrox-timestamp": timestamp,
                        "x-sayrox-signature": signature
                    },
                    body,
                    ...(context.signal ? { signal: context.signal } : {})
                }));
            } catch {
                return { ok: false, code: "CODE_SANDBOX_UNAVAILABLE", message: "ارتباط امن با محیط اجرای کد برقرار نشد؛ کدی اجرا نشده است." };
            }
            let responseText = "";
            try { responseText = await response.text(); } catch { }
            if (new TextEncoder().encode(responseText).byteLength > MAX_RESPONSE_BYTES) {
                return { ok: false, code: "CODE_SANDBOX_RESPONSE_TOO_LARGE", message: "پاسخ محیط اجرا از سقف مجاز بزرگ‌تر بود." };
            }
            let data;
            try { data = JSON.parse(responseText); } catch { data = null; }
            if (!response.ok || !data?.ok || !data.result || !Number.isInteger(data.result.exitCode)) {
                return {
                    ok: false,
                    code: typeof data?.code === "string" ? data.code.slice(0, 64) : "CODE_SANDBOX_FAILED",
                    message: typeof data?.message === "string" ? data.message.slice(0, 240) : "اجرای ایزولهٔ Python ناموفق بود."
                };
            }
            return {
                ok: true,
                language: "python",
                stdout: String(data.result.stdout || "").slice(0, 18_000),
                stderr: String(data.result.stderr || "").slice(0, 18_000),
                exitCode: data.result.exitCode,
                outputTruncated: data.result.outputTruncated === true,
                timedOut: data.result.timedOut === true,
                isolation: "cloudflare_container_no_internet",
                ...(files.length ? { inputFiles: files.map((file, index) => ({ index, name: file.name, path: `/workspace/input/document_${index + 1}.txt`, characters: file.text.length })) } : {})
            };
        }
    };
}
