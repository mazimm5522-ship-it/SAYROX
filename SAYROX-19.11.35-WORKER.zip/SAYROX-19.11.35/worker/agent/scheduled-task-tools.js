"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createScheduledTaskTool = createScheduledTaskTool;
exports.createListScheduledTasksTool = createListScheduledTasksTool;
exports.createManageScheduledTaskTool = createManageScheduledTaskTool;
exports.createDeleteScheduledTaskTool = createDeleteScheduledTaskTool;
const constants_js_1 = __load("worker/shared/constants.js");
const http_js_1 = __load("worker/shared/http.js");
const quotas_js_1 = __load("worker/features/quotas.js");
const TIMEZONE_PATTERN = /^[A-Za-z][A-Za-z0-9_+\-]*(?:\/[A-Za-z0-9_+\-]+){0,2}$/;
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const ACCOUNT_KEY = /^[A-Za-z0-9_-]{43}$/;
function validSchedule(schedule) {
    if (!schedule || typeof schedule !== "object" || Array.isArray(schedule)) return false;
    if (Object.keys(schedule).some(key => !["type", "date", "weekday", "time", "timezone"].includes(key))) return false;
    if (!["once", "daily", "weekly"].includes(schedule.type) || typeof schedule.time !== "string" || !/^([01]\d|2[0-3]):([0-5]\d)$/.test(schedule.time)) return false;
    if (typeof schedule.timezone !== "string" || schedule.timezone.length > 64 || !TIMEZONE_PATTERN.test(schedule.timezone)) return false;
    try { new Intl.DateTimeFormat("en-US", { timeZone: schedule.timezone }); } catch { return false; }
    if (schedule.type === "once") {
        const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(String(schedule.date || ""));
        if (!match || schedule.weekday !== undefined) return false;
        const date = new Date(Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3])));
        return date.getUTCFullYear() === Number(match[1]) && date.getUTCMonth() === Number(match[2]) - 1 && date.getUTCDate() === Number(match[3]);
    }
    if (schedule.type === "weekly") return schedule.date === undefined && Number.isInteger(schedule.weekday) && schedule.weekday >= 0 && schedule.weekday <= 6;
    return schedule.date === undefined && schedule.weekday === undefined;
}
function taskStub(env, accountKey) {
    if (!ACCOUNT_KEY.test(String(accountKey || ""))) throw new Error("TASKS_ACCOUNT_SCOPE_INVALID");
    if (!env?.TASKS_ACCOUNT || typeof env.TASKS_ACCOUNT.get !== "function" || typeof env.TASKS_ACCOUNT.idFromName !== "function") throw new Error("TASKS_UNAVAILABLE");
    return env.TASKS_ACCOUNT.get(env.TASKS_ACCOUNT.idFromName(`xynora-account:${accountKey}`));
}
function tasksConfigured(env, accountKey) {
    return Boolean(ACCOUNT_KEY.test(String(accountKey || "")) && env?.TASKS_ACCOUNT && typeof env.TASKS_ACCOUNT.get === "function" && typeof env.TASKS_ACCOUNT.idFromName === "function" && typeof env.TASKS_INTERNAL_SECRET === "string" && env.TASKS_INTERNAL_SECRET.length >= 32);
}
function failure(result, fallback = "عملیات کار زمان‌بندی‌شده انجام نشد.") {
    return { ok: false, code: result?.code || "TASK_OPERATION_FAILED", message: result?.message || fallback };
}
function safeTask(task) {
    if (!task || typeof task !== "object") return null;
    return {
        id: task.id, title: task.title, schedule: task.schedule, enabled: task.enabled === true,
        nextRun: task.nextRun ?? null, createdAt: task.createdAt ?? null,
        lastRunAt: task.lastRunAt ?? null, lastStatus: task.lastStatus || null
    };
}
function createScheduledTaskTool({ env, accountKey, timezone = "Asia/Tehran" } = {}) {
    if (!tasksConfigured(env, accountKey)) return null;
    return {
        id: "create_scheduled_task", specialist: "main",
        description: "Create a user-requested scheduled Agent task. Only register for clear, explicit scheduling requests and require a complete local date/time/timezone.",
        risk: "create", requiresApproval: true, timeoutMs: 12000,
        providerSchema: { type: "function", function: { name: "create_scheduled_task", description: "Create a scheduled SAYROX task only when the user explicitly asked to schedule or be reminded. Ask for missing date, time, recurrence or timezone instead of guessing. Types: once (date YYYY-MM-DD), daily, weekly (weekday 0=Sunday through 6=Saturday). Time is 24-hour local time.", parameters: {
            type: "object", additionalProperties: false,
            properties: {
                title: { type: "string", minLength: 2, maxLength: 80 },
                prompt: { type: "string", minLength: 5, maxLength: 2000 },
                schedule: { type: "object", additionalProperties: false, properties: {
                    type: { type: "string", enum: ["once", "daily", "weekly"] }, date: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$" },
                    weekday: { type: "integer", minimum: 0, maximum: 6 }, time: { type: "string", pattern: "^([01]\\d|2[0-3]):([0-5]\\d)$" }, timezone: { type: "string", minLength: 1, maxLength: 64 }
                }, required: ["type", "time", "timezone"] }, useSearch: { type: "boolean" }
            }, required: ["title", "prompt", "schedule"]
        } } },
        validateArgs(args) {
            return Boolean(args && typeof args === "object" && !Array.isArray(args) &&
                Object.keys(args).every(key => ["title", "prompt", "schedule", "useSearch"].includes(key)) &&
                typeof args.title === "string" && args.title.trim().length >= 2 && args.title.length <= 80 &&
                typeof args.prompt === "string" && args.prompt.trim().length >= 5 && args.prompt.length <= 2000 &&
                (args.useSearch === undefined || typeof args.useSearch === "boolean") && validSchedule(args.schedule));
        },
        async handler(args) {
            const tier = await quotas_js_1.currentTier(env, accountKey);
            if (!tier) return { ok: false, code: "TASKS_UNAVAILABLE", message: "سرویس سهمیهٔ کارهای زمان‌بندی‌شده در دسترس نیست." };
            let result;
            try {
                result = await taskStub(env, accountKey).createTask({
                    title: http_js_1.text(args.title, 80), prompt: http_js_1.text(args.prompt, 2000),
                    schedule: args.schedule, useSearch: args.useSearch === true
                }, constants_js_1.TASK_LIMITS[tier], accountKey);
            } catch { return { ok: false, code: "TASKS_UNAVAILABLE", message: "سرویس زمان‌بندی موقتاً در دسترس نیست." }; }
            if (!result?.ok) return failure(result, "ساخت کار زمان‌بندی‌شده انجام نشد.");
            return { ok: true, task: safeTask(result.task), timezone: args.schedule.timezone || timezone };
        }
    };
}
function createListScheduledTasksTool({ env, accountKey } = {}) {
    if (!tasksConfigured(env, accountKey)) return null;
    return {
        id: "list_scheduled_tasks", specialist: "main", risk: "read", requiresApproval: false, timeoutMs: 12000,
        description: "Read the authenticated user's scheduled tasks and recent run statuses. Use this before managing a task when its exact id is not already known.",
        providerSchema: { type: "function", function: { name: "list_scheduled_tasks", description: "List this account's scheduled tasks and recent run statuses. No arguments. Never list another account's tasks.", parameters: { type: "object", properties: {}, required: [], additionalProperties: false } } },
        validateArgs(args) { return Boolean(args && typeof args === "object" && !Array.isArray(args) && Object.keys(args).length === 0); },
        async handler() {
            try {
                const state = await taskStub(env, accountKey).listTasks();
                if (!state?.ok) return failure(state, "فهرست کارها دریافت نشد.");
                return {
                    ok: true,
                    tasks: (Array.isArray(state.tasks) ? state.tasks : []).slice(0, 80).map(safeTask).filter(Boolean),
                    recentRuns: (Array.isArray(state.runs) ? state.runs : []).slice(0, 10).map(run => ({
                        runId: run.runId, taskId: run.taskId, title: run.title, status: run.status,
                        plannedAt: run.plannedAt, startedAt: run.startedAt, finishedAt: run.finishedAt,
                        searchUsed: run.searchUsed === true
                    })), unseen: Math.max(0, Number(state.unseen) || 0)
                };
            } catch { return { ok: false, code: "TASKS_UNAVAILABLE", message: "فهرست کارهای زمان‌بندی‌شده فعلاً در دسترس نیست." }; }
        }
    };
}
function validChanges(changes) {
    if (!changes || typeof changes !== "object" || Array.isArray(changes)) return false;
    const keys = Object.keys(changes);
    if (!keys.length || keys.some(key => !["title", "prompt", "useSearch", "schedule"].includes(key))) return false;
    if ("title" in changes && (typeof changes.title !== "string" || changes.title.trim().length < 2 || changes.title.length > 80)) return false;
    if ("prompt" in changes && (typeof changes.prompt !== "string" || changes.prompt.trim().length < 5 || changes.prompt.length > 2000)) return false;
    if ("useSearch" in changes && typeof changes.useSearch !== "boolean") return false;
    if ("schedule" in changes && !validSchedule(changes.schedule)) return false;
    return true;
}
function createManageScheduledTaskTool({ env, accountKey } = {}) {
    if (!tasksConfigured(env, accountKey)) return null;
    return {
        id: "manage_scheduled_task", specialist: "main", risk: "modify", requiresApproval: true, timeoutMs: 12000,
        description: "Pause, resume, run immediately, or update one of the authenticated user's scheduled tasks. Every change requires explicit approval.",
        providerSchema: { type: "function", function: { name: "manage_scheduled_task", description: "Manage one scheduled task belonging to the signed-in user. Actions: pause, resume, run_now, update. Use the exact taskId returned by list_scheduled_tasks. For update, provide a non-empty changes object with only title, prompt, useSearch, and/or a complete schedule. All changes require the user's approval.", parameters: {
            type: "object", additionalProperties: false,
            properties: {
                taskId: { type: "string", pattern: "^[0-9a-fA-F-]{36}$" },
                action: { type: "string", enum: ["pause", "resume", "run_now", "update"] },
                changes: { type: "object", additionalProperties: false, properties: {
                    title: { type: "string", minLength: 2, maxLength: 80 }, prompt: { type: "string", minLength: 5, maxLength: 2000 },
                    useSearch: { type: "boolean" }, schedule: { type: "object", additionalProperties: false, properties: {
                        type: { type: "string", enum: ["once", "daily", "weekly"] }, date: { type: "string", pattern: "^\\d{4}-\\d{2}-\\d{2}$" },
                        weekday: { type: "integer", minimum: 0, maximum: 6 }, time: { type: "string", pattern: "^([01]\\d|2[0-3]):([0-5]\\d)$" }, timezone: { type: "string", minLength: 1, maxLength: 64 }
                    }, required: ["type", "time", "timezone"] }
                } }
            }, required: ["taskId", "action"]
        } } },
        validateArgs(args) {
            if (!args || typeof args !== "object" || Array.isArray(args) || Object.keys(args).some(key => !["taskId", "action", "changes"].includes(key))) return false;
            if (typeof args.taskId !== "string" || !UUID.test(args.taskId)) return false;
            if (!["pause", "resume", "run_now", "update"].includes(args.action)) return false;
            if (args.action === "update") return validChanges(args.changes);
            return args.changes === undefined;
        },
        async handler(args) {
            try {
                const stub = taskStub(env, accountKey);
                let result;
                if (args.action === "pause") result = await stub.setEnabled(args.taskId, false);
                else if (args.action === "resume") result = await stub.setEnabled(args.taskId, true);
                else if (args.action === "run_now") result = await stub.runNow(args.taskId);
                else result = await stub.updateTask(args.taskId, args.changes);
                if (!result?.ok) return failure(result);
                return { ok: true, action: args.action, task: safeTask(result.task), queued: result.queued === true, message: ({ pause: "کار زمان‌بندی‌شده متوقف شد.", resume: "کار زمان‌بندی‌شده دوباره فعال شد.", run_now: "اجرای فوری کار در صف قرار گرفت.", update: "کار زمان‌بندی‌شده به‌روزرسانی شد." })[args.action] };
            } catch { return { ok: false, code: "TASKS_UNAVAILABLE", message: "مدیریت کار زمان‌بندی‌شده موقتاً در دسترس نیست." }; }
        }
    };
}
function createDeleteScheduledTaskTool({ env, accountKey } = {}) {
    if (!tasksConfigured(env, accountKey)) return null;
    return {
        id: "delete_scheduled_task", specialist: "main", risk: "delete", requiresApproval: true, timeoutMs: 12000,
        description: "Permanently delete one scheduled task belonging to the authenticated user. Explicit approval is mandatory.",
        providerSchema: { type: "function", function: { name: "delete_scheduled_task", description: "Permanently delete one of the signed-in user's scheduled tasks. Use the exact taskId returned by list_scheduled_tasks. This action requires explicit approval.", parameters: { type: "object", properties: { taskId: { type: "string", pattern: "^[0-9a-fA-F-]{36}$" } }, required: ["taskId"], additionalProperties: false } } },
        validateArgs(args) { return Boolean(args && typeof args === "object" && !Array.isArray(args) && Object.keys(args).length === 1 && typeof args.taskId === "string" && UUID.test(args.taskId)); },
        async handler(args) {
            try {
                const result = await taskStub(env, accountKey).deleteTask(args.taskId);
                if (!result?.ok) return failure(result, "حذف کار زمان‌بندی‌شده انجام نشد.");
                return { ok: true, deleted: true, taskId: args.taskId, message: "کار زمان‌بندی‌شده حذف شد." };
            } catch { return { ok: false, code: "TASKS_UNAVAILABLE", message: "سرویس زمان‌بندی موقتاً در دسترس نیست." }; }
        }
    };
}
