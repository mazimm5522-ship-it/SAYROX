"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.runAgentToolLoop = runAgentToolLoop;
exports.providerTools = providerTools;
const contracts_js_1 = __load("worker/agent/contracts.js");
const runtime_js_1 = __load("worker/agent/runtime.js");
const tool_registry_js_1 = __load("worker/agent/tool-registry.js");

const MAX_TOOL_ROUNDS = 4;
const MAX_TOOL_CALLS_PER_ROUND = 3;
const MAX_TOOL_ARGUMENT_TEXT = contracts_js_1.MAX_AGENT_TOOL_ARGUMENT_BYTES;
const MAX_AGENT_LOOP_MS = 120_000;

function allowedSpecialistsForRun(registry, specialists = null, requiredToolId = "", toolSpecialists = null) {
    if (!Array.isArray(specialists) && !Array.isArray(toolSpecialists)) return null;
    const allowed = new Set((Array.isArray(specialists) ? specialists : []).filter(value => typeof value === "string" && /^[a-z]{2,16}$/.test(value)).slice(0, 3));
    allowed.add("main");
    if (Array.isArray(toolSpecialists)) {
        for (const value of toolSpecialists.slice(0, 8)) if (typeof value === "string" && /^[a-z]{2,16}$/.test(value)) allowed.add(value);
    }
    const requiredTool = requiredToolId && typeof registry?.get === "function" ? registry.get(requiredToolId) : null;
    if (requiredTool?.specialist) allowed.add(requiredTool.specialist);
    return allowed;
}
function providerTools(registry, specialists = null, requiredToolId = "", toolSpecialists = null) {
    if (!registry || typeof registry.list !== "function") return [];
    const allowed = allowedSpecialistsForRun(registry, specialists, requiredToolId, toolSpecialists);
    return registry.list()
        .filter(tool => tool.enabled && tool.providerSchema && (!allowed || allowed.has(tool.specialist || "main")))
        .map(tool => tool.providerSchema)
        .slice(0, 16);
}

function readToolCalls(data) {
    const message = data?.choices?.[0]?.message;
    const calls = Array.isArray(message?.tool_calls) ? message.tool_calls : [];
    if (calls.length) return calls.slice(0, MAX_TOOL_CALLS_PER_ROUND);
    const legacy = message?.function_call;
    if (legacy && typeof legacy === "object") {
        return [{ id: "legacy_function_call_0001", type: "function", function: legacy }];
    }
    return [];
}

function normalizeToolCall(call, fallbackIndex, run) {
    const fn = call?.function && typeof call.function === "object" ? call.function : {};
    const name = typeof fn.name === "string" ? fn.name : "";
    const raw = typeof fn.arguments === "string" ? fn.arguments : "";
    const id = typeof call?.id === "string" && /^[A-Za-z0-9_-]{1,128}$/.test(call.id)
        ? call.id
        : `sayrox-${run.id.slice(0, 24)}-${run.stepCount}-${fallbackIndex}`;
    if (!name || name.length > 64 || raw.length > MAX_TOOL_ARGUMENT_TEXT) {
        return { id, name, args: null, error: "INVALID_TOOL_CALL" };
    }
    try {
        const args = JSON.parse(raw);
        if (!args || typeof args !== "object" || Array.isArray(args)) {
            return { id, name, args: null, error: "INVALID_TOOL_ARGUMENTS" };
        }
        return { id, name, args };
    } catch {
        return { id, name, args: null, error: "INVALID_TOOL_ARGUMENTS" };
    }
}

function resultMessage(code) {
    const messages = {
        INVALID_TOOL_CALL: "درخواست ابزار از نظر ساختار معتبر نیست.",
        INVALID_TOOL_ARGUMENTS: "پارامترهای ابزار JSON معتبر یا مطابق قرارداد نیستند.",
        TOOL_NOT_FOUND: "این ابزار در فهرست مجاز Worker وجود ندارد.",
        TOOL_DISABLED: "این ابزار در محیط فعلی غیرفعال است.",
        STEP_LIMIT_REACHED: "سقف تعداد مراحل این اجرا رسیده است.",
        EXECUTION_CANCELLED: "اجرای ابزار لغو شد.",
        TOOL_TIMEOUT: "زمان اجرای ابزار به پایان رسید.",
        TOOL_EXECUTION_FAILED: "اجرای ابزار ناموفق بود.",
        TOOL_RISK_BLOCKED: "سیاست امنیتی اجرای این ابزار را مجاز نمی‌داند.",
        APPROVAL_REQUIRED: "برای این عملیات تأیید صریح کاربر لازم است."
    };
    return messages[code] || "اجرای ابزار موفق نبود؛ نتیجه را به‌عنوان موفقیت گزارش نکن.";
}

function safeToolOutput(value) {
    try {
        const text = JSON.stringify(value);
        if (typeof text !== "string") return "{}";
        return new TextEncoder().encode(text).byteLength <= contracts_js_1.MAX_AGENT_TOOL_RESULT_BYTES
            ? text
            : JSON.stringify({ ok: false, code: "TOOL_RESULT_TOO_LARGE", message: "خروجی ابزار برای ارسال به مدل بیش از حد بزرگ است." });
    } catch {
        return JSON.stringify({ ok: false, code: "INVALID_TOOL_RESULT", message: "خروجی ابزار قابل سریال‌سازی نبود." });
    }
}

async function runAgentToolLoop({ registry, run, messages, callModel, toolChoice = "auto", requiredToolId = "", specialists = null, toolSpecialists = null, signal, onToolResult, onEvent, resumeState, onCheckpoint }) {
    if (!registry || !run || !Array.isArray(messages) || typeof callModel !== "function") {
        return { ok: false, code: "INVALID_TOOL_LOOP_CONTEXT" };
    }
    const tools = providerTools(registry, specialists, requiredToolId, toolSpecialists);
    const allowedSpecialists = allowedSpecialistsForRun(registry, specialists, requiredToolId, toolSpecialists);
    if (!tools.length) return { ok: false, code: "NO_TOOLS_AVAILABLE" };
    const validResume = resumeState && typeof resumeState === "object" &&
        Array.isArray(resumeState.conversation) && resumeState.conversation.length <= 80 &&
        Array.isArray(resumeState.results) && resumeState.results.length <= 20 &&
        Array.isArray(resumeState.pendingCalls) && resumeState.pendingCalls.length <= MAX_TOOL_CALLS_PER_ROUND &&
        Number.isInteger(resumeState.pendingIndex) && resumeState.pendingIndex >= 0 && resumeState.pendingIndex <= resumeState.pendingCalls.length &&
        Number.isInteger(resumeState.rounds) && resumeState.rounds >= 0 && resumeState.rounds <= MAX_TOOL_ROUNDS &&
        Number.isInteger(resumeState.calls) && resumeState.calls >= 0 && resumeState.calls <= 20 &&
        ["auto", "required", "none"].includes(resumeState.choice);
    if (resumeState && !validResume) return { ok: false, code: "CHECKPOINT_INVALID" };
    const conversation = validResume ? resumeState.conversation : messages.slice();
    const loopController = new AbortController();
    const parentSignal = signal;
    const abortFromParent = () => loopController.abort(parentSignal?.reason || "cancelled");
    if (parentSignal?.aborted) abortFromParent();
    else parentSignal?.addEventListener?.("abort", abortFromParent, { once: true });
    const loopTimer = setTimeout(() => loopController.abort("agent_tool_loop_timeout"), MAX_AGENT_LOOP_MS);
    const loopSignal = loopController.signal;
    let choice = validResume ? resumeState.choice : (toolChoice === "required" ? "required" : "auto");
    const mustUse = typeof requiredToolId === "string" && requiredToolId && typeof registry.has === "function" && registry.has(requiredToolId) ? requiredToolId : "";
    const results = validResume ? resumeState.results : [];
    // A required tool must be invoked, not necessarily succeed. Its failure is returned to the model so it can report a degraded result honestly.
    const requiredMissing = () => Boolean(mustUse) && !results.some(item => item.tool === mustUse);
    let rounds = validResume ? resumeState.rounds : 0;
    let calls = validResume ? resumeState.calls : 0;
    let pendingCalls = validResume ? resumeState.pendingCalls : [];
    let pendingIndex = validResume ? resumeState.pendingIndex : 0;
    let checkpointPersisted = false;
    let finalResult = null;
    const notify = (type, tool = "") => {
        try { onEvent?.({ type, ...(typeof tool === "string" && tool ? { tool: tool.slice(0, 64) } : {}) }); } catch { }
    };
    const persist = async state => {
        if (typeof onCheckpoint !== "function") return false;
        const snapshot = {
            conversation, rounds, calls, results, choice, mustUse,
            pendingCalls, pendingIndex, stepCount: run.stepCount
        };
        try {
            const saved = await onCheckpoint(snapshot, state);
            if (saved?.ok === true || saved === true) checkpointPersisted = true;
            return saved?.ok === true || saved === true;
        } catch { return false; }
    };
    const failWithCheckpoint = async (code, extra = {}) => {
        const ready = await persist("ready");
        return { ok: false, code, rounds, calls, results, resumeAvailable: ready || checkpointPersisted, ...extra };
    };

    try {
        // Persist the initial state before the first provider call. This is safe to resume
        // because no external tool has started yet.
        if (typeof onCheckpoint === "function" && !validResume) await persist("leased");
        while (rounds < MAX_TOOL_ROUNDS) {
            if (!pendingCalls.length) {
                if (loopSignal.aborted) return await failWithCheckpoint(loopSignal.reason === "agent_tool_loop_timeout" ? "AGENT_LOOP_TIMEOUT" : "EXECUTION_CANCELLED");
                notify("thinking");
                let response;
                try { response = await callModel(conversation, choice, tools, loopSignal); }
                catch { return await failWithCheckpoint("PROVIDER_FAILED", { providerResult: null }); }
                if (!response?.ok) return await failWithCheckpoint("PROVIDER_FAILED", { providerResult: response });
                finalResult = response;
                const modelMessage = response.data?.choices?.[0]?.message;
                pendingCalls = readToolCalls(response.data);
                if (!pendingCalls.length) {
                    notify("responding");
                    if (choice === "required" && calls === 0) return { ok: false, code: "REQUIRED_TOOL_NOT_CALLED", providerResult: response, rounds, calls, results };
                    if (requiredMissing()) return { ok: false, code: "REQUIRED_TOOL_NOT_CALLED", providerResult: response, rounds, calls, results };
                    return { ok: true, providerResult: response, messages: conversation, rounds, calls, results, checkpointPersisted };
                }
                rounds++;
                if (modelMessage && typeof modelMessage === "object") {
                    conversation.push({
                        role: "assistant",
                        ...(typeof modelMessage.content === "string" ? { content: modelMessage.content } : { content: null }),
                        tool_calls: pendingCalls.map((call, index) => {
                            const normalized = normalizeToolCall(call, index, run);
                            return {
                                id: normalized.id, type: "function",
                                function: {
                                    name: normalized.name || "unknown_tool",
                                    arguments: typeof call?.function?.arguments === "string" ? call.function.arguments : "{}"
                                }
                            };
                        })
                    });
                }
                pendingIndex = 0;
                // A model response is now durable. If the Worker stops before a tool starts,
                // the exact pending tool-call batch can be resumed without another model call.
                await persist("leased");
            }

            while (pendingIndex < pendingCalls.length) {
                if (loopSignal.aborted) return await failWithCheckpoint(loopSignal.reason === "agent_tool_loop_timeout" ? "AGENT_LOOP_TIMEOUT" : "EXECUTION_CANCELLED");
                const index = pendingIndex;
                const call = normalizeToolCall(pendingCalls[index], index, run);
                notify("tool_requested", call.name);
                // Mark the boundary before a handler can have an external effect. An interrupted
                // in-flight call is deliberately not auto-resumable, avoiding duplicate effects.
                const flightSaved = await persist("in_flight");
                // Never run a side-effecting handler unless the unsafe boundary is durable.
                // If checkpoint storage is enabled but unavailable, preserve the previous safe
                // snapshot and stop before invoking the tool.
                if (typeof onCheckpoint === "function" && !flightSaved) {
                    return await failWithCheckpoint("CHECKPOINT_WRITE_FAILED");
                }
                let outcome;
                let toolSpecialist = "main";
                let toolRisk = "read";
                let argsHash = "";
                const previousCall = results.some(item => item?.callId === call.id);
                const tool = !call.error ? registry.get(call.name) : null;
                if (tool) {
                    toolSpecialist = tool.specialist || "main";
                    toolRisk = tool.risk || "read";
                    try { argsHash = await tool_registry_js_1.approvalArgsHash(call.args); } catch { argsHash = ""; }
                }
                const specialistAllowed = Boolean(tool && (!allowedSpecialists || allowedSpecialists.has(tool.specialist || "main")));
                const previousEffect = Boolean(tool && toolRisk !== "read" && argsHash && results.some(item =>
                    item?.tool === call.name && item?.risk !== "read" && item?.argsHash === argsHash));
                if (previousCall) {
                    outcome = { ok: false, code: "DUPLICATE_TOOL_CALL_BLOCKED", message: "این شناسهٔ فراخوانی ابزار قبلاً در همین اجرا پردازش شده است؛ از اجرای دوباره خودداری شد." };
                } else if (tool && !specialistAllowed) {
                    outcome = { ok: false, code: "TOOL_SPECIALIST_NOT_IN_TEAM", message: "این ابزار به نقش تخصصی خارج از تیم هماهنگ فعلی تعلق دارد؛ اجرا نشد." };
                } else if (previousEffect) {
                    outcome = { ok: false, code: "DUPLICATE_SIDE_EFFECT_BLOCKED", message: "همین عملیات اثرگذار با همین ابزار و آرگومان‌ها قبلاً در این اجرا تلاش شده است؛ برای جلوگیری از اثر تکراری اجرا نشد." };
                } else if (tool && toolRisk !== "read" && !argsHash) {
                    outcome = { ok: false, code: "ACTION_FINGERPRINT_UNAVAILABLE", message: "اثر انگشت امن عملیات قابل محاسبه نبود؛ برای جلوگیری از اجرای تکراری، عملیات اجرا نشد." };
                } else if (call.error) {
                    outcome = { ok: false, code: call.error, message: resultMessage(call.error) };
                } else {
                    outcome = await (async () => {
                        if (!tool) return { ok: false, code: "TOOL_NOT_FOUND", message: resultMessage("TOOL_NOT_FOUND") };
                        const executed = await tool_registry_js_1.executeAgentTool(
                            registry, run, call.name, call.args,
                            { userInitiated: true, signal: loopSignal, onEvent: event => { if (event?.type === "started") notify("tool_started", call.name); } }
                        );
                        if (!executed.ok) return { ok: false, code: executed.code, message: executed.message || resultMessage(executed.code) };
                        return { ok: true, result: executed.result };
                    })();
                }
                calls++;
                const entry = {
                    tool: call.name || "unknown_tool", callId: call.id, specialist: toolSpecialist,
                    risk: toolRisk, ...(toolRisk !== "read" && argsHash ? { argsHash } : {}), outcome
                };
                results.push(entry);
                if (outcome.code === "APPROVAL_REQUIRED") {
                    const pendingTool = registry.get(call.name);
                    notify("approval_required", call.name);
                    try { onToolResult?.(entry); } catch { }
                    return {
                        ok: true, pendingApproval: {
                            toolId: call.name, callId: call.id, args: call.args,
                            risk: pendingTool?.risk || "unclassified",
                            description: pendingTool?.description || "برای این عملیات تأیید صریح لازم است.",
                            specialist: pendingTool?.specialist || "main"
                        }, rounds, calls, results, checkpointPersisted: false
                    };
                }
                notify(outcome.ok ? "tool_completed" : "tool_failed", call.name);
                try { onToolResult?.(entry); } catch { }
                conversation.push({ role: "tool", tool_call_id: call.id, content: safeToolOutput(outcome) });
                pendingIndex++;
                const safeSaved = await persist("leased");
                if (!safeSaved && flightSaved) checkpointPersisted = false;
            }

            pendingCalls = [];
            pendingIndex = 0;
            await persist("leased");
            notify("verifying");
            if (run.state === "executing") {
                runtime_js_1.transitionAgentRun(run, "verifying");
                runtime_js_1.transitionAgentRun(run, "responding");
            }
            choice = requiredMissing() ? "required" : "auto";
            if (run.stepCount >= contracts_js_1.MAX_AGENT_STEPS) {
                conversation.push({ role: "system", content: "سقف امن مراحل ابزار برای این اجرا تکمیل شده است. ابزار دیگری فراخوانی نکن؛ فقط بر اساس نتایج واقعی موجود پاسخ بده و محدودیت را در صورت اثرگذاری اعلام کن." });
                notify("thinking");
                let final;
                try { final = await callModel(conversation, "none", [], loopSignal); }
                catch { return await failWithCheckpoint("PROVIDER_FAILED", { providerResult: null }); }
                if (!final?.ok) return await failWithCheckpoint("PROVIDER_FAILED", { providerResult: final });
                notify("responding");
                if (requiredMissing()) return { ok: false, code: "REQUIRED_TOOL_NOT_CALLED", providerResult: final, rounds, calls, results };
                return { ok: true, providerResult: final, messages: conversation, rounds, calls, results, limitReached: true, checkpointPersisted };
            }
        }

        conversation.push({ role: "system", content: "حداکثر دورهای مجاز فراخوانی ابزار تمام شده است. ابزار دیگری در دسترس نیست؛ با شواهد فعلی پاسخ بده و اگر کار کامل نیست صریح بگو." });
        notify("thinking");
        let final;
        try { final = await callModel(conversation, "none", [], loopSignal); }
        catch { return await failWithCheckpoint("PROVIDER_FAILED", { providerResult: null }); }
        if (!final?.ok) return await failWithCheckpoint("PROVIDER_FAILED", { providerResult: final });
        notify("responding");
        if (requiredMissing()) return { ok: false, code: "REQUIRED_TOOL_NOT_CALLED", providerResult: final, rounds, calls, results };
        return { ok: true, providerResult: final, messages: conversation, rounds, calls, results, roundLimitReached: true, checkpointPersisted };
    } finally {
        clearTimeout(loopTimer);
        parentSignal?.removeEventListener?.("abort", abortFromParent);
    }
}
