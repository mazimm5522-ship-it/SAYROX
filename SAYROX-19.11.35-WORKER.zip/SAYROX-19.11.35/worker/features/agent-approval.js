"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.agentApprovalApi = agentApprovalApi;
const http_js_1 = __load("worker/shared/http.js");
const ticket_js_1 = __load("worker/agent/approval-tickets.js");
const registry_js_1 = __load("worker/agent/tool-registry.js");
const runtime_js_1 = __load("worker/agent/runtime.js");
const image_tools_js_1 = __load("worker/agent/image-tools.js");
const scheduled_tools_js_1 = __load("worker/agent/scheduled-task-tools.js");
const code_execution_tools_js_1 = __load("worker/agent/code-execution-tools.js");
const browser_tools_js_1 = __load("worker/agent/browser-tools.js");
const history_js_1 = __load("worker/features/agent-history.js");
const sessions_js_1 = __load("worker/security/sessions.js");

function usageStub(env, accountKey) {
    if (!env?.USAGE_ACCOUNT || typeof env.USAGE_ACCOUNT.idFromName !== "function" || typeof env.USAGE_ACCOUNT.get !== "function") throw new Error("APPROVAL_STORAGE_UNAVAILABLE");
    return env.USAGE_ACCOUNT.get(env.USAGE_ACCOUNT.idFromName(`xynora-account:${accountKey}`));
}
function approvalLabel(toolId, args = {}) {
    if (toolId === "generate_image") return {
        title: "تولید تصویر",
        impact: "یک تصویر جدید با موتور تصویری تنظیم‌شده ساخته می‌شود و یک واحد از سهمیهٔ تولید تصویر حساب مصرف خواهد شد."
    };
    if (toolId === "create_scheduled_task") return {
        title: "ایجاد کار زمان‌بندی‌شده",
        impact: "یک کار زمان‌بندی‌شده در حساب شما ثبت می‌شود و ممکن است در زمان‌های آینده به‌طور خودکار اجرا شود."
    };
    if (toolId === "manage_scheduled_task") {
        const actions = { pause: "توقف موقت", resume: "فعال‌سازی مجدد", run_now: "قرار دادن اجرا در صف فوری", update: "ویرایش تنظیمات" };
        const action = actions[args.action] || "تغییر کار";
        const details = [`شناسهٔ کار: ${String(args.taskId || "").slice(0, 36)}`];
        if (args.action === "update" && args.changes?.schedule) details.push(`زمان‌بندی جدید: ${JSON.stringify(args.changes.schedule).slice(0, 220)}`);
        if (args.action === "update" && args.changes?.title) details.push(`عنوان جدید: ${String(args.changes.title).slice(0, 80)}`);
        if (args.action === "update" && args.changes?.prompt) details.push(`دستور جدید: ${String(args.changes.prompt).replace(/[\u0000-\u001f\u007f]/g, " ").slice(0, 220)}`);
        if (args.action === "update" && args.changes?.useSearch !== undefined) details.push(`جست‌وجوی وب: ${args.changes.useSearch ? "فعال" : "خاموش"}`);
        return { title: `تأیید ${action} کار زمان‌بندی‌شده`, impact: "فقط همان کار متعلق به حساب شما تغییر می‌کند. اگر اجرا یا تغییر با خطا روبه‌رو شود، وضعیت واقعی گزارش خواهد شد.", details };
    }
    if (toolId === "delete_scheduled_task") return {
        title: "تأیید حذف کار زمان‌بندی‌شده",
        impact: "این کار برای همیشه از فهرست وظایف فعال حساب شما حذف می‌شود. سابقهٔ اجراهای ثبت‌شده نگه داشته خواهد شد.",
        details: [`شناسهٔ کار: ${String(args.taskId || "").slice(0, 36)}`]
    };
    if (toolId === "execute_python") return {
        title: "اجرای کد Python در Sandbox ایزوله",
        impact: "کد فقط پس از تأیید شما در یک Linux microVM مستقل اجرا می‌شود؛ اینترنت و کلیدهای API در دسترس کد نیستند. خروجی محدود و فضای اجرا موقت است."
    };
    if (toolId === "browser_interact") return {
        title: "تأیید تعامل با وب‌سایت",
        impact: "SAYROX پس از تأیید، فقط توالی کلیک/تکمیل فیلد/کلیدهای درخواستی را در یک نشست مرورگر کوتاه‌عمر اجرا می‌کند. رمزها، کدهای یک‌بارمصرف، پرداخت، خرید، حذف و ارسال نهایی مجاز نیستند. مقصدها به میزبان‌های مشخص‌شده برای همین نشست محدودند."
    };
    return { title: "عملیات حساس", impact: "این عملیات می‌تواند تغییری خارج از متن گفتگو ایجاد کند." };
}
function buildApprovedTool(ticket, env, accountKey, origin, generatedImages, browserImages) {
    if (ticket.toolId === "generate_image") {
        return (0, image_tools_js_1.createImageGenerationTool)({
            env, accountKey, origin,
            onGenerated(value) { if (generatedImages.length) throw new Error("image_delivery_limit_reached"); generatedImages.push(value); }
        });
    }
    if (ticket.toolId === "create_scheduled_task") {
        return (0, scheduled_tools_js_1.createScheduledTaskTool)({ env, accountKey, timezone: ticket.args?.schedule?.timezone || "Asia/Tehran" });
    }
    if (ticket.toolId === "manage_scheduled_task") return (0, scheduled_tools_js_1.createManageScheduledTaskTool)({ env, accountKey });
    if (ticket.toolId === "delete_scheduled_task") return (0, scheduled_tools_js_1.createDeleteScheduledTaskTool)({ env, accountKey });
    if (ticket.toolId === "execute_python") {
        return (0, code_execution_tools_js_1.createPythonExecutionTool)({ env, accountKey });
    }
    if (ticket.toolId === "browser_interact") {
        return (0, browser_tools_js_1.createBrowserInteractTool)({ env, accountKey, conversationId: ticket.conversationId || '', onScreenshot(value) { if (browserImages.length) throw new Error("browser_image_delivery_limit_reached"); browserImages.push(value); } });
    }
    return null;
}
async function persistApprovalOutcome(env, accountKey, ticket, state, code = "", success = false) {
    return (0, history_js_1.persistAgentRun)(env, accountKey, {
        runId: ticket.runId, specialist: ticket.specialist || "main", state,
        createdAt: ticket.issuedAt, updatedAt: Date.now(), durationMs: Math.max(0, Date.now() - ticket.issuedAt),
        stepCount: state === "cancelled" ? ticket.stepCount : Math.min(20, ticket.stepCount + 1),
        toolEvents: [{ tool: ticket.toolId, status: success ? "success" : state === "awaiting_approval" ? "pending" : state === "cancelled" ? "cancelled" : "failed", code }],
        researchStatus: ticket.researchStatus || "not_used", researchMode: ticket.researchMode || "none",
        sourceCount: Number(ticket.sourceCount) || 0,
        provider: ticket.provider || "", model: ticket.model || ""
    });
}
async function agentApprovalApi(request, env, trustedOptions = {}) {
    if (request.method !== "POST") return (0, http_js_1.json)({ ok: false, code: "METHOD_NOT_ALLOWED", message: "روش درخواست پشتیبانی نمی‌شود." }, 405);
    if (!(0, sessions_js_1.sameOriginRequest)(request)) return (0, http_js_1.json)({ ok: false, code: "CROSS_ORIGIN", message: "مبدأ درخواست معتبر نیست." }, 403);
    if (!trustedOptions.accountKey) return (0, http_js_1.json)({ ok: false, code: "AUTH_REQUIRED", message: "برای تأیید عملیات ابتدا وارد حساب شو." }, 401);
    let data;
    try { data = await (0, http_js_1.readJson)(request, 26_000); }
    catch (error) { return (0, http_js_1.json)({ ok: false, code: "INVALID_REQUEST", message: error?.message || "درخواست معتبر نیست." }, 400); }
    const token = typeof data.ticket === "string" ? data.ticket : "";
    const decision = data.decision === "approve" ? "approved" : data.decision === "deny" ? "denied" : "";
    if (!decision || !token) return (0, http_js_1.json)({ ok: false, code: "INVALID_APPROVAL_REQUEST", message: "درخواست تأیید معتبر نیست." }, 400);
    const ticket = await (0, ticket_js_1.openAgentApprovalTicket)(env, token);
    if (!ticket || ticket.accountKey !== trustedOptions.accountKey) return (0, http_js_1.json)({ ok: false, code: "APPROVAL_TICKET_INVALID", message: "مجوز معتبر نیست یا منقضی شده است؛ درخواست را دوباره ارسال کن." }, 403);
    const label = approvalLabel(ticket.toolId, ticket.args);
    if (decision === "denied") {
        try {
            const consumed = await usageStub(env, trustedOptions.accountKey).consumeAgentApproval(ticket.ticketId, trustedOptions.accountKey, ticket.expiresAt, "denied", Date.now());
            if (!consumed?.ok) return (0, http_js_1.json)({ ok: false, code: consumed?.code || "APPROVAL_REPLAYED", message: "این کارت قبلاً تعیین تکلیف شده یا منقضی شده است." }, 409);
        } catch {
            return (0, http_js_1.json)({ ok: false, code: "APPROVAL_STORAGE_UNAVAILABLE", message: "ثبت لغو عملیات در ذخیره‌ساز امن انجام نشد؛ هیچ عملیاتی اجرا نشده است." }, 503);
        }
        await persistApprovalOutcome(env, trustedOptions.accountKey, ticket, "cancelled", "USER_DENIED", false);
        return (0, http_js_1.json)({ ok: true, approved: false, message: "عملیات طبق انتخاب شما لغو شد." });
    }
    const generatedImages = [];
    const browserImages = [];
    const definition = buildApprovedTool(ticket, env, trustedOptions.accountKey, new URL(request.url).origin, generatedImages, browserImages);
    if (!definition || definition.requiresApproval !== true || definition.id !== ticket.toolId || definition.validateArgs(ticket.args) !== true) {
        return (0, http_js_1.json)({ ok: false, code: "APPROVAL_TOOL_UNAVAILABLE", message: "این ابزار در نسخهٔ فعلی برای اجرای تأییدشده در دسترس نیست؛ هیچ عملیاتی اجرا نشد." }, 409);
    }
    try {
        const consumed = await usageStub(env, trustedOptions.accountKey).consumeAgentApproval(ticket.ticketId, trustedOptions.accountKey, ticket.expiresAt, "approved", Date.now());
        if (!consumed?.ok) return (0, http_js_1.json)({ ok: false, code: consumed?.code || "APPROVAL_REPLAYED", message: "این مجوز قبلاً استفاده شده یا منقضی شده است." }, 409);
    } catch {
        return (0, http_js_1.json)({ ok: false, code: "APPROVAL_STORAGE_UNAVAILABLE", message: "کنترل یک‌بارمصرف مجوز در دسترس نیست؛ برای امنیت عملیات اجرا نشد." }, 503);
    }
    const registry = (0, registry_js_1.createToolRegistry)([definition]);
    const run = (0, runtime_js_1.createAgentRun)(ticket.runId);
    (0, runtime_js_1.transitionAgentRun)(run, "understanding");
    (0, runtime_js_1.transitionAgentRun)(run, "planning");
    run.pendingApprovalToolId = ticket.toolId;
    (0, runtime_js_1.transitionAgentRun)(run, "awaiting_approval");
    const grant = {
        runId: ticket.runId, toolId: ticket.toolId, grantId: ticket.ticketId,
        confirmed: true, confirmedAt: Date.now(), argsHash: ticket.argsHash
    };
    const result = await (0, registry_js_1.executeAgentTool)(registry, run, ticket.toolId, ticket.args, { userInitiated: true, approvalGrant: grant, signal: request.signal });
    if (!result.ok || result.result?.ok === false) {
        const failureCode = result.code || result.result?.code || "APPROVED_TOOL_FAILED";
        const failureMessage = result.message || result.result?.message || "عملیات تأیید شد اما با موفقیت اجرا نشد؛ دوباره‌استفاده از این مجوز ممکن نیست.";
        (0, runtime_js_1.finishAgentRun)(run, "failed");
        await persistApprovalOutcome(env, trustedOptions.accountKey, ticket, "failed", failureCode, false);
        return (0, http_js_1.json)({ ok: false, code: failureCode, message: failureMessage }, 502);
    }
    (0, runtime_js_1.transitionAgentRun)(run, "verifying");
    (0, runtime_js_1.finishAgentRun)(run, "completed");
    await persistApprovalOutcome(env, trustedOptions.accountKey, ticket, "completed", "", true);
    return (0, http_js_1.json)({
        ok: true, approved: true, toolId: ticket.toolId, title: label.title,
        message: ticket.toolId === "generate_image" ? "تصویر با موفقیت ساخته شد." : ticket.toolId === "create_scheduled_task" ? "کار زمان‌بندی‌شده با موفقیت ثبت شد." : ticket.toolId === "manage_scheduled_task" ? "تغییر تأییدشده روی کار زمان‌بندی‌شده انجام شد." : ticket.toolId === "delete_scheduled_task" ? "کار زمان‌بندی‌شده حذف شد." : ticket.toolId === "browser_interact" ? "تعامل تأییدشده با مرورگر اجرا شد." : "کد Python در محیط ایزوله اجرا شد.",
        result: result.result,
        ...(generatedImages.length ? { image: generatedImages[0] } : {}),
        ...(browserImages.length ? { image: browserImages[0] } : {})
    });
}
