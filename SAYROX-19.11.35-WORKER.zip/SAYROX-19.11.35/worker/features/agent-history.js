"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.agentHistoryApi = agentHistoryApi;
exports.persistAgentRun = persistAgentRun;
exports.saveAgentCheckpoint = saveAgentCheckpoint;
exports.claimAgentCheckpoint = claimAgentCheckpoint;
exports.releaseAgentCheckpoint = releaseAgentCheckpoint;
exports.deleteAgentCheckpoint = deleteAgentCheckpoint;
exports.claimAgentBrowserSession = claimAgentBrowserSession;
exports.saveAgentBrowserSession = saveAgentBrowserSession;
exports.releaseAgentBrowserSession = releaseAgentBrowserSession;
exports.deleteAgentBrowserSession = deleteAgentBrowserSession;
const http_js_1 = __load("worker/shared/http.js");
const sessions_js_1 = __load("worker/security/sessions.js");
const passwords_js_1 = __load("worker/security/passwords.js");
const CHECKPOINT_TTL_MS = 30 * 60_000;
const MAX_CHECKPOINT_BYTES = 512_000;
const BROWSER_SESSION_TTL_MS = 15 * 60_000;
const MAX_BROWSER_SESSION_BYTES = 24_000;

function accountStub(env, accountKey) {
    if (!env?.USAGE_ACCOUNT || !accountKey) throw new Error("AGENT_HISTORY_UNAVAILABLE");
    return env.USAGE_ACCOUNT.get(env.USAGE_ACCOUNT.idFromName(`xynora-account:${accountKey}`));
}

function normalizeRunRecord(input = {}) {
    const events = Array.isArray(input.toolEvents) ? input.toolEvents.slice(0, 20).map(event => ({
        tool: (0, http_js_1.text)(event?.tool, 64).toLowerCase(),
        specialist: ['main', 'research', 'coding', 'documents', 'data', 'creative'].includes(String(event?.specialist || '')) ? String(event.specialist) : 'main',
        status: event?.status === "success" ? "success" : event?.status === "pending" ? "pending" : event?.status === "cancelled" ? "cancelled" : "failed",
        code: (0, http_js_1.text)(event?.code, 64).toUpperCase()
    })) : [];
    return {
        runId: (0, http_js_1.text)(input.runId, 36),
        specialist: (0, http_js_1.text)(input.specialist, 24),
        state: (0, http_js_1.text)(input.state, 16),
        createdAt: Number(input.createdAt) || Date.now(),
        updatedAt: Number(input.updatedAt) || Date.now(),
        durationMs: Math.max(0, Math.min(600000, Math.trunc(Number(input.durationMs) || 0))),
        stepCount: Math.max(0, Math.min(20, Math.trunc(Number(input.stepCount) || 0))),
        toolEvents: events,
        researchStatus: (0, http_js_1.text)(input.researchStatus, 16),
        researchMode: (0, http_js_1.text)(input.researchMode, 8),
        sourceCount: Math.max(0, Math.min(20, Math.trunc(Number(input.sourceCount) || 0))),
        provider: (0, http_js_1.text)(input.provider, 16),
        model: (0, http_js_1.text)(input.model, 120),
        failureCode: (0, http_js_1.text)(input.failureCode, 64).toUpperCase()
    };
}

async function persistAgentRun(env, accountKey, record) {
    if (!accountKey) return { ok: false, code: "ACCOUNT_REQUIRED" };
    try {
        return await accountStub(env, accountKey).recordAgentRun(normalizeRunRecord(record));
    } catch {
        return { ok: false, code: "AGENT_HISTORY_UNAVAILABLE" };
    }
}


function checkpointKey(env) {
    const secret = typeof env?.AUTH_SESSION_SECRET === "string" ? env.AUTH_SESSION_SECRET : "";
    if (secret.length < 32) throw new Error("AGENT_CHECKPOINT_SECRET_UNAVAILABLE");
    return crypto.subtle.digest("SHA-256", new TextEncoder().encode(`sayrox-agent-checkpoint-v1:${secret}`))
        .then(material => crypto.subtle.importKey("raw", material, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]));
}
function checkpointAad(accountKey, runId) {
    return new TextEncoder().encode(`SAYROX_AGENT_CHECKPOINT_V1:${accountKey}:${runId}`);
}
async function saveAgentCheckpoint(env, accountKey, runId, snapshot, leaseToken, state = "leased") {
    if (!/^[A-Za-z0-9_-]{43}$/.test(String(accountKey || "")) || !/^[0-9a-f-]{36}$/i.test(String(runId || "")) ||
        !/^[0-9a-f-]{36}$/i.test(String(leaseToken || "")) || !snapshot || typeof snapshot !== "object" ||
        snapshot.v !== 1 || snapshot.runId !== runId || !Number.isSafeInteger(snapshot.createdAt) ||
        !Number.isSafeInteger(snapshot.expiresAt) || snapshot.expiresAt <= Date.now() ||
        !["leased", "in_flight", "ready"].includes(state)) return { ok: false, code: "INVALID_AGENT_CHECKPOINT" };
    try {
        const plaintext = new TextEncoder().encode(JSON.stringify({ ...snapshot, accountKey }));
        if (!plaintext.byteLength || plaintext.byteLength > MAX_CHECKPOINT_BYTES) return { ok: false, code: "CHECKPOINT_TOO_LARGE" };
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const key = await checkpointKey(env);
        const ciphertext = new Uint8Array(await crypto.subtle.encrypt({ name: "AES-GCM", iv, additionalData: checkpointAad(accountKey, runId), tagLength: 128 }, key, plaintext));
        const packed = `${(0, passwords_js_1.base64url)(iv)}.${(0, passwords_js_1.base64url)(ciphertext)}`;
        return await accountStub(env, accountKey).saveAgentCheckpoint(runId, packed, snapshot.expiresAt, leaseToken, state, Date.now());
    } catch {
        return { ok: false, code: "AGENT_CHECKPOINT_UNAVAILABLE" };
    }
}
async function claimAgentCheckpoint(env, accountKey, runId) {
    if (!/^[A-Za-z0-9_-]{43}$/.test(String(accountKey || "")) || !/^[0-9a-f-]{36}$/i.test(String(runId || ""))) return { ok: false, code: "INVALID_AGENT_CHECKPOINT" };
    let claim;
    try { claim = await accountStub(env, accountKey).claimAgentCheckpoint(runId, Date.now()); }
    catch { return { ok: false, code: "AGENT_CHECKPOINT_UNAVAILABLE" }; }
    if (!claim?.ok) return claim || { ok: false, code: "CHECKPOINT_NOT_FOUND" };
    try {
        const [ivText, cipherText, extra] = String(claim.payload || "").split(".");
        if (!ivText || !cipherText || extra !== undefined || !/^[A-Za-z0-9_-]{16}$/.test(ivText) || !/^[A-Za-z0-9_-]+$/.test(cipherText)) throw new Error("invalid_checkpoint_encoding");
        const iv = (0, passwords_js_1.fromBase64url)(ivText), ciphertext = (0, passwords_js_1.fromBase64url)(cipherText);
        if (iv.byteLength !== 12 || ciphertext.byteLength < 16 || ciphertext.byteLength > MAX_CHECKPOINT_BYTES + 16 ||
            (0, passwords_js_1.base64url)(iv) !== ivText || (0, passwords_js_1.base64url)(ciphertext) !== cipherText) throw new Error("invalid_checkpoint_encoding");
        const key = await checkpointKey(env);
        const plaintext = await crypto.subtle.decrypt({ name: "AES-GCM", iv, additionalData: checkpointAad(accountKey, runId), tagLength: 128 }, key, ciphertext);
        const snapshot = JSON.parse(new TextDecoder().decode(plaintext));
        if (!snapshot || snapshot.v !== 1 || snapshot.runId !== runId || snapshot.accountKey !== accountKey ||
            !Number.isSafeInteger(snapshot.createdAt) || !Number.isSafeInteger(snapshot.expiresAt) || snapshot.expiresAt <= Date.now() ||
            !snapshot.input || typeof snapshot.input !== "object" || !snapshot.loop || typeof snapshot.loop !== "object" ||
            !Array.isArray(snapshot.loop.conversation) || snapshot.loop.conversation.length > 80 ||
            !Array.isArray(snapshot.loop.results) || snapshot.loop.results.length > 20) throw new Error("invalid_checkpoint_payload");
        return { ok: true, snapshot, leaseToken: claim.leaseToken };
    } catch {
        try { await accountStub(env, accountKey).deleteAgentCheckpoint(runId, claim.leaseToken); } catch { }
        return { ok: false, code: "CHECKPOINT_INVALID" };
    }
}
async function releaseAgentCheckpoint(env, accountKey, runId, leaseToken) {
    try { return await accountStub(env, accountKey).releaseAgentCheckpoint(runId, leaseToken, Date.now()); }
    catch { return { ok: false, code: "AGENT_CHECKPOINT_UNAVAILABLE" }; }
}
async function deleteAgentCheckpoint(env, accountKey, runId, leaseToken = "") {
    try { return await accountStub(env, accountKey).deleteAgentCheckpoint(runId, leaseToken); }
    catch { return { ok: false, code: "AGENT_CHECKPOINT_UNAVAILABLE" }; }
}

function browserSessionAad(accountKey, conversationId) {
    return new TextEncoder().encode(`SAYROX_AGENT_BROWSER_SESSION_V1:${accountKey}:${conversationId}`);
}
function validBrowserSessionSnapshot(snapshot, conversationId, now = Date.now()) {
    return Boolean(snapshot && typeof snapshot === 'object' && snapshot.v === 1 &&
        snapshot.conversationId === conversationId && typeof snapshot.sessionId === 'string' &&
        /^[A-Za-z0-9_-]{8,200}$/.test(snapshot.sessionId) && Array.isArray(snapshot.allowedHosts) &&
        snapshot.allowedHosts.length >= 1 && snapshot.allowedHosts.length <= 50 &&
        Array.isArray(snapshot.tabs) && snapshot.tabs.length >= 1 && snapshot.tabs.length <= 5 &&
        snapshot.tabs.every(tab => tab && typeof tab === 'object' && /^tab-[1-5]$/.test(tab.id) && /^[A-Za-z0-9_-]{1,200}$/.test(String(tab.targetId || ''))) &&
        snapshot.tabs.some(tab => tab.id === snapshot.activeTab) && Number.isInteger(snapshot.nextTab) &&
        snapshot.nextTab >= 1 && snapshot.nextTab <= 5 && typeof snapshot.inFlight === 'boolean' &&
        Number.isSafeInteger(snapshot.createdAt) && snapshot.createdAt <= now + 30_000 &&
        typeof snapshot.lastAction === 'string' && snapshot.lastAction.length <= 64);
}
async function saveAgentBrowserSession(env, accountKey, conversationId, snapshot, leaseToken) {
    if (!/^[A-Za-z0-9_-]{43}$/.test(String(accountKey || '')) || !/^[0-9a-f-]{36}$/i.test(String(conversationId || '')) ||
        !/^[0-9a-f-]{36}$/i.test(String(leaseToken || '')) || !validBrowserSessionSnapshot(snapshot, conversationId))
        return { ok: false, code: 'INVALID_AGENT_BROWSER_SESSION' };
    try {
        const bytes = new TextEncoder().encode(JSON.stringify({ ...snapshot, accountKey }));
        if (!bytes.byteLength || bytes.byteLength > MAX_BROWSER_SESSION_BYTES) return { ok: false, code: 'BROWSER_SESSION_TOO_LARGE' };
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const key = await checkpointKey(env);
        const cipher = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: browserSessionAad(accountKey, conversationId), tagLength: 128 }, key, bytes));
        const packed = `${(0, passwords_js_1.base64url)(iv)}.${(0, passwords_js_1.base64url)(cipher)}`;
        return await accountStub(env, accountKey).saveAgentBrowserSession(conversationId, packed, leaseToken, Date.now() + BROWSER_SESSION_TTL_MS, Date.now());
    } catch { return { ok: false, code: 'AGENT_BROWSER_SESSION_UNAVAILABLE' }; }
}
async function claimAgentBrowserSession(env, accountKey, conversationId) {
    if (!/^[A-Za-z0-9_-]{43}$/.test(String(accountKey || '')) || !/^[0-9a-f-]{36}$/i.test(String(conversationId || '')))
        return { ok: false, code: 'INVALID_AGENT_BROWSER_SESSION' };
    const leaseToken = crypto.randomUUID();
    let claim;
    try { claim = await accountStub(env, accountKey).claimAgentBrowserSession(conversationId, leaseToken, Date.now()); }
    catch { return { ok: false, code: 'AGENT_BROWSER_SESSION_UNAVAILABLE' }; }
    if (!claim?.ok) return claim || { ok: false, code: 'BROWSER_SESSION_UNAVAILABLE' };
    if (!claim.found) return { ok: true, session: null, leaseToken };
    try {
        const [ivText, cipherText, extra] = String(claim.payload || '').split('.');
        if (!ivText || !cipherText || extra !== undefined || !/^[A-Za-z0-9_-]{16}$/.test(ivText) || !/^[A-Za-z0-9_-]+$/.test(cipherText)) throw new Error('invalid_browser_session_encoding');
        const iv = (0, passwords_js_1.fromBase64url)(ivText), cipher = (0, passwords_js_1.fromBase64url)(cipherText);
        if (iv.byteLength !== 12 || cipher.byteLength < 16 || cipher.byteLength > MAX_BROWSER_SESSION_BYTES + 16 ||
            (0, passwords_js_1.base64url)(iv) !== ivText || (0, passwords_js_1.base64url)(cipher) !== cipherText) throw new Error('invalid_browser_session_encoding');
        const key = await checkpointKey(env);
        const plaintext = await crypto.subtle.decrypt({ name: 'AES-GCM', iv, additionalData: browserSessionAad(accountKey, conversationId), tagLength: 128 }, key, cipher);
        const snapshot = JSON.parse(new TextDecoder().decode(plaintext));
        if (snapshot.accountKey !== accountKey || !validBrowserSessionSnapshot(snapshot, conversationId)) throw new Error('invalid_browser_session_payload');
        return { ok: true, session: snapshot, leaseToken };
    } catch {
        try { await accountStub(env, accountKey).deleteAgentBrowserSession(conversationId, leaseToken); } catch { }
        return { ok: false, code: 'BROWSER_SESSION_INVALID' };
    }
}
async function releaseAgentBrowserSession(env, accountKey, conversationId, leaseToken, keep = true) {
    try { return await accountStub(env, accountKey).releaseAgentBrowserSession(conversationId, leaseToken, keep, Date.now()); }
    catch { return { ok: false, code: 'AGENT_BROWSER_SESSION_UNAVAILABLE' }; }
}
async function deleteAgentBrowserSession(env, accountKey, conversationId, leaseToken) {
    try { return await accountStub(env, accountKey).deleteAgentBrowserSession(conversationId, leaseToken); }
    catch { return { ok: false, code: 'AGENT_BROWSER_SESSION_UNAVAILABLE' }; }
}

async function agentHistoryApi(request, env, session, pathname) {
    if (!session?.accountKey) return (0, http_js_1.json)({ ok: false, code: "AUTH_REQUIRED", message: "برای مشاهدهٔ تاریخچهٔ Agent ابتدا وارد حساب شو." }, 401);
    if (!(0, sessions_js_1.sameOriginRequest)(request)) return (0, http_js_1.json)({ ok: false, code: "CROSS_ORIGIN", message: "مبدأ درخواست معتبر نیست." }, 403);
    let stub;
    try { stub = accountStub(env, session.accountKey); }
    catch { return (0, http_js_1.json)({ ok: false, code: "AGENT_HISTORY_UNAVAILABLE", message: "ذخیره‌ساز تاریخچهٔ Agent در دسترس نیست." }, 503); }

    if (pathname === "/api/agent/runs" && request.method === "GET") {
        const params = new URL(request.url).searchParams;
        const requestedLimit = Number(params.get("limit"));
        const requestedOffset = Number(params.get("offset"));
        const limit = Number.isSafeInteger(requestedLimit) ? Math.max(1, Math.min(50, requestedLimit)) : 30;
        const offset = Number.isSafeInteger(requestedOffset) ? Math.max(0, Math.min(100, requestedOffset)) : 0;
        try {
            const result = await stub.listAgentRuns(limit, offset);
            if (!result?.ok) throw new Error("list_failed");
            const runs = Array.isArray(result.runs) ? result.runs.slice(0, limit) : [];
            return (0, http_js_1.json)({ ok: true, runs, hasMore: result.hasMore === true, offset, nextOffset: offset + runs.length, retentionDays: 90, maxRuns: 100 });
        } catch {
            return (0, http_js_1.json)({ ok: false, code: "AGENT_HISTORY_UNAVAILABLE", message: "دریافت تاریخچهٔ Agent موقتاً ممکن نیست." }, 503);
        }
    }

    if (pathname === "/api/agent/runs" && request.method === "POST") {
        let data;
        try { data = await (0, http_js_1.readJson)(request, 2000); }
        catch (error) { return (0, http_js_1.json)({ ok: false, code: "INVALID_REQUEST", message: error?.message || "درخواست معتبر نیست." }, 400); }
        const action = (0, http_js_1.text)(data.action, 16);
        try {
            if (action === "delete") {
                const id = (0, http_js_1.text)(data.runId, 36);
                const result = await stub.deleteAgentRun(id);
                return result?.ok ? (0, http_js_1.json)({ ok: true }) : (0, http_js_1.json)({ ok: false, code: result?.code || "DELETE_FAILED", message: "اجرای موردنظر پیدا نشد یا شناسه معتبر نیست." }, 400);
            }
            if (action === "clear") {
                const result = await stub.clearAgentRuns();
                return result?.ok ? (0, http_js_1.json)({ ok: true }) : (0, http_js_1.json)({ ok: false, code: "CLEAR_FAILED", message: "پاک‌کردن تاریخچه انجام نشد." }, 503);
            }
            return (0, http_js_1.json)({ ok: false, code: "INVALID_ACTION", message: "عملیات تاریخچه شناخته نشد." }, 400);
        } catch {
            return (0, http_js_1.json)({ ok: false, code: "AGENT_HISTORY_UNAVAILABLE", message: "عملیات تاریخچه موقتاً ممکن نیست." }, 503);
        }
    }

    const match = /^\/api\/agent\/runs\/([0-9a-f-]{36})$/i.exec(pathname);
    if (match && request.method === "GET") {
        try {
            const result = await stub.getAgentRun(match[1]);
            return result?.ok ? (0, http_js_1.json)({ ok: true, run: result.run }) : (0, http_js_1.json)({ ok: false, code: "AGENT_RUN_NOT_FOUND", message: "اجرای موردنظر پیدا نشد." }, 404);
        } catch {
            return (0, http_js_1.json)({ ok: false, code: "AGENT_HISTORY_UNAVAILABLE", message: "دریافت جزئیات اجرا موقتاً ممکن نیست." }, 503);
        }
    }
    return (0, http_js_1.json)({ ok: false, code: "NOT_FOUND", message: "مسیر تاریخچه پیدا نشد." }, 404);
}
