"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.googleAuthReady = googleAuthReady;
exports.googleOAuthStart = googleOAuthStart;
exports.googleOAuthLinkStart = googleOAuthLinkStart;
exports.googleOAuthCallback = googleOAuthCallback;
const http_js_1 = __load("worker/shared/http.js");
const passwords_js_1 = __load("worker/security/passwords.js");
const sessions_js_1 = __load("worker/security/sessions.js");
const GOOGLE_AUTH_ENDPOINT = 'https://accounts.google.com/o/oauth2/v2/auth';
const GOOGLE_TOKEN_ENDPOINT = 'https://oauth2.googleapis.com/token';
const GOOGLE_JWKS_ENDPOINT = 'https://www.googleapis.com/oauth2/v3/certs';
const STATE_COOKIE = 'sayrox_google_oauth';
const STATE_TTL_SECONDS = 600;
const encoder = new TextEncoder();
let jwksCache = null;
let jwksCacheUntil = 0;
function googleAuthReady(env) {
  return typeof env?.GOOGLE_CLIENT_ID === 'string' && env.GOOGLE_CLIENT_ID.trim().length > 10 &&
    typeof env?.GOOGLE_CLIENT_SECRET === 'string' && env.GOOGLE_CLIENT_SECRET.trim().length > 10;
}
function randomToken(bytes = 32) {
  return (0, passwords_js_1.base64url)(crypto.getRandomValues(new Uint8Array(bytes)));
}
function decodeJsonSegment(segment, maxLength = 8192) {
  if (typeof segment !== 'string' || segment.length > maxLength || !/^[A-Za-z0-9_-]+$/.test(segment)) throw new Error('invalid_token_segment');
  return JSON.parse(new TextDecoder().decode((0, passwords_js_1.fromBase64url)(segment)));
}
async function stateSignature(env, encoded) {
  return (0, sessions_js_1.signSessionPayload)(env, `sayrox/google-oauth-state/v1.${encoded}`);
}
async function makeStateCookie(env, payload) {
  const encoded = (0, passwords_js_1.base64url)(encoder.encode(JSON.stringify(payload)));
  const value = `${encoded}.${await stateSignature(env, encoded)}`;
  return `${STATE_COOKIE}=${value}; Path=/api/auth/google; HttpOnly; Secure; SameSite=Lax; Max-Age=${STATE_TTL_SECONDS}`;
}
function clearStateCookie() {
  return `${STATE_COOKIE}=; Path=/api/auth/google; HttpOnly; Secure; SameSite=Lax; Max-Age=0`;
}
async function readStateCookie(request, env) {
  const value = (0, sessions_js_1.cookieValue)(request, STATE_COOKIE);
  if (!value || value.length > 4096) return null;
  const [encoded, signature, extra] = value.split('.');
  if (!encoded || !signature || extra !== undefined) return null;
  const expected = await stateSignature(env, encoded);
  if (!(0, passwords_js_1.constantTimeEqual)(signature, expected)) return null;
  try {
    const payload = decodeJsonSegment(encoded, 3072);
    const age = Math.floor(Date.now() / 1000) - Number(payload.issuedAt);
    if (!['signin', 'link'].includes(payload.purpose || 'signin') ||
        (payload.purpose === 'link' && (!/^[A-Za-z0-9_-]{43}$/.test(payload.accountKey || '') || typeof payload.userId !== 'string' || typeof payload.email !== 'string')) ||
        !/^[A-Za-z0-9_-]{43}$/.test(payload.state || '') ||
        !/^[A-Za-z0-9_-]{43}$/.test(payload.nonce || '') ||
        !/^[A-Za-z0-9_-]{43,128}$/.test(payload.verifier || '') ||
        !Number.isSafeInteger(Number(payload.issuedAt)) || age < 0 || age > STATE_TTL_SECONDS) return null;
    return payload;
  } catch { return null; }
}
function redirectHome(request, result, cookies = []) {
  const target = new URL('/', new URL(request.url).origin);
  if (result) target.searchParams.set('auth', result);
  const headers = new Headers({
    location: target.toString(),
    'cache-control': 'no-store',
    'referrer-policy': 'no-referrer',
    'x-content-type-options': 'nosniff'
  });
  for (const cookie of cookies.filter(Boolean)) headers.append('set-cookie', cookie);
  return new Response(null, { status: 303, headers });
}
async function beginGoogleAuthorization(request, env, payload) {
  const requestUrl = new URL(request.url);
  const origin = requestUrl.origin;
  const redirectUri = `${origin}/api/auth/google/callback`;
  const state = randomToken();
  const nonce = randomToken();
  const verifier = randomToken(48);
  const challenge = (0, passwords_js_1.base64url)(new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(verifier))));
  const url = new URL(GOOGLE_AUTH_ENDPOINT);
  url.search = new URLSearchParams({
    client_id: env.GOOGLE_CLIENT_ID.trim(), redirect_uri: redirectUri, response_type: 'code',
    scope: 'openid email profile', state, nonce, code_challenge: challenge,
    code_challenge_method: 'S256', prompt: 'select_account'
  }).toString();
  const cookie = await makeStateCookie(env, {
    ...payload, purpose: payload?.purpose || 'signin', state, nonce, verifier,
    issuedAt: Math.floor(Date.now() / 1000)
  });
  return new Response(null, { status: 302, headers: {
    location: url.toString(), 'set-cookie': cookie, 'cache-control': 'no-store', 'referrer-policy': 'no-referrer'
  } });
}
async function googleOAuthLinkStart(request, env) {
  if (request.method !== 'POST') return (0, http_js_1.json)({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
  if (!(0, sessions_js_1.sameOriginRequest)(request)) return (0, http_js_1.json)({ ok: false, message: 'درخواست بین‌مبدأیی مجاز نیست.' }, 403);
  if (!googleAuthReady(env)) return (0, http_js_1.json)({ ok: false, code: 'GOOGLE_AUTH_NOT_CONFIGURED', message: 'اتصال Google هنوز در Cloudflare پیکربندی نشده است.' }, 503);
  const requestUrl = new URL(request.url);
  if (requestUrl.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(requestUrl.hostname)) return (0, http_js_1.json)({ ok: false, message: 'اتصال Google فقط از HTTPS امکان‌پذیر است.' }, 400);
  const session = await (0, sessions_js_1.authenticatedSession)(request, env);
  if (!session?.user || session.accountKey !== await (0, passwords_js_1.sha256)(session.user.email)) {
    return (0, http_js_1.json)({ ok: false, message: 'برای اتصال Google ابتدا با حساب SAYROX وارد شو.' }, 401);
  }
  const attempt = await (0, sessions_js_1.recordAuthAttempt)(request, env, `google-link:${session.accountKey}`);
  if (!attempt.available) return (0, http_js_1.json)({ ok: false, message: 'سرویس کنترل امنیت ورود موقتاً در دسترس نیست.' }, 503);
  if (!attempt.allowed) return (0, http_js_1.json)({ ok: false, message: 'تعداد تلاش‌ها زیاد است. کمی بعد دوباره امتحان کن.' }, 429);
  return beginGoogleAuthorization(request, env, {
    purpose: 'link', accountKey: session.accountKey, userId: session.user.id,
    email: session.user.email
  });
}
async function googleOAuthStart(request, env) {
  if (request.method !== 'GET') return (0, http_js_1.json)({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
  if (!googleAuthReady(env)) return (0, http_js_1.json)({ ok: false, code: 'GOOGLE_AUTH_NOT_CONFIGURED', message: 'ورود با Google هنوز در Cloudflare پیکربندی نشده است.' }, 503);
  const requestUrl = new URL(request.url);
  if (requestUrl.protocol !== 'https:' && !['localhost', '127.0.0.1'].includes(requestUrl.hostname)) return (0, http_js_1.json)({ ok: false, message: 'ورود Google فقط از اتصال امن HTTPS امکان‌پذیر است.' }, 400);
  const attempt = await (0, sessions_js_1.recordAuthAttempt)(request, env, 'google-oauth-start');
  if (!attempt.available) return (0, http_js_1.json)({ ok: false, message: 'سرویس کنترل امنیت ورود موقتاً در دسترس نیست.' }, 503);
  if (!attempt.allowed) return redirectHome(request, 'google_retry');
  return beginGoogleAuthorization(request, env, { purpose: 'signin' });
}
async function googleJwks() {
  const now = Date.now();
  if (jwksCache && jwksCacheUntil > now) return jwksCache;
  const response = await fetch(GOOGLE_JWKS_ENDPOINT, { headers: { accept: 'application/json' }, signal: AbortSignal.timeout(10000) });
  if (!response.ok) throw new Error('google_jwks_unavailable');
  const data = await response.json();
  if (!Array.isArray(data.keys) || !data.keys.length) throw new Error('google_jwks_invalid');
  jwksCache = data.keys;
  const cacheControl = response.headers.get('cache-control') || '';
  const maxAge = Number(cacheControl.match(/(?:^|,)\s*max-age=(\d+)/i)?.[1] || 300);
  jwksCacheUntil = now + Math.min(6 * 60 * 60, Math.max(60, maxAge)) * 1000;
  return jwksCache;
}
async function verifyGoogleIdToken(token, expectedNonce, clientId) {
  if (typeof token !== 'string' || token.length > 16384) throw new Error('google_id_token_invalid');
  const parts = token.split('.');
  if (parts.length !== 3) throw new Error('google_id_token_invalid');
  const header = decodeJsonSegment(parts[0], 2048);
  const claims = decodeJsonSegment(parts[1], 8192);
  if (header.alg !== 'RS256' || typeof header.kid !== 'string' || header.kid.length > 256) throw new Error('google_id_token_algorithm_invalid');
  const keys = await googleJwks();
  const jwk = keys.find(item => item.kid === header.kid && item.kty === 'RSA' && item.use === 'sig' && (!item.alg || item.alg === 'RS256'));
  if (!jwk) throw new Error('google_signing_key_not_found');
  const publicKey = await crypto.subtle.importKey('jwk', jwk, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['verify']);
  const signature = (0, passwords_js_1.fromBase64url)(parts[2]);
  const verified = await crypto.subtle.verify('RSASSA-PKCS1-v1_5', publicKey, signature, encoder.encode(`${parts[0]}.${parts[1]}`));
  if (!verified) throw new Error('google_id_token_signature_invalid');
  const now = Math.floor(Date.now() / 1000);
  const audiences = Array.isArray(claims.aud) ? claims.aud : [claims.aud];
  if (!['https://accounts.google.com', 'accounts.google.com'].includes(claims.iss) ||
      !audiences.includes(clientId) || (claims.azp !== undefined && claims.azp !== clientId) || (audiences.length > 1 && claims.azp !== clientId) ||
      claims.nonce !== expectedNonce || !Number.isSafeInteger(Number(claims.exp)) || Number(claims.exp) <= now ||
      !Number.isSafeInteger(Number(claims.iat)) || Number(claims.iat) > now + 60 || now - Number(claims.iat) > 3600 ||
      claims.email_verified !== true || typeof claims.sub !== 'string' || !/^[A-Za-z0-9._-]{1,255}$/.test(claims.sub) ||
      typeof claims.email !== 'string' || claims.email.length > 254) throw new Error('google_id_token_claims_invalid');
  const email = claims.email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('google_email_invalid');
  const displayName = String(claims.name || email.split('@')[0]).replace(/[\u0000-\u001f\u007f]/g, '').trim().slice(0, 60) || email.split('@')[0];
  return { sub: claims.sub, email, displayName };
}
async function googleOAuthCallback(request, env) {
  if (request.method !== 'GET') return (0, http_js_1.json)({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
  const clearCookie = clearStateCookie();
  const params = new URL(request.url).searchParams;
  if (params.has('error')) return redirectHome(request, 'google_cancelled', [clearCookie]);
  const state = await readStateCookie(request, env);
  const code = params.get('code') || '';
  const returnedState = params.get('state') || '';
  if (!state || !code || code.length > 2048 || !(0, passwords_js_1.constantTimeEqual)(returnedState, state.state)) {
    return redirectHome(request, 'google_error', [clearCookie]);
  }
  if (!googleAuthReady(env)) return redirectHome(request, 'google_unconfigured', [clearCookie]);
  try {
    const origin = new URL(request.url).origin;
    const redirectUri = `${origin}/api/auth/google/callback`;
    const tokenResponse = await fetch(GOOGLE_TOKEN_ENDPOINT, {
      method: 'POST',
      headers: { 'content-type': 'application/x-www-form-urlencoded', accept: 'application/json' },
      body: new URLSearchParams({
        code,
        client_id: env.GOOGLE_CLIENT_ID.trim(),
        client_secret: env.GOOGLE_CLIENT_SECRET.trim(),
        redirect_uri: redirectUri,
        grant_type: 'authorization_code',
        code_verifier: state.verifier
      }),
      signal: AbortSignal.timeout(12000)
    });
    const tokenData = await tokenResponse.json().catch(() => ({}));
    if (!tokenResponse.ok || typeof tokenData.id_token !== 'string') throw new Error('google_token_exchange_failed');
    const identity = await verifyGoogleIdToken(tokenData.id_token, state.nonce, env.GOOGLE_CLIENT_ID.trim());
    if (state.purpose === 'link') {
      const session = await (0, sessions_js_1.authenticatedSession)(request, env);
      if (!session?.user || session.accountKey !== state.accountKey || session.user.id !== state.userId ||
          session.user.email !== state.email || identity.email !== session.user.email) {
        return redirectHome(request, 'google_link_mismatch', [clearCookie]);
      }
      const identityKey = `google-identity:${await (0, passwords_js_1.sha256)(identity.sub)}`;
      const identityRecord = await (0, sessions_js_1.accountRequest)(env, identityKey, '/internal/google-identity/get');
      if (!identityRecord.response.ok || !identityRecord.data.ok) throw new Error('google_identity_registry_unavailable');
      if (identityRecord.data.identity && (identityRecord.data.identity.account_key !== session.accountKey || identityRecord.data.identity.email !== identity.email)) {
        return redirectHome(request, 'google_conflict', [clearCookie]);
      }
      let claimedIdentity = false;
      if (!identityRecord.data.identity) {
        const claim = await (0, sessions_js_1.accountRequest)(env, identityKey, '/internal/google-identity/claim', {
          accountKey: session.accountKey, email: identity.email, linkedAt: Math.floor(Date.now() / 1000)
        });
        if (claim.response.status === 409) return redirectHome(request, 'google_conflict', [clearCookie]);
        if (!claim.response.ok || !claim.data.ok) throw new Error('google_identity_claim_failed');
        claimedIdentity = claim.data.created === true;
      }
      const linked = await (0, sessions_js_1.accountRequest)(env, session.accountKey, '/internal/google-link', {
        userId: session.user.id, email: identity.email, googleSub: identity.sub
      });
      if (!linked.response.ok || !linked.data.ok) {
        if (claimedIdentity) await (0, sessions_js_1.accountRequest)(env, identityKey, '/internal/google-identity/delete', { accountKey: session.accountKey });
        if (linked.data.error === 'GOOGLE_IDENTITY_CONFLICT') return redirectHome(request, 'google_conflict', [clearCookie]);
        throw new Error('google_account_link_failed');
      }
      return redirectHome(request, 'google_linked', [clearCookie]);
    }
    const accountKey = await (0, passwords_js_1.sha256)(identity.email);
    const rateLimit = await (0, sessions_js_1.recordAuthAttempt)(request, env, `google:${accountKey}`);
    if (!rateLimit.available || !rateLimit.allowed) return redirectHome(request, 'google_retry', [clearCookie]);
    // A stable subject registry prevents the same Google identity from silently
    // creating a second SAYROX account if the provider email ever changes.
    const identityKey = `google-identity:${await (0, passwords_js_1.sha256)(identity.sub)}`;
    const identityRecord = await (0, sessions_js_1.accountRequest)(env, identityKey, '/internal/google-identity/get');
    if (!identityRecord.response.ok || !identityRecord.data.ok) throw new Error('google_identity_registry_unavailable');
    if (identityRecord.data.identity && (identityRecord.data.identity.account_key !== accountKey || identityRecord.data.identity.email !== identity.email)) {
      return redirectHome(request, 'google_email_changed', [clearCookie]);
    }
    let claimedIdentity = false;
    if (!identityRecord.data.identity) {
      const claim = await (0, sessions_js_1.accountRequest)(env, identityKey, '/internal/google-identity/claim', {
        accountKey, email: identity.email, linkedAt: Math.floor(Date.now() / 1000)
      });
      if (claim.response.status === 409) return redirectHome(request, 'google_conflict', [clearCookie]);
      if (!claim.response.ok || !claim.data.ok) throw new Error('google_identity_claim_failed');
      claimedIdentity = claim.data.created === true;
    }
    const stored = await (0, sessions_js_1.accountRequest)(env, accountKey, '/internal/google-login', {
      userId: crypto.randomUUID(), email: identity.email, googleSub: identity.sub,
      displayName: identity.displayName, createdAt: Math.floor(Date.now() / 1000)
    });
    if (stored.data.error === 'GOOGLE_LINK_REQUIRED') {
      if (claimedIdentity) await (0, sessions_js_1.accountRequest)(env, identityKey, '/internal/google-identity/delete', { accountKey });
      return redirectHome(request, 'google_link_required', [clearCookie]);
    }
    if (stored.response.status === 409 || stored.data.error === 'GOOGLE_IDENTITY_CONFLICT') {
      if (claimedIdentity) await (0, sessions_js_1.accountRequest)(env, identityKey, '/internal/google-identity/delete', { accountKey });
      return redirectHome(request, 'google_conflict', [clearCookie]);
    }
    if (!stored.response.ok || !stored.data.ok || !stored.data.user) {
      if (claimedIdentity) await (0, sessions_js_1.accountRequest)(env, identityKey, '/internal/google-identity/delete', { accountKey });
      throw new Error('google_account_storage_failed');
    }
    const issued = await (0, sessions_js_1.issueSession)(env, accountKey, stored.data.user);
    if (!issued.ok) throw new Error('google_session_issue_failed');
    const sessionCookie = issued.headers.get('set-cookie');
    if (!sessionCookie) throw new Error('google_session_cookie_missing');
    return redirectHome(request, 'google_success', [sessionCookie, clearCookie]);
  } catch (error) {
    console.error('SAYROX Google sign-in failed:', String(error?.message || error).slice(0, 180));
    return redirectHome(request, 'google_error', [clearCookie]);
  }
}
