"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.providerOrder = providerOrder;
exports.providerConfig = providerConfig;
exports.validModel = validModel;
exports.visionModelForProvider = visionModelForProvider;
exports.modelCatalog = modelCatalog;
exports.modelCatalogAsync = modelCatalogAsync;
exports.discoverGapGptModels = discoverGapGptModels;
exports.discoverProviderModels = discoverProviderModels;
exports.humanModelName = humanModelName;
exports.providerDiagnostics = providerDiagnostics;
exports.resolveModelSelection = resolveModelSelection;
exports.resolveModelSelectionAsync = resolveModelSelectionAsync;
const http_js_1 = __load("worker/shared/http.js");

const CHAT_PROVIDERS = Object.freeze(['gapgpt', 'avalai', 'hooshgar']);
const PROVIDER_META = Object.freeze({
    gapgpt: { name: 'گپ‌جی‌پی‌تی', icon: '🇮🇷', base: 'https://api.gapgpt.app/v1', key: 'GAPGPT_API_KEY', baseKey: 'GAPGPT_BASE_URL', modelKey: 'GAPGPT_DEFAULT_MODEL', labelKey: 'GAPGPT_MODEL_LABEL', visionKey: 'GAPGPT_VISION_MODEL', visionLabelKey: 'GAPGPT_VISION_MODEL_LABEL' },
    avalai: { name: 'اَوَل‌ای (AvalAI)', icon: '🟣', base: 'https://api.avalai.ir/v1', key: 'AVALAI_API_KEY', baseKey: 'AVALAI_BASE_URL', modelKey: 'AVALAI_DEFAULT_MODEL', labelKey: 'AVALAI_MODEL_LABEL', visionKey: 'AVALAI_VISION_MODEL', visionLabelKey: 'AVALAI_VISION_MODEL_LABEL' },
    hooshgar: { name: 'هوشگر (Hooshgar)', icon: '🧠', base: 'https://api.hooshgar.ir/v1', key: 'HOOSHGAR_API_KEY', baseKey: 'HOOSHGAR_BASE_URL', modelKey: 'HOOSHGAR_DEFAULT_MODEL', labelKey: 'HOOSHGAR_MODEL_LABEL', visionKey: 'HOOSHGAR_VISION_MODEL', visionLabelKey: 'HOOSHGAR_VISION_MODEL_LABEL' }
});

function providerOrder(env) {
    const available = CHAT_PROVIDERS.filter(name => Boolean(providerConfig(name, env).key));
    const preferred = String(env?.AI_PROVIDER || '').trim().toLowerCase();
    if (available.includes(preferred)) return [preferred, ...available.filter(name => name !== preferred)];
    return available;
}
function safeProviderBase(value) {
    try {
        const url = new URL(String(value || '').trim());
        if (url.protocol !== 'https:' || !url.hostname || url.username || url.password || url.search || url.hash) return '';
        return url.toString().replace(/\/+$/, '');
    } catch { return ''; }
}
function providerConfig(name, env) {
    const meta = PROVIDER_META[name];
    if (meta) {
        const configuredBase = (0, http_js_1.text)(env?.[meta.baseKey], 1000).trim();
        return {
            key: (0, http_js_1.text)(env?.[meta.key], 1000).trim(),
            base: safeProviderBase(configuredBase || meta.base),
            model: (0, http_js_1.text)(env?.[meta.modelKey], 160).trim()
        };
    }
    if (name === 'openrouter') return {
        key: (0, http_js_1.text)(env?.OPENROUTER_API_KEY, 1000).trim(),
        base: ((0, http_js_1.text)(env?.OPENROUTER_BASE_URL, 1000).trim() || 'https://openrouter.ai/api/v1').replace(/\/+$/, ''),
        model: (0, http_js_1.text)(env?.OPENROUTER_DEFAULT_MODEL, 160).trim()
    };
    return { key: '', base: '', model: '' };
}
function validModel(model) {
    return typeof model === 'string' && model.length <= 240 && /^[A-Za-z0-9._:/-]+$/.test(model);
}
const MODEL_ID = /^[A-Za-z0-9._:/-]{1,160}$/;
function selectionId(provider, modelId) {
    return provider === 'gapgpt' ? modelId : `${provider}::${modelId}`;
}
function extraModelConfig(env) {
    const raw = (0, http_js_1.text)(env?.XYNORA_MODEL_CATALOG, 12000).trim();
    if (!raw) return [];
    try {
        const value = JSON.parse(raw);
        return Array.isArray(value) ? value.slice(0, 40).filter(item => item && typeof item === 'object') : [];
    } catch { return []; }
}
function visionModelForProvider(provider, env) {
    const meta = PROVIDER_META[provider];
    const direct = meta ? (0, http_js_1.text)(env?.[meta.visionKey], 160).trim() : provider === 'openrouter' ? (0, http_js_1.text)(env?.OPENROUTER_VISION_MODEL, 160).trim() : '';
    if (validModel(direct)) return direct;
    const configured = extraModelConfig(env).find(item => item.provider === provider && (item.vision === true || item.supportsVision === true) && typeof item.id === 'string' && MODEL_ID.test(item.id.trim()));
    return configured?.id?.trim() || '';
}
const DISCOVERY_TTL_MS = 90_000;
const DISCOVERY_TIMEOUT_MS = 3500;
const discoveredCache = new Map();
function modelBrand(modelId, owner = '') {
    const key = `${owner} ${modelId}`.toLowerCase();
    if (/anthropic|claude/.test(key)) return { brand: 'Anthropic', brandIcon: '◈' };
    if (/openai|gpt-|^o[134]-/.test(key)) return { brand: 'OpenAI', brandIcon: '✳' };
    if (/google|gemini|gemma/.test(key)) return { brand: 'Google', brandIcon: '✦' };
    if (/xai|grok/.test(key)) return { brand: 'xAI', brandIcon: '𝕏' };
    if (/deepseek/.test(key)) return { brand: 'DeepSeek', brandIcon: '🐋' };
    if (/qwen|alibaba/.test(key)) return { brand: 'Qwen', brandIcon: '◇' };
    if (/moonshot|kimi/.test(key)) return { brand: 'Moonshot', brandIcon: '☾' };
    if (/zhipu|z\.ai|glm/.test(key)) return { brand: 'Z.ai', brandIcon: '🧠' };
    if (/meta|llama/.test(key)) return { brand: 'Meta', brandIcon: '∞' };
    if (/mistral/.test(key)) return { brand: 'Mistral', brandIcon: '⚡' };
    if (/minimax/.test(key)) return { brand: 'MiniMax', brandIcon: '◉' };
    if (/cohere|command-r/.test(key)) return { brand: 'Cohere', brandIcon: '◍' };
    return { brand: 'مدل مستقل', brandIcon: '◇' };
}
function humanModelName(id) {
    const raw = String(id || '').split('/').pop().replace(/_/g, '-');
    const pretty = value => value.replace(/(\d+)-(\d+)(?=$|-)/g, '$1.$2').replace(/-/g, ' ').replace(/\b[a-z]/g, letter => letter.toUpperCase());
    const patterns = [
        [/^gpt-(.+)$/i, (_, rest) => `GPT-${pretty(rest)}`], [/^claude-(.+)$/i, (_, rest) => `Claude ${pretty(rest)}`],
        [/^gemini-(.+)$/i, (_, rest) => `Gemini ${pretty(rest)}`], [/^deepseek-(.+)$/i, (_, rest) => `DeepSeek ${pretty(rest)}`],
        [/^grok-(.+)$/i, (_, rest) => `Grok ${pretty(rest)}`], [/^qwen-?(.*)$/i, (_, rest) => `Qwen ${pretty(rest)}`],
        [/^kimi-(.+)$/i, (_, rest) => `Kimi ${pretty(rest)}`], [/^glm-(.+)$/i, (_, rest) => `GLM ${pretty(rest)}`]
    ];
    for (const [pattern, format] of patterns) if (pattern.test(raw)) return raw.replace(pattern, format);
    return pretty(raw);
}
function isChatCompletionModel(item) {
    const id = typeof item?.id === 'string' ? item.id : '';
    if (!MODEL_ID.test(id)) return false;
    const type = String(item?.task || item?.capability || item?.model_type || '').toLowerCase();
    if (type && !/(chat|text|language|completion)/.test(type)) return false;
    return !/(embed|whisper|tts|speech|audio|image|video|suno|midjourney|moderation|rerank|transcri)/i.test(id);
}
function keyFingerprint(value) {
    let hash = 2166136261;
    for (let index = 0; index < value.length; index++) hash = Math.imul(hash ^ value.charCodeAt(index), 16777619);
    return (hash >>> 0).toString(36);
}
function modelSupportsVision(item) {
    if (item?.supports_vision === true || item?.supportsVision === true || item?.vision === true) return true;
    const modalities = [item?.modalities, item?.input_modalities, item?.architecture?.input_modalities, item?.capabilities];
    return modalities.some(list => Array.isArray(list) && list.some(value => /^(image|vision)$/i.test(String(value))));
}
async function discoverProviderModels(provider, env) {
    if (!PROVIDER_META[provider]) return [];
    const cfg = providerConfig(provider, env);
    if (!cfg.key || !cfg.base || !/^https:\/\//i.test(cfg.base)) return [];
    const cacheKey = `${provider}|${cfg.base}|${keyFingerprint(cfg.key)}`;
    const cached = discoveredCache.get(cacheKey);
    if (cached && cached.expiresAt > Date.now()) return cached.models;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), DISCOVERY_TIMEOUT_MS);
    try {
        const response = await fetch(`${cfg.base}/models`, {
            method: 'GET', headers: { authorization: `Bearer ${cfg.key}`, accept: 'application/json' }, signal: controller.signal
        });
        if (!response.ok) return cached?.models || [];
        const declaredLength = Number(response.headers.get('content-length') || 0);
        if (declaredLength > 96_000) return cached?.models || [];
        const raw = await response.text();
        if (raw.length > 96_000) return cached?.models || [];
        const parsed = JSON.parse(raw);
        const rows = Array.isArray(parsed?.data) ? parsed.data : Array.isArray(parsed?.models) ? parsed.models : [];
        const meta = PROVIDER_META[provider];
        const models = [];
        const seen = new Set();
        for (const item of rows.slice(0, 120)) {
            if (!isChatCompletionModel(item) || seen.has(item.id)) continue;
            seen.add(item.id);
            const brand = modelBrand(item.id, item.owned_by || item.provider || item.publisher || '');
            models.push({
                id: item.id,
                label: (0, http_js_1.text)(item.name || item.display_name || item.title || humanModelName(item.id), 100).replace(/[\u0001-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim() || humanModelName(item.id),
                provider, providerName: meta.name, providerIcon: meta.icon,
                brand: brand.brand, brandIcon: brand.brandIcon,
                supportsVision: modelSupportsVision(item), source: 'live'
            });
        }
        discoveredCache.set(cacheKey, { expiresAt: Date.now() + DISCOVERY_TTL_MS, models });
        while (discoveredCache.size > 12) discoveredCache.delete(discoveredCache.keys().next().value);
        return models;
    } catch { return cached?.models || []; }
    finally { clearTimeout(timeout); }
}
async function discoverGapGptModels(env) { return discoverProviderModels('gapgpt', env); }
function modelCatalog(env, discovered = []) {
    const configuredProviders = new Set(providerOrder(env));
    const order = providerOrder(env);
    const models = [{
        id: 'auto', label: 'مدل خودکار · SAYROX', provider: 'auto',
        providerName: 'چنددرگاهی SAYROX', providerIcon: '✦', brand: 'SAYROX', brandIcon: '✦',
        supportsVision: order.some(provider => Boolean(visionModelForProvider(provider, env))), source: 'builtin'
    }];
    const add = (modelId, label, provider, supportsVision = false, metadata = {}) => {
        if (!configuredProviders.has(provider) || !MODEL_ID.test(modelId)) return;
        const id = selectionId(provider, modelId);
        const existing = models.find(item => item.id === id);
        if (existing) { existing.supportsVision ||= supportsVision; return; }
        const providerMeta = PROVIDER_META[provider];
        const brand = modelBrand(modelId, metadata.owned_by || metadata.brand || '');
        models.push({
            id, modelId,
            label: (0, http_js_1.text)(label, 100).trim() || humanModelName(modelId),
            provider, providerName: providerMeta.name, providerIcon: providerMeta.icon,
            brand: (0, http_js_1.text)(metadata.brand, 40).trim() || brand.brand,
            brandIcon: (0, http_js_1.text)(metadata.brandIcon, 8).trim() || brand.brandIcon,
            supportsVision: Boolean(supportsVision), source: metadata.source || 'configured'
        });
    };
    for (const provider of CHAT_PROVIDERS) {
        if (!configuredProviders.has(provider)) continue;
        const meta = PROVIDER_META[provider];
        const defaultId = (0, http_js_1.text)(env?.[meta.modelKey], 160).trim();
        add(defaultId, (0, http_js_1.text)(env?.[meta.labelKey], 100).trim(), provider, defaultId === visionModelForProvider(provider, env));
        const visionId = visionModelForProvider(provider, env);
        if (visionId) add(visionId, (0, http_js_1.text)(env?.[meta.visionLabelKey], 100).trim() || `مدل بینایی ${meta.name}`, provider, true);
    }
    for (const item of extraModelConfig(env)) {
        if (!PROVIDER_META[item.provider] || typeof item.id !== 'string') continue;
        add(item.id.trim(), item.label, item.provider, item.vision === true || item.supportsVision === true, item);
    }
    for (const item of Array.isArray(discovered) ? discovered : []) {
        if (!PROVIDER_META[item?.provider] || !configuredProviders.has(item.provider) || !isChatCompletionModel(item)) continue;
        add(item.id, item.label, item.provider, item.supportsVision === true, { ...item, source: 'live' });
    }
    // Keep the default/primary ordering visible in the picker, independent of the
    // provider registration order used by the implementation.
    const rank = new Map(order.map((provider, index) => [provider, index]));
    models.splice(1, models.length - 1, ...models.slice(1).sort((a, b) => (rank.get(a.provider) ?? 99) - (rank.get(b.provider) ?? 99)));
    return models;
}
async function modelCatalogAsync(env) {
    const providers = providerOrder(env);
    const discovered = (await Promise.all(providers.map(provider => discoverProviderModels(provider, env)))).flat();
    return modelCatalog(env, discovered);
}
function inspectProvider(provider, env) {
    const cfg = providerConfig(provider, env);
    const validBase = Boolean(cfg.base);
    const keyConfigured = Boolean(cfg.key);
    const defaultModelConfigured = Boolean(cfg.model && validModel(cfg.model));
    return { keyConfigured, baseUrlValid: validBase, defaultModelConfigured, ready: keyConfigured && validBase && defaultModelConfigured };
}
function providerDiagnostics(env) {
    const order = providerOrder(env);
    const primary = order[0] || null;
    const fallback = order[1] || null;
    const byProvider = Object.fromEntries(CHAT_PROVIDERS.map(provider => [provider, inspectProvider(provider, env)]));
    const primaryReady = primary ? byProvider[primary].ready : false;
    const fallbackReady = fallback ? byProvider[fallback].ready : false;
    return {
        primary, fallback, providers: byProvider,
        ...byProvider,
        openrouter: { keyConfigured: Boolean(providerConfig('openrouter', env).key), baseUrlValid: true, defaultModelConfigured: false, ready: false, chatEnabled: false },
        chatReady: order.some(provider => byProvider[provider].ready), primaryReady, fallbackReady
    };
}
function resolveModelSelection(env, requestedModel, { requiresVision = false } = {}) {
    const order = providerOrder(env);
    if (!order.length) return { ok: false, reason: 'no-provider' };
    if (requestedModel === undefined || requestedModel === null || requestedModel === '' || requestedModel === 'auto') {
        if (requiresVision) {
            const visionProviders = order.map(provider => ({ provider, model: visionModelForProvider(provider, env) })).filter(item => item.model);
            if (!visionProviders.length) return { ok: false, reason: 'no-vision-model' };
            return { ok: true, automatic: true, provider: visionProviders[0].provider, model: visionProviders[0].model, visionModels: Object.fromEntries(visionProviders.map(item => [item.provider, item.model])), fallbackProviders: visionProviders.slice(1).map(item => item.provider), requiresVision: true };
        }
        return { ok: true, automatic: true, provider: order[0], model: undefined, fallbackProviders: order.slice(1), requiresVision: false };
    }
    if (!validModel(requestedModel)) return { ok: false, reason: 'invalid-model' };
    const selected = modelCatalog(env).find(item => item.id === requestedModel && item.provider !== 'auto');
    if (!selected) return { ok: false, reason: 'model-not-configured' };
    if (requiresVision && !selected.supportsVision) return { ok: false, reason: 'vision-model-required' };
    return { ok: true, automatic: false, provider: selected.provider, model: selected.modelId || selected.id, selectionId: selected.id, fallbackProviders: [], requiresVision: Boolean(requiresVision) };
}
async function resolveModelSelectionAsync(env, requestedModel, options = {}) {
    const basic = resolveModelSelection(env, requestedModel, options);
    if (basic.ok || !['model-not-configured', 'no-vision-model'].includes(basic.reason)) return basic;
    const providers = providerOrder(env);
    const discovered = (await Promise.all(providers.map(provider => discoverProviderModels(provider, env)))).flat();
    const catalogue = modelCatalog(env, discovered);
    if (requestedModel === undefined || requestedModel === null || requestedModel === '' || requestedModel === 'auto') {
        if (options.requiresVision) {
            const vision = catalogue.find(item => item.provider !== 'auto' && item.supportsVision);
            if (vision) {
                const visionModels = Object.fromEntries(catalogue.filter(item => item.provider !== 'auto' && item.supportsVision).map(item => [item.provider, item.modelId || item.id]));
                return { ok: true, automatic: true, provider: vision.provider, model: vision.modelId || vision.id, visionModels, fallbackProviders: providers.filter(provider => provider !== vision.provider && Boolean(visionModels[provider])), requiresVision: true };
            }
        }
        return basic;
    }
    const selected = catalogue.find(item => item.id === requestedModel && item.provider !== 'auto');
    if (!selected) return basic;
    if (options.requiresVision && !selected.supportsVision) return { ok: false, reason: 'vision-model-required' };
    return { ok: true, automatic: false, provider: selected.provider, model: selected.modelId || selected.id, selectionId: selected.id, fallbackProviders: [], requiresVision: Boolean(options.requiresVision) };
}
