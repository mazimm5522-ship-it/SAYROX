"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authApi = authApi;
const constants_js_1 = __load("worker/shared/constants.js");
const http_js_1 = __load("worker/shared/http.js");
const passwords_js_1 = __load("worker/security/passwords.js");
const sessions_js_1 = __load("worker/security/sessions.js");
const google_oauth_js_1 = __load("worker/features/google-oauth.js");
async function authApi(request, env, pathname) {
    if (!(0, sessions_js_1.authReady)(env))
        return (0, http_js_1.json)({ ok: false, message: 'زیرساخت امن حساب کاربری هنوز به Worker متصل نشده است.' }, 503);
    if (pathname === '/api/auth/google/start')
        return (0, google_oauth_js_1.googleOAuthStart)(request, env);
    if (pathname === '/api/auth/google/link/start')
        return (0, google_oauth_js_1.googleOAuthLinkStart)(request, env);
    if (pathname === '/api/auth/google/callback')
        return (0, google_oauth_js_1.googleOAuthCallback)(request, env);
    if (pathname === '/api/auth/me') {
        if (request.method !== 'GET')
            return (0, http_js_1.json)({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
        const user = await (0, sessions_js_1.currentUser)(request, env);
        return (0, http_js_1.json)({ ok: true, authenticated: Boolean(user), user: (0, sessions_js_1.safeUser)(user) });
    }
    if (request.method !== 'POST')
        return (0, http_js_1.json)({ ok: false, message: 'روش درخواست پشتیبانی نمی‌شود.' }, 405);
    if (!(0, sessions_js_1.sameOriginRequest)(request))
        return (0, http_js_1.json)({ ok: false, message: 'درخواست بین‌مبدأیی مجاز نیست.' }, 403);
    if (pathname === '/api/auth/logout') {
        const token = (0, sessions_js_1.cookieValue)(request, 'xynora_session');
        if (token) {
            const session = await (0, sessions_js_1.verifySessionToken)(env, token);
            if (session)
                await (0, sessions_js_1.accountRequest)(env, session.accountKey, '/internal/delete-session', { tokenHash: await (0, passwords_js_1.sha256)(session.sessionId) });
        }
        return (0, http_js_1.json)({ ok: true }, 200, { 'set-cookie': (0, sessions_js_1.authCookie)('', 0) });
    }
    const data = await (0, http_js_1.readJson)(request, 6000);
    const email = (0, http_js_1.text)(data.email, 254).trim().toLowerCase();
    const password = (0, http_js_1.text)(data.password, 128);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
        return (0, http_js_1.json)({ ok: false, message: 'نشانی ایمیل معتبر نیست.' }, 400);
    if (password.length < 10 || password.length > 128)
        return (0, http_js_1.json)({ ok: false, message: 'رمز عبور باید بین ۱۰ تا ۱۲۸ نویسه باشد.' }, 400);
    const accountKey = await (0, passwords_js_1.sha256)(email);
    const rateLimit = await (0, sessions_js_1.recordAuthAttempt)(request, env, accountKey);
    if (!rateLimit.available)
        return (0, http_js_1.json)({ ok: false, message: 'سرویس کنترل امنیتی موقتاً در دسترس نیست. دوباره تلاش کن.' }, 503);
    if (!rateLimit.allowed)
        return (0, http_js_1.json)({ ok: false, message: 'تعداد تلاش‌ها زیاد است. ۱۵ دقیقه بعد دوباره امتحان کن.' }, 429);
    if (pathname === '/api/auth/signup') {
        const displayName = (0, http_js_1.text)(data.displayName, 60).trim();
        if (displayName.length < 2)
            return (0, http_js_1.json)({ ok: false, message: 'نام نمایشی باید حداقل دو نویسه داشته باشد.' }, 400);
        const passwordHash = await (0, passwords_js_1.createPasswordHash)(password);
        const userId = crypto.randomUUID();
        const createdAt = Math.floor(Date.now() / 1000);
        const result = await (0, sessions_js_1.accountRequest)(env, accountKey, '/internal/signup', {
            userId, email, passwordHash, displayName, createdAt
        });
        if (result.response.status === 409)
            return (0, http_js_1.json)({ ok: false, message: 'این ایمیل قبلاً ثبت شده است. وارد حساب شو.' }, 409);
        if (!result.response.ok || !result.data.ok)
            return (0, http_js_1.json)({ ok: false, message: 'ساخت حساب انجام نشد. دوباره تلاش کن.' }, 503);
        return (0, sessions_js_1.issueSession)(env, accountKey, result.data.user);
    }
    if (pathname === '/api/auth/login') {
        const result = await (0, sessions_js_1.accountRequest)(env, accountKey, '/internal/get-user');
        const user = result.response.ok && result.data.ok ? result.data.user : null;
        if (!user)
            return (0, http_js_1.json)({ ok: false, message: 'ایمیل یا رمز عبور اشتباه است.' }, 401);
        if (!user.password_hash)
            return (0, http_js_1.json)({ ok: false, message: 'این حساب با Google ساخته شده است. با همان حساب Google وارد شو.' }, 401);
        const [algorithm, roundsText, saltText, expected] = String(user.password_hash || '').split('$');
        const rounds = Number(roundsText);
        if (algorithm !== 'pbkdf2' || !(rounds === constants_js_1.PASSWORD_ITERATIONS || constants_js_1.LEGACY_PASSWORD_ITERATIONS.has(rounds)) ||
            !/^[A-Za-z0-9_-]{22}$/.test(saltText || '') || !/^[A-Za-z0-9_-]{43}$/.test(expected || '')) {
            return (0, http_js_1.json)({ ok: false, message: 'اطلاعات امنیتی حساب معتبر نیست.' }, 500);
        }
        let salt;
        try {
            salt = (0, passwords_js_1.fromBase64url)(saltText);
        }
        catch {
            return (0, http_js_1.json)({ ok: false, message: 'اطلاعات امنیتی حساب معتبر نیست.' }, 500);
        }
        const actual = await (0, passwords_js_1.derivePassword)(password, salt, rounds);
        if (!(0, passwords_js_1.constantTimeEqual)(actual, expected))
            return (0, http_js_1.json)({ ok: false, message: 'ایمیل یا رمز عبور اشتباه است.' }, 401);
        if (rounds < constants_js_1.PASSWORD_ITERATIONS) {
            const upgradedHash = await (0, passwords_js_1.createPasswordHash)(password);
            const upgraded = await (0, sessions_js_1.accountRequest)(env, accountKey, '/internal/update-password-hash', { passwordHash: upgradedHash });
            if (!upgraded.response.ok || !upgraded.data.ok)
                return (0, http_js_1.json)({ ok: false, message: 'ارتقای امنیت رمز عبور کامل نشد. دوباره تلاش کن.' }, 503);
            user.password_hash = upgradedHash;
        }
        return (0, sessions_js_1.issueSession)(env, accountKey, user);
    }
    return (0, http_js_1.json)({ ok: false, message: 'مسیر احراز هویت پیدا نشد.' }, 404);
}
