"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.base64url = base64url;
exports.fromBase64url = fromBase64url;
exports.sha256 = sha256;
exports.derivePassword = derivePassword;
exports.createPasswordHash = createPasswordHash;
exports.constantTimeEqual = constantTimeEqual;
const constants_js_1 = __load("worker/shared/constants.js");
function base64url(bytes) {
    let binary = '';
    for (const byte of bytes)
        binary += String.fromCharCode(byte);
    return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/g, '');
}
function fromBase64url(value) {
    const normalized = String(value).replace(/-/g, '+').replace(/_/g, '/');
    const binary = atob(normalized + '='.repeat((4 - normalized.length % 4) % 4));
    return Uint8Array.from(binary, c => c.charCodeAt(0));
}
async function sha256(value) {
    const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value));
    return base64url(new Uint8Array(digest));
}
async function derivePassword(password, salt, iterations = constants_js_1.PASSWORD_ITERATIONS) {
    if (typeof password !== 'string' || !(salt instanceof Uint8Array) || salt.length < 16 || salt.length > 64 ||
        !Number.isSafeInteger(iterations) || iterations < 100_000 || iterations > constants_js_1.PASSWORD_ITERATIONS) {
        throw new Error('پارامتر هش رمز عبور معتبر نیست.');
    }
    // Cloudflare Web Crypto rejects PBKDF2 iteration counts above 100,000.
    // The Worker compatibility date (2026-11-06) enables native node:crypto;
    // its PBKDF2 implementation supports our 600,000-round password policy.
    // Dynamic import keeps this native dependency isolated to password KDF use.
    const { pbkdf2 } = await import('node:crypto');
    const digest = await new Promise((resolve, reject) => {
        pbkdf2(password, salt, iterations, 32, 'sha256', (error, derivedKey) => {
            if (error) reject(error);
            else resolve(derivedKey);
        });
    });
    return base64url(new Uint8Array(digest));
}
async function createPasswordHash(password) {
    const salt = crypto.getRandomValues(new Uint8Array(16));
    const saltText = base64url(salt);
    const digest = await derivePassword(password, salt, constants_js_1.PASSWORD_ITERATIONS);
    return `pbkdf2$${constants_js_1.PASSWORD_ITERATIONS}$${saltText}$${digest}`;
}
function constantTimeEqual(a, b) {
    const left = new TextEncoder().encode(String(a));
    const right = new TextEncoder().encode(String(b));
    if (left.length !== right.length)
        return false;
    let diff = 0;
    for (let i = 0; i < left.length; i++)
        diff |= left[i] ^ right[i];
    return diff === 0;
}
