"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.cookieValue = cookieValue;
exports.authCookie = authCookie;
exports.sameOriginRequest = sameOriginRequest;
exports.safeUser = safeUser;
exports.rateLimitReady = rateLimitReady;
exports.authReadiness = authReadiness;
exports.authReady = authReady;
exports.durableObjectRequest = durableObjectRequest;
exports.accountRequest = accountRequest;
exports.rateLimitCheck = rateLimitCheck;
exports.enforceApiRateLimit = enforceApiRateLimit;
exports.recordAuthAttempt = recordAuthAttempt;
exports.signSessionPayload = signSessionPayload;
exports.createSessionToken = createSessionToken;
exports.verifySessionToken = verifySessionToken;
exports.issueSession = issueSession;
exports.authenticatedSession = authenticatedSession;
exports.currentUser = currentUser;
const constants_js_1 = __load("worker/shared/constants.js");
const http_js_1 = __load("worker/shared/http.js");
const passwords_js_1 = __load("worker/security/passwords.js");
function cookieValue(request, name) {
    const raw = request.headers.get('cookie') || '';
    for (const part of raw.split(';')) {
        const [key, ...rest] = part.trim().split('=');
        if (key === name)
            return rest.join('=');
    }
    return '';
}
function authCookie(token, maxAge = constants_js_1.SESSION_SECONDS) {
    return `xynora_session=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`;
}
function sameOriginRequest(request) {
    const origin = request.headers.get('origin');
    if (origin) {
        try {
            if (new URL(origin).origin !== new URL(request.url).origin)
                return false;
        }
        catch {
            return false;
        }
    }
    const fetchSite = request.headers.get('sec-fetch-site');
    return !fetchSite || ['same-origin', 'same-site', 'none'].includes(fetchSite);
}
function safeUser(row) { return row ? { id: row.id, email: row.email, displayName: row.display_name, createdAt: row.created_at, googleLinked: Boolean(row.google_sub) } : null; }
function namespaceReady(namespace) {
    return Boolean(namespace && typeof namespace.idFromName === 'function' && typeof namespace.get === 'function');
}
function rateLimitReady(env) {
    return namespaceReady(env?.AUTH_RATE_LIMITER);
}
function authReadiness(env) {
    return {
        accountNamespace: namespaceReady(env?.AUTH_ACCOUNTS),
        rateLimitNamespace: namespaceReady(env?.AUTH_RATE_LIMITER),
        sessionSecret: typeof env?.AUTH_SESSION_SECRET === 'string' && env.AUTH_SESSION_SECRET.length >= 32
    };
}
function authReady(env) {
    const readiness = authReadiness(env);
    return readiness.accountNamespace && readiness.rateLimitNamespace && readiness.sessionSecret;
}
async function durableObjectRequest(namespace, name, path, payload) {
    const id = namespace.idFromName(name);
    const stub = namespace.get(id);
    const response = await stub.fetch(new Request(`https://xynora-internal.invalid${path}`, {
        method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(payload)
    }));
    const data = await response.json().catch(() => ({}));
    return { response, data };
}
async function accountRequest(env, accountKey, path, payload = {}) {
    return durableObjectRequest(env.AUTH_ACCOUNTS, accountKey, path, payload);
}
async function rateLimitCheck(request, env, bucketKey, policy) {
    if (!rateLimitReady(env))
        return { available: false, allowed: false };
    const ip = (0, http_js_1.text)(request.headers.get('cf-connecting-ip') || 'unknown', 80).trim() || 'unknown';
    const ipKey = await (0, passwords_js_1.sha256)(`ip:${ip}`);
    // Bound Durable Object cardinality: hash-prefix sharding caps the namespace at 4,096 buckets.
    // The full IP hash remains in the SQL bucket key so different IPs never share a quota counter.
    const shardKey = `ip-shard:${ipKey.slice(0, 3)}`;
    const result = await durableObjectRequest(env.AUTH_RATE_LIMITER, shardKey, '/internal/check', {
        bucketKey: `${ipKey}:${bucketKey}`, now: Date.now(), maxAttempts: policy.maxAttempts, windowMs: policy.windowMs
    });
    if (!result.response.ok || !result.data.ok)
        return { available: false, allowed: false };
    return { available: true, allowed: result.data.allowed === true, attempts: result.data.attempts, retryAfterSeconds: result.data.retryAfterSeconds };
}
async function enforceApiRateLimit(request, env, route) {
    const policy = constants_js_1.API_RATE_LIMITS[route];
    if (!policy)
        return null;
    const result = await rateLimitCheck(request, env, `api:${route}`, policy);
    if (!result.available)
        return (0, http_js_1.json)({ ok: false, message: 'کنترل امنیتی محدودیت مصرف به Worker متصل نیست یا موقتاً در دسترس نیست.' }, 503);
    const remaining = Math.max(0, policy.maxAttempts - result.attempts);
    const headers = {
        'x-ratelimit-limit': String(policy.maxAttempts),
        'x-ratelimit-remaining': String(remaining)
    };
    if (!result.allowed) {
        headers['retry-after'] = String(result.retryAfterSeconds || 60);
        headers['x-ratelimit-remaining'] = '0';
        return (0, http_js_1.json)({ ok: false, message: 'تعداد درخواست‌ها در این بازه بیش از حد مجاز است. کمی بعد دوباره تلاش کن.' }, 429, headers);
    }
    return null;
}
async function recordAuthAttempt(request, env, accountKey) {
    const global = await rateLimitCheck(request, env, 'auth:global', { maxAttempts: constants_js_1.AUTH_RATE_LIMIT, windowMs: constants_js_1.AUTH_RATE_WINDOW_MS });
    if (!global.available || !global.allowed)
        return global;
    return rateLimitCheck(request, env, `auth:account:${accountKey}`, { maxAttempts: constants_js_1.AUTH_RATE_LIMIT, windowMs: constants_js_1.AUTH_RATE_WINDOW_MS });
}
async function signSessionPayload(env, payload) {
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(env.AUTH_SESSION_SECRET), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
    const signature = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(payload));
    return (0, passwords_js_1.base64url)(new Uint8Array(signature));
}
async function createSessionToken(env, accountKey, sessionId, expiresAt) {
    const payload = `v1.${accountKey}.${sessionId}.${expiresAt}`;
    const encoded = (0, passwords_js_1.base64url)(new TextEncoder().encode(payload));
    return `${encoded}.${await signSessionPayload(env, encoded)}`;
}
async function verifySessionToken(env, token) {
    if (typeof token !== 'string' || token.length > 512)
        return null;
    const [encoded, signature, extra] = token.split('.');
    if (!encoded || !signature || extra !== undefined || !/^[A-Za-z0-9_-]+$/.test(encoded))
        return null;
    const expected = await signSessionPayload(env, encoded);
    if (!(0, passwords_js_1.constantTimeEqual)(signature, expected))
        return null;
    let payload;
    try {
        payload = new TextDecoder().decode((0, passwords_js_1.fromBase64url)(encoded));
    }
    catch {
        return null;
    }
    const [version, accountKey, sessionId, expiresText, trailing] = payload.split('.');
    if (version !== 'v1' || trailing !== undefined || !/^[A-Za-z0-9_-]{43}$/.test(accountKey) ||
        !/^[A-Za-z0-9_-]{43}$/.test(sessionId) || !/^\d{10}$/.test(expiresText || ''))
        return null;
    const expiresAt = Number(expiresText);
    if (!Number.isSafeInteger(expiresAt) || expiresAt <= Math.floor(Date.now() / 1000))
        return null;
    return { accountKey, sessionId, expiresAt };
}
async function issueSession(env, accountKey, user) {
    const sessionId = (0, passwords_js_1.base64url)(crypto.getRandomValues(new Uint8Array(32)));
    const now = Math.floor(Date.now() / 1000);
    const expiresAt = now + constants_js_1.SESSION_SECONDS;
    const tokenHash = await (0, passwords_js_1.sha256)(sessionId);
    const stored = await accountRequest(env, accountKey, '/internal/create-session', { tokenHash, createdAt: now, expiresAt });
    if (!stored.response.ok || !stored.data.ok)
        return (0, http_js_1.json)({ ok: false, message: 'نشست امن حساب ساخته نشد. دوباره تلاش کن.' }, 503);
    const token = await createSessionToken(env, accountKey, sessionId, expiresAt);
    return (0, http_js_1.json)({ ok: true, user: safeUser(user) }, 200, { 'set-cookie': authCookie(token) });
}
async function authenticatedSession(request, env) {
    const token = cookieValue(request, 'xynora_session');
    if (!token || !authReady(env))
        return null;
    const session = await verifySessionToken(env, token);
    if (!session)
        return null;
    const result = await accountRequest(env, session.accountKey, '/internal/validate-session', {
        tokenHash: await (0, passwords_js_1.sha256)(session.sessionId), now: Math.floor(Date.now() / 1000)
    });
    if (!result.response.ok || !result.data.ok || !result.data.user)
        return null;
    return { ...session, user: result.data.user };
}
async function currentUser(request, env) {
    const session = await authenticatedSession(request, env);
    return session?.user || null;
}
