"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.TASK_LIMITS = exports.API_RATE_LIMITS = exports.AUTH_RATE_WINDOW_MS = exports.AUTH_RATE_LIMIT = exports.LEGACY_PASSWORD_ITERATIONS = exports.PASSWORD_ITERATIONS = exports.SESSION_SECONDS = exports.PLANS = exports.VOICES = exports.MAX_MESSAGES = exports.MAX_CHAT_BODY_BYTES = exports.MAX_BODY = exports.JSON_HEADERS = void 0;
exports.JSON_HEADERS = {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff'
};
exports.MAX_BODY = 180_000;
exports.MAX_CHAT_BODY_BYTES = 8_000_000;
exports.MAX_MESSAGES = 24;
exports.VOICES = ['aria', 'nova', 'elena', 'lyra', 'atlas', 'kai', 'orion'];
exports.PLANS = { normal: 295000, plus: 750000, pro: 2250000 };
exports.SESSION_SECONDS = 60 * 60 * 24 * 7;
exports.PASSWORD_ITERATIONS = 600_000;
exports.LEGACY_PASSWORD_ITERATIONS = new Set([120_000]);
exports.AUTH_RATE_LIMIT = 8;
exports.AUTH_RATE_WINDOW_MS = 15 * 60 * 1000;
// Maximum number of scheduled tasks per plan tier (server-authoritative; the client cannot choose it).
exports.TASK_LIMITS = Object.freeze({ free: 1, start: 3, advanced: 10, pro: 30, ultra: 80 });
exports.API_RATE_LIMITS = {
    images: { maxAttempts: 6, windowMs: 60_000 },
    tasks: { maxAttempts: 30, windowMs: 60_000 },
    'tasks-read': { maxAttempts: 120, windowMs: 60_000 },
    'models-read': { maxAttempts: 60, windowMs: 60_000 },
    chat: { maxAttempts: 30, windowMs: 60_000 },
    search: { maxAttempts: 12, windowMs: 60_000 },
    tts: { maxAttempts: 8, windowMs: 60_000 },
    payment: { maxAttempts: 5, windowMs: 15 * 60 * 1000 },
    memory: { maxAttempts: 60, windowMs: 60_000 },
    'memory-read': { maxAttempts: 120, windowMs: 60_000 },
    'agent-history': { maxAttempts: 90, windowMs: 60_000 },
    'agent-approval': { maxAttempts: 20, windowMs: 60_000 },
    'voice-token': { maxAttempts: 12, windowMs: 60_000 },
    'voice-input-token': { maxAttempts: 12, windowMs: 60_000 }
};