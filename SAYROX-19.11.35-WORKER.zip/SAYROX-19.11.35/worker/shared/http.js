"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.MAX_CHAT_BODY_BYTES = void 0;
exports.json = json;
exports.text = text;
exports.safeUrl = safeUrl;
exports.securityHeaders = securityHeaders;
exports.readJson = readJson;
exports.normalizeMessages = normalizeMessages;
exports.messagesContainImages = messagesContainImages;
exports.messageTextContent = messageTextContent;
const constants_js_1 = __load("worker/shared/constants.js");
Object.defineProperty(exports, "MAX_CHAT_BODY_BYTES", { enumerable: true, get: function () { return constants_js_1.MAX_CHAT_BODY_BYTES; } });
function json(data, status = 200, headers = {}) {
    return new Response(JSON.stringify(data), { status, headers: { ...constants_js_1.JSON_HEADERS, ...headers } });
}
function text(value, max = 20_000) {
    return typeof value === 'string' ? value.replace(/\u0000/g, '').slice(0, max) : '';
}
function safeUrl(value) {
    try {
        const url = new URL(value);
        return ['https:', 'http:'].includes(url.protocol) ? url.href : '';
    }
    catch {
        return '';
    }
}
function securityHeaders(response, request) {
    const headers = new Headers(response.headers);
    headers.set('x-content-type-options', 'nosniff');
    headers.set('x-frame-options', 'DENY');
    headers.set('referrer-policy', 'strict-origin-when-cross-origin');
    headers.set('permissions-policy', 'camera=(), microphone=(self), geolocation=(), payment=()');
    headers.set('cross-origin-opener-policy', 'same-origin');
    const url = new URL(request.url);
    if (url.protocol === 'https:')
        headers.set('strict-transport-security', 'max-age=31536000; includeSubDomains');
    // Workers Static Assets does not consume the Pages `_headers` file. Preserve
    // the previous no-store rule for the application shell at the Worker layer.
    if (url.pathname === '/' || url.pathname === '/index.html')
        headers.set('cache-control', 'no-store');
    if (url.pathname === '/sw.js')
        headers.set('cache-control', 'no-cache');
    return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
}
async function readJson(request, maxBytes = constants_js_1.MAX_BODY) {
    const contentType = request.headers.get('content-type') || '';
    if (contentType && !/^application\/(?:[a-z0-9.+-]+\+)?json(?:\s*;|$)/i.test(contentType)) {
        throw new Error('نوع محتوای درخواست باید JSON باشد.');
    }
    const declared = Number(request.headers.get('content-length') || 0);
    if (Number.isFinite(declared) && declared > maxBytes)
        throw new Error('درخواست بزرگ‌تر از حد مجاز است.');
    if (!request.body)
        throw new Error('بدنه‌ی JSON معتبر نیست.');
    const reader = request.body.getReader();
    const chunks = [];
    let total = 0;
    try {
        while (true) {
            const { done, value } = await reader.read();
            if (done)
                break;
            total += value.byteLength;
            if (total > maxBytes) {
                try {
                    await reader.cancel();
                }
                catch { }
                throw new Error('درخواست بزرگ‌تر از حد مجاز است.');
            }
            chunks.push(value);
        }
    }
    finally {
        try {
            reader.releaseLock();
        }
        catch { }
    }
    const bytes = new Uint8Array(total);
    let offset = 0;
    for (const chunk of chunks) {
        bytes.set(chunk, offset);
        offset += chunk.byteLength;
    }
    try {
        const parsed = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes));
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed))
            throw new Error('invalid_json_shape');
        return parsed;
    }
    catch {
        throw new Error('بدنه‌ی JSON معتبر نیست.');
    }
}
const IMAGE_MIME_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp']);
const MAX_IMAGE_BYTES_PER_ITEM = 1_500_000;
const MAX_IMAGE_BYTES_PER_REQUEST = 5_000_000;
const DATA_IMAGE_PATTERN = /^data:(image\/(?:jpeg|png|webp));base64,([A-Za-z0-9+/]+={0,2})$/;
function normalizeImagePart(part, imageBudget) {
    const source = part?.image_url;
    const match = typeof source?.url === 'string' ? source.url.match(DATA_IMAGE_PATTERN) : null;
    if (part?.type !== 'image_url' || !match || !IMAGE_MIME_TYPES.has(match[1])) {
        throw new Error('قالب تصویر معتبر نیست؛ فقط تصویر JPEG، PNG یا WebP با داده‌ی درون‌خطی مجاز است.');
    }
    const encoded = match[2];
    if (encoded.length % 4 !== 0)
        throw new Error('داده‌ی تصویر کدگذاری معتبر ندارد.');
    const padding = encoded.endsWith('==') ? 2 : encoded.endsWith('=') ? 1 : 0;
    const bytes = Math.floor(encoded.length * 3 / 4) - padding;
    if (bytes <= 0 || bytes > MAX_IMAGE_BYTES_PER_ITEM)
        throw new Error('حجم هر تصویر پس از بهینه‌سازی باید حداکثر ۱٫۵ مگابایت باشد.');
    let header;
    try {
        header = atob(encoded.slice(0, 24));
    }
    catch {
        throw new Error('داده‌ی تصویر کدگذاری معتبر ندارد.');
    }
    const signature = Array.from(header, character => character.charCodeAt(0));
    const validSignature = match[1] === 'image/jpeg'
        ? signature[0] === 0xff && signature[1] === 0xd8 && signature[2] === 0xff
        : match[1] === 'image/png'
            ? signature.slice(0, 8).join(',') === '137,80,78,71,13,10,26,10'
            : signature.slice(0, 4).join(',') === '82,73,70,70' && signature.slice(8, 12).join(',') === '87,69,66,80';
    if (!validSignature)
        throw new Error('نوع تصویر با محتوای واقعی فایل هم‌خوانی ندارد.');
    imageBudget.bytes += bytes;
    imageBudget.count++;
    if (imageBudget.count > 4)
        throw new Error('در هر درخواست حداکثر ۴ تصویر مجاز است.');
    if (imageBudget.bytes > MAX_IMAGE_BYTES_PER_REQUEST)
        throw new Error('حجم مجموع تصویرها از سقف امن درخواست بیشتر است.');
    const detail = ['auto', 'low', 'high'].includes(source.detail) ? source.detail : 'high';
    return { type: 'image_url', image_url: { url: source.url, detail } };
}
function normalizeMessageContent(value, role, imageBudget) {
    const limit = role === 'system' ? 20_000 : 24_000;
    if (typeof value === 'string') {
        if (value.length > limit)
            throw new Error('نقش یا طول متن یکی از پیام‌ها معتبر نیست.');
        const content = text(value, limit).trim();
        if (!content)
            throw new Error('نقش یا متن یکی از پیام‌ها معتبر نیست.');
        return content;
    }
    if (!Array.isArray(value) || role !== 'user' || value.length < 1 || value.length > 5) {
        throw new Error('ساختار محتوای یکی از پیام‌ها معتبر نیست.');
    }
    const parts = [];
    let textChars = 0, hasImage = false;
    for (const part of value) {
        if (part?.type === 'text') {
            if (typeof part.text !== 'string' || part.text.length > limit)
                throw new Error('متن یکی از بخش‌های تصویر معتبر نیست.');
            const content = text(part.text, limit).trim();
            if (content) {
                textChars += content.length;
                parts.push({ type: 'text', text: content });
            }
        }
        else if (part?.type === 'image_url') {
            parts.push(normalizeImagePart(part, imageBudget));
            hasImage = true;
        }
        else
            throw new Error('نوع یکی از بخش‌های پیام پشتیبانی نمی‌شود.');
    }
    if (textChars > limit || !parts.length || !hasImage)
        throw new Error('محتوای چندرسانه‌ای پیام معتبر نیست.');
    return parts;
}
function normalizeMessages(value) {
    if (!Array.isArray(value) || value.length < 1 || value.length > constants_js_1.MAX_MESSAGES)
        throw new Error('تعداد پیام‌ها معتبر نیست.');
    const imageBudget = { count: 0, bytes: 0 };
    return value.map(item => {
        const role = ['user', 'assistant'].includes(item?.role) ? item.role : null;
        if (!role)
            throw new Error('نقش یا متن یکی از پیام‌ها معتبر نیست.');
        const content = normalizeMessageContent(item.content, role, imageBudget);
        return { role, content };
    });
}
function messagesContainImages(messages) {
    return Array.isArray(messages) && messages.some(message => Array.isArray(message?.content) && message.content.some(part => part?.type === 'image_url'));
}
function messageTextContent(content) {
    if (typeof content === 'string')
        return content;
    if (!Array.isArray(content))
        return '';
    return content.filter(part => part?.type === 'text' && typeof part.text === 'string').map(part => part.text).join(' ').trim();
}
