# SAYROX 19.11.36

## Deploy wiring repair — Update 17

این نسخه اتصال داخلی Sandbox را از تنظیم دستی Dashboard به منبع اصلی پیکربندی Wrangler منتقل می‌کند. Worker اصلی در `wrangler.jsonc` اکنون Service Binding دقیق `CODE_SANDBOX -> sayrox-code-sandbox-preview` را تعریف می‌کند؛ Worker مقصد همچنان خصوصی (`workers_dev=false`) است و همان Durable Object/SQLite، کلاس، Container و Dockerfile قبلی را نگه می‌دارد. هیچ Worker، DO class، Namespace، جدول یا D1 جدید ساخته نشده است.

یک Guard مشترک `scripts/check-deploy-wiring.mjs` نیز پیش از Deploy، Service Binding، پنج Durable Object خارجی، نام Workerهای مقصد، خصوصی‌بودن Sandbox و قرارداد Secretهای دو سمت را کنترل می‌کند. این کنترل در تست‌ها و Deploy Kit اجرا می‌شود و اگر Binding حذف یا به Worker اشتباه متصل شود، انتشار متوقف خواهد شد.

مقادیر Secret فقط در Cloudflare می‌مانند: `CODE_SANDBOX_INTERNAL_SECRET` در Worker اصلی و `SAYROX_INTERNAL_SECRET` در Worker Sandbox باید دقیقاً یکسان باشند و حداقل ۳۲ نویسه داشته باشند. خود Binding در Wrangler مدیریت می‌شود و نباید دوباره به‌صورت دستی ساخته شود.

توجه: Dry-run Wrangler کد Worker را Bundle و اعتبارسنجی می‌کند، اما ساخت/Push واقعی Docker image فقط در Deploy کامل Container انجام می‌شود. Cloudflare اعلام می‌کند Worker پیش از پردازش image فعال می‌شود و این عملیات تراکنشی نیست؛ بنابراین Deploy Kit ترتیب Sandbox را پیش از Worker اصلی حفظ می‌کند و در شکست Sandbox، انتشار Worker اصلی را متوقف می‌کند.

جزئیات: [`docs/RELEASE-19.11.36.md`](docs/RELEASE-19.11.36.md).

## قواعد انتشار

- پیش از هر Deploy، `npm test`، Build، `verify:dev` و `npm run check:sandbox-deploy` باید موفق شوند.
- Deploy Kit هر شش Worker موجود را ابتدا Dry Run می‌کند و فقط پس از موفقیت همهٔ Dry Runها وارد مرحلهٔ انتشار می‌شود.
- `SAYROX_APP_ORIGIN` باید در Workers Builds به Origin واقعی HTTPS Worker اصلی تنظیم شود. هیچ Origin نمونه‌ای را به Production نبرید.
- هیچ Secret، فایل `.env` یا کلید API را در ZIP یا GitHub قرار ندهید.
- برای Rollback، سازگاری Container را حفظ کنید؛ `max_instances` را دوباره به سیاست `durable_object` اضافه نکنید.

## معماری

هیچ Worker، Agent، Provider، API، Tool Loop، Durable Object class، Namespace، Secret، جدول، migration یا D1 جدیدی ایجاد نشده است؛ Service Binding موجود `CODE_SANDBOX` فقط از تنظیم دستی به Wrangler منتقل شده است.
