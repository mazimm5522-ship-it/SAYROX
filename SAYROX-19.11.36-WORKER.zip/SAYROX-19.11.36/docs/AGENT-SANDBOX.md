# SAYROX 19.11.18 — محیط اجرای ایزوله Python

## هدف و مرز نسخه

Main Agent فقط وقتی اجرای Python را پیشنهاد/درخواست می‌کند که کاربر صریحاً بخواهد کد اجرا شود و سپس کارت تأیید عملیات حساس را تأیید کند. نوشتن، اصلاح یا توضیح کد به‌تنهایی Sandbox را فعال نمی‌کند.

این پیاده‌سازی فقط Python 3.13 و کتابخانه استاندارد را فراهم می‌کند. نصب پکیج، اجرای JavaScript، انتقال باینری فایل، اتصال اینترنت و دسترسی به Secretهای برنامه پشتیبانی نمی‌شود. از نسخهٔ 19.11.24، در صورت انتخاب صریح Agent و پس از کارت تأیید اجرای Python، حداکثر دو متن استخراج‌شده از پیوست‌های فعلی می‌توانند به‌صورت فایل متنی UTF-8 وارد workspace موقت همان Job شوند؛ این قابلیت، آپلود باینری یا دسترسی به File Library نیست.

## معماری

```text
Chat UI / Static Assets
  └─ SAYROX Worker: sayrox
      └─ Agent: execute_python (فقط با نیت صریح)
          └─ کارت تأیید رمزنگاری‌شده و یک‌بارمصرف
              └─ Service Binding خصوصی: CODE_SANDBOX
                  └─ sayrox-code-sandbox-preview Worker
                      └─ Durable Object اختصاصی همان Job
                          └─ Cloudflare Container / Linux microVM
                              └─ Python 3.13 بدون اینترنت
```

- اجرای کد در Worker اصلی `sayrox` انجام نمی‌شود. انتقال متن پیوست نیز تنها وقتی در دسترس است که Service Binding و دو Secret مشترک قبلی مطابق راهنمای پایین پیکربندی باشند.
- Service Binding داخلی است؛ Worker Sandbox برای دسترسی عمومی از `workers.dev` فعال نشده است (`workers_dev: false`).
- درخواست داخلی با HMAC-SHA-256 روی timestamp و متن دقیق body امضا می‌شود. زمان اعتبار امضا حداکثر ۶۰ ثانیه است. Worker Sandbox علاوه بر امضا، نام فایل، تعداد، اندازهٔ نویسه و بایت UTF-8 و فیلدهای مجاز payload را مستقلاً کنترل می‌کند.
- `jobId` برای هر اجرای Agent تازه است و Durable Object هر Job فقط یک بار اجرا را claim می‌کند.
- نشانگر ضدبازپخش در storage داخلی همان Durable Object ذخیره و با Alarm پاک می‌شود؛ SQLite داخلی Cloudflare Durable Object است و **Cloudflare D1 نیست**.
- Container برای هر Job مجزا است، از instance نوع `lite` استفاده می‌کند و `enableInternet: false` دارد. هیچ Binding برنامه، Secret، کلید API یا Token به Container داده نمی‌شود. کد و در صورت وجود، حداکثر دو متن پیوست انتخاب‌شده از stdin به‌صورت JSON امضاشده می‌رسند؛ فایل‌های متنی با نام ثابت `document_1.txt` / `document_2.txt` در `/workspace/input/` ساخته می‌شوند. نام فایل ورودی هرگز به مسیر سیستم‌فایل تبدیل نمی‌شود.
- فقط متن انتخاب‌شده و استخراج‌شده می‌تواند به Sandbox برسد؛ باینری، تصاویر تعبیه‌شده، ماکرو/VBA و فرمول اجرایی فرستاده یا اجرا نمی‌شوند. دستورهای داخل سند دادهٔ غیرقابل‌اعتماد هستند. خروجی برنامه نیز فقط به‌صورت متن محدود نمایش داده می‌شود؛ به‌عنوان دستور یا HTML اجرا نمی‌شود.

## محدودیت‌های اجرا

| کنترل | مقدار |
|---|---:|
| زبان و نسخه | Python 3.13 |
| کتابخانه‌ها | Standard Library؛ نصب پکیج غیرفعال |
| حجم کد | حداکثر ۸٬۰۰۰ نویسه و ۱۲٬۰۰۰ بایت UTF-8 |
| تعداد فایل متنی | حداکثر ۲ سند انتخاب‌شده |
| متن هر فایل | حداکثر ۶۰٬۰۰۰ نویسه |
| مجموع متن فایل‌ها | حداکثر ۱۰۰٬۰۰۰ نویسه و ۳۰۰٬۰۰۰ بایت UTF-8 |
| درخواست داخلی امضاشده | حداکثر ۳۶۰٬۰۰۰ بایت |
| Container | نوع `lite`؛ ۲۵۶ MiB RAM، ۱/۱۶ vCPU و ۲GB دیسک |
| سقف هم‌زمانی | سقف اختصاصی در Wrangler تعریف نشده؛ تابع محدودیت حساب Cloudflare و سیاست `durable_object` است |
| مهلت اجرا | ۸ ثانیه؛ سپس TERM و بعد از ۲ ثانیه KILL |
| CPU | RLIMIT_CPU برابر ۷ ثانیه (hard limit برابر ۸) |
| حافظه فرایند | RLIMIT_AS برابر ۲۵۶ MiB |
| اندازه فایل | RLIMIT_FSIZE برابر ۱ MiB |
| descriptor فایل | حداکثر ۳۲ |
| فرایند برای UID غیرریشه | RLIMIT_NPROC برابر ۱۶ |
| مجموع stdout و stderr | حداکثر ۲۴٬۰۰۰ بایت |
| اینترنت خروجی | خاموش |
| کاربر داخل Container | غیرریشه، UID برابر ۱۰۰۰۱ |

این کنترل‌ها دفاع چندلایه هستند و تضمین نبود همه آسیب‌پذیری‌های احتمالی نرم‌افزار ناشناس نیستند. `max_instances` برای سیاست `durable_object` قابل تنظیم نیست؛ پس عدد ۱۰ سقف اعمال‌شدهٔ این نسخه نیست. پیش از فعال‌سازی باید محدودیت مصرف و هزینه در Preview بررسی شود.

## پیش‌نیازها و استقرار

۱. حساب Cloudflare باید روی طرح واجد شرایط **Workers Paid** باشد؛ Cloudflare Containers در طرح Workers Paid ارائه می‌شود.
۲. محیط Deploy باید Docker یا Docker-compatible engine داشته باشد. اگر Worker Builds استفاده می‌شود، دستور Deploy باید واقعاً `wrangler deploy` را اجرا کند تا image منتشر و rollout شروع شود؛ Upload یک Worker Version به‌تنهایی image را مستقر نمی‌کند.
۳. از ریشه پروژه، بعد از آماده‌کردن Wrangler، اجرا کن:

```bash
npm run deploy:sandbox
```

۴. در Worker `sayrox-code-sandbox-preview`، Secret با نام `SAYROX_INTERNAL_SECRET` و حداقل ۳۲ نویسه ثبت کن.
۵. Service Binding از قبل در `wrangler.jsonc` نسخهٔ 19.11.36 تعریف شده است: `CODE_SANDBOX` → `sayrox-code-sandbox-preview`. آن را در Dashboard دوباره نساز؛ Deploy Kit آن را به‌عنوان منبع اصلی پیکربندی اعمال می‌کند.
۶. در Worker اصلی `sayrox`، Secret با نام `CODE_SANDBOX_INTERNAL_SECRET` و دقیقاً همان مقدار ثبت کن. هر دو Secret باید حداقل ۳۲ نویسه باشند.
۷. Worker اصلی را با Build و Deploy کامل منتشر کن تا Binding در نسخهٔ فعال قرار گیرد.
۸. `/api/health` باید فقط وضعیت Boolean `codeSandbox` را `true` اعلام کند؛ خود Secret هیچ‌وقت نباید بازگردانده شود.

## آزمون‌های پذیرش

- «کد Python را اجرا کن: `print(6 * 7)`» باید کارت تأیید نشان دهد و قبل از کلیک هیچ اجرا رخ ندهد.
- پس از تأیید، خروجی `42` و exit code صفر دریافت شود.
- با لغو کارت نباید هیچ Container اجرا شود.
- حلقه بی‌نهایت باید در سقف زمان متوقف شود.
- خروجی حجیم باید در سقف خروجی متوقف شود.
- import کتابخانه نصب‌نشده باید خطای معمول Python بدهد؛ اینترنت و pip در دسترس نیستند.
- پیام «این کد را توضیح بده» نباید ابزار اجرا را فعال کند.

## خاموش‌سازی و بازگشت

برای خاموش‌کردن قابلیت، Service Binding `CODE_SANDBOX` را از Worker اصلی حذف یا Secret `CODE_SANDBOX_INTERNAL_SECRET` را بردار؛ Main Agent در صورت نبود هرکدام ابزار را فعال نمی‌کند و گفتگوی عادی ادامه می‌یابد. برای بازگشت کامل، نسخه قبلی Worker اصلی را دوباره Deploy کن و Worker Sandbox را پس از پایان درخواست‌های فعال جداگانه حذف کن.

## محدودیت ممیزی

تست‌های محلی قرارداد، اعتبارسنجی ورودی، امضای داخلی، کنترل حجم خروجی، عدم اینترنت، تنظیمات Container، مسیر تأیید و یک‌بارمصرف بودن را بررسی می‌کنند. در این محیط Docker Engine و دسترسی انتشار Cloudflare Container موجود نیست؛ بنابراین image واقعی ساخته یا مستقر نشده و اجرای Python در microVM زنده تأیید نشده است. قابلیت تا تکمیل استقرار، Binding و Secret عمداً خاموش می‌ماند.


## سازگاری Container با Wrangler (نسخهٔ 19.11.35)

Worker موجود Sandbox از `scheduling_policy: "durable_object"` استفاده می‌کند تا Durable Object هنگام `ctx.container.start()` تصویر نام‌گذاری‌شده را انتخاب کند. در این سیاست، فیلد `max_instances` پشتیبانی نمی‌شود و Wrangler آن را رد می‌کند؛ بنابراین در `sandbox-worker/wrangler.jsonc` نباید قرار بگیرد. این گزینه فقط در سیاست `default` معتبر است و تغییر سیاست برای برنامهٔ موجود تصمیم مهاجرتی جداگانه می‌خواهد. در سیاست فعلی، تعداد instanceها تابع محدودیت حساب Cloudflare است؛ برای سقف اختصاصی باید کنترل هم‌زمانی در سطح برنامه طراحی و تست شود، نه با افزودن فیلد ناسازگار به Wrangler.


## اتصال منبع‌محور Wrangler (19.11.36)

Service Binding با نام `CODE_SANDBOX` اکنون در `wrangler.jsonc` Worker اصلی ثبت شده است؛ این Binding به Worker موجود `sayrox-code-sandbox-preview` متصل می‌شود. ساخت دستی یا تعریف Binding تکراری در Dashboard لازم نیست. `scripts/check-deploy-wiring.mjs` پیش از Deploy، این اتصال و پنج Durable Object خارجی را کنترل می‌کند. رازها همچنان باید جداگانه در Cloudflare ثبت شوند.
