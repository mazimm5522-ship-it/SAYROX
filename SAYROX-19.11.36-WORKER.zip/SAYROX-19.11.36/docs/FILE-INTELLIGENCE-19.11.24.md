# SAYROX 19.11.24 — Advanced File Intelligence (Update 5)

## دامنهٔ تغییر

این انتشار موتور جدید فایل، Parser جدید Office، OCR جدید، یا Sandbox موازی نمی‌سازد. مسیرهای موجود `SayroxDocuments`، `SayroxPdfText`، `SayroxPdfOcr`، Agent File Tools، `create_file` و Python Sandbox فعلی تقویت/متصل شده‌اند.

## پیوست Office در چت

- پیوست DOCX و PPTX در همان Composer و مسیر مشترک اسناد اضافه شد؛ سقف هر پیام دو سند و سقف هر فایل ۲۰ MiB است. محدودیت‌های قبلی PDF/Excel/ZIP حفظ شده‌اند.
- `site/src/features/chat/office-input.js` فقط adapter است و متن را با `SayroxDocuments.readDocx` یا `readPptx` موجود استخراج می‌کند؛ هیچ OOXML parser یا ZIP reader موازی ایجاد نمی‌کند.
- متن استخراج‌شده حداکثر ۶۰٬۰۰۰ نویسه به زمینهٔ زودگذر همان نشست اضافه می‌شود؛ متن خام در Local Storage/فرادادهٔ پایدار پیام کپی نمی‌شود. فایل اصلی برای تحلیل به Worker یا Provider ارسال نمی‌شود.
- در Worker، `kind: office` و پسوند DOCX/PPTX حفظ و متن مثل سایر اسناد پیوست به‌عنوان دادهٔ بیرونی و غیرقابل‌اعتماد علامت‌گذاری می‌شود.

## OCR خودکار PDF اسکن‌شده

- مسیر چت نخست از `SayroxPdfText.extractPdfText` موجود استفاده می‌کند. فقط وقتی متن خالی باشد یا موتور، PDF تصویرمحور/اسکن‌شده را تشخیص دهد، `SayroxPdfOcr.recognizePdf` موجود فراخوانی می‌شود. خطاهای غیرمرتبط بی‌دلیل به OCR تبدیل نمی‌شوند.
- OCR در مرورگر و با کتابخانه‌های موجود PDF.js/Tesseract.js و زبان `fas+eng` اجرا می‌شود. فایل PDF باینری به Worker/Provider ارسال نمی‌شود؛ فقط متن استخراج‌شده پس از تأیید ضمنیِ انتخاب و ارسال فایل به چت منتقل می‌شود. بارگیری کتابخانه از CDN نیازمند دسترسی شبکه است.
- سقف‌های OCR موجود حفظ شده‌اند: حداکثر ۲۰ صفحه، ۴٬۰۰۰٬۰۰۰ پیکسل برای هر صفحه و ۲۴٬۰۰۰٬۰۰۰ پیکسل مجموع؛ متن نهایی پیوست چت حداکثر ۶۰٬۰۰۰ نویسه است. پیشرفت OCR روی Composer گزارش می‌شود.

## ساخت PPTX با Agent

- `create_file` اکنون فرمت `pptx` را در قرارداد ابزار مجاز می‌داند و همان `SayroxDocuments.createPptx` محلی در مرورگر فایل را می‌سازد. هر Heading سطح اول یا بلوک اسلاید طبق قرارداد موجود به اسلاید تبدیل می‌شود.
- دانلود در مرورگر انجام می‌شود؛ سرور فایل خروجی را ذخیره نمی‌کند. محتوا و اندازهٔ خروجی محدود می‌ماند.

## اتصال متنی به Python Sandbox موجود

- `execute_python` فقط وقتی کاربر صریحاً اجرای کد را درخواست کرده و کارت تأیید را قبول کرده باشد فعال می‌شود. مدل ابتدا باید با `inspect_attached_files` فایل‌ها را ببیند و index دقیق را انتخاب کند.
- حداکثر دو فایل و مجموعاً ۱۰۰٬۰۰۰ نویسهٔ متن استخراج‌شده، هر فایل حداکثر ۶۰٬۰۰۰ نویسه، به‌صورت UTF-8 منتقل می‌شود. باینری، تصاویر تعبیه‌شده، ماکرو، VBA و فرمول اجرایی انتقال یا اجرا نمی‌شوند.
- Sandbox فعلی payload امضاشدهٔ HMAC را بررسی و دوباره اندازه/ساختار فایل‌ها را اعتبارسنجی می‌کند؛ فایل‌ها با نام‌های ثابت `document_1.txt` و `document_2.txt` در `/workspace/input/` نوشته می‌شوند. نام فایل کاربر به مسیر سیستم‌فایل تبدیل نمی‌شود.
- فضای کار، Container یک‌بارمصرف همان Job، محدودیت منابع، بدون اینترنت، Python 3.13 و SQLite داخلی Durable Object موجود حفظ می‌شوند.
- این اتصال فقط زمانی فعال است که Service Binding موجود `CODE_SANDBOX` و Secretهای مشترک `CODE_SANDBOX_INTERNAL_SECRET` / `SAYROX_INTERNAL_SECRET` طبق `docs/AGENT-SANDBOX.md` تنظیم شده باشند. این انتشار هیچ Binding جدیدی به `wrangler.jsonc` اضافه نمی‌کند.

## فایل‌های اصلی تغییرکرده

- `site/src/features/chat/office-input.js` (adapter تازه، نه Parser تازه)
- `site/src/features/chat/pdf-input.js` (fallback به OCR موجود)
- `app/01-core-state.js`, `app/04-message-rendering.js`, `app/05-send-message.js`, `app/09-composer-menus.js` (اتصال Composer، metadata و دانلود)
- `worker/agent/file-tools.js`, `worker/providers/chat.js`, `worker/agent/code-execution-tools.js` (قرارداد Agent و انتقال انتخابی متن)
- `sandbox-worker/src/security.mjs`, `sandbox-worker/src/index.js` (اعتبارسنجی و نوشتن متن در workspace موجود)

## تست و محدودیت استقرار

- مجموعهٔ محلی: ۱۷۳ تست از ۱۷۳ تست موفق؛ این تعداد پس از افزودن تست نیت صریح PowerPoint ممکن است افزایش یابد.
- `build:app` و `build:worker` اجرا شدند؛ `site/src/app.js` و `site/_worker.js` خروجی Build هستند، نه فایل‌های مرجع. `verify:dev` باید پس از Build اجرا شود.
- آزمون OCR با Stub انجام شده؛ کیفیت و سرعت OCR زنده روی PDFهای واقعی و CDN در این محیط سنجیده نشده است.
- اجرای فایل در Cloudflare Container واقعی در این محیط قابل تأیید نیست. برای انتقال فایل به Python، Worker Sandbox موجود نیز باید با نسخهٔ جدید Deploy شود و Service Binding/Secretهای قبلیِ پروژه فعال باشند.
- هیچ D1، Durable Object class، Namespace، migration، Secret یا Binding جدیدی به تنظیمات Wrangler اضافه نشده است. `CodeSandbox` همان DO/SQLite داخلی خودش را نگه می‌دارد.
- انتشار Cloudflare از این محیط انجام نشده است. Origin واقعی `SAYROX_APP_ORIGIN` باید توسط مالک حساب تنظیم شود.

## Rollback

برای بازگشت کد، ZIP کامل 19.11.23 را نگه دار و طبق `docs/ROLLBACK.md` Worker اصلی، Static Assets و Sandbox موجود را به نسخهٔ سازگار برگردان. هیچ DO/Namespace/Storage/جدول/داده‌ای را حذف نکن؛ این نسخه schema یا migration ذخیره‌سازی جدیدی اضافه نکرده است.


## وضعیت اتصال در نسخهٔ 19.11.36

یادداشت تاریخی بالا مربوط به زمان انتشار 19.11.24 است. در نسخهٔ 19.11.36، Service Binding همان قابلیت موجود `CODE_SANDBOX` در Wrangler Worker اصلی ثبت شده است تا از پیکربندی دستی خارج شود. هیچ Worker یا Durable Object جدیدی ایجاد نشده؛ Secretهای مشترک همچنان باید در Cloudflare ثبت شوند.
