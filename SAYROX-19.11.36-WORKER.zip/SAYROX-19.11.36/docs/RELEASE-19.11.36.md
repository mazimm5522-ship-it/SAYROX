# SAYROX 19.11.36 — Deployment Wiring Repair

## نقص قطعی پیدا شده

Worker اصلی در کد از `env.CODE_SANDBOX.fetch()` استفاده می‌کرد و Sandbox در Worker مستقلی با نام `sayrox-code-sandbox-preview` منتشر می‌شد، اما فایل اصلی `wrangler.jsonc` Service Binding متناظر را نداشت. راهنمای قبلی از کاربر می‌خواست Binding را دستی در Dashboard ثبت کند؛ در نتیجه پیکربندی واقعی با منبع کنترل‌شدهٔ Wrangler یکی نبود و Deploy ممکن بود Binding را اعمال نکند یا در Worker فعال در دسترس نباشد.

## اصلاح

- Service Binding در `wrangler.jsonc` Worker اصلی تعریف شد: `CODE_SANDBOX` → `sayrox-code-sandbox-preview`.
- همان پیکربندی به GitHub Deploy Kit نیز منتقل شد.
- Sandbox همچنان `workers_dev=false`، همان کلاس `CodeSandbox`، SQLite، `images.python` و scheduling policy `durable_object` را نگه می‌دارد.
- هیچ Service Worker، DO class، Namespace، migration، جدول، Worker یا D1 جدیدی ساخته نشده؛ فقط Service Binding موجود و مورد انتظار، منبع‌محور شد.
- Secretها همچنان دستی و محرمانه‌اند: `CODE_SANDBOX_INTERNAL_SECRET` در `sayrox` و `SAYROX_INTERNAL_SECRET` در `sayrox-code-sandbox-preview` باید مقدار یکسان (حداقل ۳۲ نویسه) داشته باشند.

## محافظ و تست

`check-deploy-wiring.mjs` کنترل می‌کند که پنج DO خارجی و Service Binding Sandbox به Worker و کلاس درست اشاره کنند، Sandbox خصوصی بماند، و کد سمت تماس‌گیرنده/مقصد، Secret nameهای مورد انتظار را مصرف کند. تست منفی نشان می‌دهد حذف Service Binding قبل از Wrangler انتشار را متوقف می‌کند.

## ترتیب و محدودیت Deploy Container

Deploy Kit ترتیب قبلی را حفظ می‌کند: Auth، Billing، Usage، Tasks، Sandbox و در آخر Main Worker. بنابراین اگر Deploy کامل Sandbox با شکست خارج شود، اسکریپت به Main Worker نمی‌رسد. با این حال، طبق مستند Cloudflare، `wrangler deploy` ابتدا Worker را فعال می‌کند و سپس image را build/push می‌کند؛ این مراحل تراکنشی نیستند. `--dry-run` هم image را build/push نمی‌کند. پس سبز بودن Dry-run به‌تنهایی ساخت image زنده را تضمین نمی‌کند.

## اعتبارسنجی این بسته

- آزمون کامل و Build کد در محیط محلی اجرا می‌شوند؛ خروجی واقعی در گزارش تحویل ثبت می‌شود.
- `npm install`، Wrangler CLI و Cloudflare API ممکن است در این محیط به‌دلیل نبود دسترسی رجیستری/حساب اجرا نشوند؛ در آن صورت Dry-run واقعی یا انتشار زنده ادعا نمی‌شود.
- بعد از Deploy، `/api/health` باید `providers.codeSandbox: true` نشان دهد. اگر `false` باشد، Binding اعمال نشده یا Secret سمت اصلی کم است؛ اجرای Python تا ثبت هر دو Secret و تست `print(6 * 7)` فعال محسوب نمی‌شود.

## Rollback

برای بازگشت کد محصول، Worker اصلی را به نسخهٔ قبلی برگردان؛ Service Binding `CODE_SANDBOX` را فقط اگر واقعاً نیاز به خاموش‌کردن قابلیت داری از Wrangler config حذف کن. Worker Sandbox، Namespace یا SQLite را برای Rollback حذف نکن.
