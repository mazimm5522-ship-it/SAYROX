// Validate the complete Worker-to-Worker deployment wiring before Wrangler is invoked.
import { readFileSync, existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(process.argv[2] || path.dirname(fileURLToPath(import.meta.url)) + '/..');
const stop = message => { console.error(`deploy wiring blocked: ${message}`); process.exit(1); };
const readJson = relative => {
  const full = path.join(root, relative);
  if (!existsSync(full)) stop(`required config is missing: ${relative}`);
  try { return JSON.parse(readFileSync(full, 'utf8')); }
  catch { stop(`${relative} must be valid JSON for deployment wiring validation.`); }
};

const main = readJson('wrangler.jsonc');
const sandbox = readJson('sandbox-worker/wrangler.jsonc');
if (main.name !== 'sayrox') stop('main Worker name must remain sayrox.');
if (sandbox.name !== 'sayrox-code-sandbox-preview' || sandbox.workers_dev !== false) {
  stop('Sandbox target must remain sayrox-code-sandbox-preview with workers_dev=false.');
}

const serviceBindings = Array.isArray(main.services) ? main.services : [];
const sandboxBindings = serviceBindings.filter(item => item?.binding === 'CODE_SANDBOX');
if (sandboxBindings.length !== 1 || sandboxBindings[0].service !== sandbox.name) {
  stop('main wrangler.jsonc must declare exactly one Service Binding CODE_SANDBOX -> sayrox-code-sandbox-preview.');
}

const expectedDo = [
  ['AUTH_ACCOUNTS', 'AccountObject', 'sayrox-auth-storage'],
  ['AUTH_RATE_LIMITER', 'AuthRateLimiter', 'sayrox-auth-storage'],
  ['BILLING_ACCOUNT', 'BillingAccountObject', 'sayrox-billing-storage'],
  ['USAGE_ACCOUNT', 'UsageAccountObject', 'sayrox-usage-storage'],
  ['TASKS_ACCOUNT', 'TaskAccountObject', 'sayrox-tasks-storage'],
];
const bindings = Array.isArray(main.durable_objects?.bindings) ? main.durable_objects.bindings : [];
const names = bindings.map(item => item?.name);
if (new Set(names).size !== names.length) stop('main Worker has duplicate Durable Object binding names.');
for (const [binding, className, scriptName] of expectedDo) {
  const matches = bindings.filter(item => item?.name === binding);
  if (matches.length !== 1 || matches[0].class_name !== className || matches[0].script_name !== scriptName) {
    stop(`Durable Object binding ${binding} must target ${className} in ${scriptName}.`);
  }
}

const mainSourcePath = path.join(root, 'site/_worker.js');
if (!existsSync(mainSourcePath)) stop('built main Worker site/_worker.js is missing.');
const mainSource = readFileSync(mainSourcePath, 'utf8');
if (!/env(?:\?\.)?\.CODE_SANDBOX\b/.test(mainSource) || !/CODE_SANDBOX_INTERNAL_SECRET/.test(mainSource)) {
  stop('main Worker source must use CODE_SANDBOX and its matching internal Secret.');
}
const sandboxSource = readFileSync(path.join(root, 'sandbox-worker/src/index.js'), 'utf8');
if (!/SAYROX_INTERNAL_SECRET/.test(sandboxSource) || !/env\.CODE_SANDBOX\b/.test(sandboxSource)) {
  stop('Sandbox Worker must verify SAYROX_INTERNAL_SECRET and use its internal CODE_SANDBOX namespace.');
}

console.log('Deployment wiring OK — all external Durable Object bindings and private CODE_SANDBOX Service Binding match their deployed Worker targets.');
