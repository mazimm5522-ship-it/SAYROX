import assert from 'node:assert/strict';
import { readFile, writeFile, mkdir, mkdtemp, rm } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { join } from 'node:path';
import { tmpdir } from 'node:os';

const root = fileURLToPath(new URL('..', import.meta.url));
const read = path => readFile(join(root, path), 'utf8');
const run = (script, args = []) => spawnSync(process.execPath, [join(root, script), ...args], { cwd: root, encoding: 'utf8' });

const pkg = JSON.parse(await read('package.json'));
const quota = JSON.parse(await read('docs/quota-policy.json'));
const sw = await read('site/sw.js');
const about = await read('site/src/features/settings/pages/other.js');
const readme = await read('README.md');
const infra = await read('docs/INFRASTRUCTURE.md');
const ignore = await read('.gitignore');
const taskConfig = await read('tasks-worker/wrangler.jsonc');
const privateWorkerConfigs = ['auth-worker/wrangler.jsonc', 'billing-worker/wrangler.jsonc', 'usage-worker/wrangler.jsonc', 'tasks-worker/wrangler.jsonc', 'sandbox-worker/wrangler.jsonc'];
const mainConfig = JSON.parse((await read('wrangler.jsonc')).replace(/^\s*\/\*[\s\S]*?\*\//gm, '').replace(/^\s*\/\/.*$/gm, ''));
const passwordSource = await read('worker/security/passwords.js');
const assetIgnore = await read('site/.assetsignore');

assert.equal(pkg.version, '19.11.36', 'release version should be explicit');
assert.equal(quota.version, pkg.version, 'quota contract version must match package');
assert.ok(sw.includes(`sayrox-shell-v${pkg.version}`), 'service-worker cache must be versioned with package');
assert.ok(about.includes(`>${pkg.version}<`), 'About page must display package version');
assert.ok(readme.startsWith(`# SAYROX ${pkg.version}`), 'README release title must match package');
assert.ok(mainConfig.compatibility_date >= '2026-08-04', 'Worker compatibility date must keep native node:crypto enabled by default');
assert.match(passwordSource, /import\('node:crypto'\)/, 'password KDF must use native node:crypto PBKDF2');
assert.doesNotMatch(passwordSource, /crypto\.subtle\.deriveBits/, 'password KDF must not use the 100,000-round-limited Web Crypto PBKDF2 path');

for (const source of ['build-app.mjs', 'build-worker.mjs']) {
  const result = run(`scripts/${source}`, ['--check']);
  assert.equal(result.status, 0, `${source} output is in sync: ${result.stderr || result.stdout}`);
}

assert.match(ignore, /^\.dev\.vars\.\*$/m, 'local Cloudflare vars variants must be ignored');
assert.match(ignore, /^\.dev\.vars$/m, 'the local Cloudflare vars file must be ignored');
assert.match(ignore, /^\.env\.\*$/m, 'local env files must be ignored');
assert.match(ignore, /^!\.env\.example$/m, 'safe env template must remain committable');
assert.match(ignore, /^\*\.pem$/m, 'private key files must be ignored');

// The uploaded project intentionally has no D1 configuration or binding.
const wranglerFiles = ['wrangler.jsonc', 'auth-worker/wrangler.jsonc', 'usage-worker/wrangler.jsonc', 'billing-worker/wrangler.jsonc', 'tasks-worker/wrangler.jsonc', 'sandbox-worker/wrangler.jsonc'];
for (const path of wranglerFiles) assert.doesNotMatch(await read(path), /d1_databases/i, `${path} must not declare D1`);
for (const path of privateWorkerConfigs) {
  const config = JSON.parse((await read(path)).replace(/^\s*\/\*[\s\S]*?\*\//gm, '').replace(/^\s*\/\/.*$/gm, '').replace(/,\s*([}\]])/g, '$1'));
  assert.equal(config.workers_dev, false, `${path} must not expose an internal storage Worker on workers.dev`);
}
for (const path of ['worker', 'auth-worker/src', 'usage-worker/src', 'billing-worker/src', 'tasks-worker/src', 'sandbox-worker/src']) {
  const { readdir } = await import('node:fs/promises');
  const { extname } = await import('node:path');
  async function walk(dir) {
    const out = [];
    for (const entry of await readdir(join(root, dir), { withFileTypes: true })) {
      const child = join(dir, entry.name);
      if (entry.isDirectory()) out.push(...await walk(child));
      else if (['.js', '.mjs'].includes(extname(entry.name))) out.push(await read(child));
    }
    return out;
  }
  const sources = (await walk(path)).join('\n');
  assert.doesNotMatch(sources, /\bD1Database\b|env\.DB\b|\.d1_databases\b/i, `${path} must not access D1`);
}

assert.equal(mainConfig.name, 'sayrox');
assert.equal(mainConfig.keep_vars, true, 'dashboard-managed variables must survive subsequent Wrangler deploys');
assert.equal(mainConfig.main, './site/_worker.js');
assert.equal(mainConfig.assets.directory, './site');
assert.equal(mainConfig.assets.binding, 'ASSETS');
assert.equal(mainConfig.browser.binding, 'BROWSER', 'Browser Run binding must be declared in local Wrangler config');
assert.equal(mainConfig.assets.run_worker_first, true);
assert.equal(mainConfig.observability.redact_query_string, true, 'sensitive query parameters must be redacted from logs');

// The shared wiring guard must reject a missing/mispointed service binding.
const wiringFixture = await mkdtemp(join(tmpdir(), 'sayrox-wiring-guard-'));
try {
  await mkdir(join(wiringFixture, 'sandbox-worker'), { recursive: true });
  await mkdir(join(wiringFixture, 'site'), { recursive: true });
  const broken = structuredClone(mainConfig);
  broken.services = [];
  await writeFile(join(wiringFixture, 'wrangler.jsonc'), JSON.stringify(broken));
  await writeFile(join(wiringFixture, 'sandbox-worker/wrangler.jsonc'), JSON.stringify({ name: 'sayrox-code-sandbox-preview', workers_dev: false }));
  await writeFile(join(wiringFixture, 'site/_worker.js'), 'env.CODE_SANDBOX env.CODE_SANDBOX_INTERNAL_SECRET');
  await mkdir(join(wiringFixture, 'sandbox-worker/src'), { recursive: true });
  await writeFile(join(wiringFixture, 'sandbox-worker/src/index.js'), 'env.CODE_SANDBOX env.SAYROX_INTERNAL_SECRET');
  const guardPath = new URL('../scripts/check-deploy-wiring.mjs', import.meta.url);
  const invalidWiring = spawnSync(process.execPath, [guardPath.pathname, wiringFixture], { encoding: 'utf8' });
  assert.equal(invalidWiring.status, 1);
  assert.match(invalidWiring.stderr, /Service Binding CODE_SANDBOX/);
} finally {
  await rm(wiringFixture, { recursive: true, force: true });
}
assert.deepEqual(mainConfig.durable_objects.bindings.map(({ name, class_name, script_name }) => ({ name, class_name, script_name })), [
  { name: 'AUTH_ACCOUNTS', class_name: 'AccountObject', script_name: 'sayrox-auth-storage' },
  { name: 'AUTH_RATE_LIMITER', class_name: 'AuthRateLimiter', script_name: 'sayrox-auth-storage' },
  { name: 'BILLING_ACCOUNT', class_name: 'BillingAccountObject', script_name: 'sayrox-billing-storage' },
  { name: 'USAGE_ACCOUNT', class_name: 'UsageAccountObject', script_name: 'sayrox-usage-storage' },
  { name: 'TASKS_ACCOUNT', class_name: 'TaskAccountObject', script_name: 'sayrox-tasks-storage' },
]);
assert.deepEqual(mainConfig.services.filter(item => item.binding === 'CODE_SANDBOX'), [{ binding: 'CODE_SANDBOX', service: 'sayrox-code-sandbox-preview' }], 'main Worker must declare the private Sandbox Service Binding');
assert.doesNotMatch(JSON.stringify(mainConfig), /d1_databases/i, 'D1 remains forbidden');
assert.equal(run('scripts/check-deploy-wiring.mjs').status, 0, 'all Worker service and Durable Object bindings must resolve to the existing targets');
assert.match(assetIgnore, /^_worker\.js$/m);
assert.match(assetIgnore, /^_headers$/m);
assert.match(infra, /AUTH_ACCOUNTS[\s\S]*sayrox-auth-storage/);
assert.match(infra, /CODE_SANDBOX[\s\S]*sayrox-code-sandbox-preview/);
assert.match(pkg.scripts['predeploy:tasks'], /check:tasks-deploy/);
assert.match(pkg.scripts['predeploy:sandbox'], /check:sandbox-deploy/);
assert.match(pkg.scripts['check:sandbox-deploy'], /check-sandbox-deploy\.mjs/);
assert.match(pkg.scripts['deploy:billing'], /billing-worker\/wrangler\.jsonc/);
assert.match(pkg.scripts['deploy:sandbox'], /sandbox-worker\/wrangler\.jsonc/);
assert.match(infra, /CODE_SANDBOX[\s\S]*sayrox-code-sandbox-preview/);
assert.match(infra, /SAYROX_APP_ORIGIN/);

const guard = run('scripts/check-tasks-deploy.mjs');
if (/REPLACE|YOUR-/i.test(taskConfig)) {
  assert.notEqual(guard.status, 0, 'Tasks deploy must be blocked while APP_ORIGIN is a template');
  assert.match(`${guard.stdout}\n${guard.stderr}`, /APP_ORIGIN/);
} else {
  assert.equal(guard.status, 0, `configured Tasks origin should pass: ${guard.stderr || guard.stdout}`);
}

// Exercise both accepted and rejected deployment-origin forms without touching the real config.
const fixture = await mkdtemp(join(tmpdir(), 'sayrox-tasks-guard-'));
try {
  await mkdir(join(fixture, 'scripts'), { recursive: true });
  await mkdir(join(fixture, 'tasks-worker'), { recursive: true });
  await writeFile(join(fixture, 'scripts/check-tasks-deploy.mjs'), await read('scripts/check-tasks-deploy.mjs'));
for (const [origin, expected] of [
  ['https://sayrox.new-account.workers.dev', 0],
  ['http://sayrox.new-account.workers.dev', 1],
  ['https://sayrox.new-account.workers.dev/', 1],
  ['https://sayrox.new-account.workers.dev ', 1],
  ['https://sayrox.new-account.workers.dev:443', 1],
  ['https://sayrox.new-account.workers.dev?x=1', 1]
]) {
    await writeFile(join(fixture, 'tasks-worker/wrangler.jsonc'), JSON.stringify({ vars: { APP_ORIGIN: origin } }));
    const result = spawnSync(process.execPath, [join(fixture, 'scripts/check-tasks-deploy.mjs')], { encoding: 'utf8' });
    assert.equal(result.status, expected, `APP_ORIGIN validation for ${origin}: ${result.stderr || result.stdout}`);
  }
await writeFile(join(fixture, 'tasks-worker/wrangler.jsonc'), '{"vars":{"APP_ORIGIN":"https://one.workers.dev","APP_ORIGIN":"https://two.workers.dev"}}');
const duplicateOrigin = spawnSync(process.execPath, [join(fixture, 'scripts/check-tasks-deploy.mjs')], { encoding: 'utf8' });
assert.equal(duplicateOrigin.status, 1, 'duplicate APP_ORIGIN entries must block deployment');
} finally {
  await rm(fixture, { recursive: true, force: true });
}

console.log('Infrastructure tests passed: private storage Workers, Worker-first config, static assets, external DO bindings, secret ignore rules, no D1, and task-origin validation');
